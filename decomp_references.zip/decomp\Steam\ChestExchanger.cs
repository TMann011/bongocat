using System;
using System.Collections;
using BongoCat;
using BongoCat.Achievements;
using BongoCat.SteamJsonParser;
using Heathen.SteamworksIntegration;
using SteamTools;
using UnityEngine;

namespace Steam;

public class ChestExchanger : MonoBehaviour
{
	private static bool IsExchanging;

	[SerializeField]
	private SteamExchange _exchange;

	public void OpenChest(Action<int> callback)
	{
		StartCoroutine(ExchangeWhenReady(callback, 5));
	}

	private IEnumerator ExchangeWhenReady(Action<int> callback, int retry)
	{
		yield return new WaitUntil(() => !IsExchanging && Game.Inventory.Achievement_Token.GetTotalQuantity() > 0 && Game.Inventory.ManualToken.GetTotalQuantity() > 0);
		IsExchanging = true;
		_exchange.Exchange(delegate((bool, ItemDetail[]) res)
		{
			IsExchanging = false;
			if (!res.Item1)
			{
				if (retry <= 0)
				{
					Debug.Log("Chest Exchange failed after multiple retries, giving up!");
					callback?.Invoke(-1);
				}
				else
				{
					Debug.Log("Chest Exchange failed, retrying!");
					StartCoroutine(ExchangeWhenReady(callback, retry - 1));
				}
			}
			else
			{
				ItemDetail[] item = res.Item2;
				for (int i = 0; i < item.Length; i++)
				{
					ItemDetail itemDetail = item[i];
					if (!(itemDetail.Definition == Game.Inventory.Achievement_Token) && !(itemDetail.Definition == Game.Inventory.ManualToken) && !(itemDetail.Definition == Game.Inventory.Chest_Token) && !(itemDetail.Definition == Game.Inventory.Emote_Chest_Token))
					{
						AchievementStats.IncrementItems();
						callback?.Invoke(itemDetail.Definition.id);
					}
				}
				CatInventory.Instance.UpdateVisuals();
			}
		});
	}
}
