using BongoCat.Multiplayer;
using Heathen.SteamworksIntegration;
using Steam;
using TMPro;
using UnityEngine;

namespace BongoCat;

public class ShopItem : MonoBehaviour
{
	[SerializeField]
	private int _price;

	[SerializeField]
	private TMP_Text _priceText;

	[SerializeField]
	private bool _waitingForServer;

	[SerializeField]
	private NewItemPopup _newItemPopup;

	[SerializeField]
	private SteamMultiplayer _steamMultiplayer;

	[SerializeField]
	private bool _isEmoteChest;

	[SerializeField]
	private Shop _shop;

	[SerializeField]
	private ChestExchanger _chestExchanger;

	private void Awake()
	{
		_priceText.text = $"{_price}";
	}

	public void Buy()
	{
		StartBuy(chargePets: true);
	}

	public void BuyAsGift()
	{
		StartBuy(chargePets: false);
	}

	public bool TrySpendForGift()
	{
		return Pets.Instance.TrySpendPets(_price);
	}

	private void StartBuy(bool chargePets)
	{
		if ((!chargePets || Pets.Instance.CanSpendPets(_price)) && !_waitingForServer)
		{
			_waitingForServer = true;
			_shop.SetLoadingVisuals();
			_chestExchanger.OpenChest(delegate(int itemId)
			{
				Callback(itemId, chargePets);
			});
		}
	}

	private void Callback(int itemId, bool chargePets)
	{
		_waitingForServer = false;
		if (itemId != -1)
		{
			_shop.SetSuccessVisuals(success: true, showError: true, chargePets);
			if (chargePets)
			{
				Pets.Instance.TrySpendPets(_price);
			}
			_shop.ItemGotBought();
			_newItemPopup.ShowPopup(itemId);
			if (!_isEmoteChest && SettingsManager.Instance.AutoEquipDrops)
			{
				CatCosmetics.Instance.AutoEquipDrop(itemId);
			}
			SteamItemIdReference.Inst[itemId].OnItemUpdated?.Invoke();
		}
		else
		{
			_shop.SetSuccessVisuals(success: false);
		}
		if (_isEmoteChest)
		{
			LobbyData.Current.MyEmoteChestReady = false;
		}
		else
		{
			LobbyData.Current.MyChestReady = false;
		}
	}

	public bool CanBuy()
	{
		return Pets.Instance.CanSpendPets(_price);
	}
}
