using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Heathen.SteamworksIntegration;
using Steam;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassManager : MonoBehaviour
{
	public static PawPassManager Instance;

	[SerializeField]
	private PawPassWindow _pawPassWindow;

	[SerializeField]
	private List<PawPassEntity> _passes = new List<PawPassEntity>();

	[SerializeField]
	private PawPassMilestoneBubble _milestoneBubblePrefab;

	[SerializeField]
	private PawPassItem _basePrefab;

	[SerializeField]
	private PawPassItemCosmetic _hatItemPrefab;

	[SerializeField]
	private PawPassItemCosmetic _skinItemPrefab;

	[SerializeField]
	private PawPassItemCosmetic _emoteItemPrefab;

	[SerializeField]
	private PawPassItemConsumable _consumableItemPrefab;

	[SerializeField]
	private PawPassItemChest _chestItemPrefab;

	[SerializeField]
	private PawPassItemFullCosmetic _fullCosmeticItemPrefab;

	[SerializeField]
	private PawPassItemMultiple _multipleItemsPrefab;

	private readonly List<PawPassItem> _freeItems = new List<PawPassItem>();

	private readonly List<PawPassItem> _premiumItems = new List<PawPassItem>();

	private readonly List<PawPassMilestoneBubble> _milestoneBubbles = new List<PawPassMilestoneBubble>();

	public PawPassEntity SelectedPass;

	private PawPassEntity _pendingUnlock;

	private bool _isClaimingAll;

	public bool IsInitialized;

	public List<PawPassEntity> PlayablePasses => _passes.FindAll((PawPassEntity pass) => pass.IsGenerated);

	public IEnumerable<PawPassEntity> VisiblePasses => from pass in StartedPasses()
		where !pass.IsHidden
		select pass;

	public IEnumerable<PawPassEntity> HiddenPasses => from pass in StartedPasses()
		where pass.IsHidden
		select pass;

	private IEnumerable<PawPassItem> Milestones => _freeItems.Take(SelectedPass.TotalMilestones).Concat(_premiumItems.Take(SelectedPass.TotalMilestones));

	private void Awake()
	{
		Instance = this;
	}

	private IEnumerator Start()
	{
		ClearPreviewRows(_pawPassWindow.FreePassParent);
		ClearPreviewRows(_pawPassWindow.PremiumPassParent);
		if (PlayablePasses.Count == 0)
		{
			Debug.LogWarning($"PawPass | None of the {_passes.Count} season(s) have their Steam items generated - " + "the pass stays empty. Generate them with Bongo Cat/Paw Pass Designer.");
			yield break;
		}
		SelectPass(NewestStartedPass());
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		yield return GrantFreePasses();
		yield return new WaitUntil(() => StatsInitializer.Initialized);
		CaptureBaselines();
		IsInitialized = true;
		SelectPass(DefaultPass());
	}

	private void CaptureBaselines()
	{
		foreach (PawPassEntity playablePass in PlayablePasses)
		{
			TapsFor(playablePass);
		}
	}

	public void SelectPass(PawPassEntity pass)
	{
		SelectedPass = pass;
		_pawPassWindow.SetSeason(pass);
		CreateMilestones();
		Refresh();
	}

	private List<PawPassEntity> StartedPasses()
	{
		return PlayablePasses.FindAll((PawPassEntity pass) => pass.HasStarted);
	}

	private PawPassEntity DefaultPass()
	{
		List<PawPassEntity> list = StartedPasses();
		if (list.Count == 0)
		{
			return PlayablePasses[0];
		}
		PawPassEntity pawPassEntity = list.FindLast((PawPassEntity pass) => !pass.IsHidden);
		if ((object)pawPassEntity == null)
		{
			pawPassEntity = list[list.Count - 1];
		}
		return pawPassEntity;
	}

	private PawPassEntity NewestStartedPass()
	{
		List<PawPassEntity> list = StartedPasses();
		if (list.Count != 0)
		{
			return list[list.Count - 1];
		}
		return PlayablePasses[0];
	}

	private IEnumerator GrantFreePasses()
	{
		foreach (PawPassEntity playablePass in PlayablePasses)
		{
			yield return GrantFreePass(playablePass);
		}
	}

	private IEnumerator GrantFreePass(PawPassEntity pass)
	{
		if (pass.HasFreePass)
		{
			yield break;
		}
		if (!pass.FreeToken.HasItem)
		{
			if (!pass.IsLive)
			{
				yield break;
			}
			bool granted = false;
			pass.FreeToken.ItemData.AddPromoItem(delegate(InventoryResult result)
			{
				granted = true;
				if (result.result != EResult.k_EResultOK)
				{
					Debug.LogWarning($"PawPass | Steam would not grant {pass.FreeToken.Name} ({result.result}), so season " + pass.SeasonCode + " cannot be joined. Are its item definitions uploaded to Steam?");
				}
			});
			yield return new WaitUntil(() => granted);
		}
		if (!pass.FreeToken.HasItem)
		{
			yield break;
		}
		bool unlocked = false;
		pass.FreeUnlockExchange.Exchange(delegate((bool, ItemDetail[]) result)
		{
			unlocked = true;
			if (!result.Item1)
			{
				Debug.LogWarning("PawPass | Redeeming " + pass.FreeToken.Name + " for season " + pass.SeasonCode + " failed.");
			}
		});
		yield return new WaitUntil(() => unlocked);
	}

	public void ShowPass(PawPassEntity pass)
	{
		SelectPass(pass);
		_pawPassWindow.ShowPassView();
	}

	public void UnlockPremiumPass()
	{
		UnlockPremiumPass(SelectedPass);
	}

	public void UnlockPremiumPass(PawPassEntity pass)
	{
		if (!pass.HasPremiumPass)
		{
			if (!pass.PremiumUnlock.CanExchange())
			{
				OpenItemStore.OpenDetailPage(pass.PassToken);
				return;
			}
			_pendingUnlock = pass;
			_pawPassWindow.ShowRedeemConfirmation();
		}
	}

	public void RedeemPassToken()
	{
		if (!_pendingUnlock.HasPremiumPass)
		{
			_pendingUnlock.PremiumUnlock.Exchange(delegate
			{
				CaptureBaselines();
				Refresh();
			});
		}
	}

	public void Refresh()
	{
		if ((bool)SelectedPass && _freeItems.Count != 0)
		{
			int num = TapsFor(SelectedPass);
			int requiredTapsPerMilestone = SelectedPass.RequiredTapsPerMilestone;
			int num2 = num / requiredTapsPerMilestone;
			int tapsIntoMilestone = num - num2 * requiredTapsPerMilestone;
			_pawPassWindow.SetCurrentMilestoneProgress(tapsIntoMilestone, requiredTapsPerMilestone, num2);
			_pawPassWindow.SetPassProgress(num, SelectedPass.TotalTaps);
			_pawPassWindow.SetGetPassVisible(!SelectedPass.HasPremiumPass);
			_pawPassWindow.SetGetPassInteractable(IsInitialized);
			for (int i = 0; i < SelectedPass.TotalMilestones; i++)
			{
				ApplyState(_freeItems[i], premium: false, i, num, requiredTapsPerMilestone);
				ApplyState(_premiumItems[i], premium: true, i, num, requiredTapsPerMilestone);
			}
			_pawPassWindow.SetClaimAllInteractable(Milestones.Any((PawPassItem item) => item.CanClaim));
		}
	}

	public void RefreshProgress()
	{
		if (_pawPassWindow.isActiveAndEnabled)
		{
			Refresh();
		}
	}

	private void ApplyState(PawPassItem item, bool premium, int index, int taps, int required)
	{
		bool flag = taps >= (index + 1) * required;
		if (!(premium ? SelectedPass.HasPremiumPass : SelectedPass.HasFreePass))
		{
			if (premium)
			{
				item.SetPayToUnlock(flag);
			}
			else
			{
				item.Lock();
			}
		}
		else if (!SelectedPass.Milestones(premium)[index].IsUnclaimed)
		{
			item.SetClaimed();
		}
		else if (!flag)
		{
			item.Lock();
		}
		else
		{
			item.SetClaimable();
		}
	}

	private void CreateMilestones()
	{
		GrowTo(_milestoneBubbles, _milestoneBubblePrefab, _pawPassWindow.MilestoneParent);
		GrowTo(_freeItems, _basePrefab, _pawPassWindow.FreePassParent);
		GrowTo(_premiumItems, _basePrefab, _pawPassWindow.PremiumPassParent);
		for (int i = 0; i < SelectedPass.TotalMilestones; i++)
		{
			_milestoneBubbles[i].SetMilestone(i + 1);
			FillMilestone(_freeItems[i], SelectedPass.FreePassMilestones[i]);
			FillMilestone(_premiumItems[i], SelectedPass.PremiumPassMilestones[i]);
		}
		LayoutRebuilder.ForceRebuildLayoutImmediate(_pawPassWindow.ScrollRect.content);
	}

	private void GrowTo<T>(List<T> rows, T prefab, RectTransform parent) where T : MonoBehaviour
	{
		while (rows.Count < SelectedPass.TotalMilestones)
		{
			rows.Add(global::UnityEngine.Object.Instantiate(prefab, parent));
		}
		for (int i = 0; i < rows.Count; i++)
		{
			rows[i].gameObject.SetActive(i < SelectedPass.TotalMilestones);
		}
	}

	private void FillMilestone(PawPassItem row, PawPassMilestone milestone)
	{
		row.Milestone = milestone;
		if (milestone.IsFullCosmetic)
		{
			Content(row, _fullCosmeticItemPrefab).FillContent(milestone);
		}
		else if (milestone.Items.Count > 1)
		{
			PawPassItemMultiple pawPassItemMultiple = row.ReplaceContent(_multipleItemsPrefab);
			pawPassItemMultiple.Add(GetPrefabForRewardType(milestone.Items[0].RewardType), 0);
			pawPassItemMultiple.Add(GetPrefabForRewardType(milestone.Items[1].RewardType), 3);
			pawPassItemMultiple.FillContent(milestone);
		}
		else
		{
			Content(row, GetPrefabForRewardType(milestone.Items[0].RewardType)).FillContent(milestone);
		}
	}

	public void ReachMilestones(float milestonesReached)
	{
		for (int i = 0; i < _milestoneBubbles.Count; i++)
		{
			_milestoneBubbles[i].SetReached((float)i < milestonesReached);
		}
	}

	private static PawPassItemClass Content(PawPassItem row, PawPassItemClass prefab)
	{
		return row.Content(prefab) ?? row.ReplaceContent(prefab);
	}

	private void ClearPreviewRows(RectTransform track)
	{
		PawPassItem[] componentsInChildren = track.GetComponentsInChildren<PawPassItem>(includeInactive: true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			global::UnityEngine.Object.Destroy(componentsInChildren[i].gameObject);
		}
	}

	private PawPassItemClass GetPrefabForRewardType(RewardType rewardType)
	{
		return rewardType switch
		{
			RewardType.HAT => _hatItemPrefab, 
			RewardType.SKIN => _skinItemPrefab, 
			RewardType.EMOTE => _emoteItemPrefab, 
			RewardType.CONSUMABLE => _consumableItemPrefab, 
			RewardType.CHEST => _chestItemPrefab, 
			_ => throw new ArgumentOutOfRangeException("rewardType", rewardType, null), 
		};
	}

	public void ClaimAll()
	{
		if (!_isClaimingAll)
		{
			_isClaimingAll = true;
			StartCoroutine(ClaimAllRoutine());
		}
	}

	private IEnumerator ClaimAllRoutine()
	{
		foreach (PawPassItem milestone in Milestones)
		{
			if (milestone.CanClaim)
			{
				bool claimed = false;
				milestone.Claim(delegate
				{
					claimed = true;
				});
				yield return new WaitUntil(() => claimed);
			}
		}
		_isClaimingAll = false;
	}

	private int TapsFor(PawPassEntity pass)
	{
		if (!StatsInitializer.Initialized || !pass.IsJoined)
		{
			return 0;
		}
		int num = Game.Stats.BongoTap.IntValue();
		string key = BaselineKey(pass);
		if (!PlayerPrefs.HasKey(key))
		{
			PlayerPrefs.SetInt(key, num);
			PlayerPrefs.Save();
		}
		return Mathf.Max(0, num - PlayerPrefs.GetInt(key));
	}

	private static string BaselineKey(PawPassEntity pass)
	{
		return "PP_BL_" + pass.SeasonCode;
	}
}
