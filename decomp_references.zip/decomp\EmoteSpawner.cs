using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat;
using BongoCat.Emotes;
using BongoCat.Multiplayer;
using Heathen.SteamworksIntegration;
using UnityEngine;
using UnityEngine.UI;

public class EmoteSpawner : MonoBehaviour
{
	[SerializeField]
	private EmoteParticle emoteParticlePrefab;

	[SerializeField]
	private ConsumableBehaviorList _consumableBehaviorList;

	[SerializeField]
	private uint particlePoolSize;

	[SerializeField]
	[Tooltip("Seconds to wait before restoring the original poolsize if pool was extended due to spamming emotes")]
	private float secondsToRestorePoolSize;

	private Queue<EmoteParticle> _emoteParticlePool;

	private int _excessEmotes;

	private Coroutine _restoringPoolSize;

	private WaitForSeconds _waitingToRestorePoolSize;

	[SerializeField]
	private SteamLobbyMemberData _lobbyMemberData;

	private bool _isMultiplayerCat;

	[SerializeField]
	private Slider _emoteSpeedSlider;

	[SerializeField]
	private Sprite _sampleEmote;

	private const string EMOTE_SPEED_KEY = "EMOTE_SPEED";

	private const float DEFAULT_EMOTE_SPEED = 0.5f;

	public static float EmoteSpeedMultiplier => (1f - PlayerPrefs.GetFloat("EMOTE_SPEED", 0.5f)) * 2f + 0.5f;

	private void Awake()
	{
		_emoteParticlePool = new Queue<EmoteParticle>();
		for (int i = 0; i < particlePoolSize; i++)
		{
			AddParticleToPool();
		}
		_waitingToRestorePoolSize = new WaitForSeconds(secondsToRestorePoolSize);
		_isMultiplayerCat = _lobbyMemberData;
	}

	private void Start()
	{
		if (_isMultiplayerCat)
		{
			SteamMultiplayer.Instance.OnEmoteReceived.Register(_lobbyMemberData.Data.user, SpawnMultiplayerEmote);
		}
		else
		{
			_emoteSpeedSlider.value = PlayerPrefs.GetFloat("EMOTE_SPEED", 0.5f);
		}
	}

	private void OnDestroy()
	{
		if (_isMultiplayerCat)
		{
			SteamMultiplayer.Instance.OnEmoteReceived.Deregister(_lobbyMemberData.Data.user, SpawnMultiplayerEmote);
		}
	}

	public void SpawnEmoteParticle(SteamItemRuntime steamItem)
	{
		EmoteBehaviorOverride behaviorOverride = _consumableBehaviorList.GetBehaviorOverride(steamItem.Id);
		SpawnEmoteParticle(steamItem.Icon, behaviorOverride);
	}

	public void SpawnEmoteParticle(Sprite icon, EmoteBehaviorOverride behavior, Transform targetTransform = null, Action onComplete = null)
	{
		if (!base.gameObject.activeInHierarchy)
		{
			onComplete?.Invoke();
			return;
		}
		if (_emoteParticlePool.Count == 0)
		{
			_excessEmotes++;
			AddParticleToPool();
		}
		if (_restoringPoolSize != null)
		{
			StopCoroutine(_restoringPoolSize);
		}
		EmoteParticle emoteParticle = _emoteParticlePool.Dequeue();
		emoteParticle.gameObject.SetActive(value: true);
		emoteParticle.StartEmote(icon, behavior, targetTransform, onComplete);
		if (_excessEmotes > 0)
		{
			_restoringPoolSize = StartCoroutine(RestorePoolSize());
		}
	}

	public void SpawnMultiplayerEmote(int id)
	{
		if (!SettingsManager.Instance.HideEmotesSetting.Value && base.gameObject.activeInHierarchy)
		{
			SteamItemRuntime steamItemRuntime = CatInventory.Instance.Items.FirstOrDefault((SteamItemRuntime item) => item.Id == id);
			if (steamItemRuntime != null)
			{
				EmoteBehaviorOverride behaviorOverride = _consumableBehaviorList.GetBehaviorOverride(id);
				SpawnEmoteParticle(steamItemRuntime.Icon, behaviorOverride);
			}
		}
	}

	private void AddParticleToPool()
	{
		EmoteParticle emoteParticle = UnityEngine.Object.Instantiate(emoteParticlePrefab, base.transform);
		emoteParticle.Init(this);
		emoteParticle.gameObject.SetActive(value: false);
		_emoteParticlePool.Enqueue(emoteParticle);
	}

	public void ReturnParticleToPool(EmoteParticle particle)
	{
		particle.gameObject.SetActive(value: false);
		_emoteParticlePool.Enqueue(particle);
	}

	private IEnumerator RestorePoolSize()
	{
		yield return _waitingToRestorePoolSize;
		while (_excessEmotes > 0)
		{
			yield return new WaitUntil(() => _emoteParticlePool.Count > 0);
			UnityEngine.Object.Destroy(_emoteParticlePool.Dequeue().gameObject);
			_excessEmotes--;
		}
		_restoringPoolSize = null;
	}

	public void ChangeEmoteSpeed(float speed)
	{
		PlayerPrefs.SetFloat("EMOTE_SPEED", speed);
	}

	public void SpawnSampleEmote()
	{
		SpawnEmoteParticle(_sampleEmote, EmoteBehaviorOverride.None);
	}
}
