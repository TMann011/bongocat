using BongoCat;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace Steam;

public class InitHeathen : MonoBehaviour
{
	private void Awake()
	{
		if (SteamAPI.RestartAppIfNecessary(Global.SteamID))
		{
			Debug.Log("[Steamworks.NET] Shutting down because RestartAppIfNecessary returned true. Steam will restart the application.");
			Application.Quit();
		}
		else
		{
			Events.Initialise();
			Game.Initialise();
		}
	}
}
