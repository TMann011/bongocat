using System.Linq;
using TMPro;
using UnityEngine;

namespace Helper;

public class InputFieldCache : MonoBehaviour
{
	private static TMP_InputField[] inputFields;

	public static bool FocusingInputField
	{
		get
		{
			if (!InputFieldHelper.ProcessingSubmit)
			{
				return inputFields.Any((TMP_InputField inputField) => inputField.isFocused);
			}
			return true;
		}
	}

	private void Awake()
	{
		inputFields = Object.FindObjectsByType<TMP_InputField>(FindObjectsInactive.Include, FindObjectsSortMode.None);
	}
}
