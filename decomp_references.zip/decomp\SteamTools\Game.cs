using System.Collections.Generic;
using Heathen.SteamworksIntegration;
using Heathen.SteamworksIntegration.API;
using UnityEngine;

namespace SteamTools;

public static class Game
{
	public static class Stats
	{
		public static StatData BongoBeat = "BongoBeat";

		public static StatData BongoMinus = "BongoMinus";

		public static StatData BongoTap = "BongoTap";

		public static StatData EmotesUsed = "EmotesUsed";

		public static StatData Exchanges = "Exchanges";

		public static StatData First_Pressed_Discord_Button = "First_Pressed_Discord_Button";

		public static StatData Frankittystein_Exchange = "Frankittystein Exchange";

		public static StatData MaxMultiplayerLobbySize = "MaxMultiplayerLobbySize";

		public static StatData Nosfergato_Exchange = "Nosfergato Exchange";

		public static StatData Pressed_Discord_Button = "Pressed_Discord_Button";

		public static StatData TotalItems = "TotalItems";

		public static StatData Version = "Version";

		public static StatData VOTING_TEST_NO = "VOTING_TEST_NO";

		public static StatData VOTING_TEST_YES = "VOTING_TEST_YES";

		public static StatData Zombie_Exchange = "Zombie Exchange";
	}

	public static class Inventory
	{
		public static ItemData Achievement_Token = 97;

		public static ItemData Acorn = 572;

		public static ItemData Acorn_Cap = 573;

		public static ItemData Acorn_Stick = 562;

		public static ItemData Adoptable_Bobby = 596;

		public static ItemData Adoptable_Jerry = 597;

		public static ItemData Adoptable_Luna = 598;

		public static ItemData Adoptable_Teddy = 599;

		public static ItemData Adoptable_Tommy = 600;

		public static ItemData Adoptable_Vinci = 601;

		public static ItemData Alien = 225;

		public static ItemData Alien_Antenna = 240;

		public static ItemData Almost_Full_Battery = 339;

		public static ItemData Almost_Full_Health = 340;

		public static ItemData American_Cheese = 341;

		public static ItemData Angel_Halo = 124;

		public static ItemData Angelic_Kitten = 745;

		public static ItemData Angry = 379;

		public static ItemData Animal_Shrimp_Emoji = 456;

		public static ItemData Anime = 226;

		public static ItemData Anime_Boy_Hair = 125;

		public static ItemData Anime_Girl_Hair = 126;

		public static ItemData Appreciation = 337;

		public static ItemData April2026_Exchange = 937;

		public static ItemData April2026_Reward_Token = 936;

		public static ItemData Armed_Bomb = 324;

		public static ItemData Arrow_In_Apple = 127;

		public static ItemData Arrow_Outside_Apple = 128;

		public static ItemData Attack_Mecha_S_L_A_S_H = 786;

		public static ItemData Autumn_Dragonfly_Wings = 582;

		public static ItemData Autumn_Faun = 574;

		public static ItemData Autumn_Leaf = 575;

		public static ItemData Autumn_Leaf_Crown = 129;

		public static ItemData Aviator_Hat = 342;

		public static ItemData Bamboo_Leaves = 241;

		public static ItemData Banana = 130;

		public static ItemData Bare_Brain = 588;

		public static ItemData Bath_Bubble_Duck = 343;

		public static ItemData Bay_Leaves = 131;

		public static ItemData Beachball = 431;

		public static ItemData Beckoning_Lucky_Cat = 829;

		public static ItemData Bedazzled_Turban = 276;

		public static ItemData Beer = 132;

		public static ItemData Beret = 133;

		public static ItemData Berlin_Exchange = 87;

		public static ItemData BerlinApartmentDemoToken = 86;

		public static ItemData Big_Pumpkin_Hat = 134;

		public static ItemData Bingus = 380;

		public static ItemData Bird_Poop = 344;

		public static ItemData Birds = 135;

		public static ItemData Black = 381;

		public static ItemData Black_Horse = 807;

		public static ItemData Black_Ribbon = 118;

		public static ItemData Black_Rubber_Duck = 136;

		public static ItemData Black_Spotted = 382;

		public static ItemData Black_Sword_Samurai_Helmet = 278;

		public static ItemData Black_Wizard_Hat = 117;

		public static ItemData Blind_Mummy = 137;

		public static ItemData Blonde_Mane = 797;

		public static ItemData Blood_Splatter_Cat = 931;

		public static ItemData Blue_Beret_Cap = 138;

		public static ItemData Blue_Crown = 345;

		public static ItemData Blue_Painter_Beret = 139;

		public static ItemData Blue_Party_Hat = 102;

		public static ItemData Blue_Ribbon = 119;

		public static ItemData Blue_Tophat = 113;

		public static ItemData Bonfire_Cat = 563;

		public static ItemData Bongo_Beats_Amethyst = 913;

		public static ItemData Bongo_Beats_Amethyst_Gem = 920;

		public static ItemData Bongo_Beats_Diamond = 914;

		public static ItemData Bongo_Beats_Diamond_Gem = 921;

		public static ItemData Bongo_Beats_Emerald = 915;

		public static ItemData Bongo_Beats_Emerald_Gem = 922;

		public static ItemData Bongo_Beats_Gold = 784;

		public static ItemData Bongo_Beats_Gold_Crown = 785;

		public static ItemData Bongo_Beats_Platinum = 916;

		public static ItemData Bongo_Beats_Platinum_Crown = 923;

		public static ItemData Bongo_Beats_Ruby = 917;

		public static ItemData Bongo_Beats_Ruby_Gem = 924;

		public static ItemData Bongo_Beats_Sapphire = 918;

		public static ItemData Bongo_Beats_Sapphire_Gem = 925;

		public static ItemData Bongo_Beats_Silver = 919;

		public static ItemData Bongo_Beats_Silver_Crown = 926;

		public static ItemData Bongo_Bunny = 140;

		public static ItemData Bongo_Calico = 141;

		public static ItemData Bongo_Cat_Hat = 112;

		public static ItemData Bongo_Cow = 142;

		public static ItemData Bongo_Dog = 321;

		public static ItemData Bongo_Mouse = 932;

		public static ItemData Bongo_Soul_Leaving = 279;

		public static ItemData Bonnet = 242;

		public static ItemData Book = 143;

		public static ItemData Book_Stack = 243;

		public static ItemData Bounty_Hunter_Bandana = 346;

		public static ItemData Brown_Fleece_Earmuffs = 720;

		public static ItemData Brown_Horse = 808;

		public static ItemData Brown_Lantern_Carrier = 830;

		public static ItemData Brown_Pilot_Goggles = 144;

		public static ItemData Bubble = 384;

		public static ItemData Bubblegum = 383;

		public static ItemData Bucket_Of_Apples = 576;

		public static ItemData Bug_Catcher = 709;

		public static ItemData Bump = 347;

		public static ItemData Bunny_Ears = 145;

		public static ItemData Burger = 146;

		public static ItemData Burning_Horse = 809;

		public static ItemData Butler = 310;

		public static ItemData Cake = 147;

		public static ItemData Calabrian_Black_Squirrel = 587;

		public static ItemData Calico = 311;

		public static ItemData Calm_Leaf = 148;

		public static ItemData Candle = 244;

		public static ItemData Candy_Cane = 730;

		public static ItemData Captain_Hat = 245;

		public static ItemData Carrion_Crow_Wings = 583;

		public static ItemData Cat_Stack = 246;

		public static ItemData Catcus = 421;

		public static ItemData Catuccino = 302;

		public static ItemData Catuccino_Cup = 300;

		public static ItemData Chain_Firecrackers = 817;

		public static ItemData Charging_Battery = 348;

		public static ItemData Charity_Pack = 38;

		public static ItemData Charity2025_Reward_Token = 84;

		public static ItemData Chef_Hat = 149;

		public static ItemData Chef_Hat_Large = 150;

		public static ItemData Cherry = 151;

		public static ItemData Cherry_Blossom = 349;

		public static ItemData Chest_Exchange = 20;

		public static ItemData Chest_Token = 98;

		public static ItemData Chinese_Pagoda = 818;

		public static ItemData Chinese_Sunset = 831;

		public static ItemData Chipmunk = 564;

		public static ItemData Chocolate_Ferret = 385;

		public static ItemData Chocolate_Siamese = 386;

		public static ItemData Chocolate_Sprinkle_Cookie_Cat = 770;

		public static ItemData Christmas_Lights_Entangler = 746;

		public static ItemData Christmas_Saboteur = 747;

		public static ItemData Christmas_Tree = 755;

		public static ItemData Christmas_Tree_Party_Headband = 731;

		public static ItemData Christmas_Tree_Star = 732;

		public static ItemData Christmas2025_F2P_Exchange_Day_1 = 633;

		public static ItemData Christmas2025_F2P_Exchange_Day_10 = 642;

		public static ItemData Christmas2025_F2P_Exchange_Day_11 = 643;

		public static ItemData Christmas2025_F2P_Exchange_Day_12 = 644;

		public static ItemData Christmas2025_F2P_Exchange_Day_13 = 645;

		public static ItemData Christmas2025_F2P_Exchange_Day_14 = 646;

		public static ItemData Christmas2025_F2P_Exchange_Day_15 = 647;

		public static ItemData Christmas2025_F2P_Exchange_Day_16 = 648;

		public static ItemData Christmas2025_F2P_Exchange_Day_17 = 649;

		public static ItemData Christmas2025_F2P_Exchange_Day_18 = 650;

		public static ItemData Christmas2025_F2P_Exchange_Day_19 = 651;

		public static ItemData Christmas2025_F2P_Exchange_Day_2 = 634;

		public static ItemData Christmas2025_F2P_Exchange_Day_20 = 652;

		public static ItemData Christmas2025_F2P_Exchange_Day_21 = 653;

		public static ItemData Christmas2025_F2P_Exchange_Day_22 = 654;

		public static ItemData Christmas2025_F2P_Exchange_Day_23 = 655;

		public static ItemData Christmas2025_F2P_Exchange_Day_24 = 656;

		public static ItemData Christmas2025_F2P_Exchange_Day_25 = 657;

		public static ItemData Christmas2025_F2P_Exchange_Day_3 = 635;

		public static ItemData Christmas2025_F2P_Exchange_Day_4 = 636;

		public static ItemData Christmas2025_F2P_Exchange_Day_5 = 637;

		public static ItemData Christmas2025_F2P_Exchange_Day_6 = 638;

		public static ItemData Christmas2025_F2P_Exchange_Day_7 = 639;

		public static ItemData Christmas2025_F2P_Exchange_Day_8 = 640;

		public static ItemData Christmas2025_F2P_Exchange_Day_9 = 641;

		public static ItemData Christmas2025_F2P_Token_Day_1 = 608;

		public static ItemData Christmas2025_F2P_Token_Day_10 = 617;

		public static ItemData Christmas2025_F2P_Token_Day_11 = 618;

		public static ItemData Christmas2025_F2P_Token_Day_12 = 619;

		public static ItemData Christmas2025_F2P_Token_Day_13 = 620;

		public static ItemData Christmas2025_F2P_Token_Day_14 = 621;

		public static ItemData Christmas2025_F2P_Token_Day_15 = 622;

		public static ItemData Christmas2025_F2P_Token_Day_16 = 623;

		public static ItemData Christmas2025_F2P_Token_Day_17 = 624;

		public static ItemData Christmas2025_F2P_Token_Day_18 = 625;

		public static ItemData Christmas2025_F2P_Token_Day_19 = 626;

		public static ItemData Christmas2025_F2P_Token_Day_2 = 609;

		public static ItemData Christmas2025_F2P_Token_Day_20 = 627;

		public static ItemData Christmas2025_F2P_Token_Day_21 = 628;

		public static ItemData Christmas2025_F2P_Token_Day_22 = 629;

		public static ItemData Christmas2025_F2P_Token_Day_23 = 630;

		public static ItemData Christmas2025_F2P_Token_Day_24 = 631;

		public static ItemData Christmas2025_F2P_Token_Day_25 = 632;

		public static ItemData Christmas2025_F2P_Token_Day_3 = 610;

		public static ItemData Christmas2025_F2P_Token_Day_4 = 611;

		public static ItemData Christmas2025_F2P_Token_Day_5 = 612;

		public static ItemData Christmas2025_F2P_Token_Day_6 = 613;

		public static ItemData Christmas2025_F2P_Token_Day_7 = 614;

		public static ItemData Christmas2025_F2P_Token_Day_8 = 615;

		public static ItemData Christmas2025_F2P_Token_Day_9 = 616;

		public static ItemData Christmas2025_PREM_Exchange_Day_1 = 684;

		public static ItemData Christmas2025_PREM_Exchange_Day_10 = 693;

		public static ItemData Christmas2025_PREM_Exchange_Day_11 = 694;

		public static ItemData Christmas2025_PREM_Exchange_Day_12 = 695;

		public static ItemData Christmas2025_PREM_Exchange_Day_13 = 696;

		public static ItemData Christmas2025_PREM_Exchange_Day_14 = 697;

		public static ItemData Christmas2025_PREM_Exchange_Day_15 = 698;

		public static ItemData Christmas2025_PREM_Exchange_Day_16 = 699;

		public static ItemData Christmas2025_PREM_Exchange_Day_17 = 700;

		public static ItemData Christmas2025_PREM_Exchange_Day_18 = 701;

		public static ItemData Christmas2025_PREM_Exchange_Day_19 = 702;

		public static ItemData Christmas2025_PREM_Exchange_Day_2 = 685;

		public static ItemData Christmas2025_PREM_Exchange_Day_20 = 703;

		public static ItemData Christmas2025_PREM_Exchange_Day_21 = 704;

		public static ItemData Christmas2025_PREM_Exchange_Day_22 = 705;

		public static ItemData Christmas2025_PREM_Exchange_Day_23 = 706;

		public static ItemData Christmas2025_PREM_Exchange_Day_24 = 707;

		public static ItemData Christmas2025_PREM_Exchange_Day_25 = 708;

		public static ItemData Christmas2025_PREM_Exchange_Day_3 = 686;

		public static ItemData Christmas2025_PREM_Exchange_Day_4 = 687;

		public static ItemData Christmas2025_PREM_Exchange_Day_5 = 688;

		public static ItemData Christmas2025_PREM_Exchange_Day_6 = 689;

		public static ItemData Christmas2025_PREM_Exchange_Day_7 = 690;

		public static ItemData Christmas2025_PREM_Exchange_Day_8 = 691;

		public static ItemData Christmas2025_PREM_Exchange_Day_9 = 692;

		public static ItemData Christmas2025_PREM_Token_Day_1 = 658;

		public static ItemData Christmas2025_PREM_Token_Day_10 = 667;

		public static ItemData Christmas2025_PREM_Token_Day_11 = 668;

		public static ItemData Christmas2025_PREM_Token_Day_12 = 669;

		public static ItemData Christmas2025_PREM_Token_Day_13 = 670;

		public static ItemData Christmas2025_PREM_Token_Day_14 = 671;

		public static ItemData Christmas2025_PREM_Token_Day_15 = 672;

		public static ItemData Christmas2025_PREM_Token_Day_16 = 673;

		public static ItemData Christmas2025_PREM_Token_Day_17 = 674;

		public static ItemData Christmas2025_PREM_Token_Day_18 = 675;

		public static ItemData Christmas2025_PREM_Token_Day_19 = 676;

		public static ItemData Christmas2025_PREM_Token_Day_2 = 659;

		public static ItemData Christmas2025_PREM_Token_Day_20 = 677;

		public static ItemData Christmas2025_PREM_Token_Day_21 = 678;

		public static ItemData Christmas2025_PREM_Token_Day_22 = 679;

		public static ItemData Christmas2025_PREM_Token_Day_23 = 680;

		public static ItemData Christmas2025_PREM_Token_Day_24 = 681;

		public static ItemData Christmas2025_PREM_Token_Day_25 = 682;

		public static ItemData Christmas2025_PREM_Token_Day_3 = 660;

		public static ItemData Christmas2025_PREM_Token_Day_4 = 661;

		public static ItemData Christmas2025_PREM_Token_Day_5 = 662;

		public static ItemData Christmas2025_PREM_Token_Day_6 = 663;

		public static ItemData Christmas2025_PREM_Token_Day_7 = 664;

		public static ItemData Christmas2025_PREM_Token_Day_8 = 665;

		public static ItemData Christmas2025_PREM_Token_Day_9 = 666;

		public static ItemData Cinnamon_Siamese = 387;

		public static ItemData Cloudscraper_Exchange = 89;

		public static ItemData Cloudscrapers_Pinwheel = 603;

		public static ItemData CloudscrapersDemoToken = 88;

		public static ItemData Clown = 237;

		public static ItemData Clown_Hair = 152;

		public static ItemData Clown_Hat = 247;

		public static ItemData Coconut_Drink = 432;

		public static ItemData Code_Police_Hat = 561;

		public static ItemData Common_Cosmetics_Exchange = 16;

		public static ItemData Common_Emote_Exchange = 30;

		public static ItemData Common_Emote_Generator = 25;

		public static ItemData Common_Generator = 11;

		public static ItemData Confused = 305;

		public static ItemData Constance_Exchange = 71;

		public static ItemData Constance_Hair = 605;

		public static ItemData ConstanceDemoToken = 70;

		public static ItemData Construction_Worker = 153;

		public static ItemData Cookie_Plate = 733;

		public static ItemData Cool_Sunglasses = 123;

		public static ItemData Cowboy_Hat = 154;

		public static ItemData Cowboy_Hat_Variant = 155;

		public static ItemData Crown = 156;

		public static ItemData Cuckoo_Clock = 312;

		public static ItemData Cup = 157;

		public static ItemData Cute_Black_Buns = 819;

		public static ItemData Cute_Brown_Horse_Mane = 798;

		public static ItemData Cute_Snow_Bunny = 721;

		public static ItemData Cute_Yeti = 711;

		public static ItemData Cutie_Punch_Chant = 933;

		public static ItemData DEAD_God_DLC_Exchange = 950;

		public static ItemData DEAD_Mecha_DLC_Exchange = 948;

		public static ItemData DEAD_Squirrel_DLC_Exchange = 946;

		public static ItemData DEAD_Wrestler_DLC_Exchange = 952;

		public static ItemData DEPRECATED_God_Pack = 23;

		public static ItemData DEPRECATED_Mecha_Pack = 790;

		public static ItemData DEPRECATED_Squirrel_Pack = 37;

		public static ItemData DEPRECATED_Wrestler_Pack = 39;

		public static ItemData Dark_Brown_Horse = 810;

		public static ItemData Dark_Red_Tang_Suit = 832;

		public static ItemData Deluxe_Advent_Calendar = 683;

		public static ItemData Devil_Horns = 158;

		public static ItemData Disguise = 313;

		public static ItemData Donut = 314;

		public static ItemData Double_Chest = 36;

		public static ItemData Dragon = 239;

		public static ItemData Dragon_Wings = 248;

		public static ItemData Dropped_Ice_Cream = 433;

		public static ItemData Duck_Whoopee_Cushion = 325;

		public static ItemData Earfit_Pompom_Hat = 722;

		public static ItemData Eastern_Grey_Squirrel = 586;

		public static ItemData Eggshell = 315;

		public static ItemData Electric_Screws = 592;

		public static ItemData Emote_Chest_Token = 90;

		public static ItemData Emote_Exchange = 34;

		public static ItemData Emote_Generator = 35;

		public static ItemData Epic_Cosmetics_Exchange = 19;

		public static ItemData Epic_Emote_Exchange = 33;

		public static ItemData Epic_Emote_Generator = 28;

		public static ItemData Epic_Generator = 14;

		public static ItemData Eurasian_Red_Squirrel = 585;

		public static ItemData Excited = 388;

		public static ItemData Face_Angry_Emoji = 457;

		public static ItemData Face_Base_Emoji = 458;

		public static ItemData Face_Bawling_Emoji = 510;

		public static ItemData Face_Blow_Kiss_Emoji = 459;

		public static ItemData Face_Blush_Emoji = 460;

		public static ItemData Face_Bonk_Emoji = 511;

		public static ItemData Face_Celebrate_Emoji = 512;

		public static ItemData Face_Cheeky_Emoji = 461;

		public static ItemData Face_Cold_Emoji = 506;

		public static ItemData Face_Content_Emoji = 462;

		public static ItemData Face_Cool_Emoji = 463;

		public static ItemData Face_Crying_Emoji = 464;

		public static ItemData Face_Dead_Emoji = 465;

		public static ItemData Face_Devil_Emoji = 507;

		public static ItemData Face_Dizzy_Emoji = 513;

		public static ItemData Face_Drool_Emoji = 514;

		public static ItemData Face_Excited_Emoji = 466;

		public static ItemData Face_Expressionless_Emoji = 515;

		public static ItemData Face_Fear_Emoji = 467;

		public static ItemData Face_Fever_Emoji = 516;

		public static ItemData Face_Flipped_Emoji = 517;

		public static ItemData Face_Fume_Emoji = 518;

		public static ItemData Face_Giggle_Emoji = 519;

		public static ItemData Face_Goofy_Emoji = 520;

		public static ItemData Face_Greedy_Emoji = 521;

		public static ItemData Face_Grimace_Emoji = 522;

		public static ItemData Face_Grin_Emoji = 523;

		public static ItemData Face_Halo_Emoji = 508;

		public static ItemData Face_Happy_Emoji = 468;

		public static ItemData Face_Heart_Smile_Emoji = 524;

		public static ItemData Face_Hot_Emoji = 525;

		public static ItemData Face_Hug_Emoji = 526;

		public static ItemData Face_Injured_Emoji = 527;

		public static ItemData Face_Kiss_Emoji = 469;

		public static ItemData Face_Laugh_Emoji = 470;

		public static ItemData Face_Love_Emoji = 471;

		public static ItemData Face_Mad_Emoji = 528;

		public static ItemData Face_Nauseated_Emoji = 529;

		public static ItemData Face_Obsessed_Emoji = 530;

		public static ItemData Face_Pensive_Emoji = 531;

		public static ItemData Face_Pleading_Emoji = 532;

		public static ItemData Face_Pleased_Emoji = 533;

		public static ItemData Face_Pout_Emoji = 534;

		public static ItemData Face_Relaxed_Emoji = 472;

		public static ItemData Face_Sad_Emoji = 473;

		public static ItemData Face_Scream_Emoji = 535;

		public static ItemData Face_Sigh_Emoji = 474;

		public static ItemData Face_Single_Tear_Emoji = 475;

		public static ItemData Face_Skull_Emoji = 509;

		public static ItemData Face_Sleep_Emoji = 476;

		public static ItemData Face_Smile_Emoji = 477;

		public static ItemData Face_Smirk_Emoji = 478;

		public static ItemData Face_Snort_Emoji = 536;

		public static ItemData Face_Squint_Emoji = 537;

		public static ItemData Face_Surprise_Emoji = 479;

		public static ItemData Face_Sweaty_Smile_Emoji = 480;

		public static ItemData Face_Sweet_Kiss_Emoji = 538;

		public static ItemData Face_Tease_Emoji = 539;

		public static ItemData Face_Unamused_Emoji = 540;

		public static ItemData Face_Upset_Emoji = 481;

		public static ItemData Face_Vomit_Emoji = 541;

		public static ItemData Face_Wink_Emoji = 482;

		public static ItemData Face_Yawn_Emoji = 542;

		public static ItemData Face_Yum_Emoji = 543;

		public static ItemData Fairy_Flower_Hat = 249;

		public static ItemData Falling_Bowling_Ball = 326;

		public static ItemData Fancy_Fez = 159;

		public static ItemData Fawn = 565;

		public static ItemData Feline_Valentine = 794;

		public static ItemData Festive_Reindeer_Antlers = 756;

		public static ItemData Festive_Smoocher = 771;

		public static ItemData Few_Hearts = 350;

		public static ItemData Fierce_Black_Bun = 820;

		public static ItemData Fine_Patterned_Christmas_Sweater = 772;

		public static ItemData Fire_Cat = 811;

		public static ItemData Fire_Foal = 799;

		public static ItemData Fire_Horse = 800;

		public static ItemData Fire_Mane = 801;

		public static ItemData Fire_Paw = 812;

		public static ItemData First_Advent_Candle = 734;

		public static ItemData Fish = 160;

		public static ItemData Fish_Bait_Stick = 301;

		public static ItemData Flag_Green_Emoji = 483;

		public static ItemData Flag_Pirate_Emoji = 544;

		public static ItemData Flag_Racing_Emoji = 545;

		public static ItemData Flag_Red_Emoji = 484;

		public static ItemData Flag_White_Emoji = 485;

		public static ItemData Flip_Flop = 434;

		public static ItemData Floaties = 422;

		public static ItemData Flower_Costume = 161;

		public static ItemData Flower_Crown = 162;

		public static ItemData Flower_Glasses = 163;

		public static ItemData Flower_Vase = 164;

		public static ItemData Follower = 335;

		public static ItemData Food_Birthday_Cake_Emoji = 486;

		public static ItemData Food_Coffee_Emoji = 487;

		public static ItemData Food_Dango_Emoji = 546;

		public static ItemData Food_Donut_Emoji = 488;

		public static ItemData Food_Meat_Emoji = 547;

		public static ItemData Food_Onigiri_Emoji = 489;

		public static ItemData Food_Peach_Emoji = 548;

		public static ItemData Food_Peeled_Banana_Emoji = 549;

		public static ItemData Food_Pizza_Emoji = 490;

		public static ItemData Food_Strawberry_Emoji = 491;

		public static ItemData Fox = 566;

		public static ItemData Frankittystein = 589;

		public static ItemData Frankittystein_Exchange = 83;

		public static ItemData Freezing_Cold = 710;

		public static ItemData Fries = 250;

		public static ItemData Froggy = 165;

		public static ItemData Frosty_Horns = 723;

		public static ItemData Full_Blue = 389;

		public static ItemData Full_Green = 390;

		public static ItemData Full_Grey = 391;

		public static ItemData Full_Orange = 392;

		public static ItemData Full_Pink = 393;

		public static ItemData Full_Purple = 394;

		public static ItemData Full_Red = 395;

		public static ItemData Full_Yellow = 396;

		public static ItemData Fully_Charged_Battery = 351;

		public static ItemData Gamer_Cap = 299;

		public static ItemData Gat = 251;

		public static ItemData Ghost = 227;

		public static ItemData Gift_Of_The_Hunt = 338;

		public static ItemData Gift_Pile = 757;

		public static ItemData Gift_Shredder = 773;

		public static ItemData Giftee = 748;

		public static ItemData Gingerbread_Cat = 749;

		public static ItemData Gingerbread_House = 758;

		public static ItemData Gingerbread_Man = 735;

		public static ItemData God_DLC_Bundle = 949;

		public static ItemData Godly_Thunderclouds = 453;

		public static ItemData Godly_Tidewaves = 454;

		public static ItemData Godly_Underflames = 455;

		public static ItemData Goggles = 166;

		public static ItemData Gold_Ribbon = 120;

		public static ItemData Gold_Tophat = 115;

		public static ItemData Graduation_Hat = 167;

		public static ItemData Grand_Jester_Hat = 168;

		public static ItemData Greaser_Hair = 169;

		public static ItemData Green_Apple_Worm = 275;

		public static ItemData Green_Gnome_Hat = 170;

		public static ItemData Green_Goggles = 252;

		public static ItemData Green_Party_Hat = 100;

		public static ItemData Green_Pirate_Bandana = 171;

		public static ItemData Green_Ribbon = 121;

		public static ItemData Green_Wrapped_Gift = 750;

		public static ItemData Grey_Horse = 813;

		public static ItemData Grey_Horse_Mane_Buns = 802;

		public static ItemData Grey_Patterned = 306;

		public static ItemData Groucho_Glasses = 327;

		public static ItemData Growing_White_Mushrooms = 352;

		public static ItemData Gummy = 238;

		public static ItemData Gummy_Bear = 253;

		public static ItemData Hades = 450;

		public static ItemData Haiku_Poet = 420;

		public static ItemData Halloween = 228;

		public static ItemData Halloween2025_Reward_Token = 80;

		public static ItemData Happy = 397;

		public static ItemData Happy_Flowers = 280;

		public static ItemData Harvesting_Straw_Hat = 577;

		public static ItemData Hawaiian_Shirt = 423;

		public static ItemData Headphones = 336;

		public static ItemData Heal_Mecha_P_U_R_R = 787;

		public static ItemData Heart_Base_Emoji = 492;

		public static ItemData Heart_Broken_Emoji = 493;

		public static ItemData Heart_Chocolate = 254;

		public static ItemData Heart_Gifted = 550;

		public static ItemData Heart_Mended_Emoji = 551;

		public static ItemData Heart_Shot_Emoji = 552;

		public static ItemData Heart_Sparkling_Emoji = 494;

		public static ItemData Hearts = 229;

		public static ItemData Ho_Ho_Ho = 759;

		public static ItemData Holly = 736;

		public static ItemData Horned_Viking_Helmet = 172;

		public static ItemData Horse_Lantern_Carrier = 833;

		public static ItemData Huge_Neon_Green_Mohawk = 173;

		public static ItemData Huge_Shit = 328;

		public static ItemData Hungry = 398;

		public static ItemData Hyper_Party_Hat = 281;

		public static ItemData Ice_Carved_Cat = 712;

		public static ItemData In_Love = 400;

		public static ItemData Infatuated = 399;

		public static ItemData Ink_Jar_Rice_Hat = 419;

		public static ItemData Item_Generator = 21;

		public static ItemData Jade_Cat = 834;

		public static ItemData Jester_Hat = 174;

		public static ItemData Jingle_Bells = 737;

		public static ItemData Jokers_Hat = 255;

		public static ItemData King = 441;

		public static ItemData Knitted_Autumn_Hat = 578;

		public static ItemData Knocked_Out = 401;

		public static ItemData Krampus = 774;

		public static ItemData Krampus_Horns = 760;

		public static ItemData Krapfen = 316;

		public static ItemData Lamp_Shade = 256;

		public static ItemData Lantern = 257;

		public static ItemData Laser_Eyed = 402;

		public static ItemData Laurel_Wrath = 282;

		public static ItemData Leaf = 175;

		public static ItemData Leaf_Pile = 567;

		public static ItemData Legendary_Emote_Generator = 29;

		public static ItemData Legendary_Generator = 15;

		public static ItemData Lei = 435;

		public static ItemData Lemonade = 436;

		public static ItemData Lion_Dance_Hat = 821;

		public static ItemData Little_Devil = 176;

		public static ItemData Little_Frog = 353;

		public static ItemData Little_Plant = 177;

		public static ItemData Little_Raincoat = 258;

		public static ItemData Lobster = 437;

		public static ItemData Long_Bunny_Ears = 178;

		public static ItemData Lotus_Leaf_Umbrella = 354;

		public static ItemData Love_Vibes = 355;

		public static ItemData Low_Battery = 356;

		public static ItemData Low_Health = 357;

		public static ItemData Lucia_Crown = 761;

		public static ItemData Lucky_Cat = 179;

		public static ItemData Lucky_Coin = 822;

		public static ItemData Luna_Exchange = 85;

		public static ItemData Luna_Moth = 180;

		public static ItemData Lunar_New_Year_Deluxe = 846;

		public static ItemData Lunar2026_F2P_Exchange_Day_1 = 861;

		public static ItemData Lunar2026_F2P_Exchange_Day_10 = 870;

		public static ItemData Lunar2026_F2P_Exchange_Day_11 = 871;

		public static ItemData Lunar2026_F2P_Exchange_Day_12 = 872;

		public static ItemData Lunar2026_F2P_Exchange_Day_13 = 873;

		public static ItemData Lunar2026_F2P_Exchange_Day_14 = 874;

		public static ItemData Lunar2026_F2P_Exchange_Day_2 = 862;

		public static ItemData Lunar2026_F2P_Exchange_Day_3 = 863;

		public static ItemData Lunar2026_F2P_Exchange_Day_4 = 864;

		public static ItemData Lunar2026_F2P_Exchange_Day_5 = 865;

		public static ItemData Lunar2026_F2P_Exchange_Day_6 = 866;

		public static ItemData Lunar2026_F2P_Exchange_Day_7 = 867;

		public static ItemData Lunar2026_F2P_Exchange_Day_8 = 868;

		public static ItemData Lunar2026_F2P_Exchange_Day_9 = 869;

		public static ItemData Lunar2026_F2P_Token_Day_1 = 847;

		public static ItemData Lunar2026_F2P_Token_Day_10 = 856;

		public static ItemData Lunar2026_F2P_Token_Day_11 = 857;

		public static ItemData Lunar2026_F2P_Token_Day_12 = 858;

		public static ItemData Lunar2026_F2P_Token_Day_13 = 859;

		public static ItemData Lunar2026_F2P_Token_Day_14 = 860;

		public static ItemData Lunar2026_F2P_Token_Day_2 = 848;

		public static ItemData Lunar2026_F2P_Token_Day_3 = 849;

		public static ItemData Lunar2026_F2P_Token_Day_4 = 850;

		public static ItemData Lunar2026_F2P_Token_Day_5 = 851;

		public static ItemData Lunar2026_F2P_Token_Day_6 = 852;

		public static ItemData Lunar2026_F2P_Token_Day_7 = 853;

		public static ItemData Lunar2026_F2P_Token_Day_8 = 854;

		public static ItemData Lunar2026_F2P_Token_Day_9 = 855;

		public static ItemData Lunar2026_PREM_Exchange_Day_1 = 889;

		public static ItemData Lunar2026_PREM_Exchange_Day_10 = 898;

		public static ItemData Lunar2026_PREM_Exchange_Day_11 = 899;

		public static ItemData Lunar2026_PREM_Exchange_Day_12 = 900;

		public static ItemData Lunar2026_PREM_Exchange_Day_13 = 901;

		public static ItemData Lunar2026_PREM_Exchange_Day_14 = 902;

		public static ItemData Lunar2026_PREM_Exchange_Day_2 = 890;

		public static ItemData Lunar2026_PREM_Exchange_Day_3 = 891;

		public static ItemData Lunar2026_PREM_Exchange_Day_4 = 892;

		public static ItemData Lunar2026_PREM_Exchange_Day_5 = 893;

		public static ItemData Lunar2026_PREM_Exchange_Day_6 = 894;

		public static ItemData Lunar2026_PREM_Exchange_Day_7 = 895;

		public static ItemData Lunar2026_PREM_Exchange_Day_8 = 896;

		public static ItemData Lunar2026_PREM_Exchange_Day_9 = 897;

		public static ItemData Lunar2026_PREM_Token_Day_1 = 875;

		public static ItemData Lunar2026_PREM_Token_Day_10 = 884;

		public static ItemData Lunar2026_PREM_Token_Day_11 = 885;

		public static ItemData Lunar2026_PREM_Token_Day_12 = 886;

		public static ItemData Lunar2026_PREM_Token_Day_13 = 887;

		public static ItemData Lunar2026_PREM_Token_Day_14 = 888;

		public static ItemData Lunar2026_PREM_Token_Day_2 = 876;

		public static ItemData Lunar2026_PREM_Token_Day_3 = 877;

		public static ItemData Lunar2026_PREM_Token_Day_4 = 878;

		public static ItemData Lunar2026_PREM_Token_Day_5 = 879;

		public static ItemData Lunar2026_PREM_Token_Day_6 = 880;

		public static ItemData Lunar2026_PREM_Token_Day_7 = 881;

		public static ItemData Lunar2026_PREM_Token_Day_8 = 882;

		public static ItemData Lunar2026_PREM_Token_Day_9 = 883;

		public static ItemData Mad_Anger = 283;

		public static ItemData Mad_Tattoo_Cat = 835;

		public static ItemData Majestic_Mercat = 424;

		public static ItemData ManualToken = 96;

		public static ItemData Many_Hearts = 358;

		public static ItemData Mark_Check_Emoji = 495;

		public static ItemData Mark_Circle_Emoji = 496;

		public static ItemData Mark_Cross_Emoji = 497;

		public static ItemData Mark_Exclamation_Emoji = 553;

		public static ItemData Mark_Interrobang_Emoji = 554;

		public static ItemData Mark_Question_Emoji = 555;

		public static ItemData Mecha_DLC_Bundle = 947;

		public static ItemData Mecha_Exchange = 792;

		public static ItemData Mechas2026_Reward_Token = 791;

		public static ItemData Medium_Health = 359;

		public static ItemData Medusa_Snakes = 181;

		public static ItemData Melon_Hat = 259;

		public static ItemData Melting_Hot = 425;

		public static ItemData Messenger_Snow_Owl = 724;

		public static ItemData Midnight = 307;

		public static ItemData Midnight_Demon = 403;

		public static ItemData Mighty_Golden_Crown = 284;

		public static ItemData Mistletoe = 762;

		public static ItemData Monarch_Butterfly_Wings = 584;

		public static ItemData Monster_Bone_Greatsword = 360;

		public static ItemData Monster_Bone_Spear = 361;

		public static ItemData Moose_Antlers = 725;

		public static ItemData Mouse_Burrow = 329;

		public static ItemData Mouse_Power_Up = 362;

		public static ItemData Mouse_With_Pen = 182;

		public static ItemData Mr_Nuts = 442;

		public static ItemData Multiplayer_Reward_Token = 91;

		public static ItemData Muscle = 404;

		public static ItemData Mushroom_Hat = 183;

		public static ItemData Musketeer_Hat = 260;

		public static ItemData Mystic_Butterfly = 184;

		public static ItemData Nature_Air_Emoji = 498;

		public static ItemData Nature_Sakura_Blossom_Emoji = 499;

		public static ItemData New_Years_Fire_Work = 823;

		public static ItemData Nicolas_Mitre = 738;

		public static ItemData Noodles = 185;

		public static ItemData Nosfergato = 590;

		public static ItemData Nosfergato_Exchange = 81;

		public static ItemData Nutcracker = 775;

		public static ItemData Nutcracker_Figure = 763;

		public static ItemData Nyaa = 285;

		public static ItemData Object_Banana_Peel_Emoji = 500;

		public static ItemData Object_Baseball_Bat_Emoji = 501;

		public static ItemData On_Fire = 803;

		public static ItemData Onsen_Towel = 363;

		public static ItemData Orange = 286;

		public static ItemData Orange_Beret_Cap = 186;

		public static ItemData Orange_Cat = 308;

		public static ItemData Orange_Patterned = 309;

		public static ItemData Orange_Snowboard = 726;

		public static ItemData Orange_Tang_Suit = 836;

		public static ItemData Orange_White = 304;

		public static ItemData Outlaw = 405;

		public static ItemData Paddle = 443;

		public static ItemData Paint = 230;

		public static ItemData Paint_Brush = 261;

		public static ItemData Panda = 231;

		public static ItemData Paper_Bag = 364;

		public static ItemData Paper_Boat = 187;

		public static ItemData Patterned_Calico = 406;

		public static ItemData Patterned_Christmas_Scarf = 776;

		public static ItemData Paw_Patterned_Christmas_Sweater = 751;

		public static ItemData Paw_Thumbs_Up_Emoji = 502;

		public static ItemData Paw_Ushanka = 365;

		public static ItemData Paw_Wave_Emoji = 503;

		public static ItemData Peach = 287;

		public static ItemData Penguin = 713;

		public static ItemData Peppermint_Sweet_Tooth = 752;

		public static ItemData Peppermint_Tea_Bag = 727;

		public static ItemData Pet_Bat = 593;

		public static ItemData Pickle_Jar = 188;

		public static ItemData Pierced_Target_Apple = 189;

		public static ItemData Pineapple = 262;

		public static ItemData Pineapple_Exchange = 92;

		public static ItemData Pineapple_Fusion = 444;

		public static ItemData Pineapple_Leaves = 449;

		public static ItemData Pinhata = 407;

		public static ItemData Pink_Ribbon = 122;

		public static ItemData Pixel = 232;

		public static ItemData Pixel_Hat = 263;

		public static ItemData Pleased_Panda = 837;

		public static ItemData Plunger = 190;

		public static ItemData Poison_Cloud = 366;

		public static ItemData Poisoned = 408;

		public static ItemData Polar_Bear = 714;

		public static ItemData Porcelain = 233;

		public static ItemData Poseidon = 452;

		public static ItemData Princess_Hat = 191;

		public static ItemData Propeller_Hat = 192;

		public static ItemData Pumkin_Spice_Latte = 579;

		public static ItemData Pumpkin = 193;

		public static ItemData Pumpkin_Pie = 580;

		public static ItemData Punk_Hair = 194;

		public static ItemData Purple_Party_Hat = 101;

		public static ItemData Purple_Rope_Obi = 367;

		public static ItemData Purple_Wizard_Hat = 116;

		public static ItemData Pyjama_Hat = 195;

		public static ItemData Rain_Boots = 568;

		public static ItemData Rain_Hat = 581;

		public static ItemData Rainbow = 234;

		public static ItemData Rainbow_Clouds = 368;

		public static ItemData Rainbow_Hair = 264;

		public static ItemData Ranged_Mecha_L_A_S_E_R = 788;

		public static ItemData Rare_Cosmetics_Exchange = 18;

		public static ItemData Rare_Emote_Exchange = 32;

		public static ItemData Rare_Emote_Generator = 27;

		public static ItemData Rare_Generator = 13;

		public static ItemData Red_Award_Ribbon = 369;

		public static ItemData Red_Chinese_Knot = 824;

		public static ItemData Red_Christmas_Tree_Ornament = 739;

		public static ItemData Red_Fan_Lady = 838;

		public static ItemData Red_Fire_Horse_Envelope = 804;

		public static ItemData Red_Flat_Cavalier_Hat = 370;

		public static ItemData Red_Foal_Mane = 805;

		public static ItemData Red_Gift_Ribbon = 740;

		public static ItemData Red_Gnome_Hat = 196;

		public static ItemData Red_Hanfu = 839;

		public static ItemData Red_Jester_Hat = 197;

		public static ItemData Red_Mandarin_Hat = 825;

		public static ItemData Red_Nosed_Reindeer = 777;

		public static ItemData Red_Origami_Horse = 806;

		public static ItemData Red_Painter_Beret = 198;

		public static ItemData Red_Panda = 235;

		public static ItemData Red_Panda_Baby = 265;

		public static ItemData Red_Pirate_Bandana = 199;

		public static ItemData Red_Plaid_Flannel = 569;

		public static ItemData Red_Scarf = 570;

		public static ItemData Red_Tang_Suit = 840;

		public static ItemData Red_Tophat = 114;

		public static ItemData Red_Valentine_s_Glasses = 793;

		public static ItemData Red_War_Samurai_Helmet = 289;

		public static ItemData Red_Yarn_Bun = 200;

		public static ItemData Reindeer_Party_Headband = 741;

		public static ItemData Ribbit_Rampage_Chant = 934;

		public static ItemData Ribbon_Dancer = 841;

		public static ItemData Rice_Cake_Stack = 826;

		public static ItemData Rice_Hat = 201;

		public static ItemData Roast_Chicken_Hat = 371;

		public static ItemData Robin_Hood_Hat = 202;

		public static ItemData Robot = 236;

		public static ItemData Robot_Antenna = 266;

		public static ItemData Rocket_Consumable = 903;

		public static ItemData Rubber_Duck = 203;

		public static ItemData Rubix_Cube = 267;

		public static ItemData Sailor_Hat = 268;

		public static ItemData Sakura_Lucky_Cat = 843;

		public static ItemData Sand = 426;

		public static ItemData Sandcastle = 438;

		public static ItemData Santa = 778;

		public static ItemData Santa_Hat = 204;

		public static ItemData Santas_Helper_Bingle = 779;

		public static ItemData Santas_Helper_Bongle = 753;

		public static ItemData Santas_Helper_Elf_Hat = 764;

		public static ItemData Santas_Overflowing_Sack = 765;

		public static ItemData Satanic_Incarnation = 205;

		public static ItemData Scheming_Lucky_Cat = 844;

		public static ItemData Shark = 409;

		public static ItemData Shiba_Inu = 410;

		public static ItemData Shooting_Star = 766;

		public static ItemData Silent_Paw_Ninja = 290;

		public static ItemData Silly_Pinwheel_Cap = 206;

		public static ItemData Silly_Post_It = 330;

		public static ItemData Simple_Silver_Tiara = 207;

		public static ItemData Six_Seven_Lives_Chant = 935;

		public static ItemData Skeleton = 411;

		public static ItemData Sketch = 322;

		public static ItemData Skull = 269;

		public static ItemData Small_Birthday_Cake = 208;

		public static ItemData Smaller_Cat = 209;

		public static ItemData Smoking_Brain = 372;

		public static ItemData Snorkel = 439;

		public static ItemData Snow_Fox = 715;

		public static ItemData Snow_Mittens = 717;

		public static ItemData Snowball_Hit = 728;

		public static ItemData Snowflake_Pin = 729;

		public static ItemData Snowman = 716;

		public static ItemData Snug_Purple_Wizard_Hat = 292;

		public static ItemData Soda = 270;

		public static ItemData Soul = 412;

		public static ItemData Special_Red_Horse = 814;

		public static ItemData Sphynx = 413;

		public static ItemData Splashing_Shark = 373;

		public static ItemData Spooky_Skeleton = 594;

		public static ItemData Spooky_Surprise = 293;

		public static ItemData Sporty_Rainbow_Glasses = 595;

		public static ItemData Spring_Flower_Crown = 210;

		public static ItemData Squirrel_DLC_Bundle = 945;

		public static ItemData Squishy_Red_Squid = 211;

		public static ItemData Starfish = 440;

		public static ItemData Stern_Racoon = 571;

		public static ItemData Stinky_Poop = 212;

		public static ItemData Stocking_Sock = 767;

		public static ItemData Strawberry_Exchange = 93;

		public static ItemData Strawberry_Fusion = 446;

		public static ItemData Strawberry_Hat = 213;

		public static ItemData Strawberry_Leaves = 445;

		public static ItemData Strawhat = 214;

		public static ItemData Streamers = 317;

		public static ItemData Striped_Dawn = 414;

		public static ItemData Striped_Dusk = 415;

		public static ItemData Stuck_Elf_Party_Headband = 742;

		public static ItemData Stunted = 416;

		public static ItemData Sun_Glow = 428;

		public static ItemData Sunburned = 427;

		public static ItemData Sunflower = 374;

		public static ItemData Sweaty = 429;

		public static ItemData Symbol_Hundred_Points_Emoji = 504;

		public static ItemData Symbol_Musical_Note_Purple_Emoji = 556;

		public static ItemData Symbol_Musical_Note_Yellow_Emoji = 505;

		public static ItemData Symbol_Prohibited_Emoji = 557;

		public static ItemData Symbol_Sleep_Emoji = 558;

		public static ItemData Symbol_Sparkle_Emoji = 927;

		public static ItemData Symbol_Speech_Bubble_Emoji = 559;

		public static ItemData Symbol_Thought_Bubble_Emoji = 560;

		public static ItemData Tank_Mecha_B_O_N_K = 789;

		public static ItemData Tap_Tap_Bunny = 940;

		public static ItemData Tap_Tap_Bunny_Ears = 943;

		public static ItemData Tap_Tap_Glasses = 905;

		public static ItemData Tap_Tap_Goo_Cat = 941;

		public static ItemData Tap_Tap_Grey_Calico = 942;

		public static ItemData Tap_Tap_Helmet = 780;

		public static ItemData Tap_Tap_Jester_Hat = 944;

		public static ItemData Tap_Tap_Orange_Calico = 904;

		public static ItemData Tap_Tap_Tabby = 781;

		public static ItemData Teapot = 271;

		public static ItemData The_Berlin_Apartment_Birdie = 602;

		public static ItemData Tic_Tac_Toe = 318;

		public static ItemData Tin_Foil_Hat = 331;

		public static ItemData Tiny_Cowboy_Hat = 215;

		public static ItemData Tiny_Yellow_Butterfly = 216;

		public static ItemData Toilet_Paper = 217;

		public static ItemData Top_Hat = 218;

		public static ItemData Torch_Bearer = 815;

		public static ItemData Toy_Locomotive = 754;

		public static ItemData Traffic_Cone = 219;

		public static ItemData Triple_Hat = 375;

		public static ItemData Trumpet = 319;

		public static ItemData Turnbound = 604;

		public static ItemData Turnbound_Exchange = 73;

		public static ItemData TurnboundDemoToken = 72;

		public static ItemData Tuxedo = 417;

		public static ItemData Twisted = 323;

		public static ItemData Typing_Farmer_Chick = 938;

		public static ItemData Typing_Farmer_Cow = 939;

		public static ItemData Typing_Farmer_Pig = 953;

		public static ItemData Typing_Farmer_Strawhat = 954;

		public static ItemData Tyrolean_Hat = 294;

		public static ItemData Uncommon_Cosmetics_Exchange = 17;

		public static ItemData Uncommon_Emote_Exchange = 31;

		public static ItemData Uncommon_Emote_Generator = 26;

		public static ItemData Uncommon_Generator = 12;

		public static ItemData Unicorn = 220;

		public static ItemData Ushanka = 376;

		public static ItemData Utter_Confusion = 295;

		public static ItemData Valentine2026_Exchange = 796;

		public static ItemData Valentines2026_Reward_Token = 795;

		public static ItemData Valve = 320;

		public static ItemData Void = 418;

		public static ItemData Waku_Waku = 296;

		public static ItemData Warm_Mulled_Wine = 768;

		public static ItemData Warm_Santa_Hat = 743;

		public static ItemData Watermelon_Exchange = 94;

		public static ItemData Watermelon_Fusion = 448;

		public static ItemData Watermelon_Helmet = 447;

		public static ItemData Wealth_Bag = 827;

		public static ItemData Wealth_Ingot = 828;

		public static ItemData Wet_Suit = 430;

		public static ItemData White_Horned_Samurai_Helmet = 297;

		public static ItemData White_Horse = 816;

		public static ItemData Wiggle_Santa_Party_Headband = 744;

		public static ItemData Windmill = 272;

		public static ItemData Winged_Angelic_Halo = 221;

		public static ItemData Winged_Unicorn = 222;

		public static ItemData Winter_Hat = 223;

		public static ItemData Wisdom_Drummer = 845;

		public static ItemData Witches_Hat = 273;

		public static ItemData Wizard_Hat = 274;

		public static ItemData Wooden_Rocking_Horse = 769;

		public static ItemData Wrestler_Cutie_Punch = 928;

		public static ItemData Wrestler_DLC_Bundle = 951;

		public static ItemData Wrestler_Ribbit_Rampage = 929;

		public static ItemData Wrestler_Six_Seven_Lives = 930;

		public static ItemData Yang = 782;

		public static ItemData Yarn_Ball = 224;

		public static ItemData Yellow_Cyber_Glasses = 377;

		public static ItemData Yellow_Ribbon = 303;

		public static ItemData Yellow_Striped_Scarf = 718;

		public static ItemData Yin = 783;

		public static ItemData Young_Stag_Antlers = 298;

		public static ItemData Yuki_Onna = 719;

		public static ItemData Zero_Hearts = 378;

		public static ItemData Zeus = 451;

		public static ItemData Zombie = 591;

		public static ItemData Zombie_Exchange = 82;
	}

	public static SteamGameServerConfiguration ServerConfiguration = new SteamGameServerConfiguration
	{
		autoInitialise = false,
		autoLogon = false,
		ip = 0u,
		gamePort = 0,
		queryPort = 0,
		spectatorPort = 0,
		serverVersion = "",
		usingGameServerAuthApi = false,
		enableHeartbeats = false,
		supportSpectators = false,
		spectatorServerName = "",
		anonymousServerLogin = false,
		gameServerToken = "",
		isPasswordProtected = false,
		serverName = "",
		gameDescription = "",
		gameDirectory = "",
		isDedicated = false,
		maxPlayerCount = 0,
		botPlayerCount = 0,
		mapName = "",
		gameData = "",
		rulePairs = null
	};

	public static void Initialise()
	{
		Debug.Log($"Initialising for app {3419430u}");
		Events.OnSteamInitialised += HandleInitialised;
		List<InputActionData> list = new List<InputActionData>();
		App.Client.Initialise(3419430u, list.ToArray());
	}

	private static void HandleInitialised()
	{
		Dictionary<string, LeaderboardData> boardMap = new Dictionary<string, LeaderboardData>();
		Dictionary<string, InputActionSetData> setMap = new Dictionary<string, InputActionSetData>();
		Dictionary<string, InputActionData> actionMap = new Dictionary<string, InputActionData>();
		Interface.RaiseOnReady(boardMap, setMap, actionMap);
	}
}
