using System;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[DisallowMultipleComponent]
public class SteamInventoryItemData : MonoBehaviour
{
	public int id;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> mDelegates;

	private SteamInventoryItemDataEvents _mEvents;

	public ItemData Data
	{
		get
		{
			return id;
		}
		set
		{
			id = value.id;
			if (_mEvents != null)
			{
				_mEvents.onChange?.Invoke();
			}
		}
	}

	private void Awake()
	{
		_mEvents = GetComponent<SteamInventoryItemDataEvents>();
	}

	public void ConsumeOne()
	{
		if (!Data.Consume(delegate(InventoryResult result)
		{
			if (result.result != EResult.k_EResultOK)
			{
				if (_mEvents != null)
				{
					_mEvents.onConsumeRequestFailed?.Invoke(result.result);
				}
			}
			else if (_mEvents != null)
			{
				_mEvents.onConsumeRequestComplete?.Invoke(result.items);
			}
		}) && _mEvents != null)
		{
			_mEvents.onConsumeRequestRejected?.Invoke();
		}
	}

	public void ConsumeMany(int quantity)
	{
		if (!Data.Consume(Convert.ToUInt32(quantity), delegate(InventoryResult result)
		{
			if (result.result != EResult.k_EResultOK)
			{
				if (_mEvents != null)
				{
					_mEvents.onConsumeRequestFailed?.Invoke(result.result);
				}
			}
			else if (_mEvents != null)
			{
				_mEvents.onConsumeRequestComplete?.Invoke(result.items);
			}
		}) && _mEvents != null)
		{
			_mEvents.onConsumeRequestRejected?.Invoke();
		}
	}

	public void AddPromo()
	{
		if (!Data.AddPromoItem(HandleAddPromoResults) && _mEvents != null)
		{
			_mEvents.onAddPromoRejected?.Invoke();
		}
	}

	public void GetAll()
	{
		Inventory.Client.GetAllItems();
	}

	public void StartPurchase()
	{
		Data.StartPurchase(delegate(SteamInventoryStartPurchaseResult_t result, bool ioError)
		{
			if (!ioError && result.m_result == EResult.k_EResultOK)
			{
				_mEvents.onPurchaseStarted?.Invoke(result);
			}
			else
			{
				_mEvents.onPurchaseStartFailed?.Invoke(result.m_result);
			}
		});
	}

	private void HandleAddPromoResults(InventoryResult results)
	{
		if (results.result != EResult.k_EResultOK)
		{
			if (_mEvents != null)
			{
				_mEvents.onAddPromoFailed?.Invoke(results.result);
			}
		}
		else if (_mEvents != null)
		{
			_mEvents.onAddPromoComplete?.Invoke(results.items);
		}
	}
}
