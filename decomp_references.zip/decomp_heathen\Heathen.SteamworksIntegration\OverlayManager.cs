using System;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[DisallowMultipleComponent]
public class OverlayManager : MonoBehaviour
{
	public enum ManagedEvents
	{
		JoinGameRequested,
		LobbyInviteAccepted,
		OverlayActivated,
		ServerChangeRequested
	}

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<ManagedEvents> mDelegates;

	[SerializeField]
	private ENotificationPosition notificationPosition = ENotificationPosition.k_EPositionBottomRight;

	[SerializeField]
	private Vector2Int notificationInset = Vector2Int.zero;

	public GameOverlayActivatedEvent evtOverlayActivated;

	public GameLobbyJoinRequestedEvent evtGameLobbyJoinRequested;

	public GameServerChangeRequestedEvent evtGameServerChangeRequested;

	public GameRichPresenceJoinRequestedEvent evtRichPresenceJoinRequested;

	public ENotificationPosition NotificationPosition
	{
		get
		{
			return Overlay.Client.NotificationPosition;
		}
		set
		{
			Overlay.Client.NotificationPosition = value;
		}
	}

	public Vector2Int NotificationInset
	{
		get
		{
			return Overlay.Client.NotificationInset;
		}
		set
		{
			Overlay.Client.NotificationInset = value;
		}
	}

	public bool IsShowing => Overlay.Client.IsShowing;

	public bool IsEnabled => Overlay.Client.IsEnabled;

	private void OnEnable()
	{
		Interface.WhenReady(EnabledProcess);
	}

	private void EnabledProcess()
	{
		NotificationPosition = notificationPosition;
		NotificationInset = notificationInset;
		Events.OnGameOverlayActivated += evtOverlayActivated.Invoke;
		Events.OnGameServerChangeRequested += evtGameServerChangeRequested.Invoke;
		Events.OnLobbyJoinRequested += evtGameLobbyJoinRequested.Invoke;
		Events.OnRichPresenceJoinRequested += evtRichPresenceJoinRequested.Invoke;
	}

	private void OnDisable()
	{
		Events.OnGameOverlayActivated -= evtOverlayActivated.Invoke;
		Events.OnGameServerChangeRequested -= evtGameServerChangeRequested.Invoke;
		Events.OnLobbyJoinRequested -= evtGameLobbyJoinRequested.Invoke;
		Events.OnRichPresenceJoinRequested -= evtRichPresenceJoinRequested.Invoke;
	}

	public void OpenDialogName(string dialog)
	{
		Overlay.Client.Activate(dialog);
	}

	public void OpenDialog(OverlayDialog dialog)
	{
		Overlay.Client.Activate(dialog);
	}

	public void OpenLobbyInvite(LobbyData lobbyId)
	{
		Overlay.Client.ActivateInviteDialog(lobbyId);
	}

	public void OpenLobbyInvite(SteamLobbyData lobby)
	{
		if (lobby != null && lobby.Data.IsValid)
		{
			Overlay.Client.ActivateInviteDialog(lobby.Data);
		}
	}

	public void OpenConnectStringInvite(string connectionString)
	{
		Overlay.Client.ActivateInviteDialog(connectionString);
	}

	public void OpenRemotePlayInvite(LobbyData lobbyId)
	{
		Overlay.Client.ActivateRemotePlayInviteDialog(lobbyId);
	}

	public void OpenRemotePlayInvite(SteamLobbyData lobby)
	{
		if (lobby != null && lobby.Data.IsValid)
		{
			Overlay.Client.ActivateRemotePlayInviteDialog(lobby.Data);
		}
	}

	public void OpenStore(int appId)
	{
		OpenStore(Convert.ToUInt32(appId), EOverlayToStoreFlag.k_EOverlayToStoreFlag_None);
	}

	public void OpenStoreAddToCart(int appId)
	{
		OpenStore(Convert.ToUInt32(appId), EOverlayToStoreFlag.k_EOverlayToStoreFlag_AddToCart);
	}

	public void OpenStoreAddToCartAndShow(int appId)
	{
		OpenStore(Convert.ToUInt32(appId), EOverlayToStoreFlag.k_EOverlayToStoreFlag_AddToCartAndShow);
	}

	public void OpenStore(AppData appID, EOverlayToStoreFlag flag)
	{
		Overlay.Client.Activate(appID, flag);
	}

	public void OpenUserProfile(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("steamid", user.Data);
		}
	}

	public void OpenUserChat(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("chat", user.Data);
		}
	}

	public void OpenUserJoinTrade(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("jointrade", user.Data);
		}
	}

	public void OpenUserStats(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("stats", user.Data);
		}
	}

	public void OpenUserAchievements(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("achievements", user.Data);
		}
	}

	public void OpenUserAddFriend(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("friendadd", user.Data);
		}
	}

	public void OpenUserRemoveFriend(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("friendremove", user.Data);
		}
	}

	public void OpenUserAcceptFriendRequest(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("friendrequestaccept", user.Data);
		}
	}

	public void OpenUserIgnoreFriendRequest(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Overlay.Client.Activate("friendrequestignore", user.Data);
		}
	}

	public void OpenUser(string dialog, CSteamID steamId)
	{
		Overlay.Client.Activate(dialog, steamId);
	}

	public void OpenUser(FriendDialog dialog, CSteamID steamId)
	{
		Overlay.Client.Activate(dialog.ToString(), steamId);
	}

	public void OpenWebPage(string url)
	{
		Overlay.Client.ActivateWebPage(url);
	}
}
