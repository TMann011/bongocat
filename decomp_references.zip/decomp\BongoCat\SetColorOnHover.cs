using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace BongoCat;

public class SetColorOnHover : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
{
	[SerializeField]
	private Image _image;

	[SerializeField]
	private Color _hoverColor;

	private Color _defaultColor;

	private void Awake()
	{
		if ((object)_image == null)
		{
			_image = GetComponent<Image>();
		}
		_defaultColor = _image.color;
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		_image.color = _hoverColor;
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		_image.color = _defaultColor;
	}
}
