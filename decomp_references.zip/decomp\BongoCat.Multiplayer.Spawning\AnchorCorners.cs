namespace BongoCat.Multiplayer.Spawning;

public enum AnchorCorners
{
	TopLeft,
	TopRight,
	BottomLeft,
	BottomRight,
	Center
}
