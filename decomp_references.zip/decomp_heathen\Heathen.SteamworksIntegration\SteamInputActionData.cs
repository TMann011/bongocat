using System.Collections.Generic;
using SteamTools;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamInputActionData : MonoBehaviour
{
	[SerializeField]
	private string setName;

	[SerializeField]
	private string layerName;

	[SerializeField]
	private string actionName;

	private InputActionSetData _mSet;

	private InputActionSetLayerData _mLayer;

	private InputActionData _mAction;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> mDelegates;

	public InputActionSetData Set
	{
		get
		{
			return _mSet;
		}
		set
		{
			_mSet = value;
		}
	}

	public InputActionSetLayerData Layer
	{
		get
		{
			return _mLayer;
		}
		set
		{
			_mLayer = value;
		}
	}

	public InputActionData Action
	{
		get
		{
			return _mAction;
		}
		set
		{
			_mAction = value;
		}
	}

	private void Start()
	{
		if (Interface.IsReady)
		{
			Interface_OnReady();
		}
		else
		{
			Interface.OnReady += Interface_OnReady;
		}
	}

	private void Interface_OnReady()
	{
		Interface.OnReady -= Interface_OnReady;
		_mSet = Interface.GetSet(layerName);
		_mLayer = new InputActionSetLayerData
		{
			LayerName = layerName
		};
		_mAction = Interface.GetAction(actionName);
	}
}
