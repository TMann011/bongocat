using System;
using UnityEngine.Localization;
using UnityEngine.Localization.Tables;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct SteamText(string value)
{
	[FormerlySerializedAs("localized")]
	[FormerlySerializedAs("Localized")]
	public LocalizedString localised = new LocalizedString();

	[FormerlySerializedAs("default")]
	[FormerlySerializedAs("Default")]
	public string defaultText = value;

	public string Get()
	{
		if (localised == null || localised.TableReference.ReferenceType == TableReference.Type.Empty || localised.TableEntryReference.ReferenceType == TableEntryReference.Type.Empty)
		{
			return defaultText;
		}
		string localizedString = localised.GetLocalizedString();
		if (!string.IsNullOrEmpty(localizedString))
		{
			return localizedString;
		}
		return defaultText;
	}

	public override string ToString()
	{
		return Get();
	}

	public static implicit operator string(SteamText l)
	{
		return l.Get();
	}
}
