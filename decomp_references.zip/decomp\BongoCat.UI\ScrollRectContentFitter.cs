using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.UI;

[RequireComponent(typeof(ScrollRect))]
public class ScrollRectContentFitter : MonoBehaviour, ILayoutElement
{
	private ScrollRect _scrollRect;

	private ScrollRect ScrollRect
	{
		get
		{
			if (!_scrollRect)
			{
				return _scrollRect = GetComponent<ScrollRect>();
			}
			return _scrollRect;
		}
	}

	public float minWidth => -1f;

	public float preferredWidth => -1f;

	public float flexibleWidth => -1f;

	public float minHeight => 0f;

	public float preferredHeight
	{
		get
		{
			if (!ScrollRect.content)
			{
				return 0f;
			}
			return LayoutUtility.GetPreferredHeight(ScrollRect.content);
		}
	}

	public float flexibleHeight => -1f;

	public int layoutPriority => 1;

	public void CalculateLayoutInputHorizontal()
	{
	}

	public void CalculateLayoutInputVertical()
	{
	}
}
