using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;

namespace BongoCat;

public class OnDemandRenderHelper : MonoBehaviour
{
	public static OnDemandRenderHelper Instance;

	private int _renderDemand;

	private bool _canPauseRendering;

	private void Awake()
	{
		Instance = this;
		_renderDemand = 1;
	}

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		TryPauseRendering();
	}

	public void ToggleRenderDemand(bool resume)
	{
		if (resume)
		{
			ResumeRendering();
		}
		else
		{
			TryPauseRendering();
		}
	}

	public void ResumeRenderingForDuration(float duration)
	{
		StartCoroutine(ResumeRenderingForDurationRoutine(duration));
	}

	private IEnumerator ResumeRenderingForDurationRoutine(float duration)
	{
		ResumeRendering();
		yield return new WaitForSeconds(duration);
		TryPauseRendering();
	}

	public void TryPauseRendering()
	{
		_renderDemand = Mathf.Max(0, _renderDemand - 1);
		PauseIfIdle();
	}

	public void ResumeRendering()
	{
		_renderDemand++;
		OnDemandRendering.renderFrameInterval = 1;
	}

	private void PauseIfIdle()
	{
		if (!Application.isEditor && _canPauseRendering && _renderDemand <= 0)
		{
			OnDemandRendering.renderFrameInterval = 100000;
		}
	}

	private void OnApplicationFocus(bool hasFocus)
	{
		_canPauseRendering = !hasFocus;
	}
}
