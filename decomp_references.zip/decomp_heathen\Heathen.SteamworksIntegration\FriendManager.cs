using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[DisallowMultipleComponent]
public class FriendManager : MonoBehaviour
{
	[FormerlySerializedAs("evtGameConnectedChatMsg")]
	public GameConnectedFriendChatMsgEvent onGameConnectedChatMsg;

	[FormerlySerializedAs("evtRichPresenceUpdated")]
	public UnityEvent<UserData, AppData> onRichPresenceUpdated;

	[FormerlySerializedAs("evtPersonaStateChanged")]
	public UnityEvent<UserData, EPersonaChange> onPersonaStateChanged;

	public bool ListenForFriendsMessages
	{
		get
		{
			return Friends.Client.IsListenForFriendsMessages;
		}
		set
		{
			Friends.Client.IsListenForFriendsMessages = value;
		}
	}

	private void OnEnable()
	{
		Events.OnGameConnectedFriendChatMsg += onGameConnectedChatMsg.Invoke;
		Events.OnFriendRichPresenceUpdate += onRichPresenceUpdated.Invoke;
		Events.OnPersonaStateChange += onPersonaStateChanged.Invoke;
	}

	private void OnDisable()
	{
		Events.OnGameConnectedFriendChatMsg -= onGameConnectedChatMsg.Invoke;
		Events.OnFriendRichPresenceUpdate -= onRichPresenceUpdated.Invoke;
		Events.OnPersonaStateChange -= onPersonaStateChanged.Invoke;
	}

	public UserData[] GetFriends(EFriendFlags flags)
	{
		return Friends.Client.GetFriends(flags);
	}

	public UserData[] GetCoplayFriends()
	{
		return Friends.Client.GetCoplayFriends();
	}

	public string GetFriendMessage(UserData userId, int index, out EChatEntryType type)
	{
		return Friends.Client.GetFriendMessage(userId, index, out type);
	}

	public bool SendMessage(UserData friend, string message)
	{
		return Friends.Client.ReplyToFriendMessage(friend, message);
	}
}
