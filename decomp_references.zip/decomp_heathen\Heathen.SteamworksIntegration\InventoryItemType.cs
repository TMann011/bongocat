namespace Heathen.SteamworksIntegration;

public enum InventoryItemType
{
	Item,
	Bundle,
	Generator,
	Playtimegenerator,
	TagGenerator,
	TagTool
}
