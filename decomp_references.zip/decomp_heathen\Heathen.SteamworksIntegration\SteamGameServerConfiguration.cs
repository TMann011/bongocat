using System;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct SteamGameServerConfiguration
{
	[FormerlySerializedAs("autoInitialize")]
	public bool autoInitialise;

	public bool autoLogon;

	public uint ip;

	public ushort gamePort;

	public ushort queryPort;

	public ushort spectatorPort;

	public string serverVersion;

	public bool usingGameServerAuthApi;

	public bool enableHeartbeats;

	public bool supportSpectators;

	public string spectatorServerName;

	public bool anonymousServerLogin;

	public string gameServerToken;

	public bool isPasswordProtected;

	public string serverName;

	public string gameDescription;

	public string gameDirectory;

	public bool isDedicated;

	public int maxPlayerCount;

	public int botPlayerCount;

	public string mapName;

	public string gameData;

	public StringKeyValuePair[] rulePairs;

	public override string ToString()
	{
		return JsonUtility.ToJson(this);
	}
}
