using UnityEngine;

namespace Heathen.SteamworksIntegration;

public class SteamGameServerData : MonoBehaviour
{
	private GameServerData _mData;

	private SteamGameServerEvents _mEvents;

	public GameServerData Data
	{
		get
		{
			return _mData;
		}
		set
		{
			_mData = value;
			if (_mEvents != null)
			{
				_mEvents.onChange?.Invoke();
			}
		}
	}

	private void Awake()
	{
		_mEvents = GetComponent<SteamGameServerEvents>();
	}
}
