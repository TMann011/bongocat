using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct ItemData : IEquatable<ItemData>, IEquatable<int>, IEquatable<SteamItemDef_t>, IComparable<ItemData>, IComparable<int>, IComparable<SteamItemDef_t>
{
	public int id;

	public string Name => Inventory.Client.GetItemDefinitionProperty(new SteamItemDef_t(id), "name");

	public static string CurrencySymbol => Inventory.Client.LocalCurrencySymbol;

	public ulong CurrentPrice
	{
		get
		{
			if (Inventory.Client.GetItemPrice(new SteamItemDef_t(id), out var currentPrice, out var _))
			{
				return currentPrice;
			}
			return 0uL;
		}
	}

	public ulong BasePrice
	{
		get
		{
			if (Inventory.Client.GetItemPrice(new SteamItemDef_t(id), out var _, out var basePrice))
			{
				return basePrice;
			}
			return 0uL;
		}
	}

	public List<ItemDetail> GetDetails()
	{
		return Inventory.Client.Details(this);
	}

	public long GetTotalQuantity()
	{
		return Inventory.Client.ItemTotalQuantity(this);
	}

	public bool AddPromoItem(Action<InventoryResult> callback)
	{
		return Inventory.Client.AddPromoItem(new SteamItemDef_t(id), callback);
	}

	public ConsumeOrder[] GetConsumeOrders(uint quantity)
	{
		List<ItemDetail> details = GetDetails();
		if (((IEnumerable<ItemDetail>)details).Sum((Func<ItemDetail, long>)((ItemDetail p) => p.Quantity)) < quantity)
		{
			return null;
		}
		List<ConsumeOrder> list = new List<ConsumeOrder>();
		uint num = 0u;
		int index = 0;
		while (num < quantity)
		{
			uint num2 = (uint)Mathf.Min((int)details[index].Quantity, quantity - num);
			num += num2;
			list.Add(new ConsumeOrder
			{
				Detail = details[index].ItemDetails,
				Quantity = num2
			});
		}
		return list.ToArray();
	}

	public bool Consume(Action<InventoryResult> callback)
	{
		List<ItemDetail> details = GetDetails();
		if (((IEnumerable<ItemDetail>)details).Sum((Func<ItemDetail, long>)((ItemDetail p) => p.Quantity)) < 1)
		{
			return false;
		}
		Inventory.Client.ConsumeItem(details.First((ItemDetail p) => p.Quantity > 0).ItemDetails.m_itemId, 1u, callback);
		return true;
	}

	public bool Consume(uint quantity, Action<InventoryResult> callback)
	{
		ConsumeOrder[] orders = GetConsumeOrders(quantity);
		if (orders == null || orders.Length < 1)
		{
			return false;
		}
		List<ItemDetail> details = new List<ItemDetail>();
		ConsumeOrder[] array = orders;
		for (int i = 0; i < array.Length; i++)
		{
			ConsumeOrder consumeOrder = array[i];
			Inventory.Client.ConsumeItem(consumeOrder.Detail.m_itemId, consumeOrder.Quantity, delegate(InventoryResult r)
			{
				if (r.result == EResult.k_EResultOK)
				{
					details.AddRange(r.items);
					if (details.Count >= orders.Sum((ConsumeOrder o) => o.Quantity))
					{
						callback?.Invoke(new InventoryResult
						{
							result = EResult.k_EResultOK,
							items = details.ToArray()
						});
					}
				}
			});
		}
		return true;
	}

	public bool GetExchangeEntry(uint quantity, out ExchangeEntry[] entries)
	{
		List<ItemDetail> details = GetDetails();
		if (((IEnumerable<ItemDetail>)details).Sum((Func<ItemDetail, long>)((ItemDetail p) => p.Quantity)) < quantity)
		{
			entries = Array.Empty<ExchangeEntry>();
			return false;
		}
		List<ExchangeEntry> list = new List<ExchangeEntry>();
		uint num = 0u;
		int num2 = 0;
		while (num < quantity)
		{
			if (details[num2].Quantity <= quantity - num)
			{
				if (details[num2].Quantity > 0)
				{
					list.Add(new ExchangeEntry
					{
						Instance = details[num2].ItemId,
						Quantity = details[num2].Quantity
					});
					num += details[num2].Quantity;
				}
			}
			else if (details[num2].Quantity > 0)
			{
				uint num3 = quantity - num;
				list.Add(new ExchangeEntry
				{
					Instance = details[num2].ItemId,
					Quantity = num3
				});
				num += num3;
			}
			num2++;
		}
		entries = list.ToArray();
		return true;
	}

	public void Exchange(IEnumerable<ExchangeEntry> recipeEntries, Action<InventoryResult> callback)
	{
		ExchangeEntry[] array = recipeEntries.ToArray();
		SteamItemInstanceID_t[] array2 = new SteamItemInstanceID_t[array.Length];
		uint[] array3 = new uint[array.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array2[i] = array[i].Instance;
			array3[i] = array[i].Quantity;
		}
		Inventory.Client.ExchangeItems(new SteamItemDef_t(id), array2, array3, callback);
	}

	public void GenerateItem(Action<InventoryResult> callback)
	{
		Inventory.Client.GenerateItems(new SteamItemDef_t[1]
		{
			new SteamItemDef_t(id)
		}, new uint[1] { 1u }, callback);
	}

	public void StartPurchase(Action<SteamInventoryStartPurchaseResult_t, bool> callback)
	{
		Inventory.Client.StartPurchase(new SteamItemDef_t[1]
		{
			new SteamItemDef_t(id)
		}, new uint[1] { 1u }, callback);
	}

	public string CurrentPriceString()
	{
		NumberFormatInfo numberFormatInfo = (NumberFormatInfo)CultureInfo.CurrentCulture.NumberFormat.Clone();
		numberFormatInfo.CurrencySymbol = CurrencySymbol;
		return ((double)CurrentPrice / 100.0).ToString("c", numberFormatInfo);
	}

	public string BasePriceString()
	{
		NumberFormatInfo numberFormatInfo = (NumberFormatInfo)CultureInfo.CurrentCulture.NumberFormat.Clone();
		numberFormatInfo.CurrencySymbol = CurrencySymbol;
		return ((double)BasePrice / 100.0).ToString("c", numberFormatInfo);
	}

	public int CompareTo(ItemData other)
	{
		int num = id;
		return num.CompareTo(other.id);
	}

	public int CompareTo(int other)
	{
		int num = id;
		return num.CompareTo(other);
	}

	public int CompareTo(SteamItemDef_t other)
	{
		int num = id;
		return num.CompareTo(other.m_SteamItemDef);
	}

	public bool Equals(ItemData other)
	{
		int num = id;
		return num.Equals(other.id);
	}

	public bool Equals(int other)
	{
		int num = id;
		return num.Equals(other);
	}

	public bool Equals(SteamItemDef_t other)
	{
		int num = id;
		return num.Equals(other.m_SteamItemDef);
	}

	public override bool Equals(object obj)
	{
		int num = id;
		return num.Equals(obj);
	}

	public override int GetHashCode()
	{
		int num = id;
		return num.GetHashCode();
	}

	public static bool operator ==(ItemData l, ItemData r)
	{
		return l.id == r.id;
	}

	public static implicit operator ItemData(int id)
	{
		return new ItemData
		{
			id = id
		};
	}

	public static implicit operator SteamItemDef_t(ItemData c)
	{
		return new SteamItemDef_t(c.id);
	}

	public static implicit operator ItemData(SteamItemDef_t id)
	{
		return new ItemData
		{
			id = id.m_SteamItemDef
		};
	}
}
