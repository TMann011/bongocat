using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

public class SteamInputManager : MonoBehaviour
{
	public static SteamInputManager Current;

	[Tooltip("If set to true then we will attempt to force Steam to use input for this app on start.\nThis is generally only needed in editor testing.")]
	[SerializeField]
	private bool forceInput = true;

	[Tooltip("If set to true the system will update every input action every frame for every controller found")]
	public bool autoUpdate = true;

	public ControllerDataEvent onInputDataChanged;

	private bool _lastAutoUpdate;

	public static bool AutoUpdate
	{
		get
		{
			if ((bool)Current)
			{
				return Current.autoUpdate;
			}
			return false;
		}
		set
		{
			if (Current != null)
			{
				Current.autoUpdate = value;
			}
		}
	}

	public static List<InputControllerStateData> Controllers { get; private set; } = new List<InputControllerStateData>();

	private void Start()
	{
		Current = this;
		Events.OnInputDataChanged += onInputDataChanged.Invoke;
		Heathen.SteamworksIntegration.API.Input.Client.IsAutoRefreshControllerState = autoUpdate;
		_lastAutoUpdate = autoUpdate;
		if (!Interface.IsReady)
		{
			Interface.OnReady += HandleInitialization;
		}
		else
		{
			HandleInitialization();
		}
	}

	private void HandleInitialization()
	{
		Interface.OnReady -= HandleInitialization;
		if (forceInput)
		{
			Application.OpenURL($"steam://forceinputappid/{App.Id}");
		}
	}

	private void OnDestroy()
	{
		if (Current == this)
		{
			Current = null;
		}
		Events.OnInputDataChanged -= onInputDataChanged.Invoke;
		if (forceInput)
		{
			Application.OpenURL("steam://forceinputappid/0");
		}
	}

	private void LateUpdate()
	{
		if (Interface.IsReady)
		{
			if (Heathen.SteamworksIntegration.API.Input.Client.IsAutoRefreshControllerState != autoUpdate)
			{
				Heathen.SteamworksIntegration.API.Input.Client.IsAutoRefreshControllerState = autoUpdate;
			}
			if (_lastAutoUpdate != Heathen.SteamworksIntegration.API.Input.Client.IsAutoRefreshControllerState)
			{
				_lastAutoUpdate = Heathen.SteamworksIntegration.API.Input.Client.IsAutoRefreshControllerState;
				autoUpdate = _lastAutoUpdate;
			}
			if (autoUpdate)
			{
				Heathen.SteamworksIntegration.API.Input.Client.RunFrame();
			}
		}
	}

	public void Refresh()
	{
		Heathen.SteamworksIntegration.API.Input.Client.RunFrame();
	}
}
