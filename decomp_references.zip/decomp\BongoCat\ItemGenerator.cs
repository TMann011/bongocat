using System.Collections;
using Heathen.SteamworksIntegration;
using SteamTools;
using UnityEngine;

namespace BongoCat;

public class ItemGenerator : MonoBehaviour
{
	[SerializeField]
	private int _itemGenAmount = 100;

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => Interface.IsReady);
		for (int i = 0; i < _itemGenAmount; i++)
		{
			((ItemData)Random.Range(200, 800)).GenerateItem(delegate
			{
			});
			if (i % 50 == 0)
			{
				yield return new WaitForSeconds(3f);
			}
		}
		Debug.Log("ItemGeneration Done");
	}
}
