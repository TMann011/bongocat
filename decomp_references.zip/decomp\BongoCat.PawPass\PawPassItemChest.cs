using BongoCat.SteamJsonParser;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassItemChest : PawPassItemCosmetic
{
	[SerializeField]
	private Image _outline;

	[SerializeField]
	private Image _outlineColor;

	public override void FillContent(PawPassMilestone pawPassMilestone)
	{
		FillContent(pawPassMilestone.Items[0]);
	}

	public override void FillContent(PawPassMilestoneItem pawPassMilestoneItem)
	{
		_cosmetic.sprite = pawPassMilestoneItem.FullImage;
		_outline.sprite = pawPassMilestoneItem.FullImage;
		_outlineColor.color = GetColor(pawPassMilestoneItem.RewardItem);
	}

	private Color GetColor(SteamItemBase rewardItem)
	{
		if (!(rewardItem is SteamGenerator steamGenerator))
		{
			return Color.white;
		}
		return steamGenerator.Quality.GetColor();
	}
}
