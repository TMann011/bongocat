using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Multiplayer.Spawning;

public class SlotPreview : MonoBehaviour
{
	[SerializeField]
	private Graphic _visuals;

	[SerializeField]
	private Color _disabledColor = Color.red;

	public int SlotIndex;

	private Color _enabledColor;

	private void Awake()
	{
		_enabledColor = _visuals.color;
	}

	public void ToggleSlotDisabled()
	{
		CatSpawnManager.Instance.ToggleSlotDisabled(SlotIndex);
	}

	public void SetDisabled(bool disabled)
	{
		Color color = (disabled ? _disabledColor : _enabledColor);
		color.a = _enabledColor.a;
		_visuals.color = color;
	}

	public void FlipVisuals(bool flipped)
	{
		Vector3 localScale = base.gameObject.transform.localScale;
		base.gameObject.transform.localScale = new Vector3(Mathf.Abs(localScale.x) * (float)((!flipped) ? 1 : (-1)), localScale.y, localScale.z);
	}
}
