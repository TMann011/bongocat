using System;
using Heathen.SteamworksIntegration.API;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct AchievementData : IEquatable<AchievementData>, IEquatable<string>, IComparable<AchievementData>, IComparable<string>
{
	[SerializeField]
	private string id;

	public string ApiName => id;

	public bool IsAchieved
	{
		set
		{
			if (value)
			{
				StatsAndAchievements.Client.SetAchievement(id);
			}
			else
			{
				StatsAndAchievements.Client.ClearAchievement(id);
			}
		}
	}

	public void Unlock()
	{
		IsAchieved = true;
	}

	public void Clear()
	{
		IsAchieved = false;
	}

	public void Store()
	{
		StatsAndAchievements.Client.StoreStats();
	}

	public override string ToString()
	{
		if (!string.IsNullOrEmpty(id))
		{
			return id;
		}
		return string.Empty;
	}

	public bool Equals(string other)
	{
		return id.Equals(other);
	}

	public bool Equals(AchievementData other)
	{
		return id.Equals(other.id);
	}

	public override bool Equals(object obj)
	{
		return id.Equals(obj);
	}

	public override int GetHashCode()
	{
		return id.GetHashCode();
	}

	public int CompareTo(AchievementData other)
	{
		return string.Compare(id, other.id, StringComparison.Ordinal);
	}

	public int CompareTo(string other)
	{
		return string.Compare(id, other, StringComparison.Ordinal);
	}

	public static implicit operator AchievementData(string id)
	{
		return new AchievementData
		{
			id = id
		};
	}
}
