using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLeaderboardData))]
[RequireComponent(typeof(SteamLeaderboardDataEvents))]
public class SteamLeaderboardRank : MonoBehaviour
{
	public TextMeshProUGUI label;

	private SteamLeaderboardData _inspector;

	private SteamLeaderboardDataEvents _events;

	private void Awake()
	{
		_inspector = GetComponent<SteamLeaderboardData>();
		_events = GetComponent<SteamLeaderboardDataEvents>();
		if (_events != null)
		{
			_events.onChange?.AddListener(HandleOnChanged);
			_events.onRankChanged?.AddListener(HandleRankChange);
		}
		if (!_inspector.Data.IsValid)
		{
			return;
		}
		_inspector.Data.GetUserEntry(0, delegate(LeaderboardEntry entry, bool ioError)
		{
			if (!ioError && entry != null)
			{
				label.text = entry.Rank.ToString();
			}
			else
			{
				label.text = string.Empty;
			}
		});
	}

	private void OnDestroy()
	{
		if ((bool)_events)
		{
			_events.onChange?.RemoveListener(HandleOnChanged);
			_events.onRankChanged?.RemoveListener(HandleRankChange);
		}
	}

	private void HandleRankChange(LeaderboardScoreUploaded arg0)
	{
		label.text = arg0.GlobalRankNew.ToString();
	}

	private void HandleOnChanged()
	{
		label.text = (_inspector.Data.IsValid ? _inspector.Data.DisplayName : string.Empty);
	}
}
