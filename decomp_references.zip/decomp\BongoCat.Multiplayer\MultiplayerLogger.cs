using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class MultiplayerLogger : MonoBehaviour
{
	public const string PREFIX = "[Multiplayer]";

	private void Start()
	{
		Events.OnSteamInitialised += OnSteamInitialised;
		Events.OnSteamInitialisationError += OnSteamInitialisationError;
		Events.OnNewUrlLaunchParameters += OnNewUrlLaunchParameters;
		Events.OnSteamServersDisconnected += OnSteamServersDisconnected;
		Events.OnSteamServerConnectFailure += OnSteamServerConnectFailure;
		Events.OnSteamServersConnected += OnSteamServersConnected;
		Events.OnGameConnectedChatLeave += OnGameConnectedChatLeave;
		Events.OnGameConnectedClanChatMsg += OnGameConnectedClanChatMsg;
		Events.OnGameConnectedChatJoin += OnGameConnectedChatJoin;
		Events.OnGameConnectedFriendChatMsg += OnGameConnectedFriendChatMsg;
		Events.OnAskedToLeaveLobby += OnAskedToLeaveLobby;
		Events.OnLobbyAuthentication += OnLobbyAuthentication;
		Events.OnLobbyEnterFailed += OnLobbyEnterFailed;
		Events.OnLobbyEnterSuccess += OnLobbyEnterSuccess;
		Events.OnLobbyGameServer += OnLobbyGameServer;
		Events.OnLobbyInvite += OnLobbyInvite;
		Events.OnLobbyLeave += OnLobbyLeave;
		Events.OnLobbyJoinRequested += OnLobbyJoinRequested;
		Events.OnRichPresenceJoinRequested += OnRichPresenceJoinRequested;
		Events.OnActiveBeaconsUpdated += OnActiveBeaconsUpdated;
		Events.OnAvailableBeaconLocationsUpdated += OnAvailableBeaconLocationsUpdated;
		Events.OnReservationNotification += OnReservationNotification;
		Events.OnAppResumeFromSuspend += OnAppResumeFromSuspend;
	}

	private void OnDestroy()
	{
		Events.OnSteamInitialised -= OnSteamInitialised;
		Events.OnSteamInitialisationError -= OnSteamInitialisationError;
		Events.OnNewUrlLaunchParameters -= OnNewUrlLaunchParameters;
		Events.OnSteamServersDisconnected -= OnSteamServersDisconnected;
		Events.OnSteamServerConnectFailure -= OnSteamServerConnectFailure;
		Events.OnSteamServersConnected -= OnSteamServersConnected;
		Events.OnGameConnectedChatLeave -= OnGameConnectedChatLeave;
		Events.OnGameConnectedClanChatMsg -= OnGameConnectedClanChatMsg;
		Events.OnGameConnectedChatJoin -= OnGameConnectedChatJoin;
		Events.OnGameConnectedFriendChatMsg -= OnGameConnectedFriendChatMsg;
		Events.OnAskedToLeaveLobby -= OnAskedToLeaveLobby;
		Events.OnLobbyAuthentication -= OnLobbyAuthentication;
		Events.OnLobbyEnterFailed -= OnLobbyEnterFailed;
		Events.OnLobbyEnterSuccess -= OnLobbyEnterSuccess;
		Events.OnLobbyGameServer -= OnLobbyGameServer;
		Events.OnLobbyInvite -= OnLobbyInvite;
		Events.OnLobbyLeave -= OnLobbyLeave;
		Events.OnLobbyJoinRequested -= OnLobbyJoinRequested;
		Events.OnRichPresenceJoinRequested -= OnRichPresenceJoinRequested;
		Events.OnActiveBeaconsUpdated -= OnActiveBeaconsUpdated;
		Events.OnAvailableBeaconLocationsUpdated -= OnAvailableBeaconLocationsUpdated;
		Events.OnReservationNotification -= OnReservationNotification;
		Events.OnAppResumeFromSuspend -= OnAppResumeFromSuspend;
	}

	private void OnSteamInitialised()
	{
		Debug.Log("[Multiplayer] SteamInitialized");
	}

	private void OnSteamInitialisationError(string message)
	{
		Debug.Log("[Multiplayer] SteamInitialisationError: " + message);
	}

	private void OnNewUrlLaunchParameters()
	{
		Debug.Log("[Multiplayer] NewUrlLaunchParameters");
	}

	private void OnSteamServersDisconnected(EResult result)
	{
		Debug.Log("[Multiplayer] SteamServersDisconnected: " + result);
	}

	private void OnSteamServerConnectFailure(EResult result, bool retrying)
	{
		Debug.Log(string.Format("{0} SteamServerConnectFailure: {1}, Retrying {2}", "[Multiplayer]", result.ToString(), retrying));
	}

	private void OnSteamServersConnected()
	{
		Debug.Log("[Multiplayer] SteamServersConnected");
	}

	private void OnGameConnectedChatLeave(ChatRoom room, UserData user, bool wasKicked, bool wasDropped)
	{
		Debug.Log(string.Format("{0} GameConnectedChatLeave: Room {1}, User {2}, Kicked {3}, Dropped {4}", "[Multiplayer]", room.id, user.Name, wasKicked, wasDropped));
	}

	private void OnGameConnectedClanChatMsg(ChatRoom room, UserData user, string message, EChatEntryType type)
	{
		Debug.Log(string.Format("{0} GameConnectedClanChatMsg: Room {1}, User {2}, {3}, ChatEntryType {4}", "[Multiplayer]", room.id, user.Name, message, type.ToString()));
	}

	private void OnGameConnectedChatJoin(ChatRoom room, UserData user)
	{
		Debug.Log(string.Format("{0} GameConnectedChatJoin: Room {1}, User {2}", "[Multiplayer]", room.id, user.Name));
	}

	private void OnGameConnectedFriendChatMsg(UserData user, string message, EChatEntryType type)
	{
		Debug.Log("[Multiplayer] GameConnectedFriendChatMsg: User " + user.Name + ", " + message + ", ChatEntryType " + type);
	}

	private void OnAskedToLeaveLobby(LobbyData lobby)
	{
		Debug.Log(string.Format("{0} AskedToLeaveLobby: {1}", "[Multiplayer]", lobby));
	}

	private void OnLobbyAuthentication(LobbyData lobby, UserData user, byte[] ticketData, byte[] inventoryData)
	{
		Debug.Log(string.Format("{0} LobbyAuthentication: Lobby {1}, User {2}", "[Multiplayer]", lobby, user.Name));
	}

	private void OnLobbyEnterFailed(LobbyData lobby, EChatRoomEnterResponse result)
	{
		Debug.Log(string.Format("{0} LobbyEnterFailed: Lobby {1}, Result {2}", "[Multiplayer]", lobby, result.ToString()));
	}

	private void OnLobbyEnterSuccess(LobbyData lobby)
	{
		Debug.Log(string.Format("{0} LobbyEnterSuccess: Lobby {1}", "[Multiplayer]", lobby));
	}

	private void OnLobbyGameServer(LobbyData lobby, CSteamID server, string ip, ushort port)
	{
		Debug.Log(string.Format("{0} LobbyGameServer: Lobby {1}", "[Multiplayer]", lobby));
	}

	private void OnLobbyInvite(UserData fromUser, LobbyData forLobby, GameData inGame)
	{
		Debug.Log("[Multiplayer] LobbyInvite: From " + fromUser.Name + ", Lobby " + forLobby.Name + ", GameData " + inGame.ToString());
	}

	private void OnLobbyLeave(LobbyData lobby)
	{
		Debug.Log(string.Format("{0} LobbyLeave: Lobby {1}", "[Multiplayer]", lobby));
	}

	private void OnLobbyJoinRequested(LobbyData lobby, UserData user)
	{
		Debug.Log(string.Format("{0} LobbyJoinRequested: Lobby {1}, User {2}", "[Multiplayer]", lobby, user.Name));
	}

	private void OnRichPresenceJoinRequested(UserData user, string connectionString)
	{
		Debug.Log("[Multiplayer] RichPresenceJoinRequested: User " + user.Name + ", " + connectionString);
	}

	private void OnActiveBeaconsUpdated()
	{
		Debug.Log("[Multiplayer] ActiveBeaconsUpdated");
	}

	private void OnAvailableBeaconLocationsUpdated()
	{
		Debug.Log("[Multiplayer] AvailableBeaconLocationsUpdated");
	}

	private void OnReservationNotification(UserData user, PartyBeaconID_t party)
	{
		Debug.Log("[Multiplayer] ReservationNotification: User " + user.Name + ", Party " + party.ToString());
	}

	private void OnAppResumeFromSuspend()
	{
		Debug.Log("[Multiplayer] AppResumeFromSuspend");
	}
}
