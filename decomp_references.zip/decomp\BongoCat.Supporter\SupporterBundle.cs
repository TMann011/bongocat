using System.Collections;
using BongoCat.SteamJsonParser;
using Helper;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Supporter;

public class SupporterBundle : MonoBehaviour
{
	[SerializeField]
	private SteamShopBundle _item;

	[SerializeField]
	private TMP_Text _priceText;

	[SerializeField]
	private TMP_Text _discountText;

	[SerializeField]
	private Image _image;

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => !string.IsNullOrEmpty(SupporterShop.Instance.PriceSymbol));
		SteamInventory.GetItemPrice(new SteamItemDef_t(_item.Id), out var pCurrentPrice, out var _);
		_priceText.SetText($"{SupporterShop.Instance.PriceSymbol}{(double)pCurrentPrice / 100.0:0.00}");
	}

	private void OnValidate()
	{
		if ((bool)_item)
		{
			string text = "SupporterBundle_" + _item.Name.Replace(" ", "");
			if (base.gameObject.name != text)
			{
				base.gameObject.name = text;
				EditorUtilityCompileSafe.SetDirty(base.gameObject);
			}
			Sprite image = _item.Image;
			if ((bool)image && _image.sprite != image)
			{
				_image.sprite = image;
				EditorUtilityCompileSafe.SetDirty(_image);
			}
			_discountText.SetText($"-{_item.PurchaseBundleDiscount}%");
			if (_item.PurchaseBundleDiscount <= 0)
			{
				_discountText.SetText($"{_item.PurchaseBundleDiscount}%");
			}
		}
	}

	public void OnBuyButtonClicked()
	{
		Application.OpenURL($"steam://openurl/https://store.steampowered.com/itemstore/{3419430}/detail/{_item.Id}/");
	}
}
