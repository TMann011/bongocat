using System;
using System.Collections.Generic;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInventoryItemData))]
public class SteamInventoryExchange : MonoBehaviour
{
	[Serializable]
	public struct RecipeEntry
	{
		public int id;

		public uint count;
	}

	public List<RecipeEntry> recipe = new List<RecipeEntry>();

	private SteamInventoryItemData _mInspector;

	private SteamInventoryItemDataEvents _mEvents;

	public bool IsCanExchange
	{
		get
		{
			if (recipe.Count == 0)
			{
				return false;
			}
			bool result = true;
			foreach (RecipeEntry item in recipe)
			{
				if (!((ItemData)item.id).GetExchangeEntry(item.count, out var _))
				{
					result = false;
					break;
				}
			}
			return result;
		}
	}

	private void Awake()
	{
		_mInspector = GetComponent<SteamInventoryItemData>();
		_mEvents = GetComponent<SteamInventoryItemDataEvents>();
		Events.OnInventoryResultReady += HandleInventoryUpdated;
		Interface.WhenReady(RefreshCanExchange);
	}

	private void OnDestroy()
	{
		Events.OnInventoryResultReady -= HandleInventoryUpdated;
	}

	private void HandleInventoryUpdated(InventoryResult _)
	{
		RefreshCanExchange();
	}

	public void RefreshCanExchange()
	{
		if (_mEvents != null)
		{
			_mEvents.onCanExchangeChange?.Invoke(IsCanExchange);
		}
	}

	public void Exchange()
	{
		List<ExchangeEntry> list = new List<ExchangeEntry>();
		bool flag = true;
		foreach (RecipeEntry item in recipe)
		{
			if (((ItemData)item.id).GetExchangeEntry(item.count, out var entries))
			{
				list.AddRange(entries);
				continue;
			}
			flag = false;
			break;
		}
		if (flag)
		{
			_mInspector.Data.Exchange(list, delegate(InventoryResult result)
			{
				if (result.result == EResult.k_EResultOK)
				{
					if (_mEvents != null)
					{
						_mEvents.onExchangeComplete?.Invoke(result.items);
					}
				}
				else if (_mEvents != null)
				{
					_mEvents.onExchangeFailed?.Invoke(result.result);
				}
			});
		}
		else if (_mEvents != null)
		{
			_mEvents.onExchangeRejected?.Invoke();
		}
	}
}
