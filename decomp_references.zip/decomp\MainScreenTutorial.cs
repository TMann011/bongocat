using System.Collections.Generic;
using BongoCat;
using Tutorial;
using UnityEngine;

public class MainScreenTutorial : TutorialStep
{
	[SerializeField]
	private ScreenChoice _screenChoice;

	[SerializeField]
	private Transform _screenChoiceParent;

	private readonly List<ScreenChoice> _screenChoices = new List<ScreenChoice>();

	public void OnBegin()
	{
		for (int i = 0; i < SettingsManager.Instance.MainScreenSetting.DisplayCount; i++)
		{
			ScreenChoice screenChoice = Object.Instantiate(_screenChoice, _screenChoiceParent);
			screenChoice.Init(this, i);
			_screenChoices.Add(screenChoice);
		}
		_screenChoices[0].ToggleToDisplay();
	}

	public void SelectScreen(int index)
	{
		for (int i = 0; i < _screenChoices.Count; i++)
		{
			_screenChoices[i].Button.interactable = i != index;
		}
	}

	public override bool ShouldSkip()
	{
		return SettingsManager.Instance.MainScreenSetting.DisplayCount <= 1;
	}
}
