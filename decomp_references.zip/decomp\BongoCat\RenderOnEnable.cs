using System.Collections;
using UnityEngine;

namespace BongoCat;

public class RenderOnEnable : MonoBehaviour
{
	private bool _skipFirstEnable = true;

	private bool _resumesRendering;

	private IEnumerator Start()
	{
		yield return null;
		ResumeRendering();
	}

	private void OnEnable()
	{
		if (_skipFirstEnable)
		{
			_skipFirstEnable = false;
		}
		else
		{
			ResumeRendering();
		}
	}

	private void OnDisable()
	{
		PauseRendering();
	}

	private void ResumeRendering()
	{
		if (!_resumesRendering)
		{
			_resumesRendering = true;
			OnDemandRenderHelper.Instance.ResumeRendering();
		}
	}

	private void PauseRendering()
	{
		if (_resumesRendering)
		{
			OnDemandRenderHelper.Instance.TryPauseRendering();
			_resumesRendering = false;
		}
	}
}
