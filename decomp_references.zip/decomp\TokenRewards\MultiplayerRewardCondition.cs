using BongoCat;
using BongoCat.TokenRewards;
using Heathen.SteamworksIntegration;
using SteamTools;
using UnityEngine;

namespace TokenRewards;

public class MultiplayerRewardCondition : TokenRewardCondition
{
	[SerializeField]
	private TokenItemReward _reward;

	private void Start()
	{
		Events.OnLobbyEnterSuccess += OnLobbyEnter;
		Events.OnLobbyChatMsg += OnPlayerJoinedLobby;
	}

	private void OnDisable()
	{
		Events.OnLobbyEnterSuccess -= OnLobbyEnter;
		Events.OnLobbyChatMsg -= OnPlayerJoinedLobby;
	}

	private void OnLobbyEnter(LobbyData lobby)
	{
		_reward.TryOpenUi();
	}

	private void OnPlayerJoinedLobby(LobbyChatMsg lobbyChatMsg)
	{
		_reward.TryOpenUi();
	}

	public override bool CheckRewardConditions()
	{
		if (LobbyData.Current.IsValid && LobbyData.Current.MemberCount > 1)
		{
			return true;
		}
		return false;
	}
}
