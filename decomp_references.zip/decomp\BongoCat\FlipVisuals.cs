using Heathen.SteamworksIntegration;
using Helper;
using UnityEngine;

namespace BongoCat;

public class FlipVisuals : MonoBehaviour
{
	[SerializeField]
	private Cat _cat;

	[SerializeField]
	private Transform _catTransform;

	[SerializeField]
	private PlayerPrefsToggle _toggle;

	public bool IsFlipped;

	[SerializeField]
	private bool _isMultiplayer;

	[SerializeField]
	private SteamUserData _steamUserData;

	private void Update()
	{
		if (_cat.hoverCallback.Hovering && Input.GetKeyDown(KeyCode.F) && !InputFieldCache.FocusingInputField)
		{
			if (!_isMultiplayer)
			{
				_toggle.Toggle();
			}
			else
			{
				ToggleFlip();
			}
		}
	}

	public void ToggleFlip()
	{
		Flip(!IsFlipped);
	}

	public void Flip(bool val)
	{
		IsFlipped = val;
		_cat.UpdateFlip(IsFlipped);
		_catTransform.localScale = new Vector3((float)((!IsFlipped) ? 1 : (-1)) * Mathf.Abs(_catTransform.localScale.x), _catTransform.localScale.y, _catTransform.localScale.z);
		SaveFlip();
		if ((bool)_toggle && _toggle.Value != val)
		{
			_toggle.Value = val;
		}
	}

	public void ResetFlip()
	{
		Flip(val: false);
	}

	private void SaveFlip()
	{
		if (_isMultiplayer && (bool)_steamUserData)
		{
			PlayerDataCache.SetFlipped(_steamUserData.Data.IdStr, IsFlipped);
		}
	}
}
