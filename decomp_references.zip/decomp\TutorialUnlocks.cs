using System;
using System.Collections;
using BongoCat;
using Steam;
using UnityEngine;
using UnityEngine.Events;

public class TutorialUnlocks : MonoBehaviour
{
	[Flags]
	public enum TutorialTasks
	{
		Done = -1,
		None = 0,
		FinishedInitTutorial = 1,
		UnlockedExchange = 2,
		UnlockedBongoDex = 4,
		UnlockedSkinTab = 8,
		UnlockedHatTab = 0x10,
		UnlockedEmoteTab = 0x20,
		UnlockedBongoTab = 0x40,
		UnlockedThemeTab = 0x80,
		All = 0xFF
	}

	[SerializeField]
	private GrantPromoItem _tutorialItem;

	private const string STEP_KEY = "TUTORIAL_STEP";

	public static readonly UnityEvent OnUnlocksChanged = new UnityEvent();

	private static TutorialTasks TutorialTask => (TutorialTasks)PlayerPrefs.GetInt("TUTORIAL_STEP", 0);

	public static bool HasFlag(TutorialTasks flag)
	{
		if (TutorialTask != TutorialTasks.Done)
		{
			return (TutorialTask & flag) == flag;
		}
		return true;
	}

	private IEnumerator Start()
	{
		if (HasFlag(TutorialTasks.FinishedInitTutorial))
		{
			yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
			if (!_tutorialItem.IsOwned)
			{
				_tutorialItem.Grant();
			}
		}
	}

	public static void SetFlag(TutorialTasks flag)
	{
		if (!HasFlag(flag))
		{
			TutorialTasks tutorialTasks = TutorialTask | flag;
			if (tutorialTasks == TutorialTasks.All)
			{
				tutorialTasks = TutorialTasks.Done;
			}
			PlayerPrefs.SetInt("TUTORIAL_STEP", (int)tutorialTasks);
			OnUnlocksChanged.Invoke();
		}
	}

	[ContextMenu("Reset Tutorial")]
	private void ClearProgress()
	{
		PlayerPrefs.DeleteKey("TUTORIAL_STEP");
	}
}
