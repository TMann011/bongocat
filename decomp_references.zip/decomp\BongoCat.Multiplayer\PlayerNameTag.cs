using Heathen.SteamworksIntegration;
using Steamworks;
using TMPro;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class PlayerNameTag : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _playerName;

	[SerializeField]
	private GameObject _handle;

	[SerializeField]
	private GameObject _visuals;

	[SerializeField]
	private SteamUserData _userData;

	private bool _mouseOnCat;

	private bool _listenToToggle;

	private void Start()
	{
		_playerName.text = _userData.Data.Nickname;
		_userData.onChanged.AddListener(OnPersonaStateChange);
		OnShowNamesToggleChanged(SettingsManager.Instance.ShowPlayerNames.Value);
		SettingsManager.Instance.ShowPlayerNames.OnToggleUpdated.AddListener(OnShowNamesToggleChanged);
		ToggleObjectsWithKey.Instance.OnToggleWithKey += OnShowNamesToggleChanged;
	}

	private void OnPersonaStateChange(UserData user, EPersonaChange changeflag)
	{
		if (changeflag.HasFlag(EPersonaChange.k_EPersonaChangeNickname) || changeflag.HasFlag(EPersonaChange.k_EPersonaChangeName))
		{
			_playerName.text = user.Nickname;
		}
	}

	private void OnShowNamesToggleChanged(bool toggle)
	{
		_listenToToggle = toggle;
		_visuals.SetActive(toggle && !_handle.activeInHierarchy);
	}

	public void ShowNameTag()
	{
		_visuals.SetActive(!_handle.activeInHierarchy);
	}

	public void TryHideNameTag()
	{
		_visuals.SetActive(_listenToToggle);
		_handle.SetActive(value: false);
	}

	private void OnDestroy()
	{
		_userData.onChanged.RemoveListener(OnPersonaStateChange);
		SettingsManager.Instance.ShowPlayerNames.OnToggleUpdated.RemoveListener(OnShowNamesToggleChanged);
		ToggleObjectsWithKey.Instance.OnToggleWithKey -= OnShowNamesToggleChanged;
	}
}
