using System;
using System.Collections.Generic;
using Steamworks;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[Serializable]
public class GameServerData : gameserveritem_t
{
	public List<StringKeyValuePair> rules;

	public List<ServerPlayerEntry> players;

	public UnityEvent evtDataUpdated = new UnityEvent();

	public CSteamID SteamId => m_steamID;

	public GameServerData(gameserveritem_t item)
	{
		evtDataUpdated = new UnityEvent();
		m_bDoNotRefresh = item.m_bDoNotRefresh;
		m_bHadSuccessfulResponse = item.m_bHadSuccessfulResponse;
		m_bPassword = item.m_bPassword;
		m_bSecure = item.m_bSecure;
		m_nAppID = item.m_nAppID;
		m_nBotPlayers = item.m_nBotPlayers;
		m_NetAdr = item.m_NetAdr;
		m_nMaxPlayers = item.m_nMaxPlayers;
		m_nPing = item.m_nPing;
		m_nPlayers = item.m_nPlayers;
		m_nServerVersion = item.m_nServerVersion;
		m_steamID = item.m_steamID;
		m_ulTimeLastPlayed = item.m_ulTimeLastPlayed;
		SetGameDescription(item.GetGameDescription());
		SetGameDir(item.GetGameDir());
		SetGameTags(item.GetGameTags());
		SetMap(item.GetMap());
		SetServerName(item.GetServerName());
		players = new List<ServerPlayerEntry>();
		rules = new List<StringKeyValuePair>();
	}

	public void Update(gameserveritem_t item)
	{
		m_bDoNotRefresh = item.m_bDoNotRefresh;
		m_bHadSuccessfulResponse = item.m_bHadSuccessfulResponse;
		m_bPassword = item.m_bPassword;
		m_bSecure = item.m_bSecure;
		m_nAppID = item.m_nAppID;
		m_nBotPlayers = item.m_nBotPlayers;
		m_NetAdr = item.m_NetAdr;
		m_nMaxPlayers = item.m_nMaxPlayers;
		m_nPing = item.m_nPing;
		m_nPlayers = item.m_nPlayers;
		m_nServerVersion = item.m_nServerVersion;
		m_steamID = item.m_steamID;
		m_ulTimeLastPlayed = item.m_ulTimeLastPlayed;
		SetGameDescription(item.GetGameDescription());
		SetGameDir(item.GetGameDir());
		SetGameTags(item.GetGameTags());
		SetMap(item.GetMap());
		SetServerName(item.GetServerName());
		evtDataUpdated.Invoke();
	}
}
