using System.Collections;
using Heathen.SteamworksIntegration;
using IroxGames.Helper;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class LastLobbyJoin : MonoBehaviour
{
	public const string LAST_LOBBY_KEY = "LAST_LOBBY";

	[SerializeField]
	private PlayerPrefsToggle _joinLastLobby;

	private bool _rejoinAfterDisconnect;

	private LobbyData _pendingRejoinLobbyId;

	private void Awake()
	{
		Events.OnLobbyDataUpdate += OnLastLobbyInfoReceived;
		Events.OnLobbyEnterSuccess += OnLobbyJoined;
		Events.OnLobbyLeave += OnLobbyLeave;
		Events.OnSteamServersConnected += OnReconnect;
	}

	private void OnDestroy()
	{
		Events.OnLobbyDataUpdate -= OnLastLobbyInfoReceived;
		Events.OnLobbyEnterSuccess -= OnLobbyJoined;
		Events.OnLobbyLeave -= OnLobbyLeave;
		Events.OnSteamServersConnected -= OnReconnect;
	}

	private IEnumerator Start()
	{
		if (!_joinLastLobby.Value)
		{
			PlayerPrefs.DeleteKey("LAST_LOBBY");
			yield break;
		}
		yield return new WaitUntil(() => Interface.IsReady);
		yield return null;
		JoinLastLobby();
	}

	private void JoinLastLobby()
	{
		if (!PlayerPrefsHelper.TryGetString("LAST_LOBBY", out var s))
		{
			Debug.Log("[Multiplayer] No last lobby code found");
			return;
		}
		LobbyData lobbyData = new CSteamID(BaseConverter.DecodeFromBase59(s));
		Debug.Log(string.Format("{0} Try to Join Last Lobby: Code {1}", "[Multiplayer]", lobbyData));
		if (!lobbyData.IsValid)
		{
			Debug.Log("[Multiplayer] Last lobby no longer exists, clearing");
			PlayerPrefs.DeleteKey("LAST_LOBBY");
		}
		else
		{
			_pendingRejoinLobbyId = lobbyData;
			SteamMatchmaking.RequestLobbyData(lobbyData);
		}
	}

	private void OnLobbyJoined(LobbyData lobby)
	{
		_rejoinAfterDisconnect = false;
		_pendingRejoinLobbyId = CSteamID.Nil;
		PlayerPrefs.SetString("LAST_LOBBY", BaseConverter.EncodeToBase59(lobby.SteamId.m_SteamID));
	}

	private void OnLobbyLeave(LobbyData lobby)
	{
		if (_rejoinAfterDisconnect)
		{
			JoinLastLobby();
		}
		else
		{
			PlayerPrefs.DeleteKey("LAST_LOBBY");
		}
	}

	private void OnReconnect()
	{
		_rejoinAfterDisconnect = true;
		LobbyData.Current.Leave();
	}

	private void OnLastLobbyInfoReceived(LobbyData lobby, LobbyMemberData? member)
	{
		if (!(lobby != _pendingRejoinLobbyId))
		{
			if (!lobby.IsValid)
			{
				Debug.Log("[Multiplayer] Last lobby no longer exists, clearing");
				PlayerPrefs.DeleteKey("LAST_LOBBY");
			}
			else if (!LobbyData.Current.IsValid)
			{
				Debug.Log("[Multiplayer] Last Lobby Joined");
				SteamMatchmaking.JoinLobby(_pendingRejoinLobbyId);
			}
		}
	}
}
