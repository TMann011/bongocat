using System.Collections.Generic;
using System.Linq;
using Heathen.SteamworksIntegration;

namespace BongoCat.Multiplayer;

public static class MultiplayerLobbyReferences
{
	public static Dictionary<UserData, LobbyListEntry> LobbyListEntries = new Dictionary<UserData, LobbyListEntry>();

	public static Dictionary<UserData, LobbyMemberInstance> GameplayInstances = new Dictionary<UserData, LobbyMemberInstance>();

	public static Dictionary<UserData, LeaderboardEntry> LeaderboardEntries = new Dictionary<UserData, LeaderboardEntry>();

	public static IEnumerable<LobbyMemberInstance> VisibleCats => GameplayInstances.Values.Where((LobbyMemberInstance instance) => !instance.IsHidden);
}
