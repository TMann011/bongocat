namespace BongoCat.SteamJsonParser;

public enum QualityCategory
{
	Common,
	Uncommon,
	Rare,
	Epic,
	Legendary,
	Special,
	Unique
}
