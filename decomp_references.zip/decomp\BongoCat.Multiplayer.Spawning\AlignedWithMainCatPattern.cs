using System.Collections.Generic;
using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public class AlignedWithMainCatPattern : CatSpawnPatternBase
{
	public override SpawnControls Controls => SpawnControls.Spacing | SpawnControls.AlignmentAxis | SpawnControls.SnapCats | SpawnControls.Recalculate;

	public override bool AnchoredOnMainCat => true;

	public override bool KeepsCatsOnTheirSlots => true;

	public override bool IncludesMainCat => true;

	public override int RotationState => MainCat.Instance.Rotator.RotationState;

	public AlignedWithMainCatPattern(CatSpawnSettings settings)
		: base(settings)
	{
	}

	protected override int SlotRotation(int layoutRotation)
	{
		return layoutRotation;
	}

	protected override List<CatSlot> Layout()
	{
		int rotationState = RotationState;
		Row(out var origin, out var direction);
		float num = ReachFrom(origin, direction);
		float num2 = ReachFrom(origin, -direction);
		float tightestSpacing = SpawnGeometry.TightestSpacing;
		int num3 = ArmSlots(num, tightestSpacing);
		int num4 = ArmSlots(num2, tightestSpacing);
		int num5 = SlotsFromSlider(1 + num3 + num4) - 1;
		float num6 = num + num2;
		int num7 = Mathf.Min(num3, (num6 > 0f) ? Mathf.RoundToInt((float)num5 * (num / num6)) : 0);
		int num8 = Mathf.Min(num4, num5 - num7);
		num7 = Mathf.Min(num3, num5 - num8);
		float num9 = ((num7 > 0) ? (num / (float)num7) : 0f);
		float num10 = ((num8 > 0) ? (num2 / (float)num8) : 0f);
		List<CatSlot> list = new List<CatSlot>
		{
			new CatSlot
			{
				Position = origin,
				RotationState = rotationState,
				ReservedForMainCat = true
			}
		};
		for (int i = 1; i <= Mathf.Max(num7, num8); i++)
		{
			if (i <= num7)
			{
				list.Add(new CatSlot
				{
					Position = origin + direction * (num9 * (float)i),
					RotationState = rotationState
				});
			}
			if (i <= num8)
			{
				list.Add(new CatSlot
				{
					Position = origin - direction * (num10 * (float)i),
					RotationState = rotationState
				});
			}
		}
		return list;
	}

	private void Row(out Vector2 origin, out Vector2 direction)
	{
		origin = MainCat.Instance.Pos;
		direction = ((Settings.AlignmentAxis == AlignmentAxes.Horizontal) ? Vector2.right : Vector2.up);
	}

	private float ReachFrom(Vector2 origin, Vector2 direction)
	{
		return Vector2.Dot(SpawnGeometry.KeepCatOnScreen(origin + direction * SpawnGeometry.Perimeter, RotationState) - origin, direction);
	}

	private static int ArmSlots(float length, float spacing)
	{
		return Mathf.Max(0, Mathf.CeilToInt(length / spacing));
	}
}
