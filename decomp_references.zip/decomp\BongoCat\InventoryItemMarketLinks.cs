using System;
using System.Collections.Generic;
using Helper;
using UnityEngine;

namespace BongoCat;

public class InventoryItemMarketLinks : ScriptableObject
{
	[Serializable]
	private struct MarketLinkData
	{
		public string Name;

		public List<int> Ids;

		public string Link;
	}

	[SerializeField]
	private List<MarketLinkData> _marketLinkData;

	private Dictionary<int, string> _linkDict;

	public bool HasCustomLink(SteamItemRuntime steamItem)
	{
		InitDict();
		return _linkDict.ContainsKey(steamItem.Id);
	}

	public string GetMarketLink(SteamItemRuntime steamItem)
	{
		InitDict();
		if (_linkDict.TryGetValue(steamItem.Id, out var value))
		{
			return "steam://openurl/" + value;
		}
		return SteamHelper.GetMarketLink(steamItem.ItemName);
	}

	private void InitDict()
	{
		if (_linkDict != null)
		{
			return;
		}
		_linkDict = new Dictionary<int, string>();
		foreach (MarketLinkData marketLinkDatum in _marketLinkData)
		{
			foreach (int id in marketLinkDatum.Ids)
			{
				_linkDict.Add(id, marketLinkDatum.Link);
			}
		}
	}
}
