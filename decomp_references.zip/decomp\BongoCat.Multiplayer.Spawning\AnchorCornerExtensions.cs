namespace BongoCat.Multiplayer.Spawning;

public static class AnchorCornerExtensions
{
	public static bool IsRight(this AnchorCorners corner)
	{
		if (corner != AnchorCorners.TopRight)
		{
			return corner == AnchorCorners.BottomRight;
		}
		return true;
	}

	public static bool IsTop(this AnchorCorners corner)
	{
		if (corner != AnchorCorners.TopLeft)
		{
			return corner == AnchorCorners.TopRight;
		}
		return true;
	}

	public static int HorizontalSign(this AnchorCorners corner)
	{
		if (corner.IsRight())
		{
			return 1;
		}
		if (corner != AnchorCorners.Center)
		{
			return -1;
		}
		return 0;
	}
}
