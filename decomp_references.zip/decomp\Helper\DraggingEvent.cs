using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace Helper;

public class DraggingEvent : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IDragHandler, IEndDragHandler
{
	public UnityEvent OnDragStarted;

	public UnityEvent Dragging;

	public UnityEvent OnDragFinished;

	public void OnBeginDrag(PointerEventData eventData)
	{
		OnDragStarted?.Invoke();
	}

	public void OnDrag(PointerEventData eventData)
	{
		Dragging?.Invoke();
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		OnDragFinished?.Invoke();
	}
}
