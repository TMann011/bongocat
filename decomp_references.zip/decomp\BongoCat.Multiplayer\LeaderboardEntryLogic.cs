using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class LeaderboardEntryLogic : MonoBehaviour
{
	[SerializeField]
	private SteamUserData _userData;

	private void Start()
	{
		Leaderboard.Instance.TapsSinceJoined?.Add(_userData.Data, 0);
		SteamMultiplayer.Instance.OnTapsReceived.Register(_userData.Data, AddTaps);
	}

	private void OnDestroy()
	{
		Leaderboard.Instance.TapsSinceJoined?.Remove(_userData.Data);
		SteamMultiplayer.Instance.OnTapsReceived.Deregister(_userData.Data, AddTaps);
	}

	private void AddTaps(int taps)
	{
		if (!Leaderboard.Instance.TapsSinceJoined.ContainsKey(_userData.Data))
		{
			Debug.LogWarning("should not happen");
			return;
		}
		Leaderboard.Instance.TapsSinceJoined[_userData.Data] += taps;
		Leaderboard.Instance.TryUpdateLeaderboardUI();
	}
}
