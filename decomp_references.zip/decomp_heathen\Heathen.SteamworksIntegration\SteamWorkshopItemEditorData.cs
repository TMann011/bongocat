using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamWorkshopItemEditorData : MonoBehaviour
{
	public uint consumingAppId;

	public TMP_InputField title;

	public TMP_InputField description;

	public TMP_InputField contentFolderPath;

	public TMP_InputField previewFilePath;

	private WorkshopItemEditorData _mData;

	private SteamWorkshopItemEditorDataEvents _mEvents;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> mDelegates = new List<string>();

	public WorkshopItemEditorData Data
	{
		get
		{
			return _mData;
		}
		set
		{
			_mData = value;
			if (_mEvents != null)
			{
				_mEvents.onChange?.Invoke();
			}
		}
	}

	private void Awake()
	{
		_mEvents = GetComponent<SteamWorkshopItemEditorDataEvents>();
		if (title != null)
		{
			title.onValueChanged.AddListener(HandleTitleUpdate);
		}
		if (description != null)
		{
			description.onValueChanged.AddListener(HandleDescriptionUpdate);
		}
		if (contentFolderPath != null)
		{
			contentFolderPath.onValueChanged.AddListener(HandleContentFolderUpdate);
		}
		if (previewFilePath != null)
		{
			previewFilePath.onValueChanged.AddListener(HandlePreviewFileUpdate);
		}
	}

	private void HandleTitleUpdate(string arg0)
	{
		_mData.title = arg0;
	}

	private void HandleDescriptionUpdate(string arg0)
	{
		_mData.description = arg0;
	}

	private void HandleContentFolderUpdate(string arg0)
	{
		_mData.Content = new DirectoryInfo(arg0);
	}

	private void HandlePreviewFileUpdate(string arg0)
	{
		_mData.Preview = new FileInfo(arg0);
	}
}
