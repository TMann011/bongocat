using System;
using System.Linq;
using BongoCat;
using DG.Tweening;
using UnityEngine;

public class TranslucentOnHover : MonoBehaviour
{
	[SerializeField]
	private CanvasGroup _alpha;

	[SerializeField]
	private GameObject[] _notClickThroughObjects;

	private int _layerIgnoreRaycast;

	private int _layerUI;

	private const float TRANSLUCENT = 0.1f;

	private const float OPAQUE = 1f;

	private void Start()
	{
		_layerIgnoreRaycast = LayerMask.NameToLayer("Ignore Raycast");
		_layerUI = LayerMask.NameToLayer("UI");
		TranslucentOnHoverSetting.OnSetTranslucent = (Action<bool>)Delegate.Combine(TranslucentOnHoverSetting.OnSetTranslucent, new Action<bool>(SetTranslucentSmooth));
	}

	private void OnDestroy()
	{
		TranslucentOnHoverSetting.OnSetTranslucent = (Action<bool>)Delegate.Remove(TranslucentOnHoverSetting.OnSetTranslucent, new Action<bool>(SetTranslucentSmooth));
	}

	public void ShowTranslucentTemporarily()
	{
		TranslucentOnHoverSetting.Instance.ShowTranslucentTemporarily();
	}

	public void TrySetTranslucent(bool translucent)
	{
		if (TranslucentOnHoverSetting.Instance.SettingEnabled)
		{
			SetTranslucentSmooth(translucent);
		}
	}

	public void SetTranslucentSmooth(bool translucent)
	{
		float num = (translucent ? 0.1f : 1f);
		DOTween.Kill(_alpha);
		OnDemandRenderHelper.Instance.ResumeRenderingForDuration(0.25f);
		_alpha.DOFade(num, 0.25f);
		SetLayerRecursively(base.transform, Mathf.Approximately(num, 1f) ? _layerUI : _layerIgnoreRaycast);
	}

	private void SetLayerRecursively(Transform current, int layer)
	{
		if (_notClickThroughObjects.Contains(current.gameObject))
		{
			return;
		}
		current.gameObject.layer = layer;
		foreach (Transform item in current)
		{
			SetLayerRecursively(item, layer);
		}
	}
}
