using System;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

public class GameServerBrowserManager : MonoBehaviour
{
	[Serializable]
	public class ResultsEvent : UnityEvent<ResultData>
	{
	}

	[Serializable]
	public class ResultData
	{
		public GameServerSearchType type;

		public List<GameServerData> entries;

		public bool hasIOFailure;

		public ResultData(GameServerSearchType type, List<GameServerData> entries, bool ioFailure)
		{
			this.type = type;
			this.entries = entries;
			hasIOFailure = ioFailure;
		}
	}

	private class Search
	{
		public HServerListRequest HRequest;

		public Action<List<GameServerData>, bool> Callback;

		public Action Clear;

		public ISteamMatchmakingServerListResponse MServerListResponse;

		public Search()
		{
			MServerListResponse = new ISteamMatchmakingServerListResponse(OnServerResponded, OnServerFailedToRespond, OnRefreshComplete);
		}

		private void OnServerResponded(HServerListRequest hRequest, int iServer)
		{
			HServerListRequest hServerListRequest = hRequest;
			Debug.Log("OnServerResponded: " + hServerListRequest.ToString() + " - " + iServer);
		}

		private void OnServerFailedToRespond(HServerListRequest hRequest, int iServer)
		{
			HServerListRequest hServerListRequest = hRequest;
			Debug.Log("OnServerFailedToRespond: " + hServerListRequest.ToString() + " - " + iServer);
			if (Callback != null)
			{
				Callback(null, arg2: true);
			}
		}

		private void OnRefreshComplete(HServerListRequest hRequest, EMatchMakingServerResponse response)
		{
			HServerListRequest hServerListRequest = hRequest;
			Debug.Log("OnRefreshComplete: " + hServerListRequest.ToString() + " - " + response);
			List<GameServerData> list = new List<GameServerData>();
			int serverCount = SteamMatchmakingServers.GetServerCount(hRequest);
			for (int i = 0; i < serverCount; i++)
			{
				gameserveritem_t serverDetails = SteamMatchmakingServers.GetServerDetails(hRequest, i);
				if (serverDetails.m_steamID.m_SteamID != 0L && serverDetails.m_nAppID == App.Id)
				{
					GameServerData item = new GameServerData(serverDetails);
					list.Add(item);
				}
			}
			if (hRequest != HServerListRequest.Invalid)
			{
				SteamMatchmakingServers.ReleaseRequest(hRequest);
			}
			if (Callback != null)
			{
				Callback(list, arg2: false);
			}
			Clear();
		}
	}

	private class PingQuery
	{
		public HServerQuery HQuery;

		public ISteamMatchmakingPingResponse MPingResponse;

		public GameServerData Target;

		public Action<GameServerData, bool> Callback;

		public Action Clear;

		public PingQuery()
		{
			MPingResponse = new ISteamMatchmakingPingResponse(OnServerRespondedPing, OnServerFailedToRespondPing);
		}

		private void OnServerFailedToRespondPing()
		{
			if (HQuery != HServerQuery.Invalid)
			{
				SteamMatchmakingServers.CancelServerQuery(HQuery);
			}
			Callback?.Invoke(Target, arg2: true);
			Clear?.Invoke();
		}

		private void OnServerRespondedPing(gameserveritem_t server)
		{
			if (HQuery != HServerQuery.Invalid)
			{
				SteamMatchmakingServers.CancelServerQuery(HQuery);
			}
			if (Target != null)
			{
				Target.Update(server);
				Target.evtDataUpdated.Invoke();
				Callback?.Invoke(Target, arg2: false);
			}
			else
			{
				Callback?.Invoke(new GameServerData(server), arg2: false);
			}
			Clear?.Invoke();
		}
	}

	private class PlayerQuery
	{
		public HServerQuery HQuery;

		public ISteamMatchmakingPlayersResponse MPlayersResponse;

		public GameServerData Target;

		public Action<GameServerData, bool> Callback;

		public Action Clear;

		public PlayerQuery()
		{
			MPlayersResponse = new ISteamMatchmakingPlayersResponse(OnAddPlayerToList, OnPlayersFailedToRespond, OnPlayersRefreshComplete);
		}

		private void OnPlayersRefreshComplete()
		{
			if (HQuery != HServerQuery.Invalid)
			{
				SteamMatchmakingServers.CancelServerQuery(HQuery);
			}
			Target.evtDataUpdated.Invoke();
			Callback?.Invoke(Target, arg2: false);
			Clear?.Invoke();
		}

		private void OnPlayersFailedToRespond()
		{
			if (HQuery != HServerQuery.Invalid)
			{
				SteamMatchmakingServers.CancelServerQuery(HQuery);
			}
			Callback?.Invoke(Target, arg2: true);
			Clear?.Invoke();
		}

		private void OnAddPlayerToList(string pchName, int nScore, float flTimePlayed)
		{
			Target.players.Add(new ServerPlayerEntry
			{
				name = pchName,
				score = nScore,
				TimePlayed = new TimeSpan(0, 0, 0, (int)flTimePlayed, 0)
			});
		}
	}

	private class RulesQuery
	{
		public HServerQuery HQuery;

		public ISteamMatchmakingRulesResponse MRulesResponse;

		public GameServerData Target;

		public Action<GameServerData, bool> Callback;

		public Action Clear;

		public RulesQuery()
		{
			MRulesResponse = new ISteamMatchmakingRulesResponse(OnAddRuleToList, OnRulesFailedToRespond, OnRulesRefreshComplete);
		}

		private void OnAddRuleToList(string pchRule, string pchValue)
		{
			Target.rules.Add(new StringKeyValuePair
			{
				key = pchRule,
				value = pchValue
			});
		}

		private void OnRulesRefreshComplete()
		{
			if (HQuery != HServerQuery.Invalid)
			{
				SteamMatchmakingServers.CancelServerQuery(HQuery);
			}
			Target.evtDataUpdated.Invoke();
			if (Callback != null)
			{
				Callback(Target, arg2: false);
			}
			if (Clear != null)
			{
				Clear();
			}
		}

		private void OnRulesFailedToRespond()
		{
			if (HQuery != HServerQuery.Invalid)
			{
				SteamMatchmakingServers.CancelServerQuery(HQuery);
			}
			Callback?.Invoke(Target, arg2: true);
			Clear?.Invoke();
		}
	}

	public class Filter : Dictionary<string, string>
	{
		public MatchMakingKeyValuePair_t[] Array
		{
			get
			{
				MatchMakingKeyValuePair_t[] array = new MatchMakingKeyValuePair_t[base.Count];
				int num = 0;
				using Enumerator enumerator = GetEnumerator();
				while (enumerator.MoveNext())
				{
					KeyValuePair<string, string> current = enumerator.Current;
					array[num] = new MatchMakingKeyValuePair_t
					{
						m_szKey = current.Key,
						m_szValue = current.Value
					};
					num++;
				}
				return array;
			}
		}
	}

	private readonly List<Search> _searchList = new List<Search>();

	private readonly List<PingQuery> _pingList = new List<PingQuery>();

	private readonly List<PlayerQuery> _playerList = new List<PlayerQuery>();

	private readonly List<RulesQuery> _ruleList = new List<RulesQuery>();

	public ResultsEvent evtSearchCompleted = new ResultsEvent();

	public void GetAllFavorites()
	{
		GetServerList(App.Id, GameServerSearchType.Favorites);
	}

	public void GetAllFriends()
	{
		GetServerList(App.Id, GameServerSearchType.Friends);
	}

	public void GetAllHistory()
	{
		GetServerList(App.Id, GameServerSearchType.History);
	}

	public void GetAllInternet()
	{
		GetServerList(App.Id, GameServerSearchType.Internet);
	}

	public void GetAllLan()
	{
		GetServerList(App.Id, GameServerSearchType.Lan);
	}

	public void GetAllSpectator()
	{
		GetServerList(App.Id, GameServerSearchType.Spectator);
	}

	public void GetFavorites(Filter filter)
	{
		GetServerList(App.Id, GameServerSearchType.Favorites, null, filter);
	}

	public void GetFriends(Filter filter)
	{
		GetServerList(App.Id, GameServerSearchType.Friends, null, filter);
	}

	public void GetHistory(Filter filter)
	{
		GetServerList(App.Id, GameServerSearchType.History, null, filter);
	}

	public void GetInternet(Filter filter)
	{
		GetServerList(App.Id, GameServerSearchType.Internet, null, filter);
	}

	public void GetLan(Filter filter)
	{
		GetServerList(App.Id, GameServerSearchType.Lan, null, filter);
	}

	public void GetSpectator(Filter filter)
	{
		GetServerList(App.Id, GameServerSearchType.Spectator, null, filter);
	}

	public void GetServerList(GameServerSearchType type, Action<List<GameServerData>, bool> callback = null, Filter filter = null)
	{
		GetServerList(App.Id, type, callback, filter);
	}

	public void GetServerList(AppId_t appId, GameServerSearchType type, Action<List<GameServerData>, bool> callback = null, Filter filter = null)
	{
		Search nSearch = new Search();
		nSearch.Clear = delegate
		{
			_searchList.Remove(nSearch);
		};
		MatchMakingKeyValuePair_t[] filters = new MatchMakingKeyValuePair_t[0];
		if (filter != null)
		{
			filters = filter.Array;
		}
		switch (type)
		{
		case GameServerSearchType.Favorites:
			nSearch.Callback = delegate(List<GameServerData> r, bool e)
			{
				callback?.Invoke(r, e);
				evtSearchCompleted.Invoke(new ResultData(GameServerSearchType.Favorites, r, e));
			};
			Matchmaking.Client.RequestFavoritesServerList(appId, filters, nSearch.MServerListResponse);
			break;
		case GameServerSearchType.Friends:
			nSearch.Callback = delegate(List<GameServerData> r, bool e)
			{
				callback?.Invoke(r, e);
				evtSearchCompleted.Invoke(new ResultData(GameServerSearchType.Friends, r, e));
			};
			Matchmaking.Client.RequestFriendsServerList(appId, filters, nSearch.MServerListResponse);
			break;
		case GameServerSearchType.History:
			nSearch.Callback = delegate(List<GameServerData> r, bool e)
			{
				callback?.Invoke(r, e);
				evtSearchCompleted.Invoke(new ResultData(GameServerSearchType.History, r, e));
			};
			Matchmaking.Client.RequestHistoryServerList(appId, filters, nSearch.MServerListResponse);
			break;
		case GameServerSearchType.Internet:
			nSearch.Callback = delegate(List<GameServerData> r, bool e)
			{
				callback?.Invoke(r, e);
				evtSearchCompleted.Invoke(new ResultData(GameServerSearchType.Internet, r, e));
			};
			Matchmaking.Client.RequestInternetServerList(appId, filters, nSearch.MServerListResponse);
			break;
		case GameServerSearchType.Lan:
			nSearch.Callback = delegate(List<GameServerData> r, bool e)
			{
				callback?.Invoke(r, e);
				evtSearchCompleted.Invoke(new ResultData(GameServerSearchType.Lan, r, e));
			};
			Matchmaking.Client.RequestLanServerList(appId, nSearch.MServerListResponse);
			break;
		case GameServerSearchType.Spectator:
			nSearch.Callback = delegate(List<GameServerData> r, bool e)
			{
				callback?.Invoke(r, e);
				evtSearchCompleted.Invoke(new ResultData(GameServerSearchType.Spectator, r, e));
			};
			Matchmaking.Client.RequestSpectatorServerList(appId, filters, nSearch.MServerListResponse);
			break;
		}
		_searchList.Add(nSearch);
	}

	public void PingServer(string ipAddress, ushort port, Action<GameServerData, bool> callback)
	{
		PingServer(Utilities.IPStringToUint(ipAddress), port, callback);
	}

	public void PingServer(uint ipAddress, ushort port, Action<GameServerData, bool> callback)
	{
		PingQuery nQuery = new PingQuery();
		nQuery.Callback = callback;
		nQuery.HQuery = Matchmaking.Client.PingServer(ipAddress, port, nQuery.MPingResponse);
		nQuery.Clear = delegate
		{
			_pingList.Remove(nQuery);
		};
		_pingList.Add(nQuery);
	}

	public void PingServer(servernetadr_t address, Action<GameServerData, bool> callback)
	{
		PingServer(address.GetIP(), address.GetQueryPort(), callback);
	}

	public void PingServer(GameServerData entry, Action<GameServerData, bool> callback)
	{
		PingQuery nQuery = new PingQuery();
		nQuery.Callback = callback;
		nQuery.Target = entry;
		nQuery.HQuery = Matchmaking.Client.PingServer(entry.m_NetAdr.GetIP(), entry.m_NetAdr.GetQueryPort(), nQuery.MPingResponse);
		nQuery.Clear = delegate
		{
			_pingList.Remove(nQuery);
		};
		_pingList.Add(nQuery);
	}

	public void PlayerDetails(GameServerData entry, Action<GameServerData, bool> callback)
	{
		PlayerQuery nQuery = new PlayerQuery();
		nQuery.Callback = callback;
		entry.players.Clear();
		nQuery.Target = entry;
		nQuery.HQuery = Matchmaking.Client.PlayerDetails(entry.m_NetAdr.GetIP(), entry.m_NetAdr.GetQueryPort(), nQuery.MPlayersResponse);
		nQuery.Clear = delegate
		{
			_playerList.Remove(nQuery);
		};
		_playerList.Add(nQuery);
	}

	public void ServerRules(GameServerData entry, Action<GameServerData, bool> callback)
	{
		RulesQuery nQuery = new RulesQuery();
		nQuery.Callback = callback;
		entry.rules.Clear();
		nQuery.Target = entry;
		nQuery.HQuery = Matchmaking.Client.ServerRules(entry.m_NetAdr.GetIP(), entry.m_NetAdr.GetQueryPort(), nQuery.MRulesResponse);
		nQuery.Clear = delegate
		{
			_ruleList.Remove(nQuery);
		};
		_ruleList.Add(nQuery);
	}

	private void OnDestroy()
	{
		if (_searchList != null)
		{
			foreach (Search search in _searchList)
			{
				try
				{
					if (search.HRequest != HServerListRequest.Invalid)
					{
						SteamMatchmakingServers.ReleaseRequest(search.HRequest);
					}
				}
				catch
				{
				}
			}
		}
		if (_pingList != null)
		{
			foreach (PingQuery ping in _pingList)
			{
				try
				{
					if (ping.HQuery != HServerQuery.Invalid)
					{
						SteamMatchmakingServers.CancelServerQuery(ping.HQuery);
					}
				}
				catch
				{
				}
			}
		}
		if (_playerList != null)
		{
			foreach (PlayerQuery player in _playerList)
			{
				try
				{
					if (player.HQuery != HServerQuery.Invalid)
					{
						SteamMatchmakingServers.CancelServerQuery(player.HQuery);
					}
				}
				catch
				{
				}
			}
		}
		if (_ruleList == null)
		{
			return;
		}
		foreach (RulesQuery rule in _ruleList)
		{
			try
			{
				if (rule.HQuery != HServerQuery.Invalid)
				{
					SteamMatchmakingServers.CancelServerQuery(rule.HQuery);
				}
			}
			catch
			{
			}
		}
	}
}
