using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat.Achievements;
using BongoCat.Localizer;
using BongoCat.SteamJsonParser;
using Heathen.SteamworksIntegration;
using Helper;
using Steam.Exchanges;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Settings;
using UnityEngine.UI;

namespace BongoCat;

public class ItemExchange : MonoBehaviour
{
	[SerializeField]
	private GameObject _exchangeTab;

	[SerializeField]
	private List<ExchangeSlot> _exchangeSlots;

	[SerializeField]
	private Button _exchangeButton;

	[SerializeField]
	private Tabs _categoryTabs;

	[SerializeField]
	private Image _fillDuplicatesFill;

	[SerializeField]
	private PlayerPrefsToggle _allowAutoSlotFavorites;

	[SerializeField]
	private PlayerPrefsToggle _excludeEventItems;

	[SerializeField]
	private TMP_Text _exchangeButtonText;

	public static ItemExchange Instance;

	private int _possibleExchanges;

	private int _currentCategoryTabIndex;

	public static Action OnOpenExchange;

	public static Action OnCloseExchange;

	[SerializeField]
	private List<SteamTagExchange> _exchanges;

	private string _currentLocaText;

	private bool _isExchanging;

	public bool IsVisible { get; private set; }

	public bool HasItemsSlotted => _exchangeSlots.Any((ExchangeSlot slot) => slot.ItemSlotted != null);

	public bool ExcludeEventItems
	{
		get
		{
			if ((bool)_excludeEventItems)
			{
				return _excludeEventItems.Value;
			}
			return false;
		}
	}

	public bool AllowFavoriteItems => _allowAutoSlotFavorites.Value;

	private void Awake()
	{
		Instance = this;
		Tabs categoryTabs = _categoryTabs;
		categoryTabs.OnOpenTab = (Action<int>)Delegate.Combine(categoryTabs.OnOpenTab, new Action<int>(OpenTab));
	}

	private void OnDestroy()
	{
		Tabs categoryTabs = _categoryTabs;
		categoryTabs.OnOpenTab = (Action<int>)Delegate.Remove(categoryTabs.OnOpenTab, new Action<int>(OpenTab));
	}

	public bool IsEventItemHidden(SteamItemRuntime item)
	{
		if (IsVisible && ExcludeEventItems)
		{
			return item.IsEventItem;
		}
		return false;
	}

	public bool IsFavoriteItemHidden(SteamItemRuntime item)
	{
		if (IsVisible && !AllowFavoriteItems)
		{
			return item.IsFavorite;
		}
		return false;
	}

	public void OnAllowFavoritesToggled(bool allowed)
	{
		if (!allowed && !_isExchanging)
		{
			bool flag = false;
			foreach (ExchangeSlot exchangeSlot in _exchangeSlots)
			{
				if (exchangeSlot.ItemSlotted != null && exchangeSlot.ItemSlotted.IsFavorite)
				{
					exchangeSlot.SetItem(null, 1L);
					flag = true;
				}
			}
			if (flag)
			{
				UpdateInteractable();
			}
		}
		CatInventory.Instance.UpdateItemsUI();
		CatInventory.Instance.UpdateScrollView(resetScrollBar: true);
	}

	public void OnExcludeEventItemsToggled(bool excluded)
	{
		if (excluded && !_isExchanging)
		{
			bool flag = false;
			foreach (ExchangeSlot exchangeSlot in _exchangeSlots)
			{
				if (exchangeSlot.ItemSlotted != null && exchangeSlot.ItemSlotted.IsEventItem)
				{
					exchangeSlot.SetItem(null, 1L);
					flag = true;
				}
			}
			if (flag)
			{
				UpdateInteractable();
			}
		}
		CatInventory.Instance.UpdateItemsUI();
		CatInventory.Instance.UpdateScrollView(resetScrollBar: true);
	}

	private void Start()
	{
		LocalizationSettings.SelectedLocaleChanged += delegate
		{
			UpdateLoca();
		};
		UpdateLoca();
	}

	private void OnDisable()
	{
		_exchangeButtonText.text = _currentLocaText;
	}

	public void ToggleExchange()
	{
		if (IsVisible)
		{
			CloseExchange();
		}
		else
		{
			OpenExchange();
		}
	}

	public void OpenExchange()
	{
		IsVisible = true;
		_exchangeTab.SetActive(value: true);
		OnOpenExchange?.Invoke();
		List<SteamItemRuntime> duplicateItems = GetDuplicateItems();
		QualityCategoryWithInfo slotDuplicateQuality = GetSlotDuplicateQuality(duplicateItems);
		_fillDuplicatesFill.color = slotDuplicateQuality.ToQuality().GetColor();
		HideItems.Instance.TempShowHiddenItems();
		CatInventory.Instance.UpdateItemsUI();
		CatInventory.Instance.UpdateScrollView();
	}

	public void OnToggled(bool toggled)
	{
		if (!toggled)
		{
			CloseExchange();
		}
	}

	public void CloseExchange()
	{
		if (IsVisible)
		{
			IsVisible = false;
			_exchangeTab.SetActive(value: false);
			OnCloseExchange?.Invoke();
			CatInventory.Instance.Tabs.EnableAllTabs(enable: true);
			CatInventory.Instance.UpdateItemsUI();
			CatInventory.Instance.UpdateScrollView();
		}
	}

	private void OpenTab(int menuTab)
	{
		_currentCategoryTabIndex = menuTab;
		List<SteamItemRuntime> duplicateItems = GetDuplicateItems();
		QualityCategoryWithInfo slotDuplicateQuality = GetSlotDuplicateQuality(duplicateItems);
		_fillDuplicatesFill.color = slotDuplicateQuality.ToQuality().GetColor();
		CatInventory.Instance.UpdateScrollView(resetScrollBar: true);
	}

	private void UpdateLoca()
	{
		_currentLocaText = Localize.Get("Exchange");
		UpdateText();
	}

	private void UpdateText()
	{
		_exchangeButtonText.text = _currentLocaText;
		if (_possibleExchanges > 1)
		{
			_exchangeButtonText.text += $" ({_possibleExchanges}x)";
		}
	}

	public void TryExchange()
	{
		Debug.Log("[Item Exchange] Trying item exchange.");
		List<SteamItemRuntime> itemsSlotted = _exchangeSlots.SelectNotNull((ExchangeSlot slot) => slot.ItemSlotted).ToList();
		StartCoroutine(ExchangeRoutine(itemsSlotted, _possibleExchanges));
	}

	private IEnumerator ExchangeRoutine(List<SteamItemRuntime> itemsSlotted, int iterations)
	{
		if (iterations == 0)
		{
			yield break;
		}
		if (itemsSlotted.Select((SteamItemRuntime item) => item.QualityCategory).Distinct().Count() != 1)
		{
			Debug.Log("[Item Exchange] Not all items had same quality. Aborting item exchange.");
			yield break;
		}
		_isExchanging = true;
		_exchangeButton.interactable = false;
		SteamItemRuntime[] items = itemsSlotted.ToArray();
		Dictionary<SteamItemRuntime, uint> steamItemAmount = new Dictionary<SteamItemRuntime, uint>();
		SteamItemRuntime[] array = items;
		foreach (SteamItemRuntime steamItemRuntime in array)
		{
			if (!steamItemAmount.ContainsKey(steamItemRuntime))
			{
				steamItemAmount[steamItemRuntime] = (uint)steamItemRuntime.CurrentlyInExchangeSlot;
			}
		}
		bool exchangeCompleted = false;
		bool errored = false;
		SteamTagExchange exchange = _exchanges.First((SteamTagExchange steamTagExchange) => items.First().Data.HasTagWithValue(steamTagExchange.InputTagValue));
		for (int it = 0; it < iterations; it++)
		{
			exchangeCompleted = false;
			uint num2 = 0u;
			List<ExchangeEntry> list = new List<ExchangeEntry>();
			foreach (KeyValuePair<SteamItemRuntime, uint> item in steamItemAmount.ToList())
			{
				uint num3 = (uint)Math.Min(item.Value, exchange.InputAmount - num2);
				if (!item.Key.RuntimeData.GetExchangeEntry(num3, out var entries))
				{
					errored = true;
					Debug.LogError($"[Item Exchange] Error getting exchange entry for item {item.Key.Id} with amount {item.Value}. Aborting item exchange.");
					break;
				}
				list.AddRange(entries);
				steamItemAmount[item.Key] -= num3;
				num2 += num3;
				if (num2 >= exchange.InputAmount)
				{
					break;
				}
			}
			exchange.ItemData.Exchange(list, delegate(InventoryResult result)
			{
				Debug.Log("exchange result received");
				if (result.result != EResult.k_EResultOK)
				{
					Debug.LogError($"[Item Exchange] Error during exchange: {result.result}. Aborting remaining exchanges.");
					exchangeCompleted = true;
					errored = true;
				}
				else
				{
					for (int i = 0; i < result.items.Length; i++)
					{
						SteamItemRuntime steamItemRuntime2 = SteamItemIdReference.Inst[result.items[i].Definition.id];
						steamItemRuntime2.OnItemUpdated?.Invoke();
						if (i == result.items.Length - 1)
						{
							NewItemPopup.Instance.ShowPopup(steamItemRuntime2.Id);
							if (!steamItemRuntime2.IsEmote && SettingsManager.Instance.AutoEquipDrops)
							{
								CatCosmetics.Instance.AutoEquipDrop(steamItemRuntime2.Id);
							}
						}
					}
					exchangeCompleted = true;
					AchievementStats.IncrementExchanges();
				}
			});
			Debug.Log("[Item Exchange] Exchanging");
			yield return new WaitUntil(() => exchangeCompleted);
			if (errored)
			{
				Debug.Log("[Item Exchange] Error during exchange. Aborting remaining exchanges.");
				break;
			}
		}
		foreach (ExchangeSlot exchangeSlot in _exchangeSlots)
		{
			exchangeSlot.SetItem(null, 1L);
		}
		CatInventory.Instance.UpdateVisuals();
		CatInventory.Instance.UpdateItemsUI();
		UpdateInteractable();
		_possibleExchanges = 0;
		UpdateText();
		_isExchanging = false;
		CatInventory.Instance.UpdateScrollView();
	}

	public void UpdateInteractable()
	{
		long num = (from slot in _exchangeSlots
			where slot.ItemSlotted != null
			select slot.SlottedAmount).Sum();
		_possibleExchanges = Mathf.FloorToInt((float)num / 10f);
		_exchangeButton.interactable = _possibleExchanges > 0;
		UpdateText();
		ExchangeSlot exchangeSlot = _exchangeSlots.FirstOrDefault((ExchangeSlot slot) => slot.ItemSlotted != null);
		if ((bool)exchangeSlot)
		{
			_fillDuplicatesFill.color = exchangeSlot.ItemSlotted.QualityCategory.GetColor();
			return;
		}
		List<SteamItemRuntime> duplicateItems = GetDuplicateItems();
		QualityCategoryWithInfo slotDuplicateQuality = GetSlotDuplicateQuality(duplicateItems);
		_fillDuplicatesFill.color = slotDuplicateQuality.ToQuality().GetColor();
	}

	public void SlotItem(SteamItemRuntime steamItem, long amount = 1L)
	{
		if (_isExchanging || !IsItemSlottable(steamItem))
		{
			return;
		}
		foreach (ExchangeSlot exchangeSlot in _exchangeSlots)
		{
			if (exchangeSlot.ItemSlotted == null)
			{
				exchangeSlot.SetItem(steamItem, amount);
				break;
			}
		}
		long num = (from slot in _exchangeSlots
			where slot.ItemSlotted != null
			select slot.SlottedAmount).Sum();
		Debug.Log($"Total slotted: {num}");
		if (num == 1)
		{
			if (steamItem.IsEmote)
			{
				CatInventory.Instance.Tabs.EnableTab(0, enable: false);
				CatInventory.Instance.Tabs.EnableTab(1, enable: false);
			}
			else if (steamItem.IsCosmetic)
			{
				CatInventory.Instance.Tabs.EnableTab(2, enable: false);
			}
		}
		_possibleExchanges = Mathf.FloorToInt((float)num / 10f);
		_exchangeButton.interactable = num >= 10;
		_fillDuplicatesFill.color = steamItem.QualityCategory.GetColor();
		UpdateText();
		steamItem.OnItemUpdated?.Invoke();
		CatInventory.Instance.UpdateItemsUI();
		CatInventory.Instance.UpdateScrollView();
	}

	public void UnslotAllItems()
	{
		if (_isExchanging)
		{
			return;
		}
		foreach (ExchangeSlot exchangeSlot in _exchangeSlots)
		{
			exchangeSlot.OnClick();
		}
		CatInventory.Instance.Tabs.EnableAllTabs(enable: true);
		CatInventory.Instance.UpdateScrollView();
	}

	private bool CanSlotDuplicate(SteamItemRuntime item, bool ignoreTab = false)
	{
		if ((item.IsFavorite && !_allowAutoSlotFavorites.Value) || item.RuntimeData.GetTotalQuantity() <= 1)
		{
			return false;
		}
		if (ExcludeEventItems && item.IsEventItem)
		{
			return false;
		}
		if (!ignoreTab)
		{
			bool flag = (_currentCategoryTabIndex < 2 && item.IsEmote) || (_currentCategoryTabIndex == 2 && item.IsCosmetic);
			if (_exchangeSlots.All((ExchangeSlot slot) => slot.ItemSlotted == null) & flag)
			{
				return false;
			}
		}
		if (_exchangeSlots.Any((ExchangeSlot slot) => slot.ItemSlotted != null && slot.ItemSlotted.QualityCategoryWithInfo != item.QualityCategoryWithInfo))
		{
			return false;
		}
		return true;
	}

	private bool HasDuplicates()
	{
		return CatInventory.Instance.Items.Any((SteamItemRuntime item) => item.RuntimeData.GetTotalQuantity() > 1 && CanSlotDuplicate(item));
	}

	private List<SteamItemRuntime> GetDuplicateItems(bool ignoreTab = false)
	{
		return CatInventory.Instance.Items.Where((SteamItemRuntime item) => item.RuntimeData.GetTotalQuantity() > 1 && CanSlotDuplicate(item, ignoreTab)).ToList();
	}

	public bool CanFillExchangeWithDuplicates(out QualityCategoryWithInfo duplicateQuality)
	{
		List<SteamItemRuntime> duplicateItems = GetDuplicateItems(ignoreTab: true);
		foreach (QualityCategoryWithInfo quality in Enum.GetValues(typeof(QualityCategoryWithInfo)))
		{
			if (!quality.ToQuality().IsTopTier() && duplicateItems.Where((SteamItemRuntime item) => item.QualityCategoryWithInfo == quality).Sum((SteamItemRuntime item) => item.RuntimeData.GetTotalQuantity() - 1) >= _exchangeSlots.Count)
			{
				duplicateQuality = quality;
				return true;
			}
		}
		duplicateQuality = QualityCategoryWithInfo.CommonCosmetic;
		return false;
	}

	public void SlotDuplicates()
	{
		if (_isExchanging || _exchangeSlots.All((ExchangeSlot slot) => slot.ItemSlotted != null) || !HasDuplicates())
		{
			return;
		}
		List<SteamItemRuntime> duplicateItems = GetDuplicateItems();
		QualityCategoryWithInfo targetQuality = GetSlotDuplicateQuality(duplicateItems);
		ExchangeSlot exchangeSlot = _exchangeSlots.FirstOrDefault((ExchangeSlot slot) => slot.ItemSlotted != null);
		if ((bool)exchangeSlot)
		{
			targetQuality = exchangeSlot.ItemSlotted.QualityCategoryWithInfo;
		}
		else
		{
			long num = 0L;
			foreach (QualityCategoryWithInfo quality in Enum.GetValues(typeof(QualityCategoryWithInfo)))
			{
				if (!quality.ToQuality().IsTopTier())
				{
					long num2 = duplicateItems.Where((SteamItemRuntime item) => item.QualityCategoryWithInfo == quality && CanSlotDuplicate(item)).Sum((SteamItemRuntime item) => item.RuntimeData.GetTotalQuantity() - 1);
					if (num2 > num)
					{
						num = num2;
						targetQuality = quality;
					}
				}
			}
		}
		duplicateItems = CatInventory.Instance.Items.Where((SteamItemRuntime item) => item.QualityCategoryWithInfo == targetQuality && CanSlotDuplicate(item) && item.RuntimeData.GetTotalQuantity() > 1).ToList();
		bool flag = false;
		foreach (SteamItemRuntime item in duplicateItems)
		{
			for (int num3 = 0; num3 < item.RuntimeData.GetTotalQuantity() - 1; num3++)
			{
				SlotDuplicate(item);
				flag = _exchangeSlots.All((ExchangeSlot slot) => slot.ItemSlotted != null);
				if (flag)
				{
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		CatInventory.Instance.UpdateItemsUI();
		CatInventory.Instance.UpdateScrollView();
	}

	private QualityCategoryWithInfo GetSlotDuplicateQuality(List<SteamItemRuntime> duplicateItems)
	{
		QualityCategoryWithInfo result = QualityCategoryWithInfo.CommonCosmetic;
		ExchangeSlot exchangeSlot = _exchangeSlots.FirstOrDefault((ExchangeSlot slot) => slot.ItemSlotted != null);
		if ((bool)exchangeSlot)
		{
			result = exchangeSlot.ItemSlotted.QualityCategoryWithInfo;
		}
		else
		{
			long num = 0L;
			foreach (QualityCategoryWithInfo quality in Enum.GetValues(typeof(QualityCategoryWithInfo)))
			{
				if (!quality.ToQuality().IsTopTier())
				{
					long num2 = duplicateItems.Where((SteamItemRuntime item) => item.QualityCategoryWithInfo == quality && CanSlotDuplicate(item)).Sum((SteamItemRuntime item) => item.RuntimeData.GetTotalQuantity() - 1);
					if (num2 > num)
					{
						num = num2;
						result = quality;
					}
				}
			}
		}
		return result;
	}

	private void SlotDuplicate(SteamItemRuntime duplicate)
	{
		if (duplicate.CurrentlyInExchangeSlot <= 0 || duplicate.CurrentlyInExchangeSlot < duplicate.RuntimeData.GetTotalQuantity() - 1)
		{
			SlotItem(duplicate, 1L);
		}
	}

	public bool IsItemExchangeable(SteamItemRuntime steamItem)
	{
		if (!steamItem.IsConsumable)
		{
			return !steamItem.QualityCategory.IsTopTier();
		}
		return false;
	}

	public bool IsItemSameCategory(SteamItemRuntime item)
	{
		if (!IsVisible)
		{
			return true;
		}
		if (!IsItemExchangeable(item))
		{
			return false;
		}
		if (_exchangeSlots.Any((ExchangeSlot slot) => slot.ItemSlotted != null && slot.ItemSlotted.QualityCategoryWithInfo != item.QualityCategoryWithInfo))
		{
			return false;
		}
		return true;
	}

	public bool IsItemSlottable(SteamItemRuntime steamItem)
	{
		if (!IsVisible)
		{
			return true;
		}
		if (!IsItemExchangeable(steamItem))
		{
			return false;
		}
		if (_exchangeSlots.Any((ExchangeSlot slot) => slot.ItemSlotted != null && slot.ItemSlotted.QualityCategoryWithInfo != steamItem.QualityCategoryWithInfo))
		{
			return false;
		}
		if (steamItem.CurrentlyInExchangeSlot > 0 && steamItem.CurrentlyInExchangeSlot >= steamItem.RuntimeData.GetTotalQuantity())
		{
			return false;
		}
		return true;
	}
}
