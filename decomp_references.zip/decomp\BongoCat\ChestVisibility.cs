using System;
using System.Linq;
using IroxGames.Helper.ClassExtensions;
using UnityEngine;

namespace BongoCat;

public class ChestVisibility : MonoBehaviour
{
	[SerializeField]
	private ChestType _chestType;

	private PlayerPrefsToggle[] _playerPrefDependencies => _chestType switch
	{
		ChestType.Cosmetic => new PlayerPrefsToggle[1] { SettingsManager.Instance.MultiplayerPopups }, 
		ChestType.Emote => new PlayerPrefsToggle[2]
		{
			SettingsManager.Instance.MultiplayerPopups,
			SettingsManager.Instance.ShowEmoteChest
		}, 
		_ => Array.Empty<PlayerPrefsToggle>(), 
	};

	private void Awake()
	{
		PlayerPrefsToggle[] playerPrefDependencies = _playerPrefDependencies;
		for (int i = 0; i < playerPrefDependencies.Length; i++)
		{
			playerPrefDependencies[i].OnToggleUpdated.AddListener(OnPlayerPrefsToggle);
		}
	}

	private void Start()
	{
		ApplyVisibility();
	}

	private void OnDestroy()
	{
		PlayerPrefsToggle[] playerPrefDependencies = _playerPrefDependencies;
		for (int i = 0; i < playerPrefDependencies.Length; i++)
		{
			playerPrefDependencies[i].OnToggleUpdated.RemoveListener(OnPlayerPrefsToggle);
		}
	}

	private void OnPlayerPrefsToggle(bool toggle)
	{
		ApplyVisibility();
	}

	private void ApplyVisibility()
	{
		base.gameObject.SetActiveWithCheck(_playerPrefDependencies.All((PlayerPrefsToggle t) => t.Value));
	}
}
