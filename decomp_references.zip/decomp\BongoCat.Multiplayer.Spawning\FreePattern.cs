using System.Collections.Generic;

namespace BongoCat.Multiplayer.Spawning;

public class FreePattern : CatSpawnPatternBase
{
	private readonly BorderLinePattern _startingRow;

	public override SpawnControls Controls => SpawnControls.IncludeMainCat;

	public override bool ComputesSlots => false;

	public override bool PlayerAuthoredSlots => true;

	public override bool KeepsCatsOnTheirSlots => true;

	public FreePattern(CatSpawnSettings settings, BorderLinePattern startingRow)
		: base(settings)
	{
		_startingRow = startingRow;
	}

	protected override List<CatSlot> Layout()
	{
		return _startingRow.BuildLine(SpawnGeometry.ScreenHeight);
	}
}
