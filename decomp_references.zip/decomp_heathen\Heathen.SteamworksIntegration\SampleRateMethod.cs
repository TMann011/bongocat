namespace Heathen.SteamworksIntegration;

public enum SampleRateMethod
{
	Optimal,
	Native,
	Custom
}
