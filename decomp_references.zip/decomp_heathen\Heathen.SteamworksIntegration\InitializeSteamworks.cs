using SteamTools;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[DisallowMultipleComponent]
public class InitializeSteamworks : MonoBehaviour
{
	private void Start()
	{
		Interface.Initialise();
	}
}
