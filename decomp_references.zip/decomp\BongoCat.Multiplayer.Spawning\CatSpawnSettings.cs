using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace BongoCat.Multiplayer.Spawning;

public class CatSpawnSettings : MonoBehaviour
{
	public int RotationOffset;

	public bool IsFlipped;

	[FormerlySerializedAs("_clockwise")]
	public PlayerPrefsToggle Clockwise;

	[FormerlySerializedAs("_includeMainCat")]
	public PlayerPrefsToggle IncludeMainCatToggle;

	private const string PATTERN_KEY = "MultiplayerSpawnPattern";

	private const string DISTANCE_KEY = "MultiplayerPreferredSpawnDist";

	private const string VERTICAL_DISTANCE_KEY = "MultiplayerPreferredSpawnDistVertical";

	private const string ANCHOR_KEY = "MultiplayerSpawnAnchor";

	private const string AXIS_KEY = "MultiplayerSpawnAlignmentAxis";

	private const string FILL_ORDER_KEY = "MultiplayerSpawnFillOrder";

	private const string PATTERN_OPTIONS_KEY = "MultiplayerSpawnPatternOptions";

	private const string DISABLED_SLOTS_KEY = "MultiplayerSpawnDisabledSlots";

	public readonly HashSet<int> DisabledSlots = new HashSet<int>();

	private CatSpawnPatterns _spawnPattern;

	private AnchorCorners _anchorCorner;

	private AlignmentAxes _alignmentAxis;

	private FillOrder _fillOrder;

	private float _preferredDistancePercent;

	private float _preferredVerticalDistancePercent;

	private Dictionary<CatSpawnPatterns, ICatSpawnPattern> _patterns;

	public ICatSpawnPattern Pattern => (_patterns ?? (_patterns = BuildPatterns()))[SpawnPattern];

	public CatSpawnPatterns SpawnPattern
	{
		get
		{
			return _spawnPattern;
		}
		set
		{
			_spawnPattern = value;
			PlayerPrefs.SetInt("MultiplayerSpawnPattern", (int)value);
			PlayerPrefs.Save();
		}
	}

	public float PreferredDistancePercent
	{
		get
		{
			return _preferredDistancePercent;
		}
		set
		{
			_preferredDistancePercent = value;
			PlayerPrefs.SetFloat("MultiplayerPreferredSpawnDist", value);
			PlayerPrefs.Save();
		}
	}

	public float PreferredVerticalDistancePercent
	{
		get
		{
			return _preferredVerticalDistancePercent;
		}
		set
		{
			_preferredVerticalDistancePercent = value;
			PlayerPrefs.SetFloat("MultiplayerPreferredSpawnDistVertical", value);
			PlayerPrefs.Save();
		}
	}

	public AnchorCorners AnchorCorner
	{
		get
		{
			return _anchorCorner;
		}
		set
		{
			_anchorCorner = value;
			PlayerPrefs.SetInt("MultiplayerSpawnAnchor", (int)value);
			PlayerPrefs.Save();
		}
	}

	public AlignmentAxes AlignmentAxis
	{
		get
		{
			return _alignmentAxis;
		}
		set
		{
			_alignmentAxis = value;
			PlayerPrefs.SetInt("MultiplayerSpawnAlignmentAxis", (int)value);
			PlayerPrefs.Save();
		}
	}

	public FillOrder GridFillOrder
	{
		get
		{
			return _fillOrder;
		}
		set
		{
			_fillOrder = value;
			PlayerPrefs.SetInt("MultiplayerSpawnFillOrder", (int)value);
			PlayerPrefs.Save();
		}
	}

	public void SaveDisabledSlots()
	{
		PlayerPrefs.SetString("MultiplayerSpawnDisabledSlots", string.Join(",", DisabledSlots));
		PlayerPrefs.Save();
	}

	private Dictionary<CatSpawnPatterns, ICatSpawnPattern> BuildPatterns()
	{
		BorderLinePattern borderLinePattern = new BorderLinePattern(this, 0, AnchorCorners.BottomLeft, AnchorCorners.BottomRight, AnchorCorners.Center);
		Dictionary<CatSpawnPatterns, ICatSpawnPattern> dictionary = new Dictionary<CatSpawnPatterns, ICatSpawnPattern>();
		dictionary[CatSpawnPatterns.AlignedWithMainCat] = new AlignedWithMainCatPattern(this);
		dictionary[CatSpawnPatterns.BottomBorder] = borderLinePattern;
		dictionary[CatSpawnPatterns.RightBorder] = new BorderLinePattern(this, 1, AnchorCorners.TopRight, AnchorCorners.BottomRight, AnchorCorners.Center);
		dictionary[CatSpawnPatterns.TopBorder] = new BorderLinePattern(this, 2, AnchorCorners.TopLeft, AnchorCorners.TopRight, AnchorCorners.Center);
		dictionary[CatSpawnPatterns.LeftBorder] = new BorderLinePattern(this, 3, AnchorCorners.TopLeft, AnchorCorners.BottomLeft, AnchorCorners.Center);
		dictionary[CatSpawnPatterns.AroundBorder] = new AroundBorderPattern(this);
		dictionary[CatSpawnPatterns.Grid] = new GridPattern(this);
		dictionary[CatSpawnPatterns.Random] = new RandomPattern(this);
		dictionary[CatSpawnPatterns.Free] = new FreePattern(this, borderLinePattern);
		return dictionary;
	}

	public void SaveSessionOptions()
	{
		PlayerPrefs.SetString("MultiplayerSpawnPatternOptions", $"{RotationOffset},{IsFlipped}");
		PlayerPrefs.Save();
	}

	public void LoadFromPlayerPrefs()
	{
		SpawnPattern = (CatSpawnPatterns)PlayerPrefs.GetInt("MultiplayerSpawnPattern", 8);
		PreferredDistancePercent = PlayerPrefs.GetFloat("MultiplayerPreferredSpawnDist", 0.5f);
		PreferredVerticalDistancePercent = PlayerPrefs.GetFloat("MultiplayerPreferredSpawnDistVertical", 0.5f);
		AnchorCorner = (AnchorCorners)PlayerPrefs.GetInt("MultiplayerSpawnAnchor", 3);
		AlignmentAxis = (AlignmentAxes)PlayerPrefs.GetInt("MultiplayerSpawnAlignmentAxis", 0);
		GridFillOrder = (FillOrder)PlayerPrefs.GetInt("MultiplayerSpawnFillOrder", 0);
		string[] array = PlayerPrefs.GetString("MultiplayerSpawnDisabledSlots", "").Split(',');
		for (int i = 0; i < array.Length; i++)
		{
			if (int.TryParse(array[i], out var result))
			{
				DisabledSlots.Add(result);
			}
		}
		string text = PlayerPrefs.GetString("MultiplayerSpawnPatternOptions", "");
		if (!string.IsNullOrEmpty(text))
		{
			string[] array2 = text.Split(',');
			RotationOffset = int.Parse(array2[0]);
			IsFlipped = bool.Parse(array2[1]);
		}
	}
}
