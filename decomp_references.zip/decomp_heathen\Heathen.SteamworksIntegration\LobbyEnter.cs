using System;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct LobbyEnter
{
	public LobbyEnter_t Data;

	public LobbyData Lobby => Data.m_ulSteamIDLobby;

	public EChatRoomEnterResponse Response => (EChatRoomEnterResponse)Data.m_EChatRoomEnterResponse;

	public static implicit operator LobbyEnter(LobbyEnter_t native)
	{
		return new LobbyEnter
		{
			Data = native
		};
	}
}
