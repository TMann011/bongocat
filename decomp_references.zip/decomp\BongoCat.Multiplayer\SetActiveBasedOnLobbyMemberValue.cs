using Heathen.SteamworksIntegration;
using SteamTools;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class SetActiveBasedOnLobbyMemberValue : MonoBehaviour
{
	[SerializeField]
	private GameObject _gameObject;

	[SerializeField]
	private string _key;

	[SerializeField]
	private SteamLobbyMemberData _lobbyMemberData;

	private bool _frozen;

	private void Start()
	{
		Events.OnLobbyDataUpdate += OnLobbyDataUpdate;
		UpdateActiveState();
	}

	private void OnDestroy()
	{
		Events.OnLobbyDataUpdate -= OnLobbyDataUpdate;
	}

	private void UpdateActiveState()
	{
		if (bool.TryParse(_lobbyMemberData.Data[_key], out var result) && _gameObject.activeSelf != result)
		{
			_gameObject.SetActive(result);
		}
	}

	private void OnLobbyDataUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		if (!_frozen && member.HasValue && !(member.Value.user != _lobbyMemberData.Data.user))
		{
			UpdateActiveState();
		}
	}

	public void FreezeState()
	{
		_frozen = true;
	}

	public void Unfreeze()
	{
		_frozen = false;
		UpdateActiveState();
	}
}
