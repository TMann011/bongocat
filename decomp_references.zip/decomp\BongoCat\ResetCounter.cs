using UnityEngine;

namespace BongoCat;

public class ResetCounter : MonoBehaviour
{
	[SerializeField]
	private ErrorMessage _warning;

	public void ShowResetPrompt()
	{
		ErrorMessageHandler.Instance.SetErrorMessage(_warning, leftButtonAction: Pets.Instance.ResetPets, rightButtonAction: ErrorMessageHandler.Instance.CloseErrorPopup);
	}
}
