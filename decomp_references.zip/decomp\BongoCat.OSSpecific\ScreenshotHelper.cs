using System.Collections;
using System.IO;
using BongoCat.OSSpecific.Windows;
using Helper;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.OSSpecific;

public class ScreenshotHelper : MonoBehaviour
{
	private const string ScreenshotLayerName = "Screenshot";

	[SerializeField]
	private Camera _camera;

	[SerializeField]
	private GameObject _gameCanvas;

	[SerializeField]
	private GameObject _multiplayerCanvas;

	[SerializeField]
	private GameObject _screenshotCanvas;

	[SerializeField]
	private Image _hat;

	[SerializeField]
	private Image _base;

	[SerializeField]
	private Image _front;

	[SerializeField]
	private Image _background;

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.F12))
		{
			StartCoroutine(CaptureScreenshotRoutine());
		}
		if (Application.isFocused && Input.GetKeyDown(KeyCode.C) && (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl)) && !InputFieldCache.FocusingInputField)
		{
			CopyCutoutToClipboard();
		}
	}

	public void CopyCutoutToClipboard()
	{
		Texture2D texture2D = RenderCatCutout();
		if ((bool)texture2D)
		{
			ClipboardHelper.CopyImageToClipboard(texture2D);
			Object.Destroy(texture2D);
		}
	}

	private Texture2D RenderCatCutout()
	{
		if (!Cat.Instance)
		{
			return null;
		}
		CatCosmetics.Instance.RestoreActuallyEquippedItems();
		_hat.sprite = Cat.Instance.GetHatSprite();
		_hat.enabled = _hat.sprite;
		_base.sprite = Cat.Instance.GetBaseSprite();
		_front.sprite = Cat.Instance.GetFrontSprite();
		bool flag = _background.enabled;
		bool activeSelf = _gameCanvas.activeSelf;
		bool activeSelf2 = _multiplayerCanvas.activeSelf;
		_background.enabled = false;
		_gameCanvas.SetActive(value: false);
		_multiplayerCanvas.SetActive(value: false);
		_screenshotCanvas.SetActive(value: true);
		Canvas component = _screenshotCanvas.GetComponent<Canvas>();
		RenderMode renderMode = component.renderMode;
		Camera worldCamera = component.worldCamera;
		float planeDistance = component.planeDistance;
		component.renderMode = RenderMode.ScreenSpaceCamera;
		component.worldCamera = _camera;
		component.planeDistance = 1f;
		int cullingMask = _camera.cullingMask;
		CameraClearFlags clearFlags = _camera.clearFlags;
		Color backgroundColor = _camera.backgroundColor;
		_camera.cullingMask = 1 << LayerMask.NameToLayer("Screenshot");
		_camera.clearFlags = CameraClearFlags.Color;
		_camera.backgroundColor = new Color(0f, 0f, 0f, 0f);
		RenderTexture renderTexture = new RenderTexture(Screen.width, Screen.height, 24, RenderTextureFormat.ARGB32);
		RenderTexture active = RenderTexture.active;
		_camera.targetTexture = renderTexture;
		RenderTexture.active = renderTexture;
		Canvas.ForceUpdateCanvases();
		_camera.Render();
		Texture2D texture2D = new Texture2D(renderTexture.width, renderTexture.height, TextureFormat.RGBA32, mipChain: false);
		texture2D.ReadPixels(new Rect(0f, 0f, renderTexture.width, renderTexture.height), 0, 0);
		texture2D.Apply();
		_camera.targetTexture = null;
		RenderTexture.active = active;
		_camera.cullingMask = cullingMask;
		_camera.clearFlags = clearFlags;
		_camera.backgroundColor = backgroundColor;
		component.renderMode = renderMode;
		component.worldCamera = worldCamera;
		component.planeDistance = planeDistance;
		_background.enabled = flag;
		_screenshotCanvas.SetActive(value: false);
		_gameCanvas.SetActive(activeSelf);
		_multiplayerCanvas.SetActive(activeSelf2);
		Object.Destroy(renderTexture);
		return texture2D.CropTexture();
	}

	public void CaptureScreenshot()
	{
		StartCoroutine(CaptureScreenshotRoutine());
	}

	private IEnumerator CaptureScreenshotRoutine()
	{
		CatCosmetics.Instance.RestoreActuallyEquippedItems();
		_hat.sprite = Cat.Instance.GetHatSprite();
		_hat.enabled = _hat.sprite;
		_base.sprite = Cat.Instance.GetBaseSprite();
		_front.sprite = Cat.Instance.GetFrontSprite();
		RenderTexture renderTexture = new RenderTexture(Screen.width, Screen.height, 24);
		_camera.targetTexture = renderTexture;
		RenderTexture.active = renderTexture;
		_gameCanvas.SetActive(value: false);
		_multiplayerCanvas.SetActive(value: false);
		_screenshotCanvas.SetActive(value: true);
		_camera.Render();
		yield return new WaitForEndOfFrame();
		Texture2D texture2D = new Texture2D(renderTexture.width, renderTexture.height, TextureFormat.RGBA32, mipChain: false);
		texture2D.ReadPixels(new Rect(0f, 0f, renderTexture.width, renderTexture.height), 0, 0);
		texture2D.Apply();
		ColorUtility.TryParseHtmlString("#929292", out var color);
		texture2D = texture2D.CropTextureBackground(color);
		_camera.targetTexture = null;
		RenderTexture.active = null;
		byte[] bytes = texture2D.EncodeToPNG();
		string text = Application.dataPath + "/../Screenshots/";
		string text2 = text + "Screenshot.png";
		if (!Directory.Exists(text))
		{
			Directory.CreateDirectory(text);
		}
		File.WriteAllBytes(text2, bytes);
		SteamScreenshots.AddScreenshotToLibrary(text2, null, texture2D.width, texture2D.height);
		Object.Destroy(renderTexture);
		Object.Destroy(texture2D);
		_gameCanvas.SetActive(value: true);
		_multiplayerCanvas.SetActive(value: true);
		_screenshotCanvas.SetActive(value: false);
	}
}
