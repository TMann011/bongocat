using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TranslucentOnHoverSetting : MonoBehaviour
{
	public static TranslucentOnHoverSetting Instance;

	[SerializeField]
	private ToggleGameObject _settingCheckToggle;

	[SerializeField]
	private float[] _temporaryTranslucentDurations;

	[SerializeField]
	private TMP_Dropdown _settingsDropdown;

	[SerializeField]
	private int _standardIdx;

	public bool DisablePopups;

	private int _durationIdx;

	private Coroutine _temporaryTranslucentRoutine;

	public static Action<bool> OnSetTranslucent;

	public bool SettingEnabled;

	private void Awake()
	{
		Instance = this;
		_durationIdx = PlayerPrefs.GetInt("TranslucentDurationIdx", _standardIdx);
	}

	private void Start()
	{
		CreateDurationsDropdown();
	}

	public void ShowTranslucentTemporarily()
	{
		if (_durationIdx != 0)
		{
			if (_temporaryTranslucentRoutine != null)
			{
				StopCoroutine(_temporaryTranslucentRoutine);
			}
			_temporaryTranslucentRoutine = StartCoroutine(TemporaryTranslucentRoutine());
		}
	}

	private IEnumerator TemporaryTranslucentRoutine()
	{
		OnSetTranslucent?.Invoke(obj: true);
		DisablePopups = true;
		yield return new WaitForSeconds(_temporaryTranslucentDurations[_durationIdx - 1]);
		OnSetTranslucent?.Invoke(obj: false);
		DisablePopups = false;
		_temporaryTranslucentRoutine = null;
	}

	private void CreateDurationsDropdown()
	{
		List<string> list = new List<string> { "Translucent Timeout: Off" };
		float[] temporaryTranslucentDurations = _temporaryTranslucentDurations;
		foreach (float num in temporaryTranslucentDurations)
		{
			list.Add($"Translucent Timeout: {num}s");
		}
		_settingsDropdown.ClearOptions();
		_settingsDropdown.AddOptions(list);
		_settingsDropdown.value = _durationIdx;
	}

	public void SetTranslucentDuration(int idx)
	{
		_durationIdx = idx;
		PlayerPrefs.SetInt("TranslucentDurationIdx", _durationIdx);
	}

	public void ToggleSetting()
	{
		_settingCheckToggle.Toggle();
		SettingEnabled = !SettingEnabled;
		if (!SettingEnabled)
		{
			OnSetTranslucent?.Invoke(obj: false);
		}
	}
}
