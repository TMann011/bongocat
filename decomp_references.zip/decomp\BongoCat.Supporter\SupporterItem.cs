using System.Collections;
using BongoCat.SteamJsonParser;
using Helper;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Supporter;

public class SupporterItem : MonoBehaviour
{
	[SerializeField]
	private SteamItemBase _item;

	[SerializeField]
	private TMP_Text _priceText;

	[SerializeField]
	private TMP_Text _ownedText;

	[SerializeField]
	private Image _image;

	[SerializeField]
	private GameObject _boughtPanel;

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		if (_item.ItemData.GetTotalQuantity() > 0)
		{
			_boughtPanel.SetActive(value: true);
			_priceText.enabled = false;
			_ownedText.enabled = true;
			yield break;
		}
		yield return new WaitUntil(() => !string.IsNullOrEmpty(SupporterShop.Instance.PriceSymbol));
		SteamInventory.GetItemPrice(new SteamItemDef_t(_item.Id), out var pCurrentPrice, out var _);
		_priceText.enabled = true;
		_ownedText.enabled = false;
		_priceText.SetText($"{SupporterShop.Instance.PriceSymbol}{(double)pCurrentPrice / 100.0:0.00}");
	}

	private void OnValidate()
	{
		if ((bool)_item)
		{
			string text = "SupporterItem_" + _item.Name.Replace(" ", "");
			if (base.gameObject.name != text)
			{
				base.gameObject.name = text;
				EditorUtilityCompileSafe.SetDirty(base.gameObject);
			}
			Sprite sprite = Object.FindAnyObjectByType<MemoryImageCache>().GetSprite(_item.Name.Replace(" ", "") + "Icon");
			if ((bool)sprite && _image.sprite != sprite)
			{
				_image.sprite = sprite;
				EditorUtilityCompileSafe.SetDirty(_image);
			}
		}
	}

	public void OnBuyButtonClicked()
	{
		Application.OpenURL($"steam://openurl/https://store.steampowered.com/itemstore/{3419430}/detail/{_item.Id}/");
	}
}
