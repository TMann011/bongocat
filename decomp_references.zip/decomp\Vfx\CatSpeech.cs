using System.Collections;
using System.Collections.Generic;
using BongoCat;
using BongoCat.Localizer;
using BongoCat.Multiplayer;
using Crosstales.BWF;
using Crosstales.BWF.Model.Enum;
using Crosstales.Common.Util;
using DG.Tweening;
using Heathen.SteamworksIntegration;
using Helper;
using IroxGames.Helper.ClassExtensions;
using TMPro;
using UnityEngine;

namespace Vfx;

public class CatSpeech : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _speechText;

	[SerializeField]
	private GameObject _speechBubble;

	[SerializeField]
	private float _hoverRadius;

	[SerializeField]
	private int _maxChars;

	[SerializeField]
	private Transform _speechButton;

	[SerializeField]
	private GameObject _speechTextfieldGo;

	[SerializeField]
	private PlayerPrefsToggle _meowMeowSetting;

	private bool _clickedOnObject;

	private bool _isMainCat;

	[SerializeField]
	private SteamLobbyMemberData _lobbyMemberData;

	private Dictionary<string, string> _meowLocaDict;

	private Dictionary<string, string> MeowLocaDict => _meowLocaDict ?? (_meowLocaDict = Localize.GetAllForKey("Meow"));

	private string MeowText => MeowLocaDict.GetValueOrDefault(Localize.CurrentCode, "Meow Meow");

	private void Awake()
	{
		if (!(_hoverRadius <= 0f))
		{
			_isMainCat = true;
		}
	}

	private void Start()
	{
		if ((bool)_lobbyMemberData)
		{
			SteamMultiplayer.Instance.OnChatReceived.Register(_lobbyMemberData.Data.user, ShowMultiplayerSpeech);
		}
	}

	private void OnDestroy()
	{
		if ((bool)_lobbyMemberData)
		{
			SteamMultiplayer.Instance.OnChatReceived.Deregister(_lobbyMemberData.Data.user, ShowMultiplayerSpeech);
		}
	}

	private void Update()
	{
		if (!_isMainCat)
		{
			return;
		}
		if (TranslucentOnHoverSetting.Instance.DisablePopups || GamingMode.Instance.IsEnabled)
		{
			_speechButton.gameObject.SetActiveWithCheck(active: false);
		}
		else
		{
			if (_speechBubble.activeSelf || _speechTextfieldGo.activeSelf || !LobbyData.Current.IsValid)
			{
				return;
			}
			if (Input.GetKeyDown(KeyCode.Return) && !InputFieldCache.FocusingInputField)
			{
				_speechTextfieldGo.SetActive(value: true);
				return;
			}
			bool active = false;
			Vector2 a = Input.mousePosition;
			Vector2 b = RectTransformUtility.WorldToScreenPoint(null, _speechButton.position);
			if (Vector2.Distance(a, b) < _hoverRadius * SettingsManager.Instance.UIScaleSetting.GetRealScaleFactor())
			{
				active = true;
			}
			_speechButton.gameObject.SetActiveWithCheck(active);
		}
	}

	public void OpenChat()
	{
		_speechButton.gameObject.SetActiveWithCheck(active: false);
		_speechText.gameObject.SetActiveWithCheck(active: true);
	}

	public void SendSpeech(string speech)
	{
		if (string.IsNullOrEmpty(speech))
		{
			if (!_meowMeowSetting.Value)
			{
				return;
			}
			speech = MeowText;
		}
		if (!SettingsManager.Instance.ChatLanguageFilter.Value || !Singleton<BWFManager>.Instance.Contains(speech, ManagerMask.All))
		{
			SteamMultiplayer.SendSpeech(speech);
		}
		_speechText.text = speech;
		_speechButton.gameObject.SetActive(value: false);
		ShowSpeech();
	}

	private void ShowMultiplayerSpeech(string speech)
	{
		if ((bool)_speechBubble && !string.IsNullOrEmpty(speech) && !SettingsManager.Instance.MuteChats.Value)
		{
			if (SettingsManager.Instance.ChatLanguageFilter.Value)
			{
				speech = Singleton<BWFManager>.Instance.ReplaceAll(speech, ManagerMask.All);
			}
			_speechText.text = speech;
			ShowSpeech();
		}
	}

	private void ShowSpeech()
	{
		if (base.gameObject.activeInHierarchy)
		{
			_speechBubble.SetActive(value: true);
			StopAllCoroutines();
			StartCoroutine(DoShowSpeech());
		}
	}

	private IEnumerator DoShowSpeech()
	{
		Transform bubbleTransform = _speechBubble.transform;
		bubbleTransform.DOKill();
		bubbleTransform.localScale = new Vector3(0.4f, 0.8f, 0.8f);
		bubbleTransform.DOScale(Vector3.one, 0.15f).SetEase(Ease.OutQuad);
		yield return new WaitForSeconds(2f + (float)_speechText.text.Length * 0.1f);
		bubbleTransform.DOScale(new Vector3(0.3f, 0.8f, 0.8f), 0.15f).SetEase(Ease.InQuad);
		yield return new WaitForSeconds(0.15f);
		_speechBubble.gameObject.SetActive(value: false);
	}

	private void OnDisable()
	{
		_speechBubble.SetActive(value: false);
	}
}
