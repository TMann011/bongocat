using System.Collections;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace BongoCat.Steam;

public class ItemDropHeartbeat : MonoBehaviour
{
	private IEnumerator Start()
	{
		while (true)
		{
			yield return new WaitForSecondsRealtime(60f);
			if (Interface.IsReady)
			{
				SteamInventory.SendItemDropHeartbeat();
			}
		}
	}
}
