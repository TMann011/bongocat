using SteamTools;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

public class SteamLobbyPlayButtons : MonoBehaviour
{
	public GameObject playUiElement;

	public GameObject waitingUiElement;

	public GameObject leaveUiElement;

	private void Awake()
	{
		Events.OnLobbyEnterSuccess += HandleLobbyEnter;
		Events.OnLobbyLeave += HandleLobbyLeave;
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= HandleLobbyEnter;
		Events.OnLobbyLeave -= HandleLobbyLeave;
	}

	private void HandleLobbyEnter(LobbyData lobby)
	{
		UpdateLobbyButtons();
	}

	private void HandleLobbyLeave(LobbyData arg0)
	{
		UpdateLobbyButtons();
	}

	private void UpdateLobbyButtons()
	{
		if (LobbyData.PartyLobby(out var lobby) && !lobby.IsOwner)
		{
			waitingUiElement.SetActive(value: true);
			playUiElement.SetActive(value: false);
			leaveUiElement.SetActive(value: false);
			return;
		}
		waitingUiElement.SetActive(value: false);
		if (LobbyData.SessionLobby(out var _))
		{
			playUiElement.SetActive(value: false);
			leaveUiElement.SetActive(value: true);
		}
		else
		{
			playUiElement.SetActive(value: true);
			leaveUiElement.SetActive(value: false);
		}
	}
}
