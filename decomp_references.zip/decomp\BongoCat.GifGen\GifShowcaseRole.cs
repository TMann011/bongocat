namespace BongoCat.GifGen;

public enum GifShowcaseRole
{
	ShowBackground,
	HideDuringCapture,
	CatRoot
}
