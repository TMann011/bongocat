using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat;
using BongoCat.Localizer;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Steam;

public class TrashCan : MonoBehaviour
{
	public static TrashCan Instance;

	[SerializeField]
	private Transform _trashSlotRoot;

	[SerializeField]
	private Button _deleteButton;

	[SerializeField]
	private Button _confirmSelectedItemDeletionButton;

	[SerializeField]
	private Button _confirmFullInventoryDeletionButton;

	[SerializeField]
	private MenuTabs _menuTabs;

	private Dictionary<SteamItemRuntime, TrashSlot> _slots = new Dictionary<SteamItemRuntime, TrashSlot>();

	[SerializeField]
	private bool _inTrashMode;

	[SerializeField]
	private TrashSlot _trashSlotPrefab;

	[SerializeField]
	private TMP_Text _deleteSelectedWarningText;

	private bool _confirmedItemDeletion;

	private const string DELETE_ITEMS_WARNING_LOCA_KEY = "DeleteSelectedItemsWarning";

	public bool InTrashMode => _inTrashMode;

	private void Awake()
	{
		Instance = this;
	}

	public void AddToTrash(SteamItemRuntime item)
	{
		if (_slots.ContainsKey(item))
		{
			RemoveFromTrash(item);
		}
		TrashSlot trashSlot = Object.Instantiate(_trashSlotPrefab, _trashSlotRoot);
		trashSlot.SetItem(item);
		_slots.Add(item, trashSlot);
		_deleteButton.interactable = _slots.Keys.Count > 0;
		_deleteSelectedWarningText.SetText(Localize.Get("DeleteSelectedItemsWarning", _slots.Keys.Count));
		item.OnItemUpdated?.Invoke();
	}

	public void RemoveFromTrash(SteamItemRuntime item)
	{
		if (_slots.TryGetValue(item, out var value))
		{
			Object.Destroy(value.gameObject);
			_slots.Remove(item);
			_deleteButton.interactable = _slots.Keys.Count > 0;
			item.OnItemUpdated?.Invoke();
		}
	}

	public void RestoreAllItems()
	{
		_inTrashMode = false;
		if (_slots.Count == 0)
		{
			return;
		}
		List<SteamItemRuntime> list = _slots.Keys.ToList();
		foreach (TrashSlot value in _slots.Values)
		{
			Object.Destroy(value.gameObject);
		}
		_slots.Clear();
		foreach (SteamItemRuntime item in list)
		{
			item.OnItemUpdated?.Invoke();
		}
		_deleteButton.interactable = false;
	}

	public void DeleteSlottedItems()
	{
		if (!_confirmedItemDeletion)
		{
			return;
		}
		foreach (SteamItemRuntime item in _slots.Keys)
		{
			item.RuntimeData.Consume((uint)item.RuntimeData.GetTotalQuantity(), delegate
			{
				item.OnItemUpdated?.Invoke();
			});
		}
		_inTrashMode = false;
		_deleteButton.interactable = _slots.Keys.Count > 0;
		_confirmedItemDeletion = false;
		ConfirmSelectedItemsDeletion(confirmed: false);
	}

	public void DeleteFullInventory()
	{
		if (_confirmedItemDeletion)
		{
			StartCoroutine(DeleteAll());
		}
	}

	private IEnumerator DeleteAll()
	{
		IEnumerable<SteamItemRuntime> enumerable = CatInventory.Instance.Items.Where((SteamItemRuntime steamItemRuntime) => steamItemRuntime.IsOwned);
		int i = 0;
		foreach (SteamItemRuntime item in enumerable)
		{
			if (i++ % 50 == 0)
			{
				yield return new WaitForSeconds(1f);
			}
			item.RuntimeData.Consume((uint)item.RuntimeData.GetTotalQuantity(), delegate
			{
			});
		}
		CatInventory.Instance.UpdateItemsUI();
		ConfirmFullInventoryDeletion(confirmed: false);
	}

	public void EnterTrashMode()
	{
		_inTrashMode = true;
		_menuTabs.OpenMenuTab(MenuTabs.MenuTab.TrashBin);
	}

	public void ConfirmSelectedItemsDeletion(bool confirmed)
	{
		_confirmedItemDeletion = confirmed;
		_confirmSelectedItemDeletionButton.interactable = confirmed;
	}

	public void ConfirmFullInventoryDeletion(bool confirmed)
	{
		_confirmedItemDeletion = confirmed;
		_confirmFullInventoryDeletionButton.interactable = confirmed;
	}

	public bool IsItemInTrash(SteamItemRuntime item)
	{
		return _slots.ContainsKey(item);
	}
}
