using Heathen.SteamworksIntegration.API;
using SteamTools;
using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInputActionData))]
public class SteamInputActionName : MonoBehaviour
{
	public TextMeshProUGUI label;

	private SteamInputActionData _mInspector;

	private void Start()
	{
		_mInspector = GetComponent<SteamInputActionData>();
		Interface.WhenReady(HandleInitialization);
	}

	private void HandleInitialization()
	{
		RefreshName();
	}

	private void OnEnable()
	{
		RefreshName();
	}

	public void RefreshName()
	{
		if (!(_mInspector != null) || string.IsNullOrEmpty(_mInspector.Action.Name) || !(label != null))
		{
			return;
		}
		if (_mInspector.Set.Handle != 0)
		{
			if (Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers.Count > 0)
			{
				string[] inputNames = _mInspector.Action.GetInputNames(Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers[0], _mInspector.Set);
				if (inputNames.Length != 0)
				{
					label.text = inputNames[0];
				}
			}
		}
		else if (!string.IsNullOrEmpty(_mInspector.Layer.LayerName) && Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers.Count > 0)
		{
			string[] inputNames2 = _mInspector.Action.GetInputNames(Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers[0], _mInspector.Layer);
			if (inputNames2.Length != 0)
			{
				label.text = inputNames2[0];
			}
		}
	}
}
