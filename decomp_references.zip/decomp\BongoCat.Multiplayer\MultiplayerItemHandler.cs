using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class MultiplayerItemHandler : MonoBehaviour
{
	[SerializeField]
	private NewItemPopup _newItemPopup;

	[SerializeField]
	private SteamLobbyMemberData _lobbyMemberData;

	private void Start()
	{
		SettingsManager.Instance.MultiplayerPopups.OnToggleUpdated.AddListener(OnMultiplayerPopupsToggle);
		OnMultiplayerPopupsToggle(SettingsManager.Instance.MultiplayerPopups.Value);
		SteamMultiplayer.Instance.OnItemReceived.Register(_lobbyMemberData.Data.user, DisplayReceivedItem);
	}

	private void OnDestroy()
	{
		SettingsManager.Instance.MultiplayerPopups.OnToggleUpdated.RemoveListener(OnMultiplayerPopupsToggle);
		SteamMultiplayer.Instance.OnItemReceived.Deregister(_lobbyMemberData.Data.user, DisplayReceivedItem);
	}

	private void OnMultiplayerPopupsToggle(bool toggle)
	{
		if (!toggle)
		{
			_newItemPopup.HidePopup();
		}
	}

	private void DisplayReceivedItem(int itemId)
	{
		if (SettingsManager.Instance.MultiplayerPopups.Value && !PlayerDataCache.GetIsHidden(_lobbyMemberData.Data.user.IdStr))
		{
			_newItemPopup.ShowPopup(itemId);
		}
	}
}
