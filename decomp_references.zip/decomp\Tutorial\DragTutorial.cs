using BongoCat;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

namespace Tutorial;

public class DragTutorial : TutorialStep
{
	[SerializeField]
	private float _duration;

	[SerializeField]
	private RectTransform _mouse;

	[SerializeField]
	private Image _circle;

	[SerializeField]
	private Vector2 _travelOffset;

	[SerializeField]
	private Draggable _dragMainCat;

	[SerializeField]
	private PlayerPrefsToggle _forbidDrag;

	private Vector2 _mouseStart;

	public void OnBegin()
	{
		_dragMainCat.OnDragFinished.AddListener(base.Complete);
		_forbidDrag.ToggleOff();
		_mouseStart = _mouse.anchoredPosition;
		_circle.transform.localScale = Vector3.zero;
		_circle.transform.DOScale(1f, _duration).SetLoops(-1);
		_circle.DOFade(0f, _duration).SetEase(Ease.Linear).SetLoops(-1);
		_mouse.DOAnchorPos(_mouseStart + _travelOffset, _duration).SetLoops(-1);
		_circle.gameObject.SetActive(value: true);
		_mouse.gameObject.SetActive(value: true);
	}

	public void OnComplete()
	{
		DOTween.Kill(_circle.transform);
		DOTween.Kill(_circle);
		DOTween.Kill(_mouse);
		_mouse.anchoredPosition = _mouseStart;
		_dragMainCat.OnDragFinished.RemoveListener(base.Complete);
		_circle.gameObject.SetActive(value: false);
		_mouse.gameObject.SetActive(value: false);
	}
}
