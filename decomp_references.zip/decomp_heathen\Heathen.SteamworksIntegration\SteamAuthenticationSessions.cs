using System;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamAuthenticationEvents))]
public class SteamAuthenticationSessions : MonoBehaviour
{
	[Flags]
	public enum AuthSessionResponseMask
	{
		None = 0,
		Ok = 1,
		NotConnectedToSteam = 2,
		NoLicenseOrExpired = 4,
		VacBanned = 8,
		LoggedInElseWhere = 0x10,
		VacCheckTimedOut = 0x20,
		Canceled = 0x40,
		AlreadyUsed = 0x80,
		Invalid = 0x100,
		PublisherIssuedBan = 0x200,
		IdentityFailure = 0x400
	}

	public AuthSessionResponseMask acceptedResponses;

	private SteamAuthenticationEvents _mEvents;

	public List<AuthenticationSession> Sessions => Authentication.ActiveSessions;

	private void Awake()
	{
		_mEvents = GetComponent<SteamAuthenticationEvents>();
	}

	public void Begin(ulong user, byte[] ticket)
	{
		EBeginAuthSessionResult eBeginAuthSessionResult = Authentication.BeginAuthSession(ticket, user, delegate(AuthenticationSession session)
		{
			AuthSessionResponseMask authSessionResponseMask = session.Response switch
			{
				EAuthSessionResponse.k_EAuthSessionResponseOK => AuthSessionResponseMask.Ok, 
				EAuthSessionResponse.k_EAuthSessionResponseUserNotConnectedToSteam => AuthSessionResponseMask.NotConnectedToSteam, 
				EAuthSessionResponse.k_EAuthSessionResponseNoLicenseOrExpired => AuthSessionResponseMask.NoLicenseOrExpired, 
				EAuthSessionResponse.k_EAuthSessionResponseVACBanned => AuthSessionResponseMask.VacBanned, 
				EAuthSessionResponse.k_EAuthSessionResponseLoggedInElseWhere => AuthSessionResponseMask.LoggedInElseWhere, 
				EAuthSessionResponse.k_EAuthSessionResponseVACCheckTimedOut => AuthSessionResponseMask.VacCheckTimedOut, 
				EAuthSessionResponse.k_EAuthSessionResponseAuthTicketCanceled => AuthSessionResponseMask.Canceled, 
				EAuthSessionResponse.k_EAuthSessionResponseAuthTicketInvalidAlreadyUsed => AuthSessionResponseMask.AlreadyUsed, 
				EAuthSessionResponse.k_EAuthSessionResponseAuthTicketInvalid => AuthSessionResponseMask.Invalid, 
				EAuthSessionResponse.k_EAuthSessionResponsePublisherIssuedBan => AuthSessionResponseMask.PublisherIssuedBan, 
				EAuthSessionResponse.k_EAuthSessionResponseAuthTicketNetworkIdentityFailure => AuthSessionResponseMask.IdentityFailure, 
				_ => AuthSessionResponseMask.None, 
			};
			if ((acceptedResponses & authSessionResponseMask) != AuthSessionResponseMask.None)
			{
				_mEvents.onSessionStart?.Invoke(session.Response);
			}
			else
			{
				session.End();
				_mEvents.onInvalidSession?.Invoke(session.Response);
			}
		});
		if (eBeginAuthSessionResult != EBeginAuthSessionResult.k_EBeginAuthSessionResultOK)
		{
			_mEvents.onInvalidTicket?.Invoke(eBeginAuthSessionResult);
		}
	}

	public void End(ulong user)
	{
		Authentication.EndAuthSession(user);
	}

	public void End(SteamUserData user)
	{
		if (user != null && user.Data.IsValid)
		{
			Authentication.EndAuthSession(user.Data);
		}
	}

	public void EndAll()
	{
		Authentication.EndAllSessions();
	}
}
