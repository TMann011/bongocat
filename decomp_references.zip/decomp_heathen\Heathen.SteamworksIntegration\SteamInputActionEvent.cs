using System.Linq;
using SteamTools;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInputActionData))]
public class SteamInputActionEvent : MonoBehaviour
{
	public ActionUpdateEvent onChanged;

	private SteamInputActionData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamInputActionData>();
		Events.OnInputDataChanged += HandleEvent;
	}

	private void OnDestroy()
	{
		Events.OnInputDataChanged -= HandleEvent;
	}

	private void HandleEvent(InputControllerStateData controller)
	{
		InputActionUpdate arg = controller.changes.FirstOrDefault((InputActionUpdate p) => p.name == _mInspector.Action.Name);
		if (arg.name == _mInspector.Action.Name)
		{
			onChanged.Invoke(arg);
		}
	}
}
