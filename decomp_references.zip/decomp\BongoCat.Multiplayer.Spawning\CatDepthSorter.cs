using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public class CatDepthSorter : MonoBehaviour
{
	private readonly List<Transform> _cats = new List<Transform>();

	public void Sort(int horizontalSign)
	{
		_cats.Clear();
		for (int i = 0; i < base.transform.childCount; i++)
		{
			_cats.Add(base.transform.GetChild(i));
		}
		IOrderedEnumerable<Transform> orderedEnumerable = _cats.OrderByDescending(Depth);
		if (horizontalSign != 0)
		{
			orderedEnumerable = orderedEnumerable.ThenBy((Transform cat) => (float)horizontalSign * cat.position.x);
		}
		int num = 0;
		foreach (Transform item in orderedEnumerable)
		{
			if (item.GetSiblingIndex() != num)
			{
				item.SetSiblingIndex(num);
			}
			num++;
		}
	}

	private static float Depth(Transform cat)
	{
		CatRotator component = cat.GetComponent<CatRotator>();
		Vector2 rhs = (component ? SpawnGeometry.QuarterTurn(Vector2.up, component.RotationState) : ((Vector2)cat.up));
		return Vector2.Dot(cat.position, rhs);
	}
}
