using System;
using Heathen.SteamworksIntegration.API;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct LeaderboardData : IEquatable<SteamLeaderboard_t>, IEquatable<ulong>, IEquatable<string>
{
	public string apiName;

	public SteamLeaderboard_t id;

	public string DisplayName => SteamUserStats.GetLeaderboardName(id);

	public bool IsValid => id.m_SteamLeaderboard != 0;

	public void GetUserEntry(int maxDetailEntries, Action<LeaderboardEntry, bool> callback)
	{
		Leaderboards.Client.DownloadEntries(id, new CSteamID[1] { UserData.Me }, maxDetailEntries, delegate(LeaderboardEntry[] results, bool error)
		{
			if (error || results.Length == 0)
			{
				callback(null, error);
			}
			else
			{
				callback(results[0], arg2: false);
			}
		});
	}

	public void GetTopEntries(int count, int maxDetailEntries, Action<LeaderboardEntry[], bool> callback)
	{
		GetEntries(ELeaderboardDataRequest.k_ELeaderboardDataRequestGlobal, 0, count, maxDetailEntries, callback);
	}

	public void GetEntries(ELeaderboardDataRequest request, int start, int end, int maxDetailEntries, Action<LeaderboardEntry[], bool> callback)
	{
		Leaderboards.Client.DownloadEntries(id, request, start, end, maxDetailEntries, callback);
	}

	public void UploadScoreKeepBest(int score, int[] details, Action<LeaderboardScoreUploaded, bool> callback = null)
	{
		UploadScore(score, details, ELeaderboardUploadScoreMethod.k_ELeaderboardUploadScoreMethodKeepBest, callback);
	}

	public void UploadScoreForceUpdate(int score, int[] details, Action<LeaderboardScoreUploaded, bool> callback = null)
	{
		UploadScore(score, details, ELeaderboardUploadScoreMethod.k_ELeaderboardUploadScoreMethodForceUpdate, callback);
	}

	public void UploadScore(int score, int[] scoreDetails, ELeaderboardUploadScoreMethod method, Action<LeaderboardScoreUploaded, bool> callback = null)
	{
		Leaderboards.Client.UploadScore(id, method, score, scoreDetails, callback);
	}

	public override string ToString()
	{
		return apiName;
	}

	public override int GetHashCode()
	{
		SteamLeaderboard_t steamLeaderboard_t = id;
		return steamLeaderboard_t.GetHashCode() + apiName.GetHashCode();
	}

	public override bool Equals(object obj)
	{
		if (obj is SteamLeaderboard_t other)
		{
			return Equals(other);
		}
		if (obj is string other2)
		{
			return Equals(other2);
		}
		if (obj is ulong other3)
		{
			return Equals(other3);
		}
		SteamLeaderboard_t steamLeaderboard_t = id;
		return steamLeaderboard_t.Equals(obj);
	}

	public bool Equals(SteamLeaderboard_t other)
	{
		SteamLeaderboard_t steamLeaderboard_t = id;
		return steamLeaderboard_t.Equals(other);
	}

	public bool Equals(ulong other)
	{
		ulong steamLeaderboard = id.m_SteamLeaderboard;
		return steamLeaderboard.Equals(other);
	}

	public bool Equals(string other)
	{
		return apiName.Equals(other);
	}

	public static bool operator ==(LeaderboardData l, LeaderboardData r)
	{
		return l.id == r.id;
	}

	public static implicit operator SteamLeaderboard_t(LeaderboardData c)
	{
		return c.id;
	}

	public static implicit operator LeaderboardData(SteamLeaderboard_t id)
	{
		return new LeaderboardData
		{
			id = id
		};
	}
}
