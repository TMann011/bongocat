using System.Collections.Generic;
using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public class AroundBorderPattern : CatSpawnPatternBase
{
	public override SpawnControls Controls => SpawnControls.Spacing | SpawnControls.Anchor | SpawnControls.Clockwise | SpawnControls.IncludeMainCat | SpawnControls.SnapCats | SpawnControls.Recalculate;

	public AroundBorderPattern(CatSpawnSettings settings)
		: base(settings)
	{
	}

	protected override int SlotRotation(int layoutRotation)
	{
		if (Settings.RotationOffset != 0)
		{
			return Settings.RotationOffset;
		}
		return layoutRotation;
	}

	protected override List<CatSlot> Layout()
	{
		float perimeter = SpawnGeometry.Perimeter;
		int num = SlotsFromSlider(Mathf.Clamp(Mathf.CeilToInt(perimeter / SpawnGeometry.TightestSpacing), 1, 250));
		float num2 = perimeter / (float)num;
		float num3 = ClockwiseDistanceToAnchor(Settings.AnchorCorner);
		float num4 = (Settings.Clockwise.Value ? num2 : (0f - num2));
		List<CatSlot> list = new List<CatSlot>();
		for (int i = 0; i < num; i++)
		{
			PointOnBorder(Mathf.Repeat(num3 + num4 * (float)i, perimeter), out var position, out var rotationState);
			list.Add(new CatSlot
			{
				Position = position,
				RotationState = rotationState
			});
		}
		return list;
	}

	private static void PointOnBorder(float travelled, out Vector2 position, out int rotationState)
	{
		if (travelled < SpawnGeometry.ScreenWidth)
		{
			position = new Vector2(SpawnGeometry.XMin + SpawnGeometry.Inset + travelled, SpawnGeometry.YMax);
			rotationState = 2;
			return;
		}
		travelled -= SpawnGeometry.ScreenWidth;
		if (travelled < SpawnGeometry.ScreenHeight)
		{
			position = new Vector2(SpawnGeometry.XMax, SpawnGeometry.YMax - SpawnGeometry.Inset - travelled);
			rotationState = 1;
			return;
		}
		travelled -= SpawnGeometry.ScreenHeight;
		if (travelled < SpawnGeometry.ScreenWidth)
		{
			position = new Vector2(SpawnGeometry.XMax - SpawnGeometry.Inset - travelled, SpawnGeometry.YMin);
			rotationState = 0;
		}
		else
		{
			travelled -= SpawnGeometry.ScreenWidth;
			position = new Vector2(SpawnGeometry.XMin, SpawnGeometry.YMin + SpawnGeometry.Inset + travelled);
			rotationState = 3;
		}
	}

	private static float ClockwiseDistanceToAnchor(AnchorCorners anchor)
	{
		return anchor switch
		{
			AnchorCorners.TopRight => SpawnGeometry.ScreenWidth, 
			AnchorCorners.BottomRight => SpawnGeometry.ScreenWidth + SpawnGeometry.ScreenHeight, 
			AnchorCorners.BottomLeft => 2f * SpawnGeometry.ScreenWidth + SpawnGeometry.ScreenHeight, 
			AnchorCorners.Center => 1.5f * SpawnGeometry.ScreenWidth + SpawnGeometry.ScreenHeight, 
			_ => 0f, 
		};
	}
}
