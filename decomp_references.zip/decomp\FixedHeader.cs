using UnityEngine;
using UnityEngine.UI;

public class FixedHeader : MonoBehaviour
{
	[SerializeField]
	private RectTransform _fixedPosParent;

	[SerializeField]
	private RectTransform _scrollPosParent;

	[SerializeField]
	private int _parentsToRebuild = 1;

	private ScrollRect _scrollRect;

	private bool _isFixedToTop;

	private float _height;

	private float _upperY;

	private void Awake()
	{
		_scrollRect = GetComponentInParent<ScrollRect>();
		_height = ((RectTransform)base.transform).rect.height;
		_upperY = (0f - _height) / 2f;
	}

	private void Update()
	{
		float y = _scrollRect.viewport.InverseTransformPoint(_scrollPosParent.position).y;
		if (!_isFixedToTop)
		{
			if (y > _upperY)
			{
				base.transform.SetParent(_fixedPosParent, worldPositionStays: false);
				RebuildLayout();
				_isFixedToTop = true;
			}
		}
		else if (y < _upperY)
		{
			base.transform.SetParent(_scrollPosParent, worldPositionStays: false);
			RebuildLayout();
			_isFixedToTop = false;
		}
	}

	private void RebuildLayout()
	{
		LayoutRebuilder.ForceRebuildLayoutImmediate(_fixedPosParent);
		Transform parent = _scrollPosParent.transform;
		for (int i = 0; i <= _parentsToRebuild; i++)
		{
			LayoutRebuilder.ForceRebuildLayoutImmediate(parent as RectTransform);
			if (!parent.parent)
			{
				break;
			}
			parent = parent.parent;
		}
	}
}
