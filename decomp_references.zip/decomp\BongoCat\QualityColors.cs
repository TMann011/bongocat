using UnityEngine;

namespace BongoCat;

public class QualityColors : ScriptableObject
{
}
