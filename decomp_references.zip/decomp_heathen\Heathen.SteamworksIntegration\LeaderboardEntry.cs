using System.Reflection;
using Steamworks;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[DefaultMember("Item")]
public class LeaderboardEntry
{
	public LeaderboardEntry_t Entry;

	public int[] Details;

	public string CashedUgcFileName = string.Empty;

	public UnityEvent<string> EvtUgcDownloaded = new UnityEvent<string>();

	public UserData User => Entry.m_steamIDUser;

	public int Rank => Entry.m_nGlobalRank;

	public int Score => Entry.m_nScore;
}
