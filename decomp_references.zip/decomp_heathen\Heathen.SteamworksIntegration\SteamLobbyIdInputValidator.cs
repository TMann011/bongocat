using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(TMP_InputField))]
public class SteamLobbyIdInputValidator : MonoBehaviour
{
	public int minimalIdLength = 8;

	[FormerlySerializedAs("OnValid")]
	public UnityEvent onValid;

	private TMP_InputField _mInputField;

	private void Awake()
	{
		_mInputField = GetComponent<TMP_InputField>();
		_mInputField.onValueChanged.AddListener(HandleValueChanged);
	}

	private void OnDestroy()
	{
		_mInputField.onValueChanged.RemoveListener(HandleValueChanged);
	}

	private void HandleValueChanged(string arg0)
	{
		if (arg0.Length >= minimalIdLength && LobbyData.Get(arg0).IsValid)
		{
			onValid?.Invoke();
		}
	}
}
