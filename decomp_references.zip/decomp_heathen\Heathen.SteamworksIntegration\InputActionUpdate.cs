using System;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct InputActionUpdate
{
	public InputHandle_t controller;

	public string name;

	public InputActionType type;

	public EInputSourceMode mode;

	public bool isActive;

	public bool isState;

	public float isX;

	public float isY;

	public bool wasActive;

	public bool wasState;

	public float wasX;

	public float wasY;

	public InputActionStateData Data => new InputActionStateData
	{
		controller = controller,
		name = name,
		type = type,
		mode = mode,
		active = isActive,
		state = isState,
		x = isX,
		y = isY
	};
}
