using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat.SteamJsonParser;

public abstract class SteamItemBase : ScriptableObject
{
	public int Id;

	public string Name;

	public ItemData ItemData => Id;

	public bool HasItem => ItemData.GetTotalQuantity() > 0;

	public abstract SteamItemJson ToSteamItemBackend();
}
