using System;
using System.Collections.Generic;
using SteamTools;
using Steamworks;
using TMPro;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamUserData))]
public class SteamUserStatus : MonoBehaviour
{
	[Serializable]
	public class Options
	{
		[Serializable]
		public class References
		{
			public Sprite icon;

			public bool setIconColor;

			public Color iconColor;

			[Tooltip("You can use %gameName% and it will be replaced with the name of the game the player is currently playing. This is only relevant for In This Game and In Another Game options.")]
			public SteamText message;

			public bool setMessageColor;

			public Color messageColor;

			public void Set(Image image, TextMeshProUGUI label, FriendGameInfo_t? gameInfo)
			{
				if (image != null)
				{
					image.gameObject.SetActive(value: true);
					image.sprite = icon;
					if (setIconColor)
					{
						image.color = iconColor;
					}
				}
				label.text = message;
				if (setMessageColor)
				{
					label.color = messageColor;
				}
			}
		}

		[FormerlySerializedAs("InThisGame")]
		public References inThisGame = new References
		{
			setIconColor = false,
			iconColor = new Color(0.8862f, 0.996f, 0.7568f, 1f),
			message = new SteamText("Playing %gameName%"),
			setMessageColor = false,
			messageColor = new Color(0.8862f, 0.996f, 0.7568f, 1f)
		};

		[FormerlySerializedAs("InAnotherGame")]
		public References inAnotherGame = new References
		{
			setIconColor = false,
			iconColor = new Color(0.5686f, 0.7607f, 0.3411f, 1f),
			message = new SteamText("Playing %gameName%"),
			setMessageColor = false,
			messageColor = new Color(0.5686f, 0.7607f, 0.3411f, 1f)
		};

		[FormerlySerializedAs("Online")]
		public References online = new References
		{
			setIconColor = false,
			iconColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f),
			message = new SteamText("Online"),
			setMessageColor = false,
			messageColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f)
		};

		[FormerlySerializedAs("Offline")]
		public References offline = new References
		{
			setIconColor = false,
			iconColor = new Color(0.887f, 0.887f, 0.887f, 1f),
			message = new SteamText("Offline"),
			setMessageColor = false,
			messageColor = new Color(0.887f, 0.887f, 0.887f, 1f)
		};

		[FormerlySerializedAs("Busy")]
		public References busy = new References
		{
			setIconColor = false,
			iconColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f),
			message = new SteamText("Busy"),
			setMessageColor = false,
			messageColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f)
		};

		[FormerlySerializedAs("Away")]
		public References away = new References
		{
			setIconColor = false,
			iconColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f),
			message = new SteamText("Away"),
			setMessageColor = false,
			messageColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f)
		};

		[FormerlySerializedAs("Snooze")]
		public References snooze = new References
		{
			setIconColor = false,
			iconColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f),
			message = new SteamText("Snooze"),
			setMessageColor = false,
			messageColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f)
		};

		[FormerlySerializedAs("LookingToTrade")]
		public References lookingToTrade = new References
		{
			setIconColor = false,
			iconColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f),
			message = new SteamText("Looking to Trade"),
			setMessageColor = false,
			messageColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f)
		};

		[FormerlySerializedAs("LookingToPlay")]
		public References lookingToPlay = new References
		{
			setIconColor = false,
			iconColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f),
			message = new SteamText("Looking to Play"),
			setMessageColor = false,
			messageColor = new Color(0.4117f, 0.7803f, 0.9254f, 1f)
		};
	}

	[Serializable]
	public class Settings
	{
		public Options configuration;

		public List<Image> images = new List<Image>();

		public List<TextMeshProUGUI> labels = new List<TextMeshProUGUI>();
	}

	public Settings settings = new Settings();

	private SteamUserData _mData;

	private void Awake()
	{
		_mData = GetComponent<SteamUserData>();
		if (_mData.Data.IsValid)
		{
			Refresh();
		}
		_mData.onChanged.AddListener(InternalPersonaStateChange);
		Events.OnFriendRichPresenceUpdate += InternalRichPresenceUpdate;
	}

	private void OnDestroy()
	{
		_mData.onChanged.RemoveListener(InternalPersonaStateChange);
		Events.OnFriendRichPresenceUpdate -= InternalRichPresenceUpdate;
	}

	private void InternalRichPresenceUpdate(UserData friend, AppData app)
	{
		Refresh();
	}

	private void InternalPersonaStateChange(UserData friend, EPersonaChange flag)
	{
		Refresh();
	}

	public void Refresh()
	{
		int num = math.max(settings.images.Count, settings.labels.Count);
		for (int i = 0; i < num; i++)
		{
			Image image = ((settings.images.Count > i) ? settings.images[i] : null);
			TextMeshProUGUI label = ((settings.labels.Count > i) ? settings.labels[i] : null);
			if (_mData.Data.GetGamePlayed(out var gameInfo))
			{
				if (gameInfo.Game.IsMe)
				{
					settings.configuration.inThisGame.Set(image, label, gameInfo);
				}
				else
				{
					settings.configuration.inAnotherGame.Set(image, label, gameInfo);
				}
				continue;
			}
			switch (_mData.Data.State)
			{
			case EPersonaState.k_EPersonaStateAway:
				settings.configuration.away.Set(image, label, null);
				break;
			case EPersonaState.k_EPersonaStateBusy:
				settings.configuration.busy.Set(image, label, null);
				break;
			case EPersonaState.k_EPersonaStateOnline:
				settings.configuration.online.Set(image, label, null);
				break;
			case EPersonaState.k_EPersonaStateSnooze:
				settings.configuration.snooze.Set(image, label, null);
				break;
			case EPersonaState.k_EPersonaStateLookingToPlay:
				settings.configuration.lookingToPlay.Set(image, label, null);
				break;
			case EPersonaState.k_EPersonaStateLookingToTrade:
				settings.configuration.lookingToTrade.Set(image, label, null);
				break;
			default:
				settings.configuration.offline.Set(image, label, null);
				break;
			}
		}
	}
}
