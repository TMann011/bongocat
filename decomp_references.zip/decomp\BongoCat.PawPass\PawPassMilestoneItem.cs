using System;
using BongoCat.SteamJsonParser;
using UnityEngine;

namespace BongoCat.PawPass;

[Serializable]
public class PawPassMilestoneItem
{
	public RewardType RewardType;

	public SteamItemBase RewardItem;

	public Sprite FullImage;

	public int Amount = 1;
}
