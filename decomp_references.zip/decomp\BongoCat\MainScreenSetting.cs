using System;
using System.Collections;
using System.Collections.Generic;
using BongoCat.Localizer;
using BongoCat.OSSpecific;
using BongoCat.OSSpecific.Windows;
using TMPro;
using UnityEngine;

namespace BongoCat;

public class MainScreenSetting : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _text;

	[SerializeField]
	private TMP_Dropdown _settingsDropdown;

	private List<DisplayInfo> _displays = new List<DisplayInfo>();

	private int _index;

	private const string PLAYER_PREFS_KEY = "MAIN_MONITOR";

	private const string MAIN_SCREEN_LOCA_KEY = "MainScreen";

	private Coroutine _switchScreenRoutine;

	public bool IsInitialized;

	public int DisplayCount => _displays.Count;

	public event Action ScreenSwitched;

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => TransparentWindow.Instance.Initialized);
		_index = PlayerPrefs.GetInt("MAIN_MONITOR", 0);
		Debug.Log($"MainScreenSetting | Display index found in player prefs {_index}");
		SetDisplay(_index);
		SwitchScreen();
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.F8))
		{
			ToggleForward();
		}
	}

	public void RefreshDisplayList()
	{
		Screen.GetDisplayLayout(_displays);
		_settingsDropdown.ClearOptions();
		List<string> list = new List<string>();
		for (int i = 0; i < DisplayCount; i++)
		{
			list.Add((i + 1).ToString());
		}
		_settingsDropdown.AddOptions(list);
		_settingsDropdown.value = Mathf.Clamp(_index, 0, DisplayCount - 1);
	}

	public void SetDisplay(int index)
	{
		Screen.GetDisplayLayout(_displays);
		Debug.Log($"MainScreenSetting | Found {DisplayCount} connected display(s)");
		if (DisplayCount < 1)
		{
			Debug.Log("MainScreenSetting | No displays found");
			return;
		}
		_index = Mathf.Clamp(index, 0, DisplayCount - 1);
		Debug.Log($"MainScreenSetting | Clamped index is {_index}");
		SwitchScreen();
	}

	private void ToggleForward()
	{
		if (DisplayCount > 0)
		{
			_index = (_index + 1) % DisplayCount;
		}
		SetDisplay(_index);
	}

	private void SwitchScreen()
	{
		Debug.Log("MainScreenSetting | Switching screen");
		if (_switchScreenRoutine != null)
		{
			Debug.Log("MainScreenSetting | Already switching screen. Interrupting routine.");
			OnDemandRenderHelper.Instance.TryPauseRendering();
			StopCoroutine(_switchScreenRoutine);
		}
		_switchScreenRoutine = StartCoroutine(UpdateMainMonitor());
	}

	private string GetWindowBounds()
	{
		WinApi.WinRect currentWindowBounds = TransparentWindow.Instance.GetCurrentWindowBounds();
		return $"{currentWindowBounds.Left}, {currentWindowBounds.Top}, {currentWindowBounds.Width}x{currentWindowBounds.Height}";
	}

	private IEnumerator UpdateMainMonitor()
	{
		OnDemandRenderHelper.Instance.ResumeRendering();
		Debug.Log("MainScreenSetting | current window bounds: " + GetWindowBounds());
		Debug.Log($"MainScreenSetting | Moving window to monitor {_index}");
		TransparentWindow.Instance.MoveWindowToMonitor(_index);
		yield return null;
		Debug.Log("MainScreenSetting | After move - Window bounds: " + GetWindowBounds());
		yield return new WaitForSeconds(0.2f);
		_text.text = string.Format("{0}: {1} (F8)", Localize.Get("MainScreen"), _index + 1);
		PlayerPrefs.SetInt("MAIN_MONITOR", _index);
		PlayerPrefs.Save();
		Debug.Log($"MainScreenSetting | After screen update: backbuffer {Screen.width}x{Screen.height} " + $"with window at {Screen.mainWindowPosition.x} {Screen.mainWindowPosition.y}");
		Debug.Log("MainScreenSetting | Final window bounds: " + GetWindowBounds());
		Debug.Log(Screen.mainWindowDisplayInfo.name);
		_switchScreenRoutine = null;
		OnDemandRenderHelper.Instance.TryPauseRendering();
		ScreenSwitched?.Invoke();
		IsInitialized = true;
	}
}
