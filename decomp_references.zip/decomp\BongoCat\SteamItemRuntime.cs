using System;
using BongoCat.SteamJsonParser;
using Heathen.SteamworksIntegration;
using Helper;
using UnityEngine;

namespace BongoCat;

public class SteamItemRuntime
{
	public ItemData RuntimeData;

	public SteamItemBasic Data;

	public Sprite Icon;

	public Sprite FullImage;

	public string ItemSlot;

	public bool IsEventItem;

	public string EventTag;

	public string CollabTag;

	public bool IsNew = true;

	public QualityCategory QualityCategory;

	public QualityCategoryWithInfo QualityCategoryWithInfo;

	public long CurrentlyInExchangeSlot;

	public int Consumed;

	public bool IsEquipped;

	public bool Hidden;

	public bool HideUntilReceived;

	public bool Marketable;

	public bool IsPremium;

	public Action OnItemUpdated;

	public int Id => Data.Id;

	public string ItemName => Data.Name;

	public bool IsHat => ItemSlot == "hat";

	public bool IsSkin => ItemSlot == "skin";

	public bool IsCosmetic
	{
		get
		{
			if (!(ItemSlot == "hat"))
			{
				return ItemSlot == "skin";
			}
			return true;
		}
	}

	public string Tag
	{
		get
		{
			if (IsConsumable)
			{
				return "consum";
			}
			if (!string.IsNullOrEmpty(EventTag))
			{
				return EventTag;
			}
			if (!string.IsNullOrEmpty(CollabTag))
			{
				return CollabTag;
			}
			if (IsEmote)
			{
				return ItemSlot;
			}
			return "";
		}
	}

	public bool IsOwned => RuntimeData.GetTotalQuantity() > 0;

	public long DisplayedItemAmount
	{
		get
		{
			long totalQuantity = RuntimeData.GetTotalQuantity();
			if (IsConsumable)
			{
				return totalQuantity - Consumed;
			}
			return Math.Max(1L, totalQuantity - CurrentlyInExchangeSlot);
		}
	}

	public bool IsEmote => ItemSlot == "emote";

	public bool IsConsumable => ItemSlot == "consumable";

	private string FavoriteKey => "Favorite_" + Id;

	private string HiddenKey => "Hidden_" + Id;

	public bool IsFavorite => PlayerPrefs.HasKey(FavoriteKey);

	public bool IsHiddenInInventory => PlayerPrefs.HasKey(HiddenKey);

	public void SetFavorite(bool value)
	{
		PlayerPrefsHelp.SetBool(FavoriteKey, value);
	}

	public void SetHideInventoryItem(bool value)
	{
		PlayerPrefsHelp.SetBool(HiddenKey, value);
	}

	public SteamItemRuntime(SteamItemBasic steamItem)
	{
		RuntimeData = steamItem.Id;
		Data = steamItem;
		if (!string.IsNullOrEmpty(steamItem.GetTagValue("quality")))
		{
			QualityCategory = (QualityCategory)Enum.Parse(typeof(QualityCategory), steamItem.GetTagValue("quality"), ignoreCase: true);
		}
		ItemSlot = steamItem.GetTagValue("itemslot");
		Marketable = steamItem.Marketable;
		HideUntilReceived = steamItem.HideUntilReceived;
		Hidden = steamItem.Hidden;
		EventTag = steamItem.GetTagValue("event");
		IsEventItem = !string.IsNullOrEmpty(EventTag);
		CollabTag = steamItem.GetTagValue("collab");
		IsPremium = !string.IsNullOrEmpty(steamItem.PriceCategory);
		QualityCategoryWithInfo = QualityCategory.ToQualityWithInfo(ItemSlot == "emote");
		Icon = MemoryImageCache.Instance.GetSprite(Data.Name.Replace(" ", "") + "Icon");
		FullImage = MemoryImageCache.Instance.GetSprite(Data.Name.Replace(" ", ""));
	}
}
