using System.Collections;
using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Multiplayer;

public class FriendListEntry : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _statusText;

	[SerializeField]
	private Image _chestIcon;

	[SerializeField]
	private Button _inviteButton;

	[SerializeField]
	private Button _joinButton;

	private bool _isInviteOnCooldown;

	[SerializeField]
	private SteamUserData _steamUserData;

	private void Start()
	{
		UpdateStatus();
	}

	private void Awake()
	{
		Events.OnLobbyDataUpdate += OnLobbyDataUpdate;
		Events.OnLobbyChatUpdate += OnLobbyChatUpdate;
		Events.OnLobbyEnterSuccess += OnLobbyEnterSuccess;
		Events.OnLobbyLeave += OnLobbyLeave;
	}

	private void OnDestroy()
	{
		Events.OnLobbyDataUpdate -= OnLobbyDataUpdate;
		Events.OnLobbyChatUpdate -= OnLobbyChatUpdate;
		Events.OnLobbyEnterSuccess -= OnLobbyEnterSuccess;
		Events.OnLobbyLeave -= OnLobbyLeave;
	}

	private void OnLobbyChatUpdate(LobbyData lobby, UserData user, EChatMemberStateChange change)
	{
		UpdateStatus();
	}

	private void OnLobbyEnterSuccess(LobbyData lobby)
	{
		UpdateStatus();
	}

	private void OnLobbyLeave(LobbyData lobby)
	{
		UpdateStatus();
	}

	public void Join()
	{
		Debug.Log("Try join lobby via join button.");
		LobbyData.Current.Leave();
		_steamUserData.Data.GameInfo.Lobby.Join();
		UpdateStatus();
	}

	public void Invite()
	{
		if (!_isInviteOnCooldown)
		{
			MultiplayerLobby.Instance.Invite(_steamUserData.Data);
			if (base.gameObject.activeInHierarchy)
			{
				StartCoroutine(InvitationCooldown());
			}
			UpdateStatus();
		}
	}

	private IEnumerator InvitationCooldown()
	{
		_isInviteOnCooldown = true;
		yield return new WaitForSeconds(2f);
		_isInviteOnCooldown = false;
		UpdateStatus();
	}

	private void UpdateStatus()
	{
		if (!this || !base.gameObject)
		{
			return;
		}
		base.gameObject.SetActive(value: true);
		bool flag = !_isInviteOnCooldown && LobbyData.Current.IsValid && !LobbyData.Current.IsClosedLobby && (!LobbyData.Current.KickListContains(_steamUserData.Data) || LobbyData.Current.IsOwner);
		_inviteButton.gameObject.SetActive(flag);
		_chestIcon.enabled = flag;
		_joinButton.gameObject.SetActive(value: false);
		_statusText.gameObject.SetActive(!flag);
		if (LobbyData.Current.IsValid)
		{
			if (LobbyData.Current.IsAMember(_steamUserData.Data))
			{
				base.gameObject.SetActive(value: false);
				_isInviteOnCooldown = false;
			}
		}
		else if (_steamUserData.Data.GameInfo.Lobby.IsValid)
		{
			_steamUserData.Data.GameInfo.Lobby.RequestData();
		}
	}

	private void OnLobbyDataUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		if ((bool)base.gameObject && (bool)this && !LobbyData.Current.IsValid && !(_steamUserData.Data.GameInfo.Lobby != lobby))
		{
			bool flag = !lobby.KickListContains(UserData.Me) && !_steamUserData.Data.GameInfo.Lobby.IsClosedLobby;
			if (!_steamUserData.Data.InThisGame)
			{
				flag = false;
			}
			_joinButton.gameObject.SetActive(flag);
			_inviteButton.gameObject.SetActive(!flag && LobbyData.Current.IsValid);
			_statusText.gameObject.SetActive(!flag);
			_chestIcon.enabled = flag;
		}
	}
}
