using System.Collections.Generic;
using IroxGames.Helper.ClassExtensions;
using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public class SlotPreviews : MonoBehaviour
{
	[SerializeField]
	private SlotPreview _previewCatPrefab;

	[SerializeField]
	private Transform _previewCatRoot;

	[SerializeField]
	private CatDepthSorter _previewDepth;

	private readonly List<SlotPreview> _previewCats = new List<SlotPreview>();

	public void Show(List<CatSlot> slots, ICatSpawnPattern pattern, bool flipped)
	{
		for (int i = 0; i < slots.Count; i++)
		{
			if (i >= _previewCats.Count)
			{
				_previewCats.Add(Object.Instantiate(_previewCatPrefab, _previewCatRoot));
			}
			CatSlot catSlot = slots[i];
			SlotPreview slotPreview = _previewCats[i];
			slotPreview.transform.position = catSlot.Position;
			int num = (pattern.ComputesSlots ? catSlot.RotationState : pattern.RotationState);
			slotPreview.transform.rotation = Quaternion.Euler(0f, 0f, num * 90);
			slotPreview.FlipVisuals(flipped);
			slotPreview.SlotIndex = i;
			slotPreview.SetDisabled(catSlot.Disabled);
			slotPreview.gameObject.SetActiveWithCheck(active: true);
		}
		HideFrom(slots.Count);
	}

	public void Hide()
	{
		HideFrom(0);
	}

	public void Sort(int horizontalSign)
	{
		_previewDepth.Sort(horizontalSign);
	}

	private void HideFrom(int index)
	{
		for (int i = index; i < _previewCats.Count; i++)
		{
			_previewCats[i].gameObject.SetActiveWithCheck(active: false);
		}
	}
}
