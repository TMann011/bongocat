using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamUserData))]
public class SteamUserLobbyInvite : MonoBehaviour
{
	[FormerlySerializedAs("CreateIfMissing")]
	public bool createIfMissing = true;

	private SteamUserData _mSteamUserData;

	private void Awake()
	{
		_mSteamUserData = GetComponent<SteamUserData>();
	}

	public void Invite(SteamLobbyData lobby)
	{
		if (!(lobby == null))
		{
			if (lobby.Data.IsValid)
			{
				lobby.Data.InviteUserToLobby(_mSteamUserData.Data);
			}
			else if (createIfMissing)
			{
				SteamLobbyCreate component = lobby.GetComponent<SteamLobbyCreate>();
				lobby.GetComponent<SteamLobbyDataEvents>().onCreate.AddListener(HandleLobbyCreated);
				component.Create();
			}
		}
		void HandleLobbyCreated(LobbyData arg0)
		{
			lobby.GetComponent<SteamLobbyDataEvents>().onCreate.RemoveListener(HandleLobbyCreated);
			lobby.Data.InviteUserToLobby(_mSteamUserData.Data);
		}
	}

	public void Invite(LobbyData lobby)
	{
		if (_mSteamUserData.Data.IsValid && lobby.IsValid)
		{
			lobby.InviteUserToLobby(_mSteamUserData.Data);
		}
	}
}
