using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamAuthenticationData : MonoBehaviour
{
	public enum ManagedEvents
	{
		Changed,
		TicketRequestErred,
		RPCInvoked,
		InvalidTicketReceived,
		InvalidSessionRequested,
		SessionStarted
	}

	private AuthenticationTicket _mData;

	private SteamAuthenticationEvents _mEvents;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<ManagedEvents> mDelegates;

	public AuthenticationTicket Data
	{
		get
		{
			return _mData;
		}
		set
		{
			_mData = value;
			if (_mEvents != null)
			{
				_mEvents.onChange?.Invoke(_mData);
			}
		}
	}

	private void Awake()
	{
		_mEvents = GetComponent<SteamAuthenticationEvents>();
	}
}
