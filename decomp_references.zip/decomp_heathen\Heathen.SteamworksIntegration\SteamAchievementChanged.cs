using Heathen.SteamworksIntegration.API;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamAchievementData))]
public class SteamAchievementChanged : MonoBehaviour
{
	public UnityEvent<bool> onChanged;

	private SteamAchievementData _mData;

	private void Awake()
	{
		_mData = GetComponent<SteamAchievementData>();
		StatsAndAchievements.Client.OnAchievementStatusChanged.AddListener(HandleChange);
	}

	private void OnDestroy()
	{
		StatsAndAchievements.Client.OnAchievementStatusChanged.RemoveListener(HandleChange);
	}

	private void HandleChange(string arg0, bool arg1)
	{
		if (arg0 == _mData.apiName)
		{
			onChanged?.Invoke(arg1);
		}
	}
}
