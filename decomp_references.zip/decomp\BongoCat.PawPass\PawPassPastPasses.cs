using IroxGames.Helper.ClassExtensions;
using UnityEngine;

namespace BongoCat.PawPass;

public class PawPassPastPasses : MonoBehaviour
{
	[SerializeField]
	private RectTransform _content;

	[SerializeField]
	private PawPassListItem _rowPrefab;

	public bool ShowAll;

	private void OnEnable()
	{
		Rebuild();
	}

	public void ToggleShowAll()
	{
		ShowAll = !ShowAll;
		Rebuild();
	}

	private void Rebuild()
	{
		_content.DestroyAllChildren();
		foreach (PawPassEntity visiblePass in PawPassManager.Instance.VisiblePasses)
		{
			AddRow(visiblePass);
		}
		if (!ShowAll)
		{
			return;
		}
		foreach (PawPassEntity hiddenPass in PawPassManager.Instance.HiddenPasses)
		{
			AddRow(hiddenPass);
		}
	}

	private void AddRow(PawPassEntity pass)
	{
		Object.Instantiate(_rowPrefab, _content).Setup(pass);
	}
}
