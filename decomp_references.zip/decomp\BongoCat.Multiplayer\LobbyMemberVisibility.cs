using Heathen.SteamworksIntegration;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Multiplayer;

public class LobbyMemberVisibility : MonoBehaviour
{
	[SerializeField]
	private SteamUserData _steamUserData;

	[SerializeField]
	private Button _hideButton;

	[SerializeField]
	private Button _showButton;

	private void Start()
	{
		SettingsManager.Instance.AutoHideCats.OnToggleUpdated.AddListener(HandleAutoHideUpdated);
		HandleAutoHideUpdated(_: false);
	}

	private void OnDestroy()
	{
		SettingsManager.Instance.AutoHideCats.OnToggleUpdated.RemoveListener(HandleAutoHideUpdated);
	}

	private void HandleAutoHideUpdated(bool _)
	{
		SetVisibility(!SettingsManager.Instance.AutoHideCats.Value);
	}

	public void SetVisibility(bool isVisible)
	{
		if (!_steamUserData.Data.IsMe)
		{
			_showButton.gameObject.SetActive(!isVisible);
			_hideButton.gameObject.SetActive(isVisible);
			if (MultiplayerLobbyReferences.GameplayInstances.TryGetValue(_steamUserData.Data, out var value))
			{
				value.IsHidden = !isVisible;
			}
		}
	}
}
