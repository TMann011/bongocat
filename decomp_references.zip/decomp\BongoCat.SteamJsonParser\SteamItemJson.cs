namespace BongoCat.SteamJsonParser;

public class SteamItemJson
{
	public int itemdefid;

	public bool auto_stack;

	public string type;

	public string name;

	public string bundle;

	public string tags;

	public bool tradable;

	public bool marketable;

	public string description;

	public string name_color;

	public string store_tags;

	public string icon_url;

	public string icon_url_large;

	public string exchange;

	public bool hidden;

	public string price_category;

	public string promo;

	public bool game_only;

	public bool granted_manually;

	public string store_images;

	public bool use_bundle_price;

	public int purchase_bundle_discount;

	public int drop_interval;

	public int purchase_limit;

	public string drop_start_time;

	public bool hide_until_received;

	public SteamItemJson(SteamItemBase steamItem)
	{
		itemdefid = steamItem.Id;
		name = steamItem.Name;
	}
}
