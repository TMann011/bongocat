using BongoCat;
using BongoCat.Multiplayer.Spawning;
using DG.Tweening;
using Heathen.SteamworksIntegration;
using Helper;
using UnityEngine;
using UnityEngine.Serialization;

public class CatRotator : MonoBehaviour
{
	[FormerlySerializedAs("_catTransform")]
	public Transform CatTransform;

	[SerializeField]
	private Cat _cat;

	private const string KEY = "ROTATE";

	private int _rotationState;

	[SerializeField]
	private SteamUserData _steamUserData;

	public int RotationState
	{
		get
		{
			return _rotationState;
		}
		set
		{
			_rotationState = value;
			CatTransform.DOKill();
			CatTransform.localRotation = Quaternion.Euler(0f, 0f, _rotationState * 90);
			SaveRotation();
		}
	}

	private void Start()
	{
		if (!_steamUserData)
		{
			RotationState = PlayerPrefs.GetInt("ROTATE", 0);
		}
	}

	private void Update()
	{
		if (_cat.hoverCallback.Hovering && Input.GetKeyDown(KeyCode.R) && !InputFieldCache.FocusingInputField)
		{
			Rotate();
		}
	}

	public void Rotate(bool left = true)
	{
		TurnBy(left ? 1 : (-1));
		CatSpawnManager.Instance.KeepRotatedCatOnScreen(this);
	}

	public void RotateTo(int rotationState)
	{
		TurnBy((rotationState + 4 - _rotationState) % 4);
	}

	private void TurnBy(int quarters)
	{
		if (quarters != 0)
		{
			OnDemandRenderHelper.Instance.ResumeRenderingForDuration(0.2f);
			_rotationState = (_rotationState + quarters + 4) % 4;
			CatTransform.DOKill(complete: true);
			CatTransform.DOLocalRotate(new Vector3(0f, 0f, (float)quarters * 90f), 0.2f, RotateMode.LocalAxisAdd).SetLink(CatTransform.gameObject);
			SaveRotation();
		}
	}

	public void ResetRotation()
	{
		RotationState = 0;
	}

	private void SaveRotation()
	{
		if (!_steamUserData)
		{
			PlayerPrefs.SetInt("ROTATE", _rotationState);
			PlayerPrefs.Save();
		}
		else
		{
			PlayerDataCache.SetRot(_steamUserData.Data.IdStr, _rotationState);
		}
	}
}
