using Heathen.SteamworksIntegration;
using Steam;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace BongoCat.Achievements;

public class AchievementStats : MonoBehaviour
{
	private void Awake()
	{
		Events.OnLobbyEnterSuccess += OnLobbyEntered;
		Events.OnLobbyChatUpdate += OnLobbyChatUpdate;
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= OnLobbyEntered;
		Events.OnLobbyChatUpdate -= OnLobbyChatUpdate;
	}

	private void OnLobbyEntered(LobbyData lobby)
	{
		SetMaxMultiplayerLobbySize(lobby.MemberCount);
	}

	private void OnLobbyChatUpdate(LobbyData lobby, UserData user, EChatMemberStateChange changes)
	{
		SetMaxMultiplayerLobbySize(lobby.MemberCount);
	}

	public static void IncrementEmotesUsed()
	{
		if (StatsInitializer.Initialized)
		{
			Game.Stats.EmotesUsed.Set(Game.Stats.EmotesUsed.IntValue() + 1);
			Game.Stats.EmotesUsed.Store();
		}
	}

	public static void SetMaxMultiplayerLobbySize(int size)
	{
		if (StatsInitializer.Initialized)
		{
			Game.Stats.MaxMultiplayerLobbySize.Set(size);
			Game.Stats.MaxMultiplayerLobbySize.Store();
		}
	}

	public static void SetTotalItems(long value)
	{
		if (StatsInitializer.Initialized)
		{
			Game.Stats.TotalItems.Set(value);
			Game.Stats.TotalItems.Store();
		}
	}

	public static void IncrementItems()
	{
		if (StatsInitializer.Initialized)
		{
			Game.Stats.TotalItems.Set(Game.Stats.TotalItems.IntValue() + 1);
			Game.Stats.TotalItems.Store();
		}
	}

	public static void IncrementExchanges()
	{
		if (StatsInitializer.Initialized)
		{
			Game.Stats.Exchanges.Set(Game.Stats.Exchanges.IntValue() + 1);
			Game.Stats.Exchanges.Store();
		}
	}
}
