using Heathen.SteamworksIntegration;
using SteamTools;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class JoinRequestJoiner : MonoBehaviour
{
	private void Awake()
	{
		Events.OnLobbyJoinRequested += OnJoinRequest;
	}

	private void OnDestroy()
	{
		Events.OnLobbyJoinRequested -= OnJoinRequest;
	}

	private void OnJoinRequest(LobbyData lobby, UserData user)
	{
		if (!(LobbyData.Current == lobby))
		{
			Debug.Log("Joining via join request (aka Steam Invite)");
			LobbyData.Current.Leave();
			lobby.Join();
		}
	}
}
