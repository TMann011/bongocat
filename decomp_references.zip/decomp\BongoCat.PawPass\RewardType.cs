namespace BongoCat.PawPass;

public enum RewardType
{
	HAT,
	SKIN,
	EMOTE,
	CONSUMABLE,
	CHEST
}
