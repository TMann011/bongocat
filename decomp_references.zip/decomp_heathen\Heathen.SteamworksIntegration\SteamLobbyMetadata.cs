using System;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyMetadata : MonoBehaviour
{
	[Serializable]
	public struct KeyEventMap
	{
		public string key;

		public UnityEvent<string> onUpdate;

		[NonSerialized]
		public string PreviousValue;
	}

	[Tooltip("A collection of key and values to be set when the Set() function is called.")]
	public List<StringKeyValuePair> dataToSet = new List<StringKeyValuePair>();

	[Tooltip("A collection of key and event, the events will be invoked when the key's data changes on the lobby.")]
	public List<KeyEventMap> onChanged = new List<KeyEventMap>();

	private SteamLobbyData _inspector;

	private void Awake()
	{
		_inspector = GetComponent<SteamLobbyData>();
		_inspector.onChanged.AddListener(HandleOnChanged);
		Events.OnLobbyDataUpdate += HandleMetadataChange;
		RefreshKeyValues();
	}

	private void HandleMetadataChange(LobbyData lobby, LobbyMemberData? member)
	{
		if (!(lobby == _inspector.Data))
		{
			return;
		}
		for (int i = 0; i < onChanged.Count; i++)
		{
			KeyEventMap value = onChanged[i];
			string text = _inspector.Data[value.key];
			if (text != value.PreviousValue)
			{
				value.PreviousValue = text;
				onChanged[i] = value;
				value.onUpdate?.Invoke(value.PreviousValue);
			}
		}
	}

	private void HandleOnChanged(LobbyData arg0)
	{
		RefreshKeyValues();
	}

	public void RefreshKeyValues()
	{
		for (int i = 0; i < onChanged.Count; i++)
		{
			KeyEventMap value = onChanged[i];
			if (_inspector.Data.IsValid)
			{
				value.PreviousValue = _inspector.Data[value.key];
			}
			else
			{
				value.PreviousValue = string.Empty;
			}
			onChanged[i] = value;
			value.onUpdate?.Invoke(value.PreviousValue);
		}
	}

	public void Set()
	{
		if (!_inspector.Data.IsValid || dataToSet.Count <= 0 || !_inspector.Data.IsOwner)
		{
			return;
		}
		foreach (StringKeyValuePair item in dataToSet)
		{
			Matchmaking.Client.SetLobbyData(_inspector.Data, item.key, item.value);
		}
	}

	public void Set(string key, string value)
	{
		if (_inspector.Data.IsValid)
		{
			if (_inspector.Data.IsOwner)
			{
				Matchmaking.Client.SetLobbyData(_inspector.Data, key, value);
			}
			else
			{
				Debug.LogWarning("[SteamLobbyMetadata] Only the owner can set data");
			}
		}
		else
		{
			Debug.LogWarning("[SteamLobbyMetadata] No lobby to set");
		}
	}

	public void Set(StringKeyValuePair data)
	{
		Set(data.key, data.value);
	}

	public string Get(string key)
	{
		if (_inspector.Data.IsValid)
		{
			return _inspector.Data[key];
		}
		Debug.LogWarning("[SteamLobbyMetadata] No lobby to read");
		return string.Empty;
	}

	public bool HasKey(string key)
	{
		if (_inspector.Data.IsValid)
		{
			return !string.IsNullOrEmpty(_inspector.Data[key]);
		}
		Debug.LogWarning("[SteamLobbyMetadata] No lobby to test");
		return false;
	}
}
