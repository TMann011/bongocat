using System.Collections;
using System.Globalization;
using Heathen.SteamworksIntegration.API;
using Steam;
using SteamTools;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace BongoCat;

public class Pets : MonoBehaviour
{
	[FormerlySerializedAs("_cashText")]
	[SerializeField]
	private TMP_Text _petsText;

	[SerializeField]
	private TMP_Text _lifetimePetsText;

	[SerializeField]
	private UnityEvent _onStatsUpdated;

	public static Pets Instance;

	private int _currentGained;

	private int _currentAchievement;

	private int _totalSpent;

	private bool _init;

	private int Current => Mathf.Max(_currentGained - _totalSpent, 0);

	public void AddPet(int value)
	{
		if (_init)
		{
			_currentGained += value;
			_currentAchievement += value;
			UpdateStats();
		}
	}

	private void Awake()
	{
		Instance = this;
	}

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => StatsInitializer.Initialized);
		_currentGained = Game.Stats.BongoTap.IntValue();
		_currentAchievement = Game.Stats.BongoBeat.IntValue();
		_totalSpent = Game.Stats.BongoMinus.IntValue();
		if (_currentGained < _totalSpent)
		{
			_currentGained = _totalSpent;
		}
		UpdateText();
		_init = true;
		Debug.Log("Pets initialized.");
		while (true)
		{
			yield return new WaitForSeconds(60f);
			StatsAndAchievements.Client.StoreStats();
		}
	}

	private void UpdateStats()
	{
		Game.Stats.BongoTap.Set(_currentGained);
		Game.Stats.BongoBeat.Set(_currentAchievement);
		Game.Stats.BongoMinus.Set(_totalSpent);
		UpdateText();
		_onStatsUpdated.Invoke();
	}

	private void UpdateText()
	{
		NumberFormatInfo numberFormatInfo = (NumberFormatInfo)CultureInfo.InvariantCulture.NumberFormat.Clone();
		numberFormatInfo.NumberGroupSeparator = " ";
		_petsText.text = Current.ToString("#,0", numberFormatInfo);
		_lifetimePetsText.text = _currentAchievement.ToString("#,0", numberFormatInfo);
	}

	public bool CanSpendPets(int value)
	{
		return Current >= value;
	}

	public bool TrySpendPets(int value)
	{
		if (!_init)
		{
			return false;
		}
		if (CanSpendPets(value))
		{
			_totalSpent += value;
			UpdateStats();
			return true;
		}
		return false;
	}

	public void ResetPets()
	{
		if (_init)
		{
			_totalSpent = _currentGained;
			UpdateStats();
		}
	}
}
