using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamInputControllerData : MonoBehaviour
{
	public enum ManagedEvents
	{
		Change,
		Update
	}

	[Tooltip("If set to true then we will attempt to force Steam to use input for this app on start.\nThis is generally only needed in editor testing.")]
	[SerializeField]
	private bool forceInput = true;

	[Tooltip("If true then the first controller connected will be set as the controller handle")]
	public bool getFirst = true;

	[FormerlySerializedAs("_delegates")]
	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<ManagedEvents> delegates;

	public UnityEvent onChanged;

	private InputHandle_t? _data;

	public InputHandle_t? Data
	{
		get
		{
			return _data;
		}
		set
		{
			_data = value;
			onChanged?.Invoke();
		}
	}

	private void Awake()
	{
		if (!Interface.IsReady)
		{
			Interface.OnReady += HandleLateInit;
		}
		else
		{
			HandleLateInit();
		}
	}

	private void OnDestroy()
	{
		if (forceInput)
		{
			Application.OpenURL("steam://forceinputappid/0");
		}
	}

	[ContextMenu("Set First Controller")]
	public void SetFirstFound()
	{
		if (Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers.Count > 0)
		{
			Data = Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers[0];
		}
		else
		{
			Data = null;
		}
	}

	public InputMotionData_t GetMotion()
	{
		if (!_data.HasValue)
		{
			return default(InputMotionData_t);
		}
		return Heathen.SteamworksIntegration.API.Input.Client.GetMotionData(_data.Value);
	}

	private void HandleLateInit()
	{
		Interface.OnReady -= HandleLateInit;
		if (forceInput)
		{
			Application.OpenURL($"steam://forceinputappid/{App.Id}");
			if (getFirst)
			{
				Invoke("SetFirstFound", 1f);
			}
		}
		else if (getFirst)
		{
			SetFirstFound();
		}
	}
}
