using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamLeaderboardData : MonoBehaviour
{
	public enum LeaderboardSortMethod
	{
		TopIsLowestScore = 1,
		TopIsHighestScore
	}

	public enum LeaderboardDisplayType
	{
		Numeric = 1,
		TimeSeconds,
		TimeMilliSeconds
	}

	public string apiName;

	public bool createIfMissing;

	public LeaderboardDisplayType createAsDisplay = LeaderboardDisplayType.Numeric;

	public LeaderboardSortMethod createWithSort = LeaderboardSortMethod.TopIsLowestScore;

	[FormerlySerializedAs("_delegates")]
	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> delegates;

	private LeaderboardData _data;

	private SteamLeaderboardDataEvents _events;

	public LeaderboardData Data
	{
		get
		{
			return _data;
		}
		set
		{
			_data = value;
			if ((bool)_events)
			{
				_events.onChange?.Invoke();
			}
		}
	}

	private void Awake()
	{
		_events = GetComponent<SteamLeaderboardDataEvents>();
	}

	private void Interface_OnReady()
	{
		Interface.OnReady -= Interface_OnReady;
		if (_data.IsValid || string.IsNullOrEmpty(apiName))
		{
			return;
		}
		_data = Interface.GetBoard(apiName);
		if (_data.IsValid || !createIfMissing)
		{
			return;
		}
		Leaderboards.Client.FindOrCreate(Data.apiName, (ELeaderboardSortMethod)createWithSort, (ELeaderboardDisplayType)createAsDisplay, delegate(LeaderboardData data, bool ioError)
		{
			if (!ioError)
			{
				_data = data;
				if (_events != null)
				{
					_events.onFindOrCreate?.Invoke();
				}
			}
			else if (_events != null)
			{
				_events.onFindOrCreateFailure?.Invoke();
			}
		});
	}

	private void Start()
	{
		_events = GetComponent<SteamLeaderboardDataEvents>();
		if (Interface.IsReady)
		{
			Interface_OnReady();
		}
		else
		{
			Interface.OnReady += Interface_OnReady;
		}
	}
}
