using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public static class SavedSlots
{
	public static void Save(List<CatSlot> slots)
	{
		if (slots.Count != 0)
		{
			PlayerPrefs.SetString("MultiplayerSpawnSlots", string.Join(";", slots.Select((CatSlot slot) => string.Join(",", (slot.Position.x / (float)ScreenHelper.FullWidth).ToString(CultureInfo.InvariantCulture), (slot.Position.y / (float)ScreenHelper.FullHeight).ToString(CultureInfo.InvariantCulture), slot.RotationState.ToString(CultureInfo.InvariantCulture), slot.ReservedForMainCat ? "1" : "0"))));
		}
	}

	public static List<CatSlot> Load()
	{
		string text = PlayerPrefs.GetString("MultiplayerSpawnSlots", "");
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		List<CatSlot> list = new List<CatSlot>();
		string[] array = text.Split(';');
		for (int i = 0; i < array.Length; i++)
		{
			string[] array2 = array[i].Split(',');
			if (array2.Length != 4)
			{
				return null;
			}
			list.Add(new CatSlot
			{
				Position = new Vector2(float.Parse(array2[0], CultureInfo.InvariantCulture) * (float)ScreenHelper.FullWidth, float.Parse(array2[1], CultureInfo.InvariantCulture) * (float)ScreenHelper.FullHeight),
				RotationState = int.Parse(array2[2], CultureInfo.InvariantCulture),
				ReservedForMainCat = (array2[3] == "1")
			});
		}
		return list;
	}

	public static void Clear()
	{
		PlayerPrefs.DeleteKey("MultiplayerSpawnSlots");
	}
}
