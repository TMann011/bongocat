using System;
using System.Collections.Generic;
using System.Text;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[Serializable]
public class ItemDefinitionSettings
{
	[Serializable]
	public class LanguageVariant
	{
		public LanguageCodes language;

		public string value;
	}

	[Serializable]
	public class LanguageVariantNode
	{
		public string node;

		public string value;

		public List<LanguageVariant> variants = new List<LanguageVariant>();

		public override string ToString()
		{
			if (variants.Count == 0)
			{
				return "\t\t\"" + node.Trim() + "\": \"" + value + "\"";
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (LanguageVariant variant in variants)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(",\n");
				}
				stringBuilder.Append("\t\t\"" + node.Trim() + "_" + variant.language.ToString() + "\": \"" + variant.value + "\"");
			}
			return stringBuilder.ToString();
		}
	}

	[Serializable]
	public struct Colour
	{
		public bool use;

		public Color color;

		public override string ToString()
		{
			return ColorUtility.ToHtmlStringRGB(color);
		}
	}

	[SerializeField]
	public int id;

	[FormerlySerializedAs("item_type")]
	[SerializeField]
	public InventoryItemType itemType;

	[FormerlySerializedAs("item_name")]
	[SerializeField]
	public LanguageVariantNode itemName = new LanguageVariantNode
	{
		node = "name"
	};

	[FormerlySerializedAs("item_description")]
	[SerializeField]
	public LanguageVariantNode itemDescription = new LanguageVariantNode
	{
		node = "description"
	};

	[FormerlySerializedAs("item_display_type")]
	[SerializeField]
	public LanguageVariantNode itemDisplayType = new LanguageVariantNode
	{
		node = "display_type"
	};

	[FormerlySerializedAs("itemBackgroundColor")]
	[FormerlySerializedAs("item_background_color")]
	[SerializeField]
	public Colour itemBackgroundColour;

	[FormerlySerializedAs("itemNameColor")]
	[FormerlySerializedAs("item_name_color")]
	[SerializeField]
	public Colour itemNameColour;

	[FormerlySerializedAs("item_icon_url")]
	[SerializeField]
	public string itemIconURL;

	[FormerlySerializedAs("item_icon_url_large")]
	[SerializeField]
	public string itemIconURLLarge;

	[FormerlySerializedAs("item_marketable")]
	[SerializeField]
	public bool itemMarketable;

	[FormerlySerializedAs("item_tradable")]
	[SerializeField]
	public bool itemTradable;

	[FormerlySerializedAs("item_store_tags")]
	[SerializeField]
	public List<string> itemStoreTags = new List<string>();

	[FormerlySerializedAs("item_store_images")]
	[SerializeField]
	public List<string> itemStoreImages = new List<string>();

	private ItemChangedEvent _eventChanged = new ItemChangedEvent();

	public ItemData Data => id;

	public ulong CurrentPrice => Data.CurrentPrice;

	public SteamItemDef_t Id => Data;
}
