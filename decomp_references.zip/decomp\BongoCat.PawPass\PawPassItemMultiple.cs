using System;
using System.Collections.Generic;
using UnityEngine;

namespace BongoCat.PawPass;

public class PawPassItemMultiple : PawPassItemClass
{
	[SerializeField]
	private RectTransform _positionTopLeft;

	[SerializeField]
	private RectTransform _positionTopRight;

	[SerializeField]
	private RectTransform _positionBottomLeft;

	[SerializeField]
	private RectTransform _positionBottomRight;

	private readonly List<PawPassItemClass> _itemClasses = new List<PawPassItemClass>();

	public void Add(PawPassItemClass itemPrefab, int index)
	{
		PawPassItemClass item = global::UnityEngine.Object.Instantiate(itemPrefab, GetPosition(index));
		_itemClasses.Add(item);
	}

	public override void ToggleBobbing(bool toggle)
	{
		foreach (PawPassItemClass itemClass in _itemClasses)
		{
			itemClass.ToggleBobbing(toggle);
		}
	}

	public override void FillContent(PawPassMilestone pawPassMilestone)
	{
		for (int i = 0; i < _itemClasses.Count; i++)
		{
			_itemClasses[i].FillContent(pawPassMilestone.Items[i]);
		}
	}

	public override void FillContent(PawPassMilestoneItem pawPassMilestoneItem)
	{
		throw new ArgumentException("This item class does not support filling only one item!");
	}

	private RectTransform GetPosition(int index)
	{
		return index switch
		{
			0 => _positionTopLeft, 
			1 => _positionTopRight, 
			2 => _positionBottomLeft, 
			3 => _positionBottomRight, 
			_ => null, 
		};
	}
}
