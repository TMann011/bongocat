using System;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct ItemChangeRecord
{
	public ItemDefinitionSettings item;

	public ItemInstanceChangeRecord[] changes;
}
