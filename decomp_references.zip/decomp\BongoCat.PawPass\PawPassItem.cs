using System;
using BongoCat.Achievements;
using Heathen.SteamworksIntegration;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassItem : MonoBehaviour
{
	[SerializeField]
	private Image _border;

	public PawPassItemClass Item;

	public PawPassMilestone Milestone;

	private PawPassItemClass _contentPrefab;

	[SerializeField]
	private Button _claimButton;

	[SerializeField]
	private LocalizeStringEvent _claimButtonText;

	[SerializeField]
	private LocalizedString _claimString;

	[SerializeField]
	private LocalizedString _claimedString;

	[SerializeField]
	private GameObject _claimed;

	[SerializeField]
	private GameObject _locked;

	[SerializeField]
	private GameObject _payToUnlock;

	[SerializeField]
	private Button _payToUnlockButton;

	[SerializeField]
	private LocalizeStringEvent _unlockButtonText;

	[SerializeField]
	private LocalizedString _unlockString;

	public bool CanClaim => _claimButton.interactable;

	public void SetClaimable()
	{
		ShowOverlay(null);
		_claimButton.interactable = true;
		_claimButtonText.StringReference = _claimString;
		Item.ToggleBobbing(toggle: true);
	}

	public void SetClaimed()
	{
		ShowOverlay(_claimed);
		_claimButton.interactable = false;
		_claimButtonText.StringReference = _claimedString;
		Item.ToggleBobbing(toggle: false);
	}

	public void Lock()
	{
		ShowOverlay(_locked);
		_claimButton.interactable = false;
		Item.ToggleBobbing(toggle: false);
	}

	public void SetPayToUnlock(bool milestoneReached)
	{
		ShowOverlay(_payToUnlock);
		_claimButton.interactable = false;
		_unlockButtonText.StringReference = _unlockString;
		Item.ToggleBobbing(milestoneReached);
	}

	public void Claim()
	{
		Claim(null);
	}

	public void Claim(Action onCompleted)
	{
		_claimButton.interactable = false;
		Milestone.Claim(delegate(bool success, ItemDetail[] granted)
		{
			if (success)
			{
				SetClaimed();
				GrantRewards(granted);
				PawPassManager.Instance.Refresh();
			}
			else
			{
				SetClaimable();
			}
			onCompleted?.Invoke();
		});
	}

	private void GrantRewards(ItemDetail[] granted)
	{
		for (int i = 0; i < granted.Length; i++)
		{
			ItemDetail itemDetail = granted[i];
			AchievementStats.IncrementItems();
			SteamItemIdReference.Inst[itemDetail.Definition.id].OnItemUpdated?.Invoke();
			if (!IsConsumableReward(itemDetail.Definition.id))
			{
				NewItemPopup.Instance.ShowPopup(itemDetail.Definition.id);
			}
		}
		CatInventory.Instance.UpdateVisuals();
	}

	private bool IsConsumableReward(int itemDefId)
	{
		return Milestone.Items.Exists((PawPassMilestoneItem item) => item.RewardType == RewardType.CONSUMABLE && item.RewardItem.Id == itemDefId);
	}

	public void UnlockPremiumPass()
	{
		PawPassManager.Instance.UnlockPremiumPass();
	}

	public T Content<T>(T prefab) where T : PawPassItemClass
	{
		if (!(_contentPrefab == prefab))
		{
			return null;
		}
		return (T)Item;
	}

	public T ReplaceContent<T>(T prefab) where T : PawPassItemClass
	{
		if ((bool)Item)
		{
			global::UnityEngine.Object.Destroy(Item.gameObject);
		}
		T val = (T)(Item = global::UnityEngine.Object.Instantiate(prefab, base.transform));
		_contentPrefab = prefab;
		val.transform.SetSiblingIndex(_border.transform.GetSiblingIndex() + 1);
		return val;
	}

	private void ShowOverlay(GameObject overlay)
	{
		_claimed.SetActive(overlay == _claimed);
		_locked.SetActive(overlay == _locked);
		_payToUnlock.SetActive(overlay == _payToUnlock);
	}
}
