using BongoCat.OSSpecific;
using UnityEngine;

namespace BongoCat;

public class GamingMode : MonoBehaviour
{
	public bool IsEnabled;

	[SerializeField]
	private ToggleGameObject _toggleGameObject;

	[SerializeField]
	private GameObject _warningPopup;

	public static GamingMode Instance;

	private void Awake()
	{
		Instance = this;
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.F4))
		{
			SetGamingMode(value: false);
		}
	}

	public void Toggle()
	{
		if (IsEnabled)
		{
			SetGamingMode(value: false);
		}
		else
		{
			_warningPopup.SetActive(value: true);
		}
	}

	public void SetGamingMode(bool value)
	{
		IsEnabled = value;
		_toggleGameObject.SetActive(value);
		_warningPopup.SetActive(value: false);
		TransparentWindow.Instance.OnTaskbarIconToggleUpdated(IsEnabled || TransparentWindow.Instance.ShowTaskbarIcon);
	}
}
