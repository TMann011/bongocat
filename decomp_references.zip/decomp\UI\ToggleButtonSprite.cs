using UnityEngine;
using UnityEngine.UI;

namespace UI;

public class ToggleButtonSprite : MonoBehaviour
{
	[SerializeField]
	private Image _targetImage;

	[SerializeField]
	private Sprite _toggled;

	[SerializeField]
	private Sprite _untoggled;

	public void OnToggle(bool toggled)
	{
		_targetImage.sprite = (toggled ? _toggled : _untoggled);
	}
}
