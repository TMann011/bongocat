using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamUserData))]
public class SteamUserAvatar : MonoBehaviour
{
	public RawImage image;

	private SteamUserData _inspector;

	private void Awake()
	{
		_inspector = GetComponent<SteamUserData>();
		_inspector.onChanged.AddListener(HandlePersonaStateChange);
	}

	private void Start()
	{
		if (_inspector.Data.IsValid)
		{
			Interface.WhenReady(HandleSteamInitialized);
		}
	}

	private void HandleSteamInitialized()
	{
		LoadAvatar(_inspector.Data);
	}

	private void HandlePersonaStateChange(UserData user, EPersonaChange flag)
	{
		if (Friends.Client.PersonaChangeHasFlag(flag, EPersonaChange.k_EPersonaChangeAvatar))
		{
			_inspector.Data.LoadAvatar(AvatarLoaded);
		}
	}

	public void LoadAvatar(UserData user)
	{
		user.LoadAvatar(AvatarLoaded);
	}

	public void LoadAvatar(CSteamID user)
	{
		UserData.Get(user).LoadAvatar(delegate(Texture2D r)
		{
			if ((bool)image)
			{
				image.texture = r;
			}
		});
	}

	public void LoadAvatar(ulong user)
	{
		UserData.Get(user).LoadAvatar(AvatarLoaded);
	}

	private void AvatarLoaded(Texture2D texture)
	{
		if ((bool)texture && (bool)image)
		{
			image.texture = texture;
		}
	}
}
