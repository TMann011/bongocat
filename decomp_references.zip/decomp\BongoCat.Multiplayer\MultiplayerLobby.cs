using BongoCat.Localizer;
using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class MultiplayerLobby : MonoBehaviour
{
	[SerializeField]
	private SteamLobbyData _steamLobbyData;

	public const string LOBBY_HEADER_LOCA_KEY = "LobbyHeader";

	public static MultiplayerLobby Instance;

	private void Awake()
	{
		Instance = this;
		Events.OnLobbyEnterSuccess += OnLobbyEntered;
		Events.OnLobbyLeave += OnLobbyLeave;
		Events.OnAskedToLeaveLobby += AskedToLeave;
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= OnLobbyEntered;
		Events.OnLobbyLeave -= OnLobbyLeave;
		Events.OnAskedToLeaveLobby -= AskedToLeave;
	}

	private void AskedToLeave(LobbyData lobby)
	{
		Debug.Log("[Multiplayer] Leaving lobby (asked to leave)");
		lobby.Leave();
	}

	private void OnLobbyEntered(LobbyData lobby)
	{
		Debug.Log("[Multiplayer] Entering lobby");
		if (lobby.KickListContains(UserData.Me) || _steamLobbyData.Data.IsClosedLobby)
		{
			Debug.Log("[Multiplayer] Leaving lobby (kick list / closed lobby)");
			lobby.Leave();
		}
		else
		{
			_steamLobbyData.Data = lobby;
		}
	}

	private void OnLobbyLeave(LobbyData lobby)
	{
		Debug.Log("[Multiplayer] Leaving lobby");
		_steamLobbyData.Data = null;
	}

	public void Create()
	{
		CreateLobbyWithCallback();
	}

	private void CreateLobbyWithCallback()
	{
		LobbyData.Create((ELobbyType)SettingsManager.Instance.PrivateLobby.Selected, SteamLobbyModeType.General, 250, delegate(EResult res, LobbyData data, bool ioError)
		{
			if (!((res != EResult.k_EResultOK) | ioError))
			{
				Debug.Log("[Multiplayer] Lobby created");
				LobbyData.Current.Name = UserData.Me.Nickname + "'s " + Localize.Get("LobbyHeader");
			}
		});
	}

	public void Invite(UserData userData)
	{
		if (!LobbyData.Current.IsValid)
		{
			Events.OnLobbyEnterSuccess += OnLobbyEnteredForInvite;
			CreateLobbyWithCallback();
		}
		else
		{
			userData.InviteToLobby(LobbyData.Current);
		}
		void OnLobbyEnteredForInvite(LobbyData lobby)
		{
			userData.InviteToLobby(LobbyData.Current);
			Events.OnLobbyEnterSuccess -= OnLobbyEnteredForInvite;
		}
	}
}
