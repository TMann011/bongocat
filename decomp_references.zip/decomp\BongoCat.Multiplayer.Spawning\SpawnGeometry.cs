using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public static class SpawnGeometry
{
	private static float ScaleFactor => SettingsManager.Instance.CatScaleSetting.GetRealScaleFactor();

	public static float CatWidth => 100f * ScaleFactor;

	public static float Inset => 70f * ScaleFactor;

	public static float XMax => SettingsManager.Instance.Snapping.Value ? ScreenHelper.XMax : ScreenHelper.FullWidth;

	public static float XMin => SettingsManager.Instance.Snapping.Value ? ScreenHelper.XMin : 0;

	public static float YMax => SettingsManager.Instance.Snapping.Value ? Mathf.Min(ScreenHelper.FullHeight, ScreenHelper.YMax + 3) : ScreenHelper.FullHeight;

	public static float YMin
	{
		get
		{
			if (!SettingsManager.Instance.Snapping.Value)
			{
				return 0f;
			}
			return Mathf.Max(0f, ScreenHelper.YMin - 3);
		}
	}

	public static float ScreenWidth => Mathf.Max(0f, XMax - XMin - 2f * Inset);

	public static float ScreenHeight => Mathf.Max(0f, YMax - YMin - 2f * Inset);

	public static float Perimeter => 2f * (ScreenWidth + ScreenHeight);

	public static float SnapDistance => CatWidth;

	public static float SlotMatchDistance => 2f * ScaleFactor;

	public static float DropOnCatDistance => CatWidth / 2f;

	public static float TightestSpacing => SpacingFor(0f);

	public static Vector2 KeepCatOnScreen(Vector2 position, int rotationState)
	{
		Vector2 vector = QuarterTurn(Vector2.up, rotationState) * (75f * ScaleFactor);
		Vector2 vector2 = QuarterTurn(Vector2.right, rotationState) * (50f * ScaleFactor);
		return new Vector2(Mathf.Clamp(position.x, XMin - Mathf.Min(0f, vector.x) + Mathf.Abs(vector2.x), XMax - Mathf.Max(0f, vector.x) - Mathf.Abs(vector2.x)), Mathf.Clamp(position.y, YMin - Mathf.Min(0f, vector.y) + Mathf.Abs(vector2.y), YMax - Mathf.Max(0f, vector.y) - Mathf.Abs(vector2.y)));
	}

	public static Vector2 QuarterTurn(Vector2 direction, int rotationState)
	{
		return (rotationState % 4) switch
		{
			1 => new Vector2(0f - direction.y, direction.x), 
			2 => -direction, 
			3 => new Vector2(direction.y, 0f - direction.x), 
			_ => direction, 
		};
	}

	public static Vector2 RandomPos()
	{
		return new Vector2(Random.Range(XMin + Inset, XMin + Inset + ScreenWidth), Random.Range(YMin + Inset, YMin + Inset + ScreenHeight));
	}

	public static float SpacingFor(float percent)
	{
		return (percent * 100f * 3f + 20f) * ScaleFactor;
	}

	public static float PercentFor(float spacing)
	{
		return Mathf.Clamp01((spacing / ScaleFactor - 20f) / 300f);
	}

	public static int SlotsSpanning(float length, ref float spacing)
	{
		int num = Mathf.Clamp(Mathf.CeilToInt(length / spacing) + 1, 1, 250);
		spacing = SpanStep(length, num);
		return num;
	}

	public static float SpanStep(float length, int count)
	{
		if (count <= 1)
		{
			return length;
		}
		return length / (float)(count - 1);
	}

	public static int CeilDivide(int value, int divisor)
	{
		return Mathf.CeilToInt((float)value / (float)divisor);
	}
}
