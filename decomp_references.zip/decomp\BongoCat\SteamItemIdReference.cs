using System.Collections.Generic;
using BongoCat.SteamJsonParser;
using UnityEngine;
using UnityEngine.Serialization;

namespace BongoCat;

public class SteamItemIdReference : ScriptableObject
{
	public List<int> Ids;

	[FormerlySerializedAs("AllItems")]
	public List<SteamItemBasic> AllItemData;

	public static SteamItemIdReference Inst;

	private Dictionary<int, SteamItemRuntime> RuntimeItems = new Dictionary<int, SteamItemRuntime>();

	public SteamItemRuntime this[int id] => RuntimeItems[id];

	public void Init()
	{
		Inst = this;
		foreach (SteamItemBasic allItemDatum in AllItemData)
		{
			RuntimeItems[allItemDatum.Id] = new SteamItemRuntime(allItemDatum);
		}
	}
}
