using System.Collections;
using System.Collections.Generic;
using BongoCat;
using BongoCat.Localizer;
using BongoCat.Multiplayer;
using BongoCat.SteamJsonParser;
using DG.Tweening;
using IroxGames.Helper.ClassExtensions;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class NewItemPopup : MonoBehaviour
{
	public static NewItemPopup Instance;

	[SerializeField]
	private Image _image;

	[SerializeField]
	private Image _border;

	[SerializeField]
	private Image _eventBadge;

	[SerializeField]
	private EventBadges _eventBadges;

	[SerializeField]
	private TMP_Text _text;

	private Queue<int> _queue;

	[SerializeField]
	private bool _sendMultiplayerMessage;

	private Coroutine _showPopupRoutine;

	private Sequence _sequence;

	private void Awake()
	{
		if (!Instance)
		{
			Instance = this;
		}
	}

	[ContextMenu("Test Show Popup")]
	private void TestShowPopup()
	{
		ShowPopup(200);
	}

	public void ShowPopup(int id)
	{
		if (_sendMultiplayerMessage)
		{
			SteamMultiplayer.SendReceivedItem(id);
		}
		if ((bool)base.gameObject)
		{
			if (_queue == null)
			{
				_queue = new Queue<int>();
			}
			_queue.Enqueue(id);
			if (_showPopupRoutine == null)
			{
				base.gameObject.SetActive(value: true);
				_showPopupRoutine = StartCoroutine(DoShowPopup());
			}
		}
	}

	private void OnDisable()
	{
		StopRunningPopup();
	}

	public void HidePopup()
	{
		if ((bool)base.gameObject)
		{
			StopRunningPopup();
			if (_queue.Count > 0)
			{
				base.gameObject.SetActive(value: true);
				_showPopupRoutine = StartCoroutine(DoShowPopup());
			}
			else
			{
				base.gameObject.SetActiveWithCheck(active: false);
			}
		}
	}

	private void StopRunningPopup()
	{
		if (_queue == null)
		{
			_queue = new Queue<int>();
		}
		if (_showPopupRoutine != null)
		{
			StopCoroutine(_showPopupRoutine);
			_showPopupRoutine = null;
		}
		_sequence?.Kill();
		_eventBadge.gameObject.SetActiveWithCheck(active: false);
	}

	private IEnumerator DoShowPopup()
	{
		while (_queue.Count > 0)
		{
			int id = _queue.Dequeue();
			InitVisuals(SteamItemIdReference.Inst[id]);
			yield return AnimatePopup();
		}
		base.gameObject.SetActive(value: false);
		_showPopupRoutine = null;
	}

	private void InitVisuals(SteamItemRuntime item)
	{
		_text.SetText((item.RuntimeData.GetTotalQuantity() > 1) ? Localize.Get("DuplicateHat") : Localize.Get("NewItem"));
		_image.sprite = item.Icon;
		_border.color = item.QualityCategory.GetColor();
		_eventBadge.sprite = _eventBadges.GetEventBadge(item.EventTag);
		_eventBadge.gameObject.SetActiveWithCheck(item.IsEventItem && (bool)_eventBadge.sprite);
	}

	private IEnumerator AnimatePopup()
	{
		if (!SettingsManager.Instance.AnimateChestPurchase.Value)
		{
			base.transform.localScale = Vector3.one;
			yield return new WaitForSeconds(3f);
			yield break;
		}
		_sequence?.Kill();
		base.transform.localScale = Vector3.zero;
		_image.transform.localScale = Vector3.zero;
		_image.transform.localRotation = Quaternion.Euler(0f, 0f, 180f);
		yield return new WaitForSeconds(0.5f);
		_sequence = DOTween.Sequence().SetLink(base.gameObject);
		_sequence.Append(_image.transform.DORotate(Vector3.zero, 0.4f));
		_sequence.Join(_image.transform.DOScale(1.5f, 0.4f));
		_sequence.Join(base.transform.DOScale(1f, 0.2f));
		_sequence.Append(_image.transform.DOScale(1f, 0.25f));
		_sequence.AppendInterval(2.3f);
		_sequence.Append(base.transform.DOScale(1.1f, 0.2f));
		_sequence.Append(base.transform.DOScale(0f, 0.2f));
		yield return _sequence.WaitForCompletion();
	}
}
