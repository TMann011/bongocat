using System.Collections;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamLobbySearch : MonoBehaviour
{
	[Tooltip("If true the search will check if there is currently a party lobby if so it will search for a lobby enough slots for each party member, else it will obey the slots field.")]
	public bool partyWise;

	[Tooltip("If less than or equal to 0 then we wont use the open slot filter")]
	public int slots;

	[Tooltip("The distance from the searching user that should be considered when searching")]
	public ELobbyDistanceFilter distance = ELobbyDistanceFilter.k_ELobbyDistanceFilterDefault;

	[Tooltip("Metadata values that should be used to sort the results e.g. values `closer` to these values will be weighted higher in the results")]
	public List<NearFilter> nearValues = new List<NearFilter>();

	[Tooltip("Metadata values that should be compared as numeric values e.g. should follow typical maths rules for concepts such as less than, greater than, etc.")]
	public List<NumericFilter> numericFilters = new List<NumericFilter>();

	[Tooltip("Metadata values that should be compared as strings")]
	public List<StringFilter> stringFilters = new List<StringFilter>();

	public int maxResults = 50;

	public SteamLobbyData template;

	public Transform content;

	[FormerlySerializedAs("OnLobbiesFound")]
	[Tooltip("Invoked when the lobby search completes. Returns an array of LobbyData.")]
	public LobbyDataListEvent onLobbiesFound;

	private readonly List<SteamLobbyData> _lobbies = new List<SteamLobbyData>();

	private void OnEnable()
	{
		StartCoroutine(RequestLobbyList());
	}

	private IEnumerator RequestLobbyList()
	{
		while (true)
		{
			Search();
			yield return new WaitForSeconds(60f);
		}
	}

	public void Search()
	{
		if (maxResults <= 0)
		{
			return;
		}
		if (partyWise && LobbyData.PartyLobby(out var lobby))
		{
			if (!lobby.IsOwner)
			{
				Debug.LogWarning("Only the owner of a party can search for a match.");
				return;
			}
			slots = lobby.MemberCount;
		}
		Matchmaking.Client.AddRequestLobbyListDistanceFilter(distance);
		if (slots > 0)
		{
			Matchmaking.Client.AddRequestLobbyListFilterSlotsAvailable(slots);
		}
		foreach (NearFilter nearValue in nearValues)
		{
			Matchmaking.Client.AddRequestLobbyListNearValueFilter(nearValue.key, nearValue.value);
		}
		foreach (NumericFilter numericFilter in numericFilters)
		{
			Matchmaking.Client.AddRequestLobbyListNumericalFilter(numericFilter.key, numericFilter.value, numericFilter.comparison);
		}
		foreach (StringFilter stringFilter in stringFilters)
		{
			Matchmaking.Client.AddRequestLobbyListStringFilter(stringFilter.key, stringFilter.value, stringFilter.comparison);
		}
		Matchmaking.Client.AddRequestLobbyListResultCountFilter(maxResults);
		Matchmaking.Client.RequestLobbyList(delegate(LobbyData[] r, bool e)
		{
			if (!e)
			{
				foreach (SteamLobbyData lobby2 in _lobbies)
				{
					Object.Destroy(lobby2.gameObject);
				}
				_lobbies.Clear();
				foreach (LobbyData data in r)
				{
					SteamLobbyData steamLobbyData = Object.Instantiate(template, content);
					steamLobbyData.Data = data;
					_lobbies.Add(steamLobbyData);
				}
				onLobbiesFound?.Invoke(r);
			}
			else
			{
				onLobbiesFound?.Invoke(new LobbyData[0]);
			}
		});
	}
}
