using System;
using System.Collections.Generic;
using System.Linq;
using BongoCat.Multiplayer;
using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using UnityEngine;

public class Leaderboard : MonoBehaviour
{
	public static Leaderboard Instance;

	[SerializeField]
	public GameObject _leaderboardViewport;

	[SerializeField]
	private GameObject _resetButton;

	public bool IsVisible;

	public Dictionary<UserData, int> TapsSinceJoined;

	public Action<bool> OnShow;

	private void Awake()
	{
		TapsSinceJoined = new Dictionary<UserData, int>();
		Instance = this;
		Events.OnLobbyEnterSuccess += CreateLeaderboardData;
		Events.OnLobbyLeave += DiscardLeaderboard;
		Events.OnLobbyChatUpdate += EnableResetButton;
	}

	private void Start()
	{
		SteamMultiplayer instance = SteamMultiplayer.Instance;
		instance.OnResetLeaderboardReceived = (Action)Delegate.Combine(instance.OnResetLeaderboardReceived, new Action(ResetAll));
		TryUpdateLeaderboardUI();
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= CreateLeaderboardData;
		Events.OnLobbyLeave -= DiscardLeaderboard;
		Events.OnLobbyChatUpdate -= EnableResetButton;
		SteamMultiplayer instance = SteamMultiplayer.Instance;
		instance.OnResetLeaderboardReceived = (Action)Delegate.Remove(instance.OnResetLeaderboardReceived, new Action(ResetAll));
	}

	private void CreateLeaderboardData(LobbyData lobby)
	{
		TapsSinceJoined = new Dictionary<UserData, int>();
		EnableResetButton(null, default(UserData), (EChatMemberStateChange)0);
	}

	private void DiscardLeaderboard(LobbyData lobby)
	{
		TapsSinceJoined = null;
		SetLeaderboardUIVisibility(visible: false);
	}

	public void TryUpdateLeaderboardUI()
	{
		if (!IsVisible)
		{
			return;
		}
		int num = 1;
		int num2 = 0;
		foreach (KeyValuePair<UserData, int> item in TapsSinceJoined.OrderByDescending((KeyValuePair<UserData, int> kvp) => kvp.Value))
		{
			if (MultiplayerLobbyReferences.LeaderboardEntries.ContainsKey(item.Key) && (bool)MultiplayerLobbyReferences.LeaderboardEntries[item.Key])
			{
				MultiplayerLobbyReferences.LeaderboardEntries[item.Key].UpdateValues(num, item.Value);
				MultiplayerLobbyReferences.LeaderboardEntries[item.Key].transform.SetAsLastSibling();
				if (item.Value != num2)
				{
					num2 = item.Value;
					num++;
				}
			}
		}
	}

	public void ResetLeaderboard()
	{
		if (!LobbyData.Current.IsOwner)
		{
			Debug.Log("Couldn't reset leaderboard because user isn't lobby owner");
			return;
		}
		SteamMultiplayer.SendResetLeaderboard();
		ResetAll();
	}

	public void ResetAll()
	{
		TapsSinceJoined = TapsSinceJoined.ToDictionary((KeyValuePair<UserData, int> kvp) => kvp.Key, (KeyValuePair<UserData, int> kvp) => 0);
		TryUpdateLeaderboardUI();
	}

	public void ToggleLeaderboardUI()
	{
		SetLeaderboardUIVisibility(!IsVisible);
	}

	public void SetLeaderboardUIVisibility(bool visible)
	{
		IsVisible = visible;
		_leaderboardViewport.SetActive(visible);
		OnShow?.Invoke(visible);
		if (visible)
		{
			TryUpdateLeaderboardUI();
		}
	}

	private void EnableResetButton(LobbyData lobby, UserData user, EChatMemberStateChange changes)
	{
		_resetButton.SetActive(LobbyData.Current.IsOwner);
	}

	public List<UserData> GetLowerHalf()
	{
		int cutoff = TapsSinceJoined.OrderByDescending((KeyValuePair<UserData, int> p) => p.Value).ElementAt(Mathf.CeilToInt((float)TapsSinceJoined.Count / 2f)).Value;
		return (from p in TapsSinceJoined
			where p.Value <= cutoff
			select p.Key).ToList();
	}
}
