using System;
using System.Collections;
using System.Collections.Generic;
using Steam;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassWindow : MonoBehaviour
{
	[SerializeField]
	private LocalizeStringEvent _title;

	[SerializeField]
	private LocalizeStringEvent _subtitle;

	[SerializeField]
	private Slider _overallProgressFill;

	[SerializeField]
	private TMP_Text _progressNumber;

	[SerializeField]
	private PawPassMilestoneBubble _currentMilestoneNumber;

	[SerializeField]
	private PawPassMilestoneBubble _nextMilestoneNumber;

	public RectTransform FreePassParent;

	public RectTransform PremiumPassParent;

	public ScrollRect ScrollRect;

	[SerializeField]
	private Slider _passProgressFill;

	public RectTransform MilestoneParent;

	[SerializeField]
	private GameObject _passView;

	[SerializeField]
	private GameObject _pastPassesView;

	[SerializeField]
	private GameObject _disconnectedPanel;

	[SerializeField]
	private GameObject _welcomeNote;

	[SerializeField]
	private List<Button> _getPassButtons;

	[SerializeField]
	private List<Button> _claimAllButtons;

	[SerializeField]
	private GameObject _confirmPopup;

	private const string PAWPASSTUTORIALKEY = "PP_TUTORIAL";

	private int _pawPassTutorialStep;

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => StatsInitializer.Initialized);
		_pawPassTutorialStep = PlayerPrefs.GetInt("PP_TUTORIAL", 0);
		_welcomeNote.SetActive(_pawPassTutorialStep < 1);
	}

	private void OnEnable()
	{
		_confirmPopup.SetActive(value: false);
		ShowPassView();
		PawPassManager.Instance.Refresh();
	}

	public void SetSeason(PawPassEntity pass)
	{
		_title.StringReference = pass.Title;
		_subtitle.StringReference = pass.Subtitle;
	}

	public void ShowPassView()
	{
		_passView.SetActive(value: true);
		_pastPassesView.SetActive(value: false);
	}

	public void ShowPastPasses()
	{
		_passView.SetActive(value: false);
		_pastPassesView.SetActive(value: true);
	}

	public void ShowRedeemConfirmation()
	{
		_confirmPopup.SetActive(value: true);
	}

	public void ConfirmRedeem()
	{
		_confirmPopup.SetActive(value: false);
		PawPassManager.Instance.RedeemPassToken();
	}

	public void RequestPremiumUnlock()
	{
		PawPassManager.Instance.UnlockPremiumPass();
	}

	public void SetGetPassVisible(bool visible)
	{
		foreach (Button getPassButton in _getPassButtons)
		{
			getPassButton.gameObject.SetActive(visible);
		}
	}

	public void SetGetPassInteractable(bool interactable)
	{
		foreach (Button getPassButton in _getPassButtons)
		{
			getPassButton.interactable = interactable;
		}
	}

	public void SetClaimAllInteractable(bool interactable)
	{
		foreach (Button claimAllButton in _claimAllButtons)
		{
			claimAllButton.interactable = interactable;
		}
	}

	public void ClaimAll()
	{
		PawPassManager.Instance.ClaimAll();
	}

	public void SetCurrentMilestoneProgress(int tapsIntoMilestone, int requiredTaps, int currentMilestone)
	{
		_progressNumber.text = FormatNumber(tapsIntoMilestone) + "/" + FormatNumber(requiredTaps);
		_overallProgressFill.value = Mathf.Clamp01((float)tapsIntoMilestone / (float)requiredTaps);
		int totalMilestones = PawPassManager.Instance.SelectedPass.TotalMilestones;
		_currentMilestoneNumber.gameObject.SetActive(currentMilestone != 0);
		_currentMilestoneNumber.SetMilestone(Math.Min(currentMilestone, totalMilestones));
		bool active = currentMilestone < totalMilestones;
		_nextMilestoneNumber.gameObject.SetActive(active);
		_nextMilestoneNumber.SetMilestone(Math.Min(currentMilestone + 1, totalMilestones));
	}

	public void SetPassProgress(int taps, int totalTaps)
	{
		int requiredTapsPerMilestone = PawPassManager.Instance.SelectedPass.RequiredTapsPerMilestone;
		float num = ((taps < requiredTapsPerMilestone) ? ((float)taps / 2f / (float)totalTaps) : (((float)taps - (float)requiredTapsPerMilestone / 2f) / ((float)totalTaps - (float)requiredTapsPerMilestone / 2f)));
		_passProgressFill.value = Mathf.Clamp01(num);
		float milestonesReached = Mathf.Floor(num * (float)PawPassManager.Instance.SelectedPass.TotalMilestones);
		PawPassManager.Instance.ReachMilestones(milestonesReached);
	}

	private static string FormatNumber(int number)
	{
		if (number < 1000)
		{
			return number.ToString();
		}
		return $"{(float)number / 1000f:0.#}k";
	}

	public void AdvancePawPassTutorial()
	{
		_pawPassTutorialStep++;
		PlayerPrefs.SetInt("PP_TUTORIAL", _pawPassTutorialStep);
		PlayerPrefs.Save();
	}
}
