using Crosstales.BWF;
using Crosstales.BWF.Model.Enum;
using Crosstales.Common.Util;
using Heathen.SteamworksIntegration;
using Heathen.SteamworksIntegration.API;
using IroxGames.Helper.ClassExtensions;
using SteamTools;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Multiplayer;

public class LobbyIdJoin : MonoBehaviour
{
	private const int MIN_LOBBYCODE_SIZE = 5;

	private const int MAX_LOBBYCODE_SIZE = 12;

	[SerializeField]
	private Button _joinButton;

	[SerializeField]
	private GameObject _createCodeLobbyButton;

	[SerializeField]
	private GameObject _randomJoinButton;

	[SerializeField]
	private Button _createLobbyButton;

	[SerializeField]
	private TMP_InputField _inputField;

	[SerializeField]
	private LobbyIdDisplay _idDisplay;

	private string _currentLobbyCodeInput;

	private LobbyData _lobby;

	private int _lobbyListRequest;

	private bool _creatingCustomLobby;

	[SerializeField]
	private SpecialLobbyCodeReferencer _specialLobbyCodeReferencer;

	private void Awake()
	{
		Events.OnLobbyDataUpdate += OnLobbyInfoReceived;
	}

	private void OnDestroy()
	{
		Events.OnLobbyDataUpdate -= OnLobbyInfoReceived;
	}

	public void OnValueChanged(string val)
	{
		_currentLobbyCodeInput = val.Trim();
		_creatingCustomLobby = false;
		if (string.IsNullOrWhiteSpace(_currentLobbyCodeInput))
		{
			_randomJoinButton.SetActive(value: true);
			_joinButton.gameObject.SetActive(value: false);
			_createCodeLobbyButton.SetActive(value: false);
			return;
		}
		_randomJoinButton.SetActive(value: false);
		_joinButton.gameObject.SetActive(value: true);
		_createCodeLobbyButton.SetActive(value: false);
		_joinButton.interactable = false;
		if (_specialLobbyCodeReferencer.IsSpecialLobbyCode(_currentLobbyCodeInput.ToLower()))
		{
			_joinButton.interactable = true;
		}
		else if (_currentLobbyCodeInput.Length >= 5)
		{
			if (_currentLobbyCodeInput.Length > 12)
			{
				_currentLobbyCodeInput = _currentLobbyCodeInput.Substring(0, 12);
			}
			Matchmaking.Client.AddRequestLobbyListStringFilter("LOBBYCODE", _currentLobbyCodeInput, ELobbyComparison.k_ELobbyComparisonEqual);
			Matchmaking.Client.AddRequestLobbyListDistanceFilter(ELobbyDistanceFilter.k_ELobbyDistanceFilterWorldwide);
			RequestLobbyList();
		}
	}

	public void JoinLobby()
	{
		if (_specialLobbyCodeReferencer.TryGrantCode(_currentLobbyCodeInput))
		{
			_joinButton.interactable = false;
		}
		else if (_lobby.IsValid)
		{
			_lobby.Join();
			_inputField.text = string.Empty;
			_lobby = CSteamID.Nil;
			_joinButton.interactable = false;
		}
	}

	public void TryCreateLobby()
	{
		_creatingCustomLobby = true;
		Matchmaking.Client.AddRequestLobbyListStringFilter("LOBBYCODE", _currentLobbyCodeInput, ELobbyComparison.k_ELobbyComparisonEqual);
		Matchmaking.Client.AddRequestLobbyListDistanceFilter(ELobbyDistanceFilter.k_ELobbyDistanceFilterWorldwide);
		RequestLobbyList();
	}

	public void JoinRandomLobby()
	{
		_createLobbyButton.interactable = false;
		_lobbyListRequest = 0;
		Matchmaking.Client.AddRequestLobbyListDistanceFilter(ELobbyDistanceFilter.k_ELobbyDistanceFilterDefault);
		RequestLobbyList();
	}

	private void CreateLobby()
	{
		_idDisplay.SetLobbyId(_currentLobbyCodeInput);
		SettingsManager.Instance.PrivateLobby.SetSelection(2, onlyUpdateVisuals: false);
		MultiplayerLobby.Instance.Create();
	}

	private void CheckLobbyCode(LobbyData[] lobbies)
	{
		if (_specialLobbyCodeReferencer.IsSpecialLobbyCode(_currentLobbyCodeInput.ToLower()))
		{
			_joinButton.interactable = true;
		}
		else if (lobbies.Length == 0)
		{
			ulong ulSteamID = BaseConverter.DecodeFromBase59(_currentLobbyCodeInput);
			_lobby = new CSteamID(ulSteamID);
			if (_lobby.IsValid)
			{
				Matchmaking.Client.RequestLobbyData(_lobby);
			}
			else if (!Singleton<BWFManager>.Instance.Contains(_currentLobbyCodeInput, ManagerMask.All))
			{
				if (_creatingCustomLobby)
				{
					CreateLobby();
					return;
				}
				_joinButton.gameObject.SetActive(value: false);
				_createCodeLobbyButton.SetActive(value: true);
			}
		}
		else
		{
			_lobby = lobbies[0];
			if (_lobby.IsValid)
			{
				Matchmaking.Client.RequestLobbyData(_lobby);
			}
		}
	}

	private void OnLobbyInfoReceived(LobbyData lobby, LobbyMemberData? member)
	{
		if (!(lobby != _lobby))
		{
			if (_creatingCustomLobby)
			{
				JoinLobby();
			}
			else
			{
				_joinButton.interactable = base.gameObject.activeInHierarchy && lobby.MemberCount > 0;
			}
		}
	}

	private void RequestLobbyList()
	{
		Matchmaking.Client.RequestLobbyList(delegate(LobbyData[] lobbies, bool error)
		{
			if (error)
			{
				_createLobbyButton.interactable = true;
			}
			else
			{
				OnLobbyMatchList(lobbies);
			}
		});
	}

	private void OnLobbyMatchList(LobbyData[] lobbies)
	{
		if (string.IsNullOrEmpty(_currentLobbyCodeInput))
		{
			TryJoinRandom(lobbies);
		}
		else
		{
			CheckLobbyCode(lobbies);
		}
	}

	private void TryJoinRandom(LobbyData[] lobbies)
	{
		if (lobbies.Length == 0)
		{
			switch (_lobbyListRequest)
			{
			case 0:
				Matchmaking.Client.AddRequestLobbyListDistanceFilter(ELobbyDistanceFilter.k_ELobbyDistanceFilterFar);
				break;
			case 1:
				Matchmaking.Client.AddRequestLobbyListDistanceFilter(ELobbyDistanceFilter.k_ELobbyDistanceFilterWorldwide);
				break;
			default:
				Debug.Log("No open lobbies were found");
				_createLobbyButton.interactable = true;
				return;
			}
			_lobbyListRequest++;
			Invoke("RequestLobbyList", 1f);
		}
		else
		{
			lobbies.GetRandom().Join();
			_createLobbyButton.interactable = true;
		}
	}

	private void OnDisable()
	{
		_inputField.text = string.Empty;
		_lobby = CSteamID.Nil;
		_joinButton.interactable = false;
		_randomJoinButton.SetActive(value: true);
		_joinButton.gameObject.SetActive(value: false);
		_createLobbyButton.interactable = true;
	}
}
