using Steamworks;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamWorkshopItemDetailData))]
public class SteamWorkshopItemDetailDataEvents : MonoBehaviour
{
	public UnityEvent onChange;

	public UnityEvent<PublishedFileId_t> onSubscribed = new UnityEvent<PublishedFileId_t>();

	public UnityEvent<PublishedFileId_t> onUnsubscribed = new UnityEvent<PublishedFileId_t>();

	public UnityEvent<PublishedFileId_t> onDelete = new UnityEvent<PublishedFileId_t>();

	public UnityEvent<PublishedFileId_t> onVoteSet = new UnityEvent<PublishedFileId_t>();

	public UnityEvent<PublishedFileId_t> onPlayStarted = new UnityEvent<PublishedFileId_t>();

	public UnityEvent<PublishedFileId_t> onPlayEnded = new UnityEvent<PublishedFileId_t>();

	public UnityEvent<PublishedFileId_t> onEdited = new UnityEvent<PublishedFileId_t>();

	public UnityEvent<EResult> onSubscribeFailed = new UnityEvent<EResult>();

	public UnityEvent<EResult> onUnsubscribeFailed = new UnityEvent<EResult>();

	public UnityEvent<EResult> onDeleteFailed = new UnityEvent<EResult>();

	public UnityEvent<EResult> onVoteSetFailed = new UnityEvent<EResult>();

	public UnityEvent<EResult> onPlayStartedFailed = new UnityEvent<EResult>();

	public UnityEvent<EResult> onPlayEndedFailed = new UnityEvent<EResult>();

	public UnityEvent<EResult> onEditFailed = new UnityEvent<EResult>();

	public UnityEvent<bool> onSetIsSubscribed = new UnityEvent<bool>();

	public UnityEvent<bool> onSetIsNotSubscribed = new UnityEvent<bool>();

	public UnityEvent<bool> onSetIsInstalled = new UnityEvent<bool>();

	public UnityEvent<bool> onSetIsNotInstalled = new UnityEvent<bool>();

	public UnityEvent<byte[]> onPreviewImageLoaded = new UnityEvent<byte[]>();

	private SteamWorkshopItemDetailData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamWorkshopItemDetailData>();
		onChange.AddListener(HandleOnChange);
	}

	private void HandleOnChange()
	{
		if (_mInspector.Data != null)
		{
			onSetIsSubscribed?.Invoke(_mInspector.Data.IsSubscribed);
			onSetIsNotSubscribed?.Invoke(!_mInspector.Data.IsSubscribed);
			onSetIsInstalled?.Invoke(_mInspector.Data.IsInstalled);
			onSetIsNotInstalled?.Invoke(!_mInspector.Data.IsInstalled);
		}
	}
}
