using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BongoCat;

public class ItemCollection : MonoBehaviour
{
	[SerializeField]
	private InventoryItem _collectionItemPrefab;

	[SerializeField]
	private InventoryItem _emoteItemPrefab;

	[SerializeField]
	private Transform _collectionRoot;

	[SerializeField]
	private Transform _favoriteCollectionRoot;

	[SerializeField]
	private GameObject _favoriteSeparator;

	private bool _isPartOfBongoDex;

	private bool _isHiddenCollection;

	private string _filter = string.Empty;

	private List<InventoryItem> _collectionItems = new List<InventoryItem>();

	public Action OnInitialized;

	public int Count => _collectionItems.Count(IsRevealed);

	public bool ContainsActiveItems => _collectionItems.Any((InventoryItem item) => item.gameObject.activeSelf);

	public bool ContainsVisibleItems => _collectionItems.Any((InventoryItem item) => item.SteamItem.IsOwned && !item.SteamItem.IsHiddenInInventory);

	public int OwnedItems => _collectionItems.Count((InventoryItem item) => item.SteamItem.IsOwned);

	public bool UnhideHiddenCollection
	{
		get
		{
			if (_isHiddenCollection)
			{
				return _collectionItems.Any((InventoryItem item) => item.SteamItem.IsOwned);
			}
			return false;
		}
	}

	public List<InventoryItem> CollectionItems => _collectionItems;

	public void CreateCollection(string collectionName, List<SteamItemRuntime> collectionSteamItems, bool isPartOfBongoDex)
	{
		_isPartOfBongoDex = isPartOfBongoDex;
		foreach (SteamItemRuntime collectionSteamItem in collectionSteamItems)
		{
			Add(collectionSteamItem, _isPartOfBongoDex);
		}
		SortCollectionInitial();
		if (_isPartOfBongoDex)
		{
			base.gameObject.name = collectionName ?? "";
			_isHiddenCollection = _collectionItems.TrueForAll((InventoryItem item) => item.SteamItem.HideUntilReceived);
			OnInitialized?.Invoke();
			return;
		}
		foreach (SteamItemRuntime item in collectionSteamItems.Where((SteamItemRuntime i) => i.IsFavorite))
		{
			SeparateItem(item);
		}
		OnInitialized?.Invoke();
	}

	private void Add(SteamItemRuntime item, bool isPartOfBongoDex)
	{
		InventoryItem inventoryItem = ((!item.IsEmote && !item.IsConsumable) ? global::UnityEngine.Object.Instantiate(_collectionItemPrefab, _collectionRoot) : global::UnityEngine.Object.Instantiate(_emoteItemPrefab, _collectionRoot));
		inventoryItem.SetItem(item, isPartOfBongoDex, this);
		_collectionItems.Add(inventoryItem);
	}

	public void SortCollection()
	{
		if (_collectionRoot.gameObject.activeInHierarchy)
		{
			_collectionItems.RemoveAll((InventoryItem item) => !item);
			StartCoroutine(SortCollectionDelayed());
		}
	}

	private void SortCollectionInitial()
	{
		_collectionItems = (_isPartOfBongoDex ? SortBongoCollection() : SortInventoryCollection());
		foreach (InventoryItem collectionItem in _collectionItems)
		{
			collectionItem.transform.SetAsLastSibling();
		}
	}

	private IEnumerator SortCollectionDelayed()
	{
		yield return null;
		SortCollectionInitial();
	}

	private List<InventoryItem> SortInventoryCollection()
	{
		bool sortAscending = CatInventory.Instance.SortAscending;
		IOrderedEnumerable<InventoryItem> source = _collectionItems.OrderByDescending((InventoryItem i) => i.SteamItem.IsFavorite);
		return (CatInventory.Instance.SortMode switch
		{
			CatInventory.SortingMode.Count => (sortAscending ? source.ThenBy((InventoryItem i) => i.SteamItem.DisplayedItemAmount) : source.ThenByDescending((InventoryItem i) => i.SteamItem.DisplayedItemAmount)).ThenByDescending((InventoryItem i) => (int)i.SteamItem.QualityCategory).ThenByDescending((InventoryItem i) => i.SteamItem.Tag), 
			CatInventory.SortingMode.Event => (sortAscending ? source.ThenBy((InventoryItem i) => i.SteamItem.Tag) : source.ThenByDescending((InventoryItem i) => i.SteamItem.Tag)).ThenByDescending((InventoryItem i) => (int)i.SteamItem.QualityCategory), 
			_ => (sortAscending ? source.ThenBy((InventoryItem i) => (int)i.SteamItem.QualityCategory) : source.ThenByDescending((InventoryItem i) => (int)i.SteamItem.QualityCategory)).ThenByDescending((InventoryItem i) => i.SteamItem.Tag), 
		}).ThenBy((InventoryItem i) => i.SteamItem.Id).ToList();
	}

	private List<InventoryItem> SortBongoCollection()
	{
		return _collectionItems = _collectionItems.OrderByDescending((InventoryItem i) => (int)i.SteamItem.QualityCategory).ThenByDescending(delegate(InventoryItem i)
		{
			string itemSlot = i.SteamItem.ItemSlot;
			if (itemSlot == "hat")
			{
				return 2;
			}
			return (itemSlot == "skin") ? 1 : 0;
		}).ThenBy((InventoryItem i) => i.SteamItem.Id)
			.ToList();
	}

	public void Filter(string filter)
	{
		_filter = filter;
		foreach (InventoryItem collectionItem in _collectionItems)
		{
			collectionItem.gameObject.SetActive(IsItemVisible(collectionItem));
		}
	}

	public bool IsItemVisible(InventoryItem item)
	{
		if (IsRevealed(item))
		{
			if (_filter.Length != 0)
			{
				return item.name.ToLower().Contains(_filter);
			}
			return true;
		}
		return false;
	}

	private bool IsRevealed(InventoryItem item)
	{
		if (!item.SteamItem.IsOwned && item.SteamItem.HideUntilReceived)
		{
			return UnhideHiddenCollection;
		}
		return true;
	}

	public void SeparateItem(SteamItemRuntime item, bool sortCollection = false)
	{
		InventoryItem inventoryItem = _collectionItems.FirstOrDefault((InventoryItem i) => i.SteamItem == item);
		if ((bool)inventoryItem)
		{
			inventoryItem.transform.SetParent(item.IsFavorite ? _favoriteCollectionRoot : _collectionRoot);
			if (sortCollection)
			{
				SortCollection();
			}
		}
	}

	public void SetFavoriteSeparatorVisibility()
	{
		bool flag = Enumerable.Range(0, _collectionRoot.childCount).Any((int i) => _collectionRoot.GetChild(i).gameObject.activeSelf);
		bool flag2 = Enumerable.Range(0, _favoriteCollectionRoot.childCount).Any((int i) => _favoriteCollectionRoot.GetChild(i).gameObject.activeSelf);
		_favoriteCollectionRoot.gameObject.SetActive(flag & flag2);
		_favoriteSeparator.SetActive(flag & flag2);
	}
}
