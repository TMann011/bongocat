using System.Collections.Generic;
using Helper;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.UI;

public class BongoDexView : MonoBehaviour
{
	[SerializeField]
	private TMP_InputField _searchInputField;

	public ScrollRect ScrollRect;

	public ScrollViewUpdater ScrollViewUpdater;

	public List<BongoDexCollection> BongoDexCollections { get; } = new List<BongoDexCollection>();

	private void OnEnable()
	{
		_searchInputField.text = string.Empty;
		BongoDexCollections.ForEach(delegate(BongoDexCollection collection)
		{
			collection.Reset();
		});
		CatInventory.OnInventoryChanged.AddListener(Refresh);
	}

	private void OnDisable()
	{
		CatInventory.OnInventoryChanged.RemoveListener(Refresh);
	}

	public void Refresh()
	{
		BongoDexCollections.ForEach(delegate(BongoDexCollection collection)
		{
			collection.Refresh();
		});
		ScrollViewUpdater.UpdateScrollView();
	}

	public void FilterName(string filter)
	{
		string lowerFilter = filter.ToLower().Trim();
		BongoDexCollections.ForEach(delegate(BongoDexCollection collection)
		{
			collection.Filter(lowerFilter);
		});
		ScrollViewUpdater.UpdateScrollRect();
	}

	public void FilterName()
	{
		FilterName(_searchInputField.text);
	}

	public void ClearSearch()
	{
		_searchInputField.text = string.Empty;
		FilterName(string.Empty);
	}
}
