using UnityEngine;
using UnityEngine.Localization;

namespace Tutorial;

public abstract class UnlockCondition : ScriptableObject
{
	public TutorialUnlocks.TutorialTasks Flag;

	public LocalizedString LocalizerKey;

	public int Target = 1;

	public int Remaining => Mathf.Max(0, Target - Current);

	public bool IsMet => Current >= Target;

	public abstract int Current { get; }

	public virtual bool RevealSeen => TutorialUnlocks.HasFlag(Flag);

	public virtual void MarkRevealSeen()
	{
		TutorialUnlocks.SetFlag(Flag);
	}
}
