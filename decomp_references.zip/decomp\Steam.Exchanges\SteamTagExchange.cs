using BongoCat.SteamJsonParser;

namespace Steam.Exchanges;

public class SteamTagExchange : SteamItemBase
{
	public string InputTagValue;

	public int InputAmount;

	public SteamItemBase OutputItem;

	public override SteamItemJson ToSteamItemBackend()
	{
		return new SteamItemJson(this)
		{
			type = "bundle",
			bundle = $"{OutputItem.Id}",
			exchange = $"{InputTagValue}*{InputAmount}"
		};
	}
}
