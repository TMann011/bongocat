namespace BongoCat.Multiplayer.Spawning;

public enum FillOrder
{
	RowFirst,
	ColumnFirst
}
