using BongoCat.Multiplayer.Spawning;
using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat.Multiplayer;

[DefaultExecutionOrder(100)]
public class LobbyMemberInstance : MonoBehaviour, ISlotOccupant
{
	public Cat cat;

	[SerializeField]
	private Draggable _draggable;

	public SteamUserData steamUserData;

	public CatRotator Rotator => cat.catRotator;

	public FlipVisuals FlipVisuals => cat.flipVisuals;

	public CatPatter Patter => cat.catPatter;

	public Vector2 Pos => _draggable.transform.position;

	public bool IsHidden
	{
		get
		{
			return PlayerDataCache.GetIsHidden(steamUserData.Data.IdStr);
		}
		set
		{
			bool num = value != IsHidden;
			PlayerDataCache.SetIsHidden(steamUserData.Data.IdStr, value);
			cat.gameObject.SetActive(!value);
			if (num)
			{
				if (value)
				{
					CatSpawnManager.Instance.HandleCatRemoved(this);
				}
				else
				{
					CatSpawnManager.Instance.TryCalcPosition(this);
				}
			}
		}
	}

	private void Awake()
	{
		cat.gameObject.SetActive(value: false);
	}

	private void Start()
	{
		MultiplayerLobbyReferences.GameplayInstances.Add(steamUserData.Data, this);
		_draggable.SlotOwner = this;
		_draggable.OnDragStarted.AddListener(BringToFront);
		_draggable.OnDragFinished.AddListener(OnMovedExternally);
		IsHidden = IsHidden || SettingsManager.Instance.AutoHideCats.Value;
		cat.transform.SetParent(SteamMultiplayer.Instance.Root);
		CatSpawnManager.Instance.TryCalcPosition(this);
	}

	public void SetPos(Vector2 pos)
	{
		_draggable.transform.position = pos;
		SavePos();
	}

	private void SavePos()
	{
		_draggable.FetchRelativePos();
		PlayerDataCache.SetPos(steamUserData.Data.IdStr, _draggable.transform.position);
	}

	private void BringToFront()
	{
		cat.transform.SetAsLastSibling();
	}

	private void OnMovedExternally()
	{
		SavePos();
		CatSpawnManager.Instance.UpdateOccupancy(this);
	}

	private void OnDestroy()
	{
		MultiplayerLobbyReferences.GameplayInstances.Remove(steamUserData.Data);
		if ((bool)CatSpawnManager.Instance)
		{
			CatSpawnManager.Instance.HandleCatRemoved(this);
		}
		if ((bool)cat)
		{
			if ((bool)BattleRoyale.Instance && (BattleRoyale.Instance.InBattle || BattleRoyale.Instance.HasWon))
			{
				BattleRoyale.Instance.KillCat(cat.transform);
			}
			else
			{
				Object.Destroy(cat.gameObject);
			}
		}
		if ((bool)_draggable)
		{
			_draggable.OnDragStarted.RemoveListener(BringToFront);
			_draggable.OnDragFinished.RemoveListener(OnMovedExternally);
		}
		if ((bool)OnDemandRenderHelper.Instance)
		{
			OnDemandRenderHelper.Instance.ResumeRenderingForDuration(0.1f);
		}
	}
}
