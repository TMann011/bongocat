using System;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassItemFullCosmetic : PawPassItemClass
{
	[SerializeField]
	private Image _skin;

	[SerializeField]
	private Image _hat;

	public override void FillContent(PawPassMilestone pawPassMilestone)
	{
		foreach (PawPassMilestoneItem item in pawPassMilestone.Items)
		{
			FillContent(item);
		}
	}

	public override void FillContent(PawPassMilestoneItem pawPassMilestoneItem)
	{
		switch (pawPassMilestoneItem.RewardType)
		{
		case RewardType.HAT:
			_hat.sprite = pawPassMilestoneItem.FullImage;
			break;
		case RewardType.SKIN:
			_skin.sprite = pawPassMilestoneItem.FullImage;
			break;
		default:
			throw new ArgumentOutOfRangeException();
		}
	}
}
