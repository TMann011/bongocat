using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassItemConsumable : PawPassItemClass
{
	[SerializeField]
	private Image _icon;

	[SerializeField]
	private TMP_Text _amount;

	public override void FillContent(PawPassMilestone pawPassMilestone)
	{
		FillContent(pawPassMilestone.Items[0]);
	}

	public override void FillContent(PawPassMilestoneItem pawPassMilestoneItem)
	{
		_icon.sprite = pawPassMilestoneItem.FullImage;
		_amount.text = pawPassMilestoneItem.Amount.ToString();
	}
}
