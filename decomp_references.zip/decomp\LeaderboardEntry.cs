using BongoCat.Multiplayer;
using Heathen.SteamworksIntegration;
using TMPro;
using UnityEngine;

public class LeaderboardEntry : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _rank;

	[SerializeField]
	private TMP_Text _tapAmount;

	[SerializeField]
	private SteamUserData _userData;

	private void Start()
	{
		MultiplayerLobbyReferences.LeaderboardEntries.Add(_userData.Data, this);
	}

	private void OnDestroy()
	{
		MultiplayerLobbyReferences.LeaderboardEntries.Remove(_userData.Data);
	}

	public void UpdateValues(int rank, int tapAmount)
	{
		_rank.text = $"{rank}.";
		_tapAmount.text = tapAmount.ToString();
	}
}
