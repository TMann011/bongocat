using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class LeaveLobby : MonoBehaviour
{
	public void Leave()
	{
		if (LobbyData.Current.IsValid)
		{
			LobbyData.Current.Leave();
		}
	}
}
