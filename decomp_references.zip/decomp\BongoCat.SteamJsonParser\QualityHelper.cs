using UnityEngine;

namespace BongoCat.SteamJsonParser;

public static class QualityHelper
{
	public static Color GetColor(this QualityCategory quality)
	{
		return quality switch
		{
			QualityCategory.Common => new Color(0.6901961f, 0.6901961f, 0.6901961f), 
			QualityCategory.Uncommon => new Color(0.3529412f, 0.8f, 0.2392157f), 
			QualityCategory.Rare => new Color(0.145098f, 0.5568628f, 0.8313726f), 
			QualityCategory.Epic => new Color(37f / 51f, 0.2235294f, 0.8588235f), 
			QualityCategory.Legendary => new Color(1f, 0.6901961f, 0f), 
			QualityCategory.Unique => new Color(1f, 0.24f, 0.53f), 
			_ => Color.black, 
		};
	}

	public static bool IsTopTier(this QualityCategory quality)
	{
		if (quality != QualityCategory.Legendary)
		{
			return quality == QualityCategory.Unique;
		}
		return true;
	}
}
