using System;
using System.Collections.Generic;
using System.Linq;
using BongoCat.SteamJsonParser;
using Heathen.SteamworksIntegration;

namespace BongoCat.PawPass;

[Serializable]
public class PawPassMilestone
{
	public List<PawPassMilestoneItem> Items = new List<PawPassMilestoneItem>();

	public bool IsFullCosmetic;

	public SteamItemBasic ClaimToken;

	public SteamExchange ClaimExchange;

	public bool IsUnclaimed => ClaimToken.HasItem;

	public void Claim(Action<bool, ItemDetail[]> onCompleted)
	{
		ClaimExchange.Exchange(delegate((bool, ItemDetail[]) result)
		{
			onCompleted(result.Item1, result.Item1 ? Rewards(result.Item2) : null);
		});
	}

	private ItemDetail[] Rewards(ItemDetail[] granted)
	{
		return granted.Where((ItemDetail item) => !ClaimExchange.Input.Exists((SteamItemBasic input) => input.Id == item.Definition.id)).ToArray();
	}
}
