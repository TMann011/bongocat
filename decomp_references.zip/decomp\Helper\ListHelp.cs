using System;
using System.Collections.Generic;
using System.Linq;

namespace Helper;

public static class ListHelp
{
	public static IEnumerable<TResult> SelectNotNull<TSource, TResult>(this IEnumerable<TSource> source, Func<TSource, TResult> selector)
	{
		return from o in source.Select(selector)
			where o != null
			select o;
	}
}
