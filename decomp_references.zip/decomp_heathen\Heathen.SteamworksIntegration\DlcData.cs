using System;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct DlcData : IEquatable<AppId_t>, IEquatable<uint>, IEquatable<AppData>, IComparable<AppData>, IComparable<AppId_t>, IComparable<uint>
{
	[SerializeField]
	private uint id;

	public override string ToString()
	{
		return id.ToString();
	}

	public int CompareTo(AppData other)
	{
		uint num = id;
		return num.CompareTo(other.AppId.m_AppId);
	}

	public int CompareTo(AppId_t other)
	{
		uint num = id;
		return num.CompareTo(other.m_AppId);
	}

	public int CompareTo(uint other)
	{
		uint num = id;
		return num.CompareTo(other);
	}

	public bool Equals(uint other)
	{
		uint num = id;
		return num.Equals(other);
	}

	public override bool Equals(object obj)
	{
		uint num = id;
		return num.Equals(obj);
	}

	public override int GetHashCode()
	{
		uint num = id;
		return num.GetHashCode();
	}

	public bool Equals(AppId_t other)
	{
		uint num = id;
		return num.Equals(other.m_AppId);
	}

	public bool Equals(AppData other)
	{
		uint num = id;
		return num.Equals(other.AppId.m_AppId);
	}

	public static implicit operator DlcData(AppId_t id)
	{
		return new DlcData
		{
			id = id.m_AppId
		};
	}
}
