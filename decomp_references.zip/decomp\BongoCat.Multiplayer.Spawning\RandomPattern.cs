using System.Collections.Generic;

namespace BongoCat.Multiplayer.Spawning;

public class RandomPattern : CatSpawnPatternBase
{
	public override SpawnControls Controls => SpawnControls.Recalculate;

	public override bool ComputesSlots => false;

	public override bool IncludesMainCat => false;

	public RandomPattern(CatSpawnSettings settings)
		: base(settings)
	{
	}

	protected override List<CatSlot> Layout()
	{
		return new List<CatSlot>();
	}
}
