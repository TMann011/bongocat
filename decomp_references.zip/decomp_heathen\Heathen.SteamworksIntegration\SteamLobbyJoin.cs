using Steamworks;
using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyJoin : MonoBehaviour
{
	[Tooltip("If true and creating a Party it will leave any existing lobby first, if true when creating a session it will notify any existing party of the new session lobby.")]
	public bool partyWise;

	private SteamLobbyData _mInspector;

	private SteamLobbyDataEvents _mEvents;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mEvents = GetComponent<SteamLobbyDataEvents>();
	}

	public void RequestJoin(SteamLobbyJoin toRequest)
	{
		if (toRequest != null && _mInspector.Data.IsValid)
		{
			toRequest.Join(_mInspector.Data);
		}
	}

	public void JoinFromIdString(string id)
	{
		Join(LobbyData.Get(id));
	}

	public void JoinFromIdInputField(TMP_InputField input)
	{
		Join(LobbyData.Get(input.text));
	}

	public void Join(LobbyData lobby)
	{
		if (!lobby.IsValid || lobby == _mInspector.Data)
		{
			return;
		}
		LobbyData partyLobby = CSteamID.Nil;
		if (partyWise && LobbyData.PartyLobby(out partyLobby) && !partyLobby.IsOwner)
		{
			Debug.LogWarning("Only a party lobby leader can join lobbies");
			return;
		}
		lobby.Join(delegate(LobbyEnter enterLobby, bool enterIoError)
		{
			if (!enterIoError && enterLobby.Response == EChatRoomEnterResponse.k_EChatRoomEnterResponseSuccess)
			{
				_mInspector.Data = enterLobby.Lobby;
				if (_mEvents != null)
				{
					_mEvents.onEnterSuccess?.Invoke(enterLobby.Lobby);
				}
				if (partyLobby.IsValid && enterLobby.Lobby.IsSession)
				{
					partyLobby["z_heathenSessionLobby"] = enterLobby.Lobby.ToString();
				}
			}
			else if (_mEvents != null)
			{
				_mEvents.onEnterFailure?.Invoke(enterLobby.Response);
			}
		});
	}

	public void JoinOnRequestEvent(LobbyData lobby, UserData user)
	{
		Join(lobby);
	}
}
