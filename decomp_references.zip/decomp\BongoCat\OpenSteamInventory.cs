using UnityEngine;

namespace BongoCat;

public class OpenSteamInventory : MonoBehaviour
{
	public void OpenInventory()
	{
		Application.OpenURL($"steam://openurl/https://steamcommunity.com/my/inventory/{3419430}");
	}

	public void OpenMarket()
	{
		Application.OpenURL($"steam://openurl/https://steamcommunity.com/market/search?appid={3419430}");
	}
}
