using System.Collections;
using BongoCat.Localizer;
using Crosstales.BWF;
using Crosstales.BWF.Model.Enum;
using Crosstales.Common.Util;
using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using TMPro;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class MultiplayerLobbyUi : MonoBehaviour
{
	[SerializeField]
	private GameObject _lobbyButtons;

	[SerializeField]
	private GameObject _leaveLobbyButton;

	[SerializeField]
	private GameObject _offlineWarning;

	[SerializeField]
	private GameObject _playerCountTxt;

	[SerializeField]
	private LobbyIdJoin _lobbyIdJoin;

	[SerializeField]
	private Tabs _bottomTabButtons;

	[SerializeField]
	private GameObject _lobbyHeader;

	[SerializeField]
	private TMP_Text _headerTitle;

	[SerializeField]
	private GameObject _editTitleButton;

	[SerializeField]
	private GameObject[] _lobbyOnlyHeaderItems;

	[SerializeField]
	private GameObject _lobbyInfo;

	private IEnumerator Start()
	{
		Events.OnLobbyEnterSuccess += OnLobbyEntered;
		Events.OnLobbyLeave += OnLobbyLeft;
		Events.OnSteamServersDisconnected += OnLostConnection;
		Events.OnSteamServersConnected += OnReconnected;
		Events.OnLobbyChatUpdate += OnLobbyMemberChange;
		Events.OnLobbyDataUpdate += OnLobbyDataUpdate;
		yield return new WaitUntil(() => Interface.IsReady);
		bool flag = SteamUser.BLoggedOn();
		_lobbyButtons.SetActive(flag);
		_offlineWarning.SetActive(!flag);
		_playerCountTxt.SetActive(flag);
		_leaveLobbyButton.SetActive(value: false);
		SetLobbyOnlyHeaderItemsActive(active: false);
	}

	private void OnLobbyEntered(LobbyData lobby)
	{
		_lobbyButtons.SetActive(value: false);
		_lobbyIdJoin.gameObject.SetActive(value: false);
		_lobbyInfo.gameObject.SetActive(value: true);
		_leaveLobbyButton.SetActive(value: true);
		SetLobbyOnlyHeaderItemsActive(active: true);
		_bottomTabButtons.OpenTab(0);
		_bottomTabButtons.gameObject.SetActive(value: false);
		_editTitleButton.SetActive(lobby.IsOwner);
		ShowLobbyHeader();
	}

	private void OnLobbyLeft(LobbyData lobby)
	{
		_lobbyButtons.SetActive(value: true);
		_lobbyIdJoin.gameObject.SetActive(value: true);
		_bottomTabButtons.gameObject.SetActive(value: true);
		_lobbyInfo.SetActive(value: false);
		_leaveLobbyButton.SetActive(value: false);
		_lobbyHeader.SetActive(value: false);
		SetLobbyOnlyHeaderItemsActive(active: false);
		_editTitleButton.SetActive(value: false);
	}

	private void SetLobbyOnlyHeaderItemsActive(bool active)
	{
		GameObject[] lobbyOnlyHeaderItems = _lobbyOnlyHeaderItems;
		for (int i = 0; i < lobbyOnlyHeaderItems.Length; i++)
		{
			lobbyOnlyHeaderItems[i].SetActive(active);
		}
	}

	private void OnLostConnection(EResult result)
	{
		_lobbyHeader.SetActive(value: false);
		_lobbyButtons.SetActive(value: false);
		_offlineWarning.SetActive(value: true);
		_playerCountTxt.SetActive(value: false);
	}

	private void OnReconnected()
	{
		_lobbyButtons.SetActive(value: true);
		_offlineWarning.SetActive(value: false);
		_playerCountTxt.SetActive(value: true);
	}

	private void OnLobbyMemberChange(LobbyData lobby, UserData user, EChatMemberStateChange changes)
	{
		_editTitleButton.SetActive(lobby.IsOwner);
		Debug.Log("User " + user.Name + " changed state: " + changes);
	}

	private void ShowLobbyHeader()
	{
		string text = LobbyData.Current.Name;
		if (string.IsNullOrEmpty(text))
		{
			text = Localize.Get("LobbyHeader");
		}
		_headerTitle.text = text;
		_lobbyHeader.SetActive(value: true);
	}

	private void OnLobbyDataUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		if (LobbyData.Current.IsValid && !(lobby != LobbyData.Current))
		{
			ShowLobbyHeader();
		}
	}

	public void SetLobbyName(string newName)
	{
		if (!Singleton<BWFManager>.Instance.Contains(newName, ManagerMask.All) && !string.IsNullOrEmpty(newName))
		{
			LobbyData.Current.Name = newName;
		}
	}
}
