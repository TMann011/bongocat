using Steamworks;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamWorkshopItemEditorData))]
public class SteamWorkshopItemEditorDataEvents : MonoBehaviour
{
	public UnityEvent onChange;

	public UnityEvent onCreateUpdateSuccess;

	public UnityEvent<EResult, string> onCreateUpdateError;

	public UnityEvent onUserNeedsToAcceptWorkshopAgreement;
}
