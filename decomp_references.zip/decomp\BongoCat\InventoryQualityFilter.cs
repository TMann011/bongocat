using System.Collections.Generic;
using System.Linq;
using BongoCat.SteamJsonParser;
using UnityEngine;

namespace BongoCat;

public class InventoryQualityFilter : MonoBehaviour
{
	public static InventoryQualityFilter Instance;

	[SerializeField]
	private List<QualityFilterButton> _buttons;

	private bool _filterVisible = true;

	private HashSet<QualityCategory> _selectedQualities;

	public bool FilterVisible => _filterVisible;

	private void Awake()
	{
		Instance = this;
		_selectedQualities = new HashSet<QualityCategory>();
	}

	private void Start()
	{
		foreach (QualityFilterButton button in _buttons)
		{
			button.ToggleQuality();
		}
	}

	public bool PassesFilter(SteamItemRuntime item)
	{
		if (ItemExchange.Instance.IsVisible)
		{
			return true;
		}
		return _selectedQualities.Contains(item.QualityCategory);
	}

	public void ToggleQuality(QualityCategory qualityValue)
	{
		if (!_selectedQualities.Add(qualityValue))
		{
			_selectedQualities.Remove(qualityValue);
		}
		SetButtonVisuals();
		RefreshInventory();
	}

	public void ToggleQualityExclusive(QualityCategory qualityValue)
	{
		_selectedQualities.Clear();
		ToggleQuality(qualityValue);
	}

	private void SetButtonVisuals()
	{
		foreach (QualityFilterButton button in _buttons)
		{
			button.SetSelected(_selectedQualities.Contains(button.Quality));
		}
	}

	private void RefreshInventory()
	{
		CatInventory.Instance.UpdateItemsUI();
		CatInventory.Instance.UpdateScrollView(resetScrollBar: true);
	}

	public void SetFilterVisible(bool visible)
	{
		_filterVisible = visible;
		if (visible)
		{
			return;
		}
		foreach (QualityCategory item in _selectedQualities.ToList())
		{
			ToggleQuality(item);
		}
	}
}
