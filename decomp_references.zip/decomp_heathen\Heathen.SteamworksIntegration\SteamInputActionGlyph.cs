using Heathen.SteamworksIntegration.API;
using SteamTools;
using UnityEngine;
using UnityEngine.UI;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInputActionData))]
public class SteamInputActionGlyph : MonoBehaviour
{
	public RawImage image;

	private SteamInputActionData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamInputActionData>();
		if (!Interface.IsReady)
		{
			Interface.OnReady += HandleInitialization;
		}
		else
		{
			HandleInitialization();
		}
	}

	private void HandleInitialization()
	{
		Interface.OnReady -= HandleInitialization;
		RefreshImage();
	}

	private void OnEnable()
	{
		RefreshImage();
	}

	public void RefreshImage()
	{
		if (!(_mInspector != null) || string.IsNullOrEmpty(_mInspector.Action.Name) || !(image != null))
		{
			return;
		}
		if (_mInspector.Set.Handle != 0)
		{
			if (Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers.Count > 0)
			{
				Texture2D[] inputGlyphs = _mInspector.Action.GetInputGlyphs(Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers[0], _mInspector.Set);
				if (inputGlyphs.Length != 0)
				{
					image.texture = inputGlyphs[0];
				}
			}
		}
		else if (!string.IsNullOrEmpty(_mInspector.Layer.LayerName) && Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers.Count > 0)
		{
			Texture2D[] inputGlyphs2 = _mInspector.Action.GetInputGlyphs(Heathen.SteamworksIntegration.API.Input.Client.ConnectedControllers[0], _mInspector.Layer);
			if (inputGlyphs2.Length != 0)
			{
				image.texture = inputGlyphs2[0];
			}
		}
	}
}
