using System;
using System.Collections.Generic;
using BongoCat;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

public class OnUIHoverCallback : MonoBehaviour
{
	public static OnUIHoverCallback Instance;

	public UnityEvent onHoverEnter;

	public UnityEvent onHoverExit;

	public Action<List<RaycastResult>> onNewRaycastResults;

	private int _uiLayer;

	private int _ignoreLayer;

	private bool _lastFrameIsOver;

	private Vector3 _lastMousePos;

	private PointerEventData _eventData;

	private List<RaycastResult> _raycastResults;

	public bool Hovering { get; private set; }

	private void Awake()
	{
		Instance = this;
		_uiLayer = LayerMask.NameToLayer("UI");
		_ignoreLayer = LayerMask.NameToLayer("Ignore Raycast");
		_eventData = new PointerEventData(EventSystem.current);
		_raycastResults = new List<RaycastResult>();
	}

	private void Update()
	{
		if (Input.mousePosition == _lastMousePos)
		{
			return;
		}
		_lastMousePos = Input.mousePosition;
		_eventData.position = _lastMousePos;
		EventSystem.current.RaycastAll(_eventData, _raycastResults);
		Hovering = IsPointerOverUIElement();
		if (_lastFrameIsOver != Hovering)
		{
			if (Hovering)
			{
				onHoverEnter?.Invoke();
				OnDemandRenderHelper.Instance.ResumeRendering();
			}
			else
			{
				onHoverExit?.Invoke();
				onNewRaycastResults?.Invoke(_raycastResults);
				OnDemandRenderHelper.Instance.TryPauseRendering();
			}
		}
		_lastFrameIsOver = Hovering;
	}

	private bool IsPointerOverUIElement()
	{
		foreach (RaycastResult raycastResult in _raycastResults)
		{
			if (raycastResult.gameObject.layer == _uiLayer || raycastResult.gameObject.layer == _ignoreLayer)
			{
				onNewRaycastResults?.Invoke(_raycastResults);
				return true;
			}
		}
		return false;
	}
}
