using BongoCat.SteamJsonParser;
using UnityEngine;

namespace BongoCat;

public class OpenItemStore : MonoBehaviour
{
	[SerializeField]
	private SteamItemBase _item;

	public void Open()
	{
		OpenDetailPage(_item);
	}

	public static void OpenDetailPage(SteamItemBase item)
	{
		Application.OpenURL($"steam://openurl/https://store.steampowered.com/itemstore/{3419430}/detail/{item.Id}/");
	}
}
