using Steamworks;

namespace BongoCat;

public static class Global
{
	public static AppId_t SteamID = (AppId_t)3419430u;

	public static string Exe = "BongoCat.exe";

	public static string ShortCut = "BongoCat.lnk";
}
