using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamGameServerData))]
public class SteamGameServerEvents : MonoBehaviour
{
	public UnityEvent onChange;
}
