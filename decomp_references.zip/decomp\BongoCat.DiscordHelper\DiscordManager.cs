using System;
using BongoCat.Localizer;
using Discord.Sdk;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace BongoCat.DiscordHelper;

public class DiscordManager : MonoBehaviour
{
	private Client _client;

	public static DiscordManager Instance;

	[FormerlySerializedAs("_setting")]
	[SerializeField]
	private PlayerPrefsToggle _discordIntegrationActive;

	private void Awake()
	{
		Instance = this;
		_discordIntegrationActive.OnToggleUpdated.AddListener(ToggleUpdated);
	}

	private void Init()
	{
		if (_client != null)
		{
			if (!_discordIntegrationActive.Value)
			{
				_client.Dispose();
				_client = null;
			}
		}
		else if (_discordIntegrationActive.Value)
		{
			_client = new Client();
			_client.SetApplicationId(1480978256919265390uL);
			_client.RegisterLaunchSteamApplication(1480978256919265390uL, (uint)Global.SteamID);
			_client.SetActivityJoinCallback(delegate(string secret)
			{
				SteamMatchmaking.JoinLobby(new CSteamID(ulong.Parse(secret)));
			});
		}
	}

	private void ToggleUpdated(bool value)
	{
		if (value)
		{
			SetDefaultActivity();
			return;
		}
		_client?.ClearRichPresence();
		_client?.Dispose();
		_client = null;
	}

	public void SetDefaultActivity()
	{
		Init();
		if (_discordIntegrationActive.Value)
		{
			Activity activity = new Activity();
			activity.SetType(ActivityTypes.Playing);
			activity.SetState(Localize.Get("DiscordSoloState"));
			activity.SetDetails(Localize.Get("DiscordSoloDetails"));
			_client.UpdateRichPresence(activity, delegate
			{
			});
		}
	}

	public void SetMultiplayerActivity(string secret, int numLobbyMembers)
	{
		Init();
		if (_discordIntegrationActive.Value)
		{
			Activity activity = new Activity();
			activity.SetType(ActivityTypes.Playing);
			activity.SetState(Localize.Get("DiscordCoopState"));
			activity.SetDetails(Localize.Get("DiscordCoopDetails"));
			ActivityParty activityParty = new ActivityParty();
			activityParty.SetId(default(Guid).ToString());
			activityParty.SetCurrentSize(numLobbyMembers);
			activityParty.SetMaxSize(250);
			activity.SetParty(activityParty);
			ActivitySecrets activitySecrets = new ActivitySecrets();
			activitySecrets.SetJoin(secret);
			activity.SetSecrets(activitySecrets);
			activity.SetSupportedPlatforms(ActivityGamePlatforms.Desktop);
			_client.UpdateRichPresence(activity, delegate
			{
			});
		}
	}
}
