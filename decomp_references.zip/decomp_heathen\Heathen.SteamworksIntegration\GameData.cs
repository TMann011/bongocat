using System;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct GameData : IEquatable<AppId_t>, IEquatable<CGameID>, IEquatable<uint>, IEquatable<ulong>, IEquatable<AppData>, IComparable<AppData>, IComparable<AppId_t>, IComparable<uint>, IComparable<ulong>
{
	[SerializeField]
	private ulong id;

	public static GameData Me => Heathen.SteamworksIntegration.API.App.Id.AppId;

	public CGameID GameId => new CGameID(id);

	public AppData App => GameId.AppID();

	public bool IsMe => this == Me;

	public int CompareTo(AppData other)
	{
		return App.CompareTo(other.AppId);
	}

	public int CompareTo(AppId_t other)
	{
		return App.CompareTo(other);
	}

	public int CompareTo(ulong other)
	{
		return GameId.m_GameID.CompareTo(other);
	}

	public int CompareTo(uint other)
	{
		return App.CompareTo(other);
	}

	public override string ToString()
	{
		return GameId.ToString();
	}

	public bool Equals(AppData other)
	{
		return App.Equals(other.AppId);
	}

	public bool Equals(AppId_t other)
	{
		return App.Id.Equals(other.m_AppId);
	}

	public bool Equals(uint other)
	{
		return App.Id.Equals(other);
	}

	public bool Equals(CGameID other)
	{
		return GameId.AppID().Equals(other.AppID());
	}

	public bool Equals(ulong other)
	{
		return GameId.Equals(new CGameID(other));
	}

	public override bool Equals(object obj)
	{
		return GameId.m_GameID.Equals(obj);
	}

	public override int GetHashCode()
	{
		return GameId.GetHashCode();
	}

	public static bool operator ==(GameData l, GameData r)
	{
		return l.GameId.m_GameID == r.GameId.m_GameID;
	}

	public static implicit operator GameData(CGameID id)
	{
		return new GameData
		{
			id = id.m_GameID
		};
	}

	public static implicit operator GameData(ulong id)
	{
		return new GameData
		{
			id = id
		};
	}

	public static implicit operator GameData(AppId_t id)
	{
		return new CGameID(id);
	}
}
