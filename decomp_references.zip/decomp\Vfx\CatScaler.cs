using System.Collections;
using BongoCat;
using BongoCat.Localizer;
using TMPro;
using UnityEngine;

namespace Vfx;

public class CatScaler : Scaler
{
	[SerializeField]
	private TMP_Text _text;

	[SerializeField]
	private bool useShortText;

	[SerializeField]
	private bool _isMainCat;

	private bool _init;

	private ScaleSetting ScaleSetting => SettingsManager.Instance.CatScaleSetting;

	private IEnumerator Start()
	{
		yield return null;
		yield return null;
		Index = SettingsManager.Instance.CatScaleSetting.Index;
		UpdateScale();
		SettingsManager.Instance.ScaleAllCats.OnToggleUpdated.AddListener(OnScaleAllCats);
		OnScaleAllCats(SettingsManager.Instance.ScaleAllCats.Value);
		_init = true;
	}

	private void OnDestroy()
	{
		SettingsManager.Instance?.ScaleAllCats?.OnToggleUpdated?.RemoveListener(OnScaleAllCats);
		SettingsManager.Instance?.CatScaleSetting?.OnScaleApplied?.RemoveListener(base.SetScale);
	}

	private void OnScaleAllCats(bool toggle)
	{
		if (_isMainCat)
		{
			if (!_init)
			{
				ScaleSetting.OnScaleApplied.AddListener(base.SetScale);
			}
		}
		else if (toggle)
		{
			ScaleSetting.OnScaleApplied.AddListener(base.SetScale);
		}
		else
		{
			ScaleSetting.OnScaleApplied.RemoveListener(base.SetScale);
		}
	}

	public void ToggleForward()
	{
		Index = (Index + 1) % ScaleSetting.GetAvailableScales().Count;
		if (SettingsManager.Instance.ScaleAllCats.Value)
		{
			ScaleSetting.SetUnappliedScaleIndex(Index);
			ScaleSetting.UpdateScale();
		}
		else
		{
			UpdateScale();
		}
	}

	public void ToggleBackward()
	{
		Index = (Index - 1) % ScaleSetting.GetAvailableScales().Count;
		if (SettingsManager.Instance.ScaleAllCats.Value)
		{
			ScaleSetting.SetUnappliedScaleIndex(Index);
			ScaleSetting.UpdateScale();
		}
		else
		{
			UpdateScale();
		}
	}

	protected override void UpdateScale()
	{
		if ((bool)targetTransform)
		{
			float realScaleFactor = ScaleSetting.GetRealScaleFactor();
			int num = 1;
			if ((double)targetTransform.localScale.x < 0.1)
			{
				num = -1;
			}
			targetTransform.localScale = new Vector3((float)num * realScaleFactor, realScaleFactor, realScaleFactor);
		}
		if ((bool)_text)
		{
			float scale = ScaleSetting.GetScale();
			_text.text = (useShortText ? $"{scale:0.00}x" : string.Format("{0} {1:G3}x", Localize.Get("Scale"), scale));
		}
	}
}
