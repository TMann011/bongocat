using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct LobbyData : IEquatable<CSteamID>, IEquatable<ulong>, IEquatable<LobbyData>
{
	public static LobbyData Current;

	private ulong _id;

	public const string DataName = "LOBBY_NAME";

	public const string LobbyCodeKey = "LOBBYCODE";

	public const string DataVersion = "z_heathenGameVersion";

	public const string DataReady = "z_heathenReady";

	public const string DataKick = "z_heathenKick";

	public const string DataMode = "z_heathenMode";

	public const string DataType = "PRIVATE_LOBBY";

	public const string DataSessionLobby = "z_heathenSessionLobby";

	public const string DataModeGeneral = "General";

	public const string DataModeSession = "Session";

	public const string DataModeParty = "Party";

	public bool MyChestReady
	{
		set
		{
			if (IsValid)
			{
				LobbyMemberData me = Me;
				me.ChestReady = value;
			}
		}
	}

	public bool MyEmoteChestReady
	{
		set
		{
			if (IsValid)
			{
				LobbyMemberData me = Me;
				me.EmoteChestReady = value;
			}
		}
	}

	public int MyHat
	{
		set
		{
			if (IsValid)
			{
				LobbyMemberData me = Me;
				me.Hat = value;
			}
		}
	}

	public int MySkin
	{
		set
		{
			if (IsValid)
			{
				LobbyMemberData me = Me;
				me.Skin = value;
			}
		}
	}

	public CSteamID SteamId => new CSteamID(_id);

	public AccountID_t AccountId => SteamId.GetAccountID();

	public uint FriendId => AccountId.m_AccountID;

	public string HexId => FriendId.ToString("X");

	public bool IsValid
	{
		get
		{
			CSteamID steamId = SteamId;
			if (steamId == CSteamID.Nil || steamId.GetEAccountType() != EAccountType.k_EAccountTypeChat || steamId.GetEUniverse() != EUniverse.k_EUniversePublic)
			{
				return false;
			}
			return true;
		}
	}

	public string Name
	{
		get
		{
			return this["LOBBY_NAME"];
		}
		set
		{
			this["LOBBY_NAME"] = value;
		}
	}

	public string LobbyCode
	{
		get
		{
			return GetMetadata().GetValueOrDefault("LOBBYCODE");
		}
		set
		{
			SetLobbyMetadata("LOBBYCODE", value);
		}
	}

	public LobbyMemberData Owner => new LobbyMemberData
	{
		lobby = this,
		user = Matchmaking.Client.GetLobbyOwner(_id)
	};

	public LobbyMemberData Me => new LobbyMemberData
	{
		lobby = this,
		user = User.Client.Id
	};

	public LobbyMemberData[] Members => Matchmaking.Client.GetLobbyMembers(_id);

	public ELobbyType Type
	{
		get
		{
			if (int.TryParse(Matchmaking.Client.GetLobbyData(_id, "PRIVATE_LOBBY"), out var result))
			{
				return (ELobbyType)result;
			}
			return ELobbyType.k_ELobbyTypePrivate;
		}
		set
		{
			Matchmaking.Client.SetLobbyType(_id, value);
		}
	}

	public bool IsOwner => SteamUser.GetSteamID() == SteamMatchmaking.GetLobbyOwner(this);

	public SteamLobbyModeType Mode
	{
		get
		{
			string text = this["z_heathenMode"];
			if (text == "Party")
			{
				return SteamLobbyModeType.Party;
			}
			if (text == "Session")
			{
				return SteamLobbyModeType.Session;
			}
			return SteamLobbyModeType.General;
		}
		set
		{
			switch (value)
			{
			case SteamLobbyModeType.Party:
				this["z_heathenMode"] = "Party";
				break;
			case SteamLobbyModeType.Session:
				this["z_heathenMode"] = "Session";
				break;
			default:
				this["z_heathenMode"] = "General";
				break;
			}
		}
	}

	public bool IsParty => Mode == SteamLobbyModeType.Party;

	public bool IsSession => Mode == SteamLobbyModeType.Session;

	public bool IsGeneral => Mode == SteamLobbyModeType.General;

	public bool HasServer
	{
		get
		{
			uint punGameServerIP;
			ushort punGameServerPort;
			CSteamID psteamIDGameServer;
			return SteamMatchmaking.GetLobbyGameServer(this, out punGameServerIP, out punGameServerPort, out psteamIDGameServer);
		}
	}

	public LobbyGameServer GameServer => Matchmaking.Client.GetLobbyGameServer(_id);

	public bool IsClosedLobby => !string.IsNullOrEmpty(this["LobbyClosed"]);

	public bool Full
	{
		get
		{
			if (IsValid)
			{
				return Matchmaking.Client.GetLobbyMemberLimit(_id) <= SteamMatchmaking.GetNumLobbyMembers(this);
			}
			return false;
		}
	}

	public int MaxMembers => Matchmaking.Client.GetLobbyMemberLimit(_id);

	public int MemberCount
	{
		get
		{
			if (!IsValid)
			{
				return 0;
			}
			return SteamMatchmaking.GetNumLobbyMembers(this);
		}
	}

	public string this[string metadataKey]
	{
		get
		{
			return Matchmaking.Client.GetLobbyData(_id, metadataKey);
		}
		set
		{
			Matchmaking.Client.SetLobbyData(_id, metadataKey, value);
		}
	}

	public bool IsAMember(UserData id)
	{
		return Matchmaking.Client.IsAMember(this, id);
	}

	public bool SetJoinable(bool makeJoinable)
	{
		return Matchmaking.Client.SetLobbyJoinable(_id, makeJoinable);
	}

	public Dictionary<string, string> GetMetadata()
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		int lobbyDataCount = SteamMatchmaking.GetLobbyDataCount(this);
		for (int i = 0; i < lobbyDataCount; i++)
		{
			SteamMatchmaking.GetLobbyDataByIndex(this, i, out var pchKey, 255, out var pchValue, 8192);
			dictionary.Add(pchKey, pchValue);
		}
		return dictionary;
	}

	public static void Create(ELobbyType type, SteamLobbyModeType mode, int slots, Action<EResult, LobbyData, bool> callback)
	{
		Matchmaking.Client.CreateLobby(type, mode, slots, callback);
	}

	public void Join(Action<LobbyEnter, bool> callback = null)
	{
		if (IsValid)
		{
			Matchmaking.Client.JoinLobby(this, callback);
		}
	}

	public void Leave()
	{
		if (IsValid)
		{
			Matchmaking.Client.LeaveLobby(this);
		}
	}

	public bool InviteUserToLobby(UserData targetUser)
	{
		if (KickListContains(targetUser))
		{
			if (!IsOwner)
			{
				return false;
			}
			RemoveFromKickList(targetUser);
		}
		return Matchmaking.Client.InviteUserToLobby(_id, targetUser);
	}

	public bool SendChatMessage(string message)
	{
		if (string.IsNullOrEmpty(message))
		{
			return false;
		}
		byte[] bytes = Encoding.UTF8.GetBytes(message);
		return SteamMatchmaking.SendLobbyChatMsg(this, bytes, bytes.Length);
	}

	public bool SendChatMessage(byte[] data)
	{
		if (data == null || data.Length < 1)
		{
			return false;
		}
		return SteamMatchmaking.SendLobbyChatMsg(this, data, data.Length);
	}

	public bool SendChatMessage(object jsonObject)
	{
		return SendChatMessage(Encoding.UTF8.GetBytes(JsonUtility.ToJson(jsonObject)));
	}

	public void SetGameServer(string address, ushort port, CSteamID gameServerId)
	{
		Matchmaking.Client.SetLobbyGameServer(_id, address, port, gameServerId);
	}

	public void SetGameServer(string address, ushort port)
	{
		Matchmaking.Client.SetLobbyGameServer(_id, address, port, CSteamID.Nil);
	}

	public void SetGameServer(CSteamID gameServerId)
	{
		Matchmaking.Client.SetLobbyGameServer(_id, 0u, 0, gameServerId);
	}

	public void SetGameServer()
	{
		Matchmaking.Client.SetLobbyGameServer(_id, 0u, 0, User.Client.Id);
	}

	public bool KickMember(UserData memberId)
	{
		if (!IsOwner)
		{
			return false;
		}
		string text = Matchmaking.Client.GetLobbyData(_id, "z_heathenKick") ?? string.Empty;
		if (!text.Contains("[" + memberId.ToString() + "]"))
		{
			text = text + "[" + memberId.ToString() + "]";
		}
		return Matchmaking.Client.SetLobbyData(_id, "z_heathenKick", text);
	}

	public bool KickListContains(UserData memberId)
	{
		return Matchmaking.Client.GetLobbyData(_id, "z_heathenKick").Contains("[" + memberId.ToString() + "]");
	}

	public bool RemoveFromKickList(UserData memberId)
	{
		if (!IsOwner)
		{
			return false;
		}
		string lobbyData = Matchmaking.Client.GetLobbyData(_id, "z_heathenKick");
		lobbyData = lobbyData.Replace("[" + memberId.ToString() + "]", string.Empty);
		return Matchmaking.Client.SetLobbyData(_id, "z_heathenKick", lobbyData);
	}

	public void SetLobbyMetadata(string key, string value)
	{
		Matchmaking.Client.SetLobbyData(_id, key, value);
	}

	public bool RequestData()
	{
		return Matchmaking.Client.RequestLobbyData(_id);
	}

	public static LobbyData Get(string accountId)
	{
		try
		{
			uint num = Convert.ToUInt32(accountId, 16);
			if (num != 0)
			{
				return Get(num);
			}
			return CSteamID.Nil;
		}
		catch (Exception ex)
		{
			Debug.LogWarning("Failed to parse account Id: " + ex.Message);
			return CSteamID.Nil;
		}
	}

	public static LobbyData Get(uint accountId)
	{
		return new CSteamID(new AccountID_t(accountId), 393216u, EUniverse.k_EUniversePublic, EAccountType.k_EAccountTypeChat);
	}

	public static bool PartyLobby(out LobbyData lobby)
	{
		lobby = Matchmaking.Client.MemberOfLobbies.FirstOrDefault((LobbyData p) => p.IsParty);
		return lobby.IsValid;
	}

	public static bool SessionLobby(out LobbyData lobby)
	{
		lobby = Matchmaking.Client.MemberOfLobbies.FirstOrDefault((LobbyData p) => p.IsSession);
		return lobby.IsValid;
	}

	public static void Join(LobbyData lobby, Action<LobbyEnter, bool> callback = null)
	{
		Matchmaking.Client.JoinLobby(lobby, callback);
	}

	public override string ToString()
	{
		return HexId;
	}

	public bool Equals(CSteamID other)
	{
		return _id.Equals(other.m_SteamID);
	}

	public bool Equals(ulong other)
	{
		return _id.Equals(other);
	}

	public override bool Equals(object obj)
	{
		return _id.Equals(obj);
	}

	public override int GetHashCode()
	{
		return _id.GetHashCode();
	}

	public bool Equals(LobbyData other)
	{
		return _id.Equals(other._id);
	}

	public static bool operator ==(LobbyData l, LobbyData r)
	{
		return l._id == r._id;
	}

	public static bool operator !=(LobbyData l, LobbyData r)
	{
		return l._id != r._id;
	}

	public static bool operator !=(LobbyData l, ulong r)
	{
		return l._id != r;
	}

	public static implicit operator CSteamID(LobbyData c)
	{
		return c.SteamId;
	}

	public static implicit operator LobbyData(CSteamID id)
	{
		return new LobbyData
		{
			_id = id.m_SteamID
		};
	}

	public static implicit operator LobbyData(ulong id)
	{
		return new LobbyData
		{
			_id = id
		};
	}

	public static implicit operator LobbyData(uint id)
	{
		return Get(id);
	}

	public static implicit operator LobbyData(string id)
	{
		return Get(id);
	}
}
