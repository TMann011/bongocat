using Heathen.SteamworksIntegration.UI;
using Steamworks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamUserData))]
public class SteamUserDataEvents : MonoBehaviour, IPointerClickHandler, IEventSystemHandler
{
	public UnityEvent<UserData, EPersonaChange> onChange;

	public UnityUserAndPointerDataEvent onClick;

	private SteamUserData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamUserData>();
		_mInspector.onChanged?.AddListener(onChange.Invoke);
	}

	private void OnDestroy()
	{
		if (_mInspector != null)
		{
			_mInspector.onChanged?.RemoveListener(onChange.Invoke);
		}
	}

	public void OnPointerClick(PointerEventData eventData)
	{
		onClick.Invoke(new UserAndPointerData(_mInspector.Data, eventData));
	}
}
