using UnityEngine;
using UnityEngine.UI;

public class ItemScaler : MonoBehaviour
{
	[SerializeField]
	private float _maxWidth = 214f;

	[SerializeField]
	private int _parentsToRebuild = 1;

	private GridLayoutGroup _grid;

	private ItemScaleSetting _scaleSetting;

	private void Awake()
	{
		_grid = GetComponent<GridLayoutGroup>();
	}

	private void Start()
	{
		_scaleSetting = ItemScaleSetting.Instance;
		_scaleSetting.AddScaler(this, _parentsToRebuild);
		ChangeCellCount();
	}

	public void ChangeCellCount()
	{
		int count = _scaleSetting.Count;
		float num = (_maxWidth - (float)(count - 1) * _grid.spacing.x) / (float)count;
		_grid.cellSize = new Vector2(num, num);
		_grid.constraintCount = count;
	}
}
