using System;
using System.Collections;
using BongoCat;
using DG.Tweening;
using Steam;
using TMPro;
using UnityEngine;
using Vfx;

namespace Tutorial;

public class FakeShop : MonoBehaviour
{
	[SerializeField]
	private GrantPromoItem _grantPromoItem;

	[SerializeField]
	private TutorialStep _waitingForChest;

	[SerializeField]
	private TutorialStep _chestReadyStep;

	[SerializeField]
	private TutorialStep[] _grantSuccessfulSteps;

	[SerializeField]
	private TutorialStep[] _grantUnsuccessfulSteps;

	[SerializeField]
	private int _price = 25;

	[SerializeField]
	private GameObject _shopVisuals;

	[SerializeField]
	private GameObject _shopItem;

	[SerializeField]
	private GameObject _timer;

	[SerializeField]
	private GameObject _loading;

	[SerializeField]
	private GameObject _success;

	[SerializeField]
	private GameObject _failed;

	[SerializeField]
	private TMP_Text _stockRefreshText;

	[SerializeField]
	private TMP_Text _priceText;

	[SerializeField]
	private PricePaid _pricePaid;

	[SerializeField]
	private FlashAnimation _counterFlash;

	[SerializeField]
	private ShakeAnimation _shakeAnimation;

	private bool _chestReady;

	private bool CanAfford => Pets.Instance.CanSpendPets(_price);

	public void InitFakeShop()
	{
		_chestReady = false;
		_priceText.text = _price.ToString();
		_shopItem.SetActive(value: false);
		_loading.SetActive(value: false);
		_success.SetActive(value: false);
		_timer.SetActive(value: true);
		StartCoroutine(StockCountdown());
	}

	private IEnumerator StockCountdown()
	{
		for (int left = 3; left > 0; left--)
		{
			_stockRefreshText.text = $"{TimeSpan.FromSeconds(left):mm':'ss}";
			yield return new WaitForSecondsRealtime(1f);
		}
		_chestReady = true;
		_timer.SetActive(value: false);
		_shopItem.SetActive(value: true);
		_waitingForChest.Complete();
		_shopVisuals.SetActive(value: true);
	}

	public void OnClick()
	{
		if (!_chestReady)
		{
			_shakeAnimation.Shake();
		}
		else if (!CanAfford)
		{
			_shakeAnimation.Shake();
			_counterFlash.Flash();
		}
		else
		{
			StartCoroutine(Buy());
		}
	}

	private IEnumerator Buy()
	{
		_chestReady = false;
		_shopItem.SetActive(value: false);
		_loading.SetActive(value: true);
		SteamItemRuntime tutorialItem = null;
		bool answered = false;
		PromoItemChecker instance = PromoItemChecker.Instance;
		instance.OnItemUpdated = (Action<SteamItemRuntime>)Delegate.Combine(instance.OnItemUpdated, new Action<SteamItemRuntime>(OnUpdate));
		_grantPromoItem.Grant();
		int timeout = 5;
		for (int i = 0; i < timeout; i++)
		{
			if (answered)
			{
				break;
			}
			yield return new WaitForSeconds(1f);
		}
		PromoItemChecker instance2 = PromoItemChecker.Instance;
		instance2.OnItemUpdated = (Action<SteamItemRuntime>)Delegate.Remove(instance2.OnItemUpdated, new Action<SteamItemRuntime>(OnUpdate));
		bool flag = tutorialItem == null;
		_loading.SetActive(value: false);
		TutorialStep[] grantSuccessfulSteps = _grantSuccessfulSteps;
		for (int j = 0; j < grantSuccessfulSteps.Length; j++)
		{
			grantSuccessfulSteps[j].SetSkippable(flag);
		}
		grantSuccessfulSteps = _grantUnsuccessfulSteps;
		for (int j = 0; j < grantSuccessfulSteps.Length; j++)
		{
			grantSuccessfulSteps[j].SetSkippable(!flag);
		}
		if (!flag)
		{
			_success.SetActive(value: true);
			Pets.Instance.TrySpendPets(_price);
			_pricePaid.Animate();
		}
		else
		{
			_failed.SetActive(value: true);
		}
		_shopVisuals.transform.DOPunchScale(Vector3.one * 0.15f, 0.5f).OnComplete(delegate
		{
			_shopVisuals.SetActive(value: false);
		});
		_chestReadyStep.Complete();
		yield return new WaitForSeconds(1f);
		_shopVisuals.SetActive(value: false);
		void OnUpdate(SteamItemRuntime item)
		{
			tutorialItem = item;
			answered = true;
		}
	}

	public void ToggleVisibility()
	{
		_shopVisuals.SetActive(!_shopVisuals.activeSelf || _chestReady);
	}
}
