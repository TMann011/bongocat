using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.UI;

public class BongoDexCollection : MonoBehaviour
{
	[SerializeField]
	private DropdownToggle _toggle;

	public ItemCollectionHeader CollectionHeader;

	public ItemCollectionHeader CollapsedCollectionHeader;

	public ItemCollection ItemCollection;

	private CollectionNames.CollectionName _collectionName;

	private string _filter = string.Empty;

	public void Init(List<SteamItemRuntime> collection, CollectionNames.CollectionName collectionName)
	{
		_collectionName = collectionName;
		ItemCollection.CreateCollection(_collectionName.DisplayName, collection, isPartOfBongoDex: true);
		CollectionHeader.Init(ItemCollection, _collectionName);
		CollapsedCollectionHeader.Init(ItemCollection, _collectionName);
		Reset();
	}

	public void CollapseCollectionHeader(bool collapse)
	{
		CollectionHeader.Enable(!collapse);
		CollapsedCollectionHeader.Enable(collapse);
	}

	public void OpenCollection(bool show)
	{
		_toggle.SetToggle(show);
		LayoutRebuilder.ForceRebuildLayoutImmediate(base.transform as RectTransform);
	}

	public void Filter(string filter)
	{
		_filter = filter;
		Refresh();
	}

	public void Refresh()
	{
		bool flag = _filter.Length > 0;
		CollapseCollectionHeader(flag);
		ItemCollection.Filter(base.gameObject.name.ToLower().Contains(_filter) ? string.Empty : _filter);
		OpenCollection(flag);
		base.gameObject.SetActive((_collectionName.AlwaysVisible || ItemCollection.OwnedItems > 0) && ItemCollection.ContainsActiveItems);
	}

	public void ToggleHideCollectionInInventory()
	{
		bool containsVisibleItems = ItemCollection.ContainsVisibleItems;
		foreach (InventoryItem collectionItem in ItemCollection.CollectionItems)
		{
			if (collectionItem.SteamItem.IsOwned)
			{
				if (containsVisibleItems)
				{
					collectionItem.HideInInventory();
				}
				else
				{
					collectionItem.ShowInInventory();
				}
			}
		}
		CollectionHeader.ShowHiddenIndicator(containsVisibleItems);
		CollapsedCollectionHeader.ShowHiddenIndicator(containsVisibleItems);
	}

	public void Reset()
	{
		Filter(string.Empty);
	}
}
