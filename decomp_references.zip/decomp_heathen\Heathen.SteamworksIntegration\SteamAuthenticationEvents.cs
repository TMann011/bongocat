using Steamworks;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamAuthenticationData))]
public class SteamAuthenticationEvents : MonoBehaviour
{
	public UnityEvent<AuthenticationTicket> onChange;

	public UnityEvent<ulong, byte[]> onRpcInvoke;

	public UnityEvent<EResult> onError;

	public UnityEvent<EBeginAuthSessionResult> onInvalidTicket;

	public UnityEvent<EAuthSessionResponse> onInvalidSession;

	public UnityEvent<EAuthSessionResponse> onSessionStart;
}
