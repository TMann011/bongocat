using System;
using Heathen.SteamworksIntegration.API;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct LobbyMemberData : IEquatable<LobbyMemberData>
{
	public LobbyData lobby;

	public UserData user;

	public bool ChestReady
	{
		set
		{
			this["chest_ready"] = value.ToString().ToLower();
		}
	}

	public bool EmoteChestReady
	{
		set
		{
			this["emote_chest_ready"] = value.ToString().ToLower();
		}
	}

	public int Hat
	{
		get
		{
			if (!int.TryParse(this["hat"], out var result))
			{
				return -1;
			}
			return result;
		}
		set
		{
			this["hat"] = value.ToString();
		}
	}

	public int Skin
	{
		get
		{
			if (!int.TryParse(this["skin"], out var result))
			{
				return -1;
			}
			return result;
		}
		set
		{
			this["skin"] = value.ToString();
		}
	}

	public string this[string metadataKey]
	{
		get
		{
			return Matchmaking.Client.GetLobbyMemberData(lobby, user, metadataKey);
		}
		set
		{
			if (user == User.Client.Id)
			{
				Matchmaking.Client.SetLobbyMemberData(lobby, metadataKey, value);
			}
		}
	}

	public bool IsReady => this["z_heathenReady"] == "true";

	public bool IsOwner => lobby.Owner.Equals(this);

	public bool Equals(LobbyMemberData other)
	{
		if (other.lobby == lobby)
		{
			return other.user == user;
		}
		return false;
	}

	public override bool Equals(object obj)
	{
		if (obj.GetType() != typeof(LobbyMemberData))
		{
			return false;
		}
		return Equals((LobbyMemberData)obj);
	}

	public override int GetHashCode()
	{
		return HashCode.Combine(lobby, user);
	}

	public static LobbyMemberData Get(LobbyData lobby, UserData user)
	{
		return new LobbyMemberData
		{
			lobby = lobby,
			user = user
		};
	}

	public static bool operator ==(LobbyMemberData l, LobbyMemberData r)
	{
		if (l.lobby == r.lobby)
		{
			return l.user == r.user;
		}
		return false;
	}

	public static bool operator !=(LobbyMemberData l, LobbyMemberData r)
	{
		if (!(l.lobby != r.lobby))
		{
			return l.user != r.user;
		}
		return true;
	}
}
