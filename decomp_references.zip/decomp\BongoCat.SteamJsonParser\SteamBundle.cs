using System.Collections.Generic;
using UnityEngine;

namespace BongoCat.SteamJsonParser;

public class SteamBundle : SteamItemBase
{
	[SerializeField]
	private string Promo;

	[SerializeField]
	private List<SteamItemBase> _itemsInBundle;

	public override SteamItemJson ToSteamItemBackend()
	{
		string text = "";
		foreach (SteamItemBase item in _itemsInBundle)
		{
			text = text + item.Id + ";";
		}
		text = text.TrimEnd(';');
		return new SteamItemJson(this)
		{
			type = "bundle",
			bundle = text,
			promo = Promo
		};
	}
}
