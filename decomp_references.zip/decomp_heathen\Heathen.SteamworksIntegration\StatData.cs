using System;
using Heathen.SteamworksIntegration.API;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct StatData : IEquatable<StatData>, IEquatable<string>, IComparable<StatData>, IComparable<string>
{
	[SerializeField]
	private string id;

	public int IntValue()
	{
		StatsAndAchievements.Client.GetStat(id, out var data);
		return data;
	}

	public void Set(float value)
	{
		StatsAndAchievements.Client.SetStat(id, value);
	}

	public void Set(int value)
	{
		StatsAndAchievements.Client.SetStat(id, value);
	}

	public void Store()
	{
		StatsAndAchievements.Client.StoreStats();
	}

	public override string ToString()
	{
		if (!string.IsNullOrEmpty(id))
		{
			return id;
		}
		return string.Empty;
	}

	public bool Equals(string other)
	{
		return id.Equals(other);
	}

	public bool Equals(StatData other)
	{
		return id.Equals(other.id);
	}

	public override bool Equals(object obj)
	{
		return id.Equals(obj);
	}

	public override int GetHashCode()
	{
		return id.GetHashCode();
	}

	public int CompareTo(StatData other)
	{
		return string.Compare(id, other.id, StringComparison.Ordinal);
	}

	public int CompareTo(string other)
	{
		return string.Compare(id, other, StringComparison.Ordinal);
	}

	public static implicit operator StatData(string id)
	{
		return new StatData
		{
			id = id
		};
	}
}
