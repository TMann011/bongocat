using Helper;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Supporter;

public class SupporterDlc : MonoBehaviour
{
	[SerializeField]
	private string _dlcName;

	[SerializeField]
	private uint _dlcId;

	[SerializeField]
	private Image _image;

	[SerializeField]
	private GameObject _boughtPanel;

	[SerializeField]
	private TMP_Text _text;

	private void Start()
	{
		if (SteamApps.BIsDlcInstalled(new AppId_t(_dlcId)))
		{
			_boughtPanel.SetActive(value: true);
		}
		_text.SetText(_dlcName);
	}

	private void OnValidate()
	{
		string text = "SupporterDlc_" + _dlcName.Replace(" ", "");
		if (base.gameObject.name != text)
		{
			base.gameObject.name = text;
			_text.SetText(_dlcName);
			EditorUtilityCompileSafe.SetDirty(base.gameObject);
		}
	}

	public void OnBuyButtonClicked()
	{
		Application.OpenURL($"steam://openurl/https://store.steampowered.com/app/{_dlcId}/");
	}
}
