using Newtonsoft.Json;
using UnityEngine;

namespace Helper;

public static class PlayerPrefsHelp
{
	public static void SetObject(string key, object o)
	{
		string value = JsonConvert.SerializeObject(o);
		PlayerPrefs.SetString(key, value);
		PlayerPrefs.Save();
	}

	public static bool TryGetObject<T>(string key, out T o)
	{
		if (PlayerPrefs.HasKey(key))
		{
			string value = PlayerPrefs.GetString(key);
			o = JsonConvert.DeserializeObject<T>(value);
			return true;
		}
		o = default(T);
		return false;
	}

	public static void SetBool(string key, bool value)
	{
		if (value)
		{
			PlayerPrefs.SetInt(key, 1);
		}
		else
		{
			PlayerPrefs.DeleteKey(key);
		}
		PlayerPrefs.Save();
	}
}
