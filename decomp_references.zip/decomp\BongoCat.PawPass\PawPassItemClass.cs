using System.Collections;
using UnityEngine;

namespace BongoCat.PawPass;

public abstract class PawPassItemClass : MonoBehaviour
{
	[SerializeField]
	private CatBobbing _catBobbing;

	private Coroutine _bobRoutine;

	public virtual void ToggleBobbing(bool toggle)
	{
		if (_bobRoutine != null)
		{
			StopCoroutine(_bobRoutine);
			_bobRoutine = null;
		}
		if (toggle)
		{
			if (base.gameObject.activeInHierarchy)
			{
				_bobRoutine = StartCoroutine(BobbingCoroutine(Random.Range(0.4f, 0.8f)));
			}
		}
		else
		{
			_catBobbing.ToggleBobbingAnimation(toggle: false);
		}
	}

	private void OnDisable()
	{
		if (_bobRoutine != null)
		{
			StopCoroutine(_bobRoutine);
			_bobRoutine = null;
		}
		_catBobbing.KillBobbing();
	}

	private IEnumerator BobbingCoroutine(float delay)
	{
		yield return new WaitForSeconds(delay);
		_catBobbing.ToggleBobbingAnimation(toggle: true);
		_bobRoutine = null;
	}

	public abstract void FillContent(PawPassMilestone pawPassMilestone);

	public abstract void FillContent(PawPassMilestoneItem pawPassMilestoneItem);
}
