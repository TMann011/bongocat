using UnityEngine;

public static class ScreenHelper
{
	public static int FullWidth
	{
		get
		{
			if (!Application.isEditor)
			{
				if (Screen.mainWindowDisplayInfo.width == 0)
				{
					return 1920;
				}
				return Screen.mainWindowDisplayInfo.width;
			}
			return Screen.width;
		}
	}

	public static int FullHeight
	{
		get
		{
			if (!Application.isEditor)
			{
				if (Screen.mainWindowDisplayInfo.height == 0)
				{
					return 1080;
				}
				return Screen.mainWindowDisplayInfo.height;
			}
			return Screen.height;
		}
	}

	public static int XMin
	{
		get
		{
			if (!Application.isEditor)
			{
				return Screen.mainWindowDisplayInfo.workArea.xMin;
			}
			return 0;
		}
	}

	public static int XMax
	{
		get
		{
			if (!Application.isEditor)
			{
				return Screen.mainWindowDisplayInfo.workArea.xMax;
			}
			return FullWidth;
		}
	}

	public static int YMin
	{
		get
		{
			if (!Application.isEditor)
			{
				return FullHeight - Screen.mainWindowDisplayInfo.workArea.yMax;
			}
			return 0;
		}
	}

	public static int YMax
	{
		get
		{
			if (!Application.isEditor)
			{
				return FullHeight - Screen.mainWindowDisplayInfo.workArea.yMin;
			}
			return FullHeight;
		}
	}
}
