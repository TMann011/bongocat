using System;
using System.Collections.Generic;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamLobbyGameObjectEnabler : MonoBehaviour
{
	public enum EnableWhenRule
	{
		IsSet,
		IsNotSet,
		AmITheOwner,
		AmINotTheOwner,
		AmIMember,
		AmINotMember,
		IsParty,
		IsSession,
		IsNotParty,
		IsNotSession,
		IsNotFull,
		IsFull
	}

	public enum ConditionMode
	{
		Or = 1,
		And
	}

	[Serializable]
	public struct Condition
	{
		[FormerlySerializedAs("Note")]
		public string note;

		[Tooltip("The rules that will be evaluated together.")]
		public EnableWhenRule[] rules;

		[Tooltip("How the rules are combined.")]
		public ConditionMode mode;
	}

	public SteamLobbyData targetLobby;

	[Tooltip("The conditions that must all be true for this GameObject to be enabled.")]
	public List<Condition> conditions = new List<Condition>();

	private void Awake()
	{
		if (targetLobby != null)
		{
			targetLobby.onChanged?.AddListener(HandleOnChanged);
			HandleOnChanged(targetLobby.Data);
		}
		else
		{
			HandleOnChanged(CSteamID.Nil);
		}
	}

	private void OnDestroy()
	{
		if (targetLobby != null)
		{
			targetLobby.onChanged?.RemoveListener(HandleOnChanged);
		}
	}

	private void HandleOnChanged(LobbyData arg0)
	{
		bool active = true;
		foreach (Condition condition in conditions)
		{
			if (!EvaluateCondition(condition))
			{
				active = false;
				break;
			}
		}
		base.gameObject.SetActive(active);
	}

	private bool EvaluateCondition(Condition condition)
	{
		if (condition.rules == null || condition.rules.Length == 0)
		{
			return true;
		}
		bool flag = condition.mode == ConditionMode.And;
		EnableWhenRule[] rules = condition.rules;
		foreach (EnableWhenRule rule in rules)
		{
			bool flag2 = CheckRule(rule);
			flag = ((condition.mode != ConditionMode.Or) ? (flag & flag2) : (flag | flag2));
		}
		return flag;
	}

	private bool CheckRule(EnableWhenRule rule)
	{
		return rule switch
		{
			EnableWhenRule.IsSet => targetLobby != null && targetLobby.Data.IsValid, 
			EnableWhenRule.IsNotSet => targetLobby == null || !targetLobby.Data.IsValid, 
			EnableWhenRule.AmITheOwner => targetLobby != null && targetLobby.Data.IsOwner, 
			EnableWhenRule.AmINotTheOwner => targetLobby == null || !targetLobby.Data.IsOwner, 
			EnableWhenRule.AmIMember => targetLobby != null && targetLobby.Data.IsAMember(UserData.Me), 
			EnableWhenRule.AmINotMember => targetLobby == null || !targetLobby.Data.IsAMember(UserData.Me), 
			EnableWhenRule.IsParty => targetLobby != null && targetLobby.Data.IsParty, 
			EnableWhenRule.IsSession => targetLobby != null && targetLobby.Data.IsSession, 
			EnableWhenRule.IsNotParty => targetLobby == null || !targetLobby.Data.IsParty, 
			EnableWhenRule.IsNotSession => targetLobby == null || !targetLobby.Data.IsSession, 
			EnableWhenRule.IsNotFull => targetLobby == null || !targetLobby.Data.Full, 
			EnableWhenRule.IsFull => targetLobby != null && targetLobby.Data.IsValid && targetLobby.Data.Full, 
			_ => false, 
		};
	}
}
