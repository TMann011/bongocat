using BongoCat.SteamJsonParser;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat;

[RequireComponent(typeof(Button))]
public class QualityFilterButton : MonoBehaviour
{
	public QualityCategory Quality;

	[SerializeField]
	private Image _circle;

	[SerializeField]
	private GameObject _selectedIndicator;

	private Color _baseColor;

	private Color _selectedColor;

	private void Awake()
	{
		_selectedColor = Quality.GetColor();
		_baseColor = new Color(_selectedColor.r, _selectedColor.g, _selectedColor.b, 0.5f);
		_circle.color = _selectedColor;
	}

	public void SetSelected(bool selected)
	{
		_selectedIndicator.SetActive(selected);
		_circle.color = (selected ? _selectedColor : _baseColor);
	}

	public void ToggleQuality()
	{
		InventoryQualityFilter.Instance.ToggleQuality(Quality);
	}

	public void ToggleQualityExclusive()
	{
		InventoryQualityFilter.Instance.ToggleQualityExclusive(Quality);
	}
}
