using Heathen.SteamworksIntegration.API;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLeaderboardData))]
public class SteamLeaderboardDataEvents : MonoBehaviour
{
	public UnityEvent onChange;

	public UnityEvent onFindOrCreate;

	public UnityEvent onFindOrCreateFailure;

	public UnityEvent<LeaderboardScoreUploaded> onScoreUploaded;

	public UnityEvent<LeaderboardScoreUploaded> onRankChanged;

	[FormerlySerializedAs("onUGCAttached")]
	public UnityEvent<LeaderboardUgcSet> onUgcAttached;

	private SteamLeaderboardData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLeaderboardData>();
		Leaderboards.Client.OnScoreUploaded.AddListener(HandleScoreUpload);
		Leaderboards.Client.OnUgcAttached.AddListener(HandleUgcAttached);
	}

	private void OnDestroy()
	{
		Leaderboards.Client.OnScoreUploaded.RemoveListener(HandleScoreUpload);
		Leaderboards.Client.OnUgcAttached.RemoveListener(HandleUgcAttached);
	}

	private void HandleUgcAttached(LeaderboardUgcSet arg0, bool arg1)
	{
		if (!arg1 && arg0.Leaderboard == _mInspector.Data)
		{
			onUgcAttached.Invoke(arg0);
		}
	}

	private void HandleScoreUpload(LeaderboardScoreUploaded arg0, bool arg1)
	{
		if (!arg1 && arg0.Leaderboard == _mInspector.Data)
		{
			onScoreUploaded.Invoke(arg0);
			if (arg0.GlobalRankNew != arg0.GlobalRankPrevious)
			{
				onRankChanged?.Invoke(arg0);
			}
		}
	}
}
