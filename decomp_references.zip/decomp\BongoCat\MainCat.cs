using System;
using System.Collections;
using BongoCat.Multiplayer;
using BongoCat.Multiplayer.Spawning;
using BongoCat.OSSpecific;
using Helper;
using SteamTools;
using UnityEngine;

namespace BongoCat;

public class MainCat : MonoBehaviour, ISlotOccupant
{
	public static MainCat Instance;

	[SerializeField]
	private Draggable _draggable;

	[SerializeField]
	private PlayerPrefsToggle _lockPosition;

	[SerializeField]
	private CatRotator _catRotator;

	[SerializeField]
	private FlipVisuals _catFlipVisuals;

	[SerializeField]
	private ToggleGameObject _menu;

	private Pets _pets;

	private const string MENU_POS_X_REL = "BongoMenuPosXRel";

	private const string MENU_POS_Y_REL = "BongoMenuPosYRel";

	public CatRotator Rotator => _catRotator;

	public FlipVisuals FlipVisuals => _catFlipVisuals;

	public CatPatter Patter => Cat.Instance.catPatter;

	public Vector2 Pos => (Vector2)_draggable.transform.position + SlotSwing;

	private Vector2 SlotSwing
	{
		get
		{
			Vector2 vector = (Vector2)_catRotator.CatTransform.position - (Vector2)_draggable.transform.position;
			return vector - (Vector2)(Quaternion.Euler(0f, 0f, (float)_catRotator.RotationState * 90f) * vector);
		}
	}

	private void Awake()
	{
		Instance = this;
		_draggable.SlotOwner = this;
	}

	private IEnumerator Start()
	{
		_pets = Pets.Instance;
		BongoCat.OSSpecific.GlobalKeyHook instance = BongoCat.OSSpecific.GlobalKeyHook.Instance;
		instance.OnKeyPressed = (Action<int>)Delegate.Combine(instance.OnKeyPressed, new Action<int>(Cat.Instance.Tap));
		Cat.Instance.OnTap.AddListener(HandleTap);
		yield return null;
		if (PlayerPrefs.HasKey("BongoMenuPosXRel") && PlayerPrefs.HasKey("BongoMenuPosYRel"))
		{
			float value = PlayerPrefs.GetFloat("BongoMenuPosXRel");
			value = Mathf.Clamp(value, 0f, 1f);
			float value2 = PlayerPrefs.GetFloat("BongoMenuPosYRel");
			value2 = Mathf.Clamp(value2, 0f, 1f);
			_draggable.transform.position = new Vector3(value * (float)ScreenHelper.FullWidth, value2 * (float)ScreenHelper.FullHeight);
		}
		else
		{
			ResetPosition();
		}
		_draggable.FetchRelativePos();
		CheckBoundaries();
		SavePosition();
		_draggable.OnDragFinished.AddListener(OnMoved);
	}

	public void SetPos(Vector2 pos)
	{
		_draggable.transform.position = pos - SlotSwing;
		_draggable.FetchRelativePos();
		RecordPosition();
	}

	private void OnMoved()
	{
		SavePosition();
		CatSpawnManager.Instance.UpdateOccupancy(this);
	}

	private void CheckBoundaries()
	{
		_draggable.OutOfBoundsFix();
	}

	private IEnumerator CheckCatIsOnScreenRoutine()
	{
		WaitForSeconds waitFor30Seconds = new WaitForSeconds(30f);
		while (true)
		{
			yield return waitFor30Seconds;
		}
	}

	private void HandleTap(int amount)
	{
		_pets.AddPet(amount);
	}

	private void SavePosition()
	{
		RecordPosition();
		PlayerPrefs.Save();
	}

	private void RecordPosition()
	{
		PlayerPrefs.SetFloat("BongoMenuPosXRel", _draggable.transform.position.x / (float)ScreenHelper.FullWidth);
		PlayerPrefs.SetFloat("BongoMenuPosYRel", _draggable.transform.position.y / (float)ScreenHelper.FullHeight);
	}

	private void OnDestroy()
	{
		_draggable.OnDragFinished.RemoveListener(OnMoved);
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.F1))
		{
			Reset();
		}
		else if (MenuTogglePressed())
		{
			_menu.Toggle();
		}
	}

	public void Reset()
	{
		ResetPosition();
		SettingsManager.Instance.CatScaleSetting.ResetScale();
		SettingsManager.Instance.UIScaleSetting.ResetScale();
		_catRotator.ResetRotation();
		_catFlipVisuals.ResetFlip();
	}

	private bool MenuTogglePressed()
	{
		if (Cat.Instance.hoverCallback.Hovering && Input.GetMouseButtonDown(2))
		{
			return true;
		}
		if (!Input.GetKeyDown(KeyCode.M) && !Input.GetKeyDown(KeyCode.Escape))
		{
			return false;
		}
		return !InputFieldCache.FocusingInputField;
	}

	private void ResetPosition()
	{
		PlayerPrefs.DeleteKey("BongoMenuPosXRel");
		PlayerPrefs.DeleteKey("BongoMenuPosYRel");
		_lockPosition.Value = false;
		_draggable.transform.position = new Vector2((float)ScreenHelper.FullWidth / 2f, (float)ScreenHelper.FullHeight / 2f);
		_draggable.FetchRelativePos();
		Debug.Log("Resetting position to center of screen: " + _draggable.transform.position.ToString());
	}

	public void OnApplicationQuit()
	{
		if (Interface.IsReady)
		{
			SavePosition();
		}
	}
}
