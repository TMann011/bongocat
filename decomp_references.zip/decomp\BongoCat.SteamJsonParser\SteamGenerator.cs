using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BongoCat.SteamJsonParser;

public class SteamGenerator : SteamItemBase
{
	public enum GeneratorType
	{
		Generator,
		PlaytimeGenerator
	}

	[Serializable]
	public struct BundleEntry
	{
		public SteamItemBase Item;

		public int BundleFrequency;
	}

	[SerializeField]
	private GeneratorType _generatorType;

	[SerializeField]
	private List<BundleEntry> _bundleEntries = new List<BundleEntry>();

	[SerializeField]
	private string _tagWithValue;

	public bool AutofillOnGenerate;

	public QualityCategory Quality
	{
		get
		{
			if (!Enum.TryParse<QualityCategory>(_tagWithValue.Split(':').Last(), ignoreCase: true, out var result))
			{
				return QualityCategory.Common;
			}
			return result;
		}
	}

	public override SteamItemJson ToSteamItemBackend()
	{
		return new SteamItemJson(this)
		{
			type = ((_generatorType == GeneratorType.Generator) ? "generator" : "playtimegenerator"),
			bundle = string.Join(';', _bundleEntries.Select((BundleEntry item) => (item.BundleFrequency <= 1) ? item.Item.Id.ToString() : (item.Item.Id + "x" + item.BundleFrequency)).ToArray())
		};
	}
}
