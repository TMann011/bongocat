using BongoCat.Localizer;
using BongoCat.SteamJsonParser;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Settings;

namespace BongoCat;

public class WishlistTextSetter : MonoBehaviour
{
	[SerializeField]
	private string _gameName;

	[SerializeField]
	private SteamItemBase _steamItemReward;

	[SerializeField]
	private TMP_Text _wishlistText;

	private void Start()
	{
		LocalizationSettings.SelectedLocaleChanged += delegate
		{
			OnLocaUpdate();
		};
		OnLocaUpdate();
	}

	private void OnLocaUpdate()
	{
		_wishlistText.text = Localize.Get("WishlistFollowGeneric", _steamItemReward.Name, _gameName);
	}
}
