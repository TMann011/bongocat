using System.Collections.Generic;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamWorkshopItemDetailData : MonoBehaviour
{
	private WorkshopItemDetails _mData;

	private SteamWorkshopItemDetailDataEvents _mEvents;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> mDelegates = new List<string>();

	public WorkshopItemDetails Data
	{
		get
		{
			return _mData;
		}
		set
		{
			_mData = value;
			if (_mEvents != null)
			{
				_mEvents.onChange?.Invoke();
			}
		}
	}

	private void Awake()
	{
		_mEvents = GetComponent<SteamWorkshopItemDetailDataEvents>();
	}

	public void Get(PublishedFileId_t fileId)
	{
		WorkshopItemDetails.Get(fileId, HandleItemGet);
	}

	public void LoadPreview()
	{
		if (_mEvents != null && _mData != null && _mData.SourceItemDetails.m_nPreviewFileSize > 0)
		{
			_mData.GetPreviewImage(delegate(string name, byte[] data)
			{
				_mEvents.onPreviewImageLoaded?.Invoke(data);
			});
		}
	}

	public void Subscribe()
	{
		if (_mData != null)
		{
			_mData.Subscribe(HandleSubscribed);
		}
	}

	public void Unsubscribe()
	{
		if (_mData != null)
		{
			_mData.Unsubscribe(HandleUnsubscribe);
		}
	}

	public void DownloadItem()
	{
		if (_mData != null)
		{
			_mData.DownloadItem(highPriority: false);
		}
	}

	public void DownloadItemHighPriority()
	{
		if (_mData != null)
		{
			_mData.DownloadItem(highPriority: true);
		}
	}

	public void Delete()
	{
		if (_mData != null)
		{
			_mData.DeleteItem(HandleItemDelete);
		}
	}

	public void UpVote()
	{
		if (_mData != null)
		{
			_mData.SetVote(voteUp: true, HandleVoteSet);
		}
	}

	public void DownVote()
	{
		if (_mData != null)
		{
			_mData.SetVote(voteUp: false, HandleVoteSet);
		}
	}

	public void StartPlaytime()
	{
		if (_mData != null)
		{
			_mData.StartPlayTime(HandleStartPlaytime);
		}
	}

	public void StopPlaytime()
	{
		if (_mData != null)
		{
			_mData.StartPlayTime(HandleEndPlaytime);
		}
	}

	private void HandleItemGet(WorkshopItemDetails details)
	{
		Data = details;
	}

	private void HandleStartPlaytime(StartPlaytimeTrackingResult_t t, bool arg2)
	{
		if (_mEvents != null)
		{
			if (arg2 || t.m_eResult != EResult.k_EResultOK)
			{
				_mEvents.onPlayStartedFailed?.Invoke(t.m_eResult);
			}
			else
			{
				_mEvents.onPlayStarted?.Invoke(_mData.FileId);
			}
		}
	}

	private void HandleEndPlaytime(StartPlaytimeTrackingResult_t t, bool arg2)
	{
		if (_mEvents != null)
		{
			if (arg2 || t.m_eResult != EResult.k_EResultOK)
			{
				_mEvents.onPlayEndedFailed?.Invoke(t.m_eResult);
			}
			else
			{
				_mEvents.onPlayEnded?.Invoke(_mData.FileId);
			}
		}
	}

	private void HandleVoteSet(SetUserItemVoteResult_t t, bool arg2)
	{
		if (_mEvents != null)
		{
			if (arg2 || t.m_eResult != EResult.k_EResultOK)
			{
				_mEvents.onVoteSetFailed?.Invoke(t.m_eResult);
			}
			else
			{
				_mEvents.onVoteSet?.Invoke(t.m_nPublishedFileId);
			}
		}
	}

	private void HandleItemDelete(DeleteItemResult_t t, bool arg2)
	{
		if (_mEvents != null)
		{
			if (arg2 || t.m_eResult != EResult.k_EResultOK)
			{
				_mEvents.onDeleteFailed?.Invoke(t.m_eResult);
			}
			else
			{
				_mEvents.onDelete?.Invoke(t.m_nPublishedFileId);
			}
		}
	}

	private void HandleUnsubscribe(RemoteStorageUnsubscribePublishedFileResult_t t, bool arg2)
	{
		if (_mEvents != null)
		{
			if (arg2 || t.m_eResult != EResult.k_EResultOK)
			{
				_mEvents.onUnsubscribeFailed?.Invoke(t.m_eResult);
			}
			else
			{
				_mEvents.onUnsubscribed?.Invoke(t.m_nPublishedFileId);
			}
		}
	}

	private void HandleSubscribed(RemoteStorageSubscribePublishedFileResult_t t, bool arg2)
	{
		if (_mEvents != null)
		{
			if (arg2 || t.m_eResult != EResult.k_EResultOK)
			{
				_mEvents.onSubscribeFailed?.Invoke(t.m_eResult);
			}
			else
			{
				_mEvents.onSubscribed?.Invoke(t.m_nPublishedFileId);
			}
		}
	}
}
