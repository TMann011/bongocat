using System;
using BongoCat;
using UnityEngine;

public class MenuWindow : MonoBehaviour
{
	[SerializeField]
	private bool _hideOnClose = true;

	private RectTransform _rect;

	private ToggleGameObject _toggle;

	private Vector2 _homeAnchoredPosition;

	private readonly Vector3[] _corners = new Vector3[4];

	private readonly Vector3[] _catCorners = new Vector3[4];

	private static Action<MenuWindow> _onMenuWindowOpen;

	private void Awake()
	{
		_rect = GetComponent<RectTransform>();
		_toggle = GetComponent<ToggleGameObject>();
		_homeAnchoredPosition = _rect.anchoredPosition;
		_onMenuWindowOpen = (Action<MenuWindow>)Delegate.Combine(_onMenuWindowOpen, new Action<MenuWindow>(OnWindowOpened));
		MenuTabs.OnCloseTab = (Action<MenuTabs.MenuTab>)Delegate.Combine(MenuTabs.OnCloseTab, new Action<MenuTabs.MenuTab>(Hide));
	}

	private void OnEnable()
	{
		_onMenuWindowOpen(this);
	}

	private void OnWindowOpened(MenuWindow toOpen)
	{
		if (toOpen != this)
		{
			Hide();
		}
	}

	private void Hide(MenuTabs.MenuTab menuTab = MenuTabs.MenuTab.Inventory)
	{
		if (_hideOnClose)
		{
			_toggle.SetActive(active: false);
		}
	}

	private void LateUpdate()
	{
		_rect.anchoredPosition = _homeAnchoredPosition;
		_rect.GetWorldCorners(_corners);
		if (IsOffScreen() || OverlapsCat())
		{
			MirrorAcrossMenu();
		}
	}

	private bool IsOffScreen()
	{
		if (!(_corners[0].x < (float)ScreenHelper.XMin))
		{
			return _corners[3].x > (float)ScreenHelper.XMax;
		}
		return true;
	}

	private bool OverlapsCat()
	{
		((RectTransform)Cat.Instance.transform).GetWorldCorners(_catCorners);
		float num = Mathf.Min(_catCorners[0].x, _catCorners[2].x);
		float num2 = Mathf.Max(_catCorners[0].x, _catCorners[2].x);
		float num3 = Mathf.Min(_catCorners[0].y, _catCorners[2].y);
		float num4 = Mathf.Max(_catCorners[0].y, _catCorners[2].y);
		if (_corners[0].x < num2 && _corners[3].x > num && _corners[0].y < num4)
		{
			return _corners[1].y > num3;
		}
		return false;
	}

	private void MirrorAcrossMenu()
	{
		RectTransform rectTransform = (RectTransform)_rect.parent;
		float num = _rect.localPosition.x + (0.5f - _rect.pivot.x) * _rect.rect.width;
		float x = 2f * (rectTransform.rect.center.x - num);
		_rect.anchoredPosition += new Vector2(x, 0f);
	}

	private void OnDestroy()
	{
		_onMenuWindowOpen = (Action<MenuWindow>)Delegate.Remove(_onMenuWindowOpen, new Action<MenuWindow>(OnWindowOpened));
		MenuTabs.OnCloseTab = (Action<MenuTabs.MenuTab>)Delegate.Remove(MenuTabs.OnCloseTab, new Action<MenuTabs.MenuTab>(Hide));
	}
}
