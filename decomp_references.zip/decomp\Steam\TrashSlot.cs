using BongoCat;
using BongoCat.SteamJsonParser;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Steam;

public class TrashSlot : MonoBehaviour
{
	[SerializeField]
	private Image _icon;

	private SteamItemRuntime _itemSlotted;

	[SerializeField]
	private Image _borderImage;

	[SerializeField]
	private GameObject _counterIndicator;

	[SerializeField]
	private TMP_Text _counter;

	public void SetItem(SteamItemRuntime item)
	{
		SteamItemRuntime itemSlotted = _itemSlotted;
		_itemSlotted = item;
		if (item == null)
		{
			_icon.sprite = null;
			_borderImage.color = Color.clear;
			_counterIndicator.SetActive(value: false);
			itemSlotted?.OnItemUpdated?.Invoke();
		}
		else
		{
			long totalQuantity = item.RuntimeData.GetTotalQuantity();
			_counter.text = totalQuantity.ToString();
			_counterIndicator.SetActive(totalQuantity > 1);
			_counter.color = item.QualityCategory.GetColor();
			_icon.sprite = item.Icon;
			_borderImage.color = item.QualityCategory.GetColor();
		}
	}

	public void OnClick()
	{
		if (_itemSlotted != null)
		{
			TrashCan.Instance.RemoveFromTrash(_itemSlotted);
		}
	}
}
