namespace BongoCat.SteamJsonParser;

public enum QualityCategoryWithInfo
{
	SpecialCosmetic = 0,
	SpecialEmote = 1,
	CommonCosmetic = 10,
	UncommonCosmetic = 11,
	RareCosmetic = 12,
	EpicCosmetic = 13,
	LegendaryCosmetic = 14,
	UniqueCosmetic = 15,
	CommonEmote = 20,
	UncommonEmote = 21,
	RareEmote = 22,
	EpicEmote = 23,
	LegendaryEmote = 24,
	UniqueEmote = 25
}
