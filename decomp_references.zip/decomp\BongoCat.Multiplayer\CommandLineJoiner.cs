using System;
using System.Collections;
using Heathen.SteamworksIntegration;
using SteamTools;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class CommandLineJoiner : MonoBehaviour
{
	private const string COMMAND_LINE_CONNECT = "+connect_lobby";

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => Interface.IsReady);
		ParseCommandLineForLobbyInvite();
	}

	private static void ParseCommandLineForLobbyInvite()
	{
		string[] commandLineArgs = Environment.GetCommandLineArgs();
		for (int i = 1; i < commandLineArgs.Length - 1; i++)
		{
			if (commandLineArgs[i] == "+connect_lobby" && ulong.TryParse(commandLineArgs[i + 1], out var result))
			{
				Debug.Log("[Multiplayer] Connecting to lobby via command line arg (aka Steam Invite without app running)");
				PlayerPrefs.DeleteKey("LAST_LOBBY");
				LobbyData.Join(result);
				break;
			}
		}
	}
}
