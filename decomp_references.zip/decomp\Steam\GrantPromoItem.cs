using BongoCat;
using BongoCat.SteamJsonParser;
using UnityEngine;

namespace Steam;

public class GrantPromoItem : MonoBehaviour
{
	[SerializeField]
	private SteamItemBasic _itemToGrant;

	public bool IsOwned => SteamItemIdReference.Inst[_itemToGrant.Id].IsOwned;

	public void Grant()
	{
		GrantWithDelay(0f);
	}

	public void GrantWithDelay(float delay)
	{
		PromoItemChecker.Instance.GrantPromoItem(_itemToGrant.Id, delay);
	}
}
