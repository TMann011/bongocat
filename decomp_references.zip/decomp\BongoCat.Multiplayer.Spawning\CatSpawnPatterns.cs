namespace BongoCat.Multiplayer.Spawning;

public enum CatSpawnPatterns
{
	AlignedWithMainCat,
	BottomBorder,
	RightBorder,
	TopBorder,
	LeftBorder,
	AroundBorder,
	Grid,
	Random,
	Free
}
