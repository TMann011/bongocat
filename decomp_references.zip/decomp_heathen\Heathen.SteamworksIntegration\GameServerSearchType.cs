namespace Heathen.SteamworksIntegration;

public enum GameServerSearchType
{
	Internet,
	Friends,
	Favorites,
	Lan,
	Spectator,
	History
}
