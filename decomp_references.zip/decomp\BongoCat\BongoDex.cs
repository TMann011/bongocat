using System.Collections;
using System.Collections.Generic;
using BongoCat.UI;
using Helper;
using UnityEngine;

namespace BongoCat;

public class BongoDex : MonoBehaviour
{
	public static BongoDex Instance;

	[SerializeField]
	private CollectionNames _collectionNames;

	[SerializeField]
	private BongoDexView _bongoDexView;

	[SerializeField]
	private BongoDexCollection _bongoDexCollectionPrefab;

	private float _scrollBarSavedValue;

	private ScrollViewUpdater _scrollViewUpdater;

	private readonly Dictionary<string, List<SteamItemRuntime>> _collections = new Dictionary<string, List<SteamItemRuntime>>();

	public readonly HashSet<string> allTags = new HashSet<string>();

	private void Awake()
	{
		Instance = this;
	}

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		yield return new WaitUntil(() => CatInventory.Instance.Items.Count > 0);
		PrepareCollections();
		foreach (CollectionNames.CollectionName collection in _collectionNames.Collections)
		{
			BongoDexCollection bongoDexCollection = Object.Instantiate(_bongoDexCollectionPrefab, _bongoDexView.ScrollRect.content.transform);
			bongoDexCollection.Init(GetItemsOfCollection(collection), collection);
			_bongoDexView.BongoDexCollections.Add(bongoDexCollection);
		}
	}

	private List<SteamItemRuntime> GetItemsOfCollection(CollectionNames.CollectionName collectionInfo)
	{
		if (collectionInfo.OtherKeys.Count == 0)
		{
			return _collections[collectionInfo.Key];
		}
		List<SteamItemRuntime> list = _collections[collectionInfo.Key];
		foreach (string otherKey in collectionInfo.OtherKeys)
		{
			list.AddRange(_collections[otherKey]);
		}
		return list;
	}

	private void PrepareCollections()
	{
		foreach (CollectionNames.CollectionName collection in _collectionNames.Collections)
		{
			_collections.Add(collection.Key, new List<SteamItemRuntime>());
			foreach (string otherKey in collection.OtherKeys)
			{
				_collections.Add(otherKey, new List<SteamItemRuntime>());
			}
		}
		foreach (SteamItemRuntime item in CatInventory.Instance.Items)
		{
			string text = item.Tag;
			if (string.IsNullOrWhiteSpace(text))
			{
				text = item.QualityCategory.ToString();
			}
			allTags.Add(text);
			_collections[text].Add(item);
		}
	}
}
