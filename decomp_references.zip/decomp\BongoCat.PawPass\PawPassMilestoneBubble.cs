using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassMilestoneBubble : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _milestoneText;

	[SerializeField]
	private Image _bubbleImage;

	[SerializeField]
	private Sprite _unreached;

	[SerializeField]
	private Sprite _reached;

	public void SetMilestone(int milestoneNumber)
	{
		_milestoneText.text = milestoneNumber.ToString();
	}

	public void SetReached(bool reached)
	{
		_bubbleImage.sprite = (reached ? _reached : _unreached);
	}
}
