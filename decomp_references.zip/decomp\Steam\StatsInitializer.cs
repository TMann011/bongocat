using System.Collections;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace Steam;

public class StatsInitializer : MonoBehaviour
{
	private CallResult<GlobalStatsReceived_t> _t;

	private CallResult<UserStatsReceived_t> _t2;

	public static bool Initialized { get; private set; }

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => Interface.IsReady);
		_t = CallResult<GlobalStatsReceived_t>.Create(OnGlobalStatsReceived);
		_t2 = CallResult<UserStatsReceived_t>.Create(OnUserStatsReceived);
		SteamAPICall_t hAPICall = SteamUserStats.RequestUserStats(SteamUser.GetSteamID());
		_t2.Set(hAPICall);
		yield return new WaitUntil(() => Initialized);
	}

	private void OnUserStatsReceived(UserStatsReceived_t userStatsReceivedT, bool bIOFailure)
	{
		if (bIOFailure || userStatsReceivedT.m_eResult != EResult.k_EResultOK)
		{
			Debug.LogWarning("Retrying fetching user stats..");
			SteamAPICall_t hAPICall = SteamUserStats.RequestUserStats(SteamUser.GetSteamID());
			_t2.Set(hAPICall);
		}
		else if (!Initialized)
		{
			SteamAPICall_t hAPICall2 = SteamUserStats.RequestGlobalStats(1);
			_t.Set(hAPICall2);
		}
	}

	private void OnGlobalStatsReceived(GlobalStatsReceived_t param, bool biofailure)
	{
		if ((param.m_eResult != EResult.k_EResultOK) | biofailure)
		{
			Debug.LogWarning("Retrying fetching global stats..");
			SteamAPICall_t hAPICall = SteamUserStats.RequestGlobalStats(1);
			_t.Set(hAPICall);
		}
		else
		{
			Initialized = true;
		}
	}
}
