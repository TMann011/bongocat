using BongoCat;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ScreenChoice : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _idxIndicator;

	private MainScreenTutorial _mainScreenTutorial;

	private int _index;

	public Button Button;

	public void Init(MainScreenTutorial mainScreenTutorial, int index)
	{
		_mainScreenTutorial = mainScreenTutorial;
		_index = index;
		_idxIndicator.text = (_index + 1).ToString();
	}

	public void ToggleToDisplay()
	{
		_mainScreenTutorial.SelectScreen(_index);
		SettingsManager.Instance.MainScreenSetting.SetDisplay(_index);
	}
}
