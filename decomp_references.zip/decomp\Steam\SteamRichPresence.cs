using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace Steam;

public class SteamRichPresence : MonoBehaviour
{
	private const string RICH_PRESENCE_CONNECT = "connect";

	private const string RICH_PRESENCE_GROUP = "steam_player_group";

	private const string RICH_PRESENCE_GROUP_SIZE = "steam_player_group_size";

	private void Awake()
	{
		Events.OnLobbyEnterSuccess += OnLobbyEntered;
		Events.OnLobbyLeave += OnLobbyLeave;
		Events.OnLobbyChatUpdate += OnLobbyChatUpdate;
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= OnLobbyEntered;
		Events.OnLobbyLeave -= OnLobbyLeave;
		Events.OnLobbyChatUpdate -= OnLobbyChatUpdate;
	}

	private void OnLobbyEntered(LobbyData lobby)
	{
		SteamFriends.SetRichPresence("connect", lobby.ToString());
		SteamFriends.SetRichPresence("steam_player_group", lobby.ToString());
		SteamFriends.SetRichPresence("steam_player_group_size", lobby.MemberCount.ToString());
	}

	private void OnLobbyChatUpdate(LobbyData lobby, UserData user, EChatMemberStateChange changes)
	{
		SteamFriends.SetRichPresence("steam_player_group_size", lobby.MemberCount.ToString());
	}

	private void OnLobbyLeave(LobbyData lobby)
	{
		SteamFriends.ClearRichPresence();
	}
}
