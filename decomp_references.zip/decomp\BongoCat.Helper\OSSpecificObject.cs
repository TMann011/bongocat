using IroxGames.Helper.ClassExtensions;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Helper;

public class OSSpecificObject : MonoBehaviour
{
	[SerializeField]
	private bool _windows = true;

	[SerializeField]
	private bool _apple = true;

	[SerializeField]
	private bool _linux = true;

	[SerializeField]
	private int _parentsToRebuild;

	private bool SupportedOnThisPlatform
	{
		get
		{
			switch (Application.platform)
			{
			case RuntimePlatform.WindowsPlayer:
			case RuntimePlatform.WindowsEditor:
			case RuntimePlatform.WindowsServer:
				return _windows;
			case RuntimePlatform.OSXEditor:
			case RuntimePlatform.OSXPlayer:
			case RuntimePlatform.OSXServer:
				return _apple;
			case RuntimePlatform.LinuxPlayer:
			case RuntimePlatform.LinuxEditor:
			case RuntimePlatform.LinuxHeadlessSimulation:
			case RuntimePlatform.EmbeddedLinuxArm64:
			case RuntimePlatform.EmbeddedLinuxArm32:
			case RuntimePlatform.EmbeddedLinuxX64:
			case RuntimePlatform.EmbeddedLinuxX86:
			case RuntimePlatform.LinuxServer:
				return _linux;
			default:
				return true;
			}
		}
	}

	private void OnEnable()
	{
		if (SupportedOnThisPlatform)
		{
			return;
		}
		base.gameObject.SetActiveWithCheck(active: false);
		RectTransform rectTransform = base.transform.parent as RectTransform;
		for (int i = 0; i < _parentsToRebuild; i++)
		{
			if (!rectTransform)
			{
				break;
			}
			LayoutRebuilder.ForceRebuildLayoutImmediate(rectTransform);
			rectTransform = rectTransform.parent as RectTransform;
		}
	}
}
