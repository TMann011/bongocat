using System.Collections.Generic;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;
using UnityEngine.Localization.Tables;

namespace BongoCat.Localizer;

public static class Localize
{
	public static string CurrentCode
	{
		get
		{
			if (!LocalizationSettings.SelectedLocale)
			{
				return "en";
			}
			return LocalizationSettings.SelectedLocale.Identifier.Code;
		}
	}

	public static string Get(string key)
	{
		return LocalizationSettings.StringDatabase.GetLocalizedString("BongoCat", key, null, FallbackBehavior.UseProjectSettings);
	}

	public static string Get(string key, params object[] args)
	{
		return LocalizationSettings.StringDatabase.GetLocalizedString("BongoCat", key, null, FallbackBehavior.UseProjectSettings, args);
	}

	public static Dictionary<string, string> GetAllForKey(string key)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		foreach (Locale locale in LocalizationSettings.AvailableLocales.Locales)
		{
			StringTableEntry stringTableEntry = LocalizationSettings.StringDatabase.GetTable("BongoCat", locale)?.GetEntry(key);
			if (stringTableEntry != null)
			{
				dictionary[locale.Identifier.Code] = stringTableEntry.GetLocalizedString();
			}
		}
		return dictionary;
	}
}
