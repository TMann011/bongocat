using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace BongoCat;

public class OnSpecificUIHoverCallback : MonoBehaviour
{
	public bool Hovering;

	public UnityEvent OnHoverEnter;

	public UnityEvent OnHoverExit;

	private void Start()
	{
		OnUIHoverCallback instance = OnUIHoverCallback.Instance;
		instance.onNewRaycastResults = (Action<List<RaycastResult>>)Delegate.Combine(instance.onNewRaycastResults, new Action<List<RaycastResult>>(Recalculate));
	}

	private void OnDestroy()
	{
		OnUIHoverCallback instance = OnUIHoverCallback.Instance;
		instance.onNewRaycastResults = (Action<List<RaycastResult>>)Delegate.Remove(instance.onNewRaycastResults, new Action<List<RaycastResult>>(Recalculate));
	}

	private void Recalculate(List<RaycastResult> results)
	{
		bool flag = results.Any((RaycastResult r) => r.gameObject.transform.IsChildOf(base.transform));
		if (flag != Hovering)
		{
			Hovering = flag;
			if (flag)
			{
				OnHoverEnter?.Invoke();
			}
			else
			{
				OnHoverExit?.Invoke();
			}
		}
	}
}
