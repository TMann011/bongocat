using DG.Tweening;
using UnityEngine;
using UnityEngine.Events;

namespace Tutorial;

public class TutorialStep : MonoBehaviour
{
	public UnityEvent onBegin;

	public UnityEvent onCompleted;

	private bool _active;

	private bool _shouldSkip;

	public void Begin()
	{
		DOTween.Kill(base.transform);
		base.transform.localScale = Vector3.zero;
		base.transform.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutBack);
		base.gameObject.SetActive(value: true);
		_active = true;
		onBegin.Invoke();
	}

	public void Complete()
	{
		if (_active)
		{
			_active = false;
			DOTween.Kill(base.transform);
			base.transform.DOScale(Vector3.zero, 0.5f).SetEase(Ease.InBack).OnComplete(delegate
			{
				base.gameObject.SetActive(value: false);
			});
			DOVirtual.DelayedCall(0.4f, delegate
			{
				onCompleted.Invoke();
			});
		}
	}

	public void SetSkippable(bool skip)
	{
		_shouldSkip = skip;
	}

	public virtual bool ShouldSkip()
	{
		return _shouldSkip;
	}
}
