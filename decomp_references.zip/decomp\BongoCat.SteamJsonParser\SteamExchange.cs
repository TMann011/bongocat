using System;
using System.Collections.Generic;
using System.Linq;
using Heathen.SteamworksIntegration;
using Steamworks;
using UnityEngine;

namespace BongoCat.SteamJsonParser;

public class SteamExchange : SteamItemBase
{
	public List<SteamItemBasic> Input;

	public List<SteamItemBase> Output;

	public void Exchange(Action<(bool, ItemDetail[])> callback)
	{
		List<ExchangeEntry> list = TryToFulfill();
		if (list == null)
		{
			Debug.LogWarning("SteamExchange | Not enough items to exchange for " + Name);
			callback?.Invoke((false, null));
		}
		else
		{
			base.ItemData.Exchange(list, delegate(InventoryResult result)
			{
				callback?.Invoke((result.result == EResult.k_EResultOK, result.items.Skip(Input.Count).ToArray()));
			});
		}
	}

	public bool CanExchange()
	{
		return TryToFulfill() != null;
	}

	private List<ExchangeEntry> TryToFulfill()
	{
		List<ExchangeEntry> list = new List<ExchangeEntry>();
		Dictionary<SteamItemBasic, uint> dictionary = new Dictionary<SteamItemBasic, uint>();
		foreach (SteamItemBasic item in Input)
		{
			if (!dictionary.TryAdd(item, 1u))
			{
				dictionary[item]++;
			}
		}
		foreach (KeyValuePair<SteamItemBasic, uint> item2 in dictionary)
		{
			if (!item2.Key.ItemData.GetExchangeEntry(item2.Value, out var entries))
			{
				Debug.Log($"SteamExchange | Not enough items to exchange for {Name}, missing {item2.Value} of {item2.Key.Name}");
				return null;
			}
			list.AddRange(entries);
		}
		return list;
	}

	public override SteamItemJson ToSteamItemBackend()
	{
		string text = string.Join(';', from item in Output
			group item by item.Id into @group
			select (@group.Count() <= 1) ? @group.Key.ToString() : $"{@group.Key}x{@group.Count()}");
		string text2 = "";
		if (Input.Count > 0)
		{
			text2 += Input[0].Id;
			for (int num = 1; num < Input.Count; num++)
			{
				text2 += $",{Input[num].Id}";
			}
		}
		return new SteamItemJson(this)
		{
			type = (string.IsNullOrEmpty(text) ? "item" : "bundle"),
			bundle = text,
			exchange = text2
		};
	}
}
