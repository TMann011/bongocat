using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyLeave : MonoBehaviour
{
	private SteamLobbyData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
	}

	public void Leave()
	{
		if (_mInspector.Data.IsValid)
		{
			_mInspector.Data.Leave();
			_mInspector.Data = CSteamID.Nil;
		}
	}
}
