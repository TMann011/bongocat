using System;
using System.IO;
using System.Runtime.InteropServices;
using UnityEngine;

namespace BongoCat.OSSpecific.Windows;

public static class ClipboardHelper
{
	[DllImport("user32.dll")]
	private static extern bool OpenClipboard(IntPtr hWndNewOwner);

	[DllImport("user32.dll")]
	private static extern bool CloseClipboard();

	[DllImport("user32.dll")]
	private static extern bool EmptyClipboard();

	[DllImport("user32.dll")]
	private static extern IntPtr SetClipboardData(uint uFormat, IntPtr data);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GlobalAlloc(uint uFlags, UIntPtr dwBytes);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GlobalLock(IntPtr hMem);

	[DllImport("kernel32.dll")]
	private static extern bool GlobalUnlock(IntPtr hMem);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern uint RegisterClipboardFormat(string lpszFormat);

	public static void CopyImageToClipboard(Texture2D texture)
	{
		if (texture == null)
		{
			return;
		}
		byte[] array = texture.EncodeToPNG();
		byte[] array2 = ConvertToDibV5(texture);
		uint num = RegisterClipboardFormat("PNG");
		if (OpenClipboard(WinApi.GetActiveWindow()))
		{
			EmptyClipboard();
			if (array2 != null)
			{
				SetClipboardData(17u, CopyToClipboardMemory(array2));
			}
			if (array != null && num != 0)
			{
				SetClipboardData(num, CopyToClipboardMemory(array));
			}
			CloseClipboard();
		}
	}

	private static byte[] ConvertToDibV5(Texture2D texture)
	{
		int width = texture.width;
		int height = texture.height;
		Color32[] pixels = texture.GetPixels32();
		using MemoryStream memoryStream = new MemoryStream();
		using BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write(124u);
		binaryWriter.Write(width);
		binaryWriter.Write(height);
		binaryWriter.Write((ushort)1);
		binaryWriter.Write((ushort)32);
		binaryWriter.Write(3u);
		binaryWriter.Write((uint)(width * height * 4));
		binaryWriter.Write(2835);
		binaryWriter.Write(2835);
		binaryWriter.Write(0u);
		binaryWriter.Write(0u);
		binaryWriter.Write(16711680u);
		binaryWriter.Write(65280u);
		binaryWriter.Write(255u);
		binaryWriter.Write(4278190080u);
		binaryWriter.Write(1934772034u);
		for (int i = 0; i < 9; i++)
		{
			binaryWriter.Write(0u);
		}
		binaryWriter.Write(0u);
		binaryWriter.Write(0u);
		binaryWriter.Write(0u);
		binaryWriter.Write(4u);
		binaryWriter.Write(0u);
		binaryWriter.Write(0u);
		binaryWriter.Write(0u);
		Color32[] array = pixels;
		for (int j = 0; j < array.Length; j++)
		{
			Color32 color = array[j];
			binaryWriter.Write(color.b);
			binaryWriter.Write(color.g);
			binaryWriter.Write(color.r);
			binaryWriter.Write(color.a);
		}
		binaryWriter.Flush();
		return memoryStream.ToArray();
	}

	private static IntPtr CopyToClipboardMemory(byte[] data)
	{
		IntPtr intPtr = GlobalAlloc(2u, (UIntPtr)(ulong)data.Length);
		if (intPtr == IntPtr.Zero)
		{
			return IntPtr.Zero;
		}
		IntPtr destination = GlobalLock(intPtr);
		Marshal.Copy(data, 0, destination, data.Length);
		GlobalUnlock(intPtr);
		return intPtr;
	}
}
