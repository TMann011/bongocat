using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;

namespace BongoCat;

[RequireComponent(typeof(TMP_Dropdown))]
public class EnumLocalizer : MonoBehaviour
{
	[SerializeField]
	private string _enumType;

	[SerializeField]
	private List<EnumToLocalizedString> _enumToLocalizeStrings = new List<EnumToLocalizedString>();

	private TMP_Dropdown _dropdown;

	private List<string> _visibleKeys;

	private TMP_Dropdown Dropdown
	{
		get
		{
			if (!_dropdown)
			{
				return _dropdown = GetComponent<TMP_Dropdown>();
			}
			return _dropdown;
		}
	}

	private void OnEnable()
	{
		LocalizationSettings.SelectedLocaleChanged += OnSelectedLocaleChanged;
		Refresh();
	}

	private void OnDisable()
	{
		LocalizationSettings.SelectedLocaleChanged -= OnSelectedLocaleChanged;
	}

	public void SetVisibleValues(List<string> keys)
	{
		_visibleKeys = keys;
		Refresh();
	}

	public void Refresh()
	{
		IEnumerable<EnumToLocalizedString> enumerable;
		if (_visibleKeys != null)
		{
			enumerable = from key in _visibleKeys
				select _enumToLocalizeStrings.FirstOrDefault((EnumToLocalizedString entry) => entry.Key == key) into entry
				where entry != null
				select entry;
		}
		else
		{
			IEnumerable<EnumToLocalizedString> enumToLocalizeStrings = _enumToLocalizeStrings;
			enumerable = enumToLocalizeStrings;
		}
		IEnumerable<EnumToLocalizedString> source = enumerable;
		Dropdown.options = source.Select((EnumToLocalizedString entry) => new TMP_Dropdown.OptionData(Localized(entry))).ToList();
	}

	private static string Localized(EnumToLocalizedString entry)
	{
		if (!entry.Value.IsEmpty)
		{
			return entry.Value.GetLocalizedString();
		}
		return entry.Key;
	}

	private void OnSelectedLocaleChanged(Locale locale)
	{
		Refresh();
	}
}
