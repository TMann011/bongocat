using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInventoryItemDataEvents))]
[RequireComponent(typeof(SteamInventoryItemData))]
public class SteamInventoryItemName : MonoBehaviour
{
	public TextMeshProUGUI label;

	private SteamInventoryItemData _mInspector;

	private SteamInventoryItemDataEvents _mEvents;

	private void Awake()
	{
		_mInspector = GetComponent<SteamInventoryItemData>();
		_mEvents = GetComponent<SteamInventoryItemDataEvents>();
		_mEvents.onChange?.AddListener(HandleChange);
	}

	private void HandleChange()
	{
		if (label != null)
		{
			label.text = _mInspector.Data.Name;
		}
	}
}
