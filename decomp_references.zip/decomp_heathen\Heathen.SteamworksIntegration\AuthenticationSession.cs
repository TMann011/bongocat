using System;
using System.Runtime.CompilerServices;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public class AuthenticationSession
{
	[CompilerGenerated]
	private UserData _003CGameOwner_003Ek__BackingField;

	public bool IsClientSession { get; private set; }

	public UserData User { get; private set; }

	private UserData GameOwner
	{
		[CompilerGenerated]
		set
		{
			_003CGameOwner_003Ek__BackingField = value;
		}
	}

	public EAuthSessionResponse Response { get; private set; }

	public Action<AuthenticationSession> OnStartCallback { get; private set; }

	public AuthenticationSession(CSteamID userId, Action<AuthenticationSession> callback, bool isClient = true)
	{
		IsClientSession = isClient;
		User = userId;
		OnStartCallback = callback;
	}

	internal void Authenticate(ValidateAuthTicketResponse_t response)
	{
		Response = response.m_eAuthSessionResponse;
		GameOwner = response.m_OwnerSteamID;
	}

	public void End()
	{
		if (IsClientSession)
		{
			SteamUser.EndAuthSession(User);
		}
		else
		{
			SteamGameServer.EndAuthSession(User);
		}
	}
}
