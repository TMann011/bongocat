namespace Heathen.SteamworksIntegration;

public enum InputActionType
{
	Analog,
	Digital
}
