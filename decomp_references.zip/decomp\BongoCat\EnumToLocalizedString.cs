using System;
using UnityEngine.Localization;

namespace BongoCat;

[Serializable]
public class EnumToLocalizedString
{
	public string Key;

	public LocalizedString Value;
}
