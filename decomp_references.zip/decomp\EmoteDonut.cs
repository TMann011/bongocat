using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat;
using BongoCat.OSSpecific;
using Helper;
using UnityEngine;

public class EmoteDonut : MonoBehaviour
{
	[SerializeField]
	private PlayerPrefsToggle _showEmoteWheel;

	[SerializeField]
	private int maxEmoteCount;

	[SerializeField]
	private float radius;

	[SerializeField]
	private EmoteDonutEntry emoteEntryPrefab;

	[SerializeField]
	private EmoteSpawner emoteSpawner;

	[SerializeField]
	private Transform emoteEntryParent;

	[SerializeField]
	private GameObject _menu;

	private Dictionary<int, EmoteDonutEntry> IDtoEmoteEntry = new Dictionary<int, EmoteDonutEntry>();

	private bool _isOpen;

	private bool _activelyClosed;

	public static EmoteDonut Instance;

	private const string EQUIPPED_EMOTES_KEY = "EQUIPPED_EMOTES_3";

	[SerializeField]
	private float _interactionDistance;

	private void Awake()
	{
		Instance = this;
	}

	private IEnumerator Start()
	{
		if (!PlayerPrefsHelp.TryGetObject<int[]>("EQUIPPED_EMOTES_3", out var ids) || ids == null)
		{
			yield break;
		}
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		yield return new WaitUntil(() => !CatInventory.Instance.FetchingItems);
		foreach (SteamItemRuntime item in from id in ids
			select SteamItemIdReference.Inst[id] into item
			where item.RuntimeData.GetTotalQuantity() > 0
			select item)
		{
			AddEmote(item);
		}
	}

	private void Update()
	{
		if (TransparentWindow.Instance.GamingModeEnabled || TranslucentOnHoverSetting.Instance.DisablePopups || _menu.gameObject.activeSelf || !_showEmoteWheel.Value)
		{
			Close();
			return;
		}
		bool flag = false;
		Vector2 a = Input.mousePosition;
		foreach (Transform item in emoteEntryParent)
		{
			Vector2 b = RectTransformUtility.WorldToScreenPoint(null, item.position);
			if (Vector2.Distance(a, b) < _interactionDistance * SettingsManager.Instance.UIScaleSetting.GetScale())
			{
				flag = true;
				break;
			}
		}
		if (flag)
		{
			Open();
		}
		else
		{
			Close();
		}
	}

	private void AddEmote(SteamItemRuntime steamItem)
	{
		EmoteDonutEntry emoteDonutEntry = UnityEngine.Object.Instantiate(emoteEntryPrefab, emoteEntryParent);
		IDtoEmoteEntry.Add(steamItem.Id, emoteDonutEntry);
		PlayerPrefsHelp.SetObject("EQUIPPED_EMOTES_3", IDtoEmoteEntry.Keys.ToArray());
		if (!_isOpen)
		{
			emoteDonutEntry.gameObject.SetActive(value: false);
		}
		emoteDonutEntry.SetItem(steamItem, emoteSpawner, this);
		RearrangeEmotes();
		steamItem.IsEquipped = true;
		steamItem.IsNew = false;
		steamItem.OnItemUpdated?.Invoke();
	}

	private void RemoveEmote(SteamItemRuntime steamItem)
	{
		UnityEngine.Object.Destroy(IDtoEmoteEntry[steamItem.Id].gameObject);
		IDtoEmoteEntry.Remove(steamItem.Id);
		PlayerPrefsHelp.SetObject("EQUIPPED_EMOTES_3", IDtoEmoteEntry.Keys.ToArray());
		RearrangeEmotes();
		steamItem.IsEquipped = false;
		steamItem.OnItemUpdated?.Invoke();
	}

	public void Validate()
	{
		if (!PlayerPrefs.HasKey("EQUIPPED_EMOTES_3"))
		{
			return;
		}
		PlayerPrefsHelp.TryGetObject<int[]>("EQUIPPED_EMOTES_3", out var ids);
		List<SteamItemRuntime> source = CatInventory.Instance.Items.Where((SteamItemRuntime item) => ids.Contains(item.Id) && item.RuntimeData.GetTotalQuantity() > 0 && (item.IsEmote || item.IsConsumable)).ToList();
		foreach (int id in IDtoEmoteEntry.Keys.ToList())
		{
			if (!source.Any((SteamItemRuntime item) => item.Id == id))
			{
				SteamItemRuntime steamItemRuntime = CatInventory.Instance.Items.FirstOrDefault((SteamItemRuntime item) => item.Id == id);
				if (steamItemRuntime != null)
				{
					RemoveEmote(steamItemRuntime);
				}
			}
		}
	}

	private void RearrangeEmotes()
	{
		float num = 20 * IDtoEmoteEntry.Count;
		List<EmoteDonutEntry> list = IDtoEmoteEntry.Values.ToList();
		for (int i = 0; i < list.Count; i++)
		{
			EmoteDonutEntry emoteDonutEntry = list[i];
			float num2 = (float)i / (float)(list.Count - 1) * num * ((float)Math.PI / 180f);
			num2 += (0f - num) / 2f * ((float)Math.PI / 180f);
			if (list.Count < 2)
			{
				num2 = 0f;
			}
			emoteDonutEntry.transform.localPosition = new Vector3(Mathf.Sin(num2), Mathf.Cos(num2), 0f) * radius;
		}
	}

	private void Open()
	{
		if (_isOpen || _activelyClosed || emoteEntryParent.childCount <= 1)
		{
			return;
		}
		_isOpen = true;
		foreach (Transform item in emoteEntryParent)
		{
			item.gameObject.SetActive(value: true);
		}
	}

	private void Close()
	{
		_activelyClosed = false;
		if (!_isOpen)
		{
			return;
		}
		_isOpen = false;
		foreach (Transform item in emoteEntryParent)
		{
			item.gameObject.SetActive(value: false);
		}
	}

	public void CloseActively()
	{
		Close();
		_activelyClosed = true;
	}

	public void ToggleItem(SteamItemRuntime steamItem)
	{
		if (IDtoEmoteEntry.Keys.Contains(steamItem.Id))
		{
			RemoveEmote(steamItem);
		}
		else if (maxEmoteCount > IDtoEmoteEntry.Count)
		{
			AddEmote(steamItem);
		}
	}
}
