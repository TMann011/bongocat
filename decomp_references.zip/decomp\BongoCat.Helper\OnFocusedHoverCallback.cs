using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace BongoCat.Helper;

public class OnFocusedHoverCallback : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
{
	public UnityEvent onHoverEnter;

	public UnityEvent onHoverExit;

	private bool _hovering;

	public bool Hovering => _hovering;

	public void OnPointerEnter(PointerEventData eventData)
	{
		_hovering = true;
		onHoverEnter?.Invoke();
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		_hovering = false;
		onHoverExit?.Invoke();
	}
}
