using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.UI;

public class PresetsWindowLayout : MonoBehaviour
{
	[SerializeField]
	private ScrollRect _scrollRect;

	[SerializeField]
	private List<RectTransform> _rebuildLayouts;

	private void OnEnable()
	{
		Rebuild(scrollToBottom: false);
	}

	public void Rebuild(bool scrollToBottom)
	{
		if (!base.gameObject.activeInHierarchy)
		{
			return;
		}
		foreach (RectTransform rebuildLayout in _rebuildLayouts)
		{
			LayoutRebuilder.ForceRebuildLayoutImmediate(rebuildLayout);
		}
		if (scrollToBottom)
		{
			_scrollRect.verticalNormalizedPosition = 0f;
		}
	}
}
