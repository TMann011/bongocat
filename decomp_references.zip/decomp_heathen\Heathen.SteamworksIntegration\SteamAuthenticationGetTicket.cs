using Heathen.SteamworksIntegration.API;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamAuthenticationData))]
public class SteamAuthenticationGetTicket : MonoBehaviour
{
	private AuthenticationTicket _mData;

	public AuthenticationTicket Data
	{
		get
		{
			return _mData;
		}
		private set
		{
			_mData = value;
		}
	}

	public void GetTicketForLobbyServer(SteamLobbyData lobby)
	{
		if (lobby.Data.IsValid)
		{
			LobbyGameServer gameServer = lobby.Data.GameServer;
			if (gameServer.id.IsValid())
			{
				Authentication.GetAuthSessionTicket(gameServer.id, HandleTicketCallback);
			}
		}
	}

	public void GetTicketForLobbyOwner(SteamLobbyData lobby)
	{
		if (lobby.Data.IsValid)
		{
			Authentication.GetAuthSessionTicket(lobby.Data.Owner.user, HandleTicketCallback);
		}
	}

	public void GetTicketForUser(SteamUserData user)
	{
		if (user.Data.IsValid)
		{
			Authentication.GetAuthSessionTicket(user.Data, HandleTicketCallback);
		}
	}

	public void GetTicketForGameServer(SteamGameServerData server)
	{
		if (server.Data.SteamId.IsValid())
		{
			Authentication.GetAuthSessionTicket(server.Data.SteamId, HandleTicketCallback);
		}
	}

	public void GetTicketForWebAPI(string identity)
	{
		Authentication.GetWebAuthSessionTicket(identity, HandleTicketCallback);
	}

	private void HandleTicketCallback(AuthenticationTicket ticket, bool ioError)
	{
		Data = ticket;
	}
}
