using Heathen.SteamworksIntegration.API;
using SteamTools;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyJoin))]
[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyJoinOnInvite : MonoBehaviour
{
	public enum JoinOnMode
	{
		WithInitialInvite,
		AfterAcceptInFriendChat
	}

	public enum FilterMode
	{
		None,
		IgnoreIfInParty,
		IgnoreIfInSession,
		IgnoreIfInAny
	}

	public enum PreprocessOptions
	{
		None,
		LeaveAllFirst,
		LeavePartyFirst,
		LeaveSessionFirst
	}

	public JoinOnMode mode;

	public FilterMode filter;

	public PreprocessOptions preprocess;

	private SteamLobbyData _mInspector;

	private SteamLobbyJoin _mJoin;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mJoin = GetComponent<SteamLobbyJoin>();
		Events.OnLobbyInvite += HandleInviteReceived;
		Events.OnLobbyJoinRequested += HandleInviteAccepted;
	}

	private void OnDestroy()
	{
		Events.OnLobbyInvite -= HandleInviteReceived;
		Events.OnLobbyJoinRequested -= HandleInviteAccepted;
	}

	private bool CanProcess()
	{
		LobbyData lobby;
		return filter switch
		{
			FilterMode.None => true, 
			FilterMode.IgnoreIfInParty => !LobbyData.PartyLobby(out lobby), 
			FilterMode.IgnoreIfInSession => !LobbyData.SessionLobby(out lobby), 
			FilterMode.IgnoreIfInAny => Matchmaking.Client.MemberOfLobbies.Count == 0, 
			_ => true, 
		};
	}

	private void Preprocess()
	{
		if (preprocess == PreprocessOptions.None)
		{
			return;
		}
		LobbyData[] array = Matchmaking.Client.MemberOfLobbies.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			switch (preprocess)
			{
			case PreprocessOptions.LeaveAllFirst:
				array[i].Leave();
				break;
			case PreprocessOptions.LeaveSessionFirst:
				if (array[i].IsSession)
				{
					array[i].Leave();
				}
				break;
			case PreprocessOptions.LeavePartyFirst:
				if (array[i].IsParty)
				{
					array[i].Leave();
				}
				break;
			}
		}
	}

	private void HandleInviteReceived(UserData user, LobbyData lobby, GameData game)
	{
		if (mode != JoinOnMode.WithInitialInvite || lobby.IsAMember(UserData.Me))
		{
			return;
		}
		Preprocess();
		if (CanProcess())
		{
			if (_mJoin != null)
			{
				_mJoin.Join(lobby);
			}
			else
			{
				Debug.LogWarning("To join a lobby you are invited to the GameObject must have a Steam Lobby Join component");
			}
		}
	}

	private void HandleInviteAccepted(LobbyData arg0, UserData arg1)
	{
		if (mode != JoinOnMode.AfterAcceptInFriendChat || arg0.IsAMember(UserData.Me))
		{
			return;
		}
		Preprocess();
		if (CanProcess())
		{
			if (_mJoin != null)
			{
				_mJoin.Join(arg0);
			}
			else
			{
				Debug.LogWarning("To join a lobby you are invited to the GameObject must have a Steam Lobby Join component");
			}
		}
	}

	public void OpenOverlay()
	{
		if (_mInspector.Data.IsValid)
		{
			Overlay.Client.ActivateInviteDialog(_mInspector.Data);
		}
		else
		{
			Debug.LogWarning("No lobby to invite to");
		}
	}

	public void InviteUser(UserData user)
	{
		if (_mInspector.Data.IsValid)
		{
			_mInspector.Data.InviteUserToLobby(user);
		}
		else
		{
			Debug.LogWarning("No lobby to invite to");
		}
	}
}
