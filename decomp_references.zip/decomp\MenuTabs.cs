using System;
using BongoCat;
using Steam;
using UnityEngine;
using UnityEngine.UI;

public class MenuTabs : MonoBehaviour
{
	public enum MenuTab
	{
		Inventory,
		Bongodecks,
		Multiplayer,
		Supporter,
		Settings,
		TrashBin
	}

	[SerializeField]
	private GameObject[] _inventorySpecific;

	public static Action<MenuTab> OnOpenTab;

	public static Action<MenuTab> OnCloseTab;

	private void Awake()
	{
		Tabs component = GetComponent<Tabs>();
		component.OnOpenTab = (Action<int>)Delegate.Combine(component.OnOpenTab, new Action<int>(OpenTab));
		Tabs component2 = GetComponent<Tabs>();
		component2.OnCloseTab = (Action<int>)Delegate.Combine(component2.OnCloseTab, new Action<int>(CloseTab));
		ItemExchange.OnOpenExchange = (Action)Delegate.Combine(ItemExchange.OnOpenExchange, new Action(OpenExchange));
		ItemExchange.OnCloseExchange = (Action)Delegate.Combine(ItemExchange.OnCloseExchange, new Action(CloseExchange));
	}

	private void OpenTab(int menuTab)
	{
		OpenMenuTab((MenuTab)menuTab);
	}

	public void OpenMenuTab(MenuTab menuTab)
	{
		GetComponentInChildren<ScrollRect>().verticalNormalizedPosition = 1f;
		OnOpenTab?.Invoke(menuTab);
		if (menuTab == MenuTab.Inventory)
		{
			GameObject[] inventorySpecific = _inventorySpecific;
			for (int i = 0; i < inventorySpecific.Length; i++)
			{
				inventorySpecific[i].SetActive(value: true);
			}
		}
		if (menuTab != MenuTab.TrashBin)
		{
			TrashCan.Instance.RestoreAllItems();
		}
	}

	private void CloseTab(int menuTab)
	{
		CloseMenuTab((MenuTab)menuTab);
	}

	private void CloseMenuTab(MenuTab menuTab)
	{
		ItemExchange.Instance.CloseExchange();
		OnCloseTab?.Invoke(menuTab);
	}

	private void OpenExchange()
	{
		GameObject[] inventorySpecific = _inventorySpecific;
		for (int i = 0; i < inventorySpecific.Length; i++)
		{
			inventorySpecific[i].SetActive(value: false);
		}
	}

	private void CloseExchange()
	{
		GameObject[] inventorySpecific = _inventorySpecific;
		for (int i = 0; i < inventorySpecific.Length; i++)
		{
			inventorySpecific[i].SetActive(value: true);
		}
	}
}
