using System.Collections.Generic;
using BongoCat;

namespace Tutorial;

public class DistinctCollectionsCondition : UnlockCondition
{
	public override int Current
	{
		get
		{
			HashSet<string> hashSet = new HashSet<string>();
			foreach (SteamItemRuntime item in CatInventory.Instance.Items)
			{
				if (item.IsOwned)
				{
					hashSet.Add(string.IsNullOrEmpty(item.Tag) ? item.QualityCategory.ToString() : item.Tag);
				}
			}
			return hashSet.Count;
		}
	}
}
