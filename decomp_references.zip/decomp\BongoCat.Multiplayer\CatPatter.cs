using System;
using BongoCat.Emotes;
using DG.Tweening;
using Heathen.SteamworksIntegration;
using Steamworks;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class CatPatter : MonoBehaviour
{
	[SerializeField]
	private SteamUserData _userData;

	[SerializeField]
	private EmoteSpawner _emoteSpawner;

	[SerializeField]
	private Sprite _heartIcon;

	private Vector3 _squishedScale;

	private Vector3 _expandedScale;

	private Sequence _seq;

	private bool _isMultiplayer;

	private void Start()
	{
		if ((bool)_userData)
		{
			_isMultiplayer = true;
			return;
		}
		SteamMultiplayer instance = SteamMultiplayer.Instance;
		instance.OnPatReceived = (Action<CSteamID>)Delegate.Combine(instance.OnPatReceived, new Action<CSteamID>(GetPat));
	}

	public void Pat()
	{
		if (!_isMultiplayer)
		{
			if (!SettingsManager.Instance.PatOwnCat.Value)
			{
				return;
			}
		}
		else
		{
			if (!SettingsManager.Instance.ReceivePats.Value)
			{
				return;
			}
			SteamMultiplayer.SendPat(_userData.Data);
		}
		PatSequence(1);
	}

	private void GetPat(CSteamID sender)
	{
		GetPat(1);
	}

	public void GetPat(int heartAmount = 0)
	{
		if (SettingsManager.Instance.ReceivePats.Value)
		{
			PatSequence(heartAmount);
		}
		else if (heartAmount > 0)
		{
			SpawnHearts(heartAmount);
		}
	}

	private Vector3 ScaledVector(float xMult, float yMult)
	{
		float num = (_isMultiplayer ? 1f : SettingsManager.Instance.CatScaleSetting.GetRealScaleFactor());
		return new Vector3(num * xMult, num * yMult, num);
	}

	private void PatSequence(int amount)
	{
		_seq?.Kill();
		Vector3 endValue = ScaledVector(1.15f, 0.85f);
		Vector3 endValue2 = ScaledVector(0.9f, 1.1f);
		Vector3 baseScale = ScaledVector(1f, 1f);
		_seq = DOTween.Sequence();
		_seq.SetLink(base.gameObject);
		_seq.Append(base.transform.DOScale(endValue, 0.2f)).SetEase(Ease.OutQuad);
		if (amount > 0 && !SettingsManager.Instance.HideEmotesSetting.Value)
		{
			_seq.AppendCallback(delegate
			{
				SpawnHearts(amount);
			});
		}
		_seq.Append(base.transform.DOScale(endValue2, 0.2f).SetEase(Ease.OutQuad));
		_seq.Append(base.transform.DOScale(baseScale, 0.3f));
		_seq.OnComplete(delegate
		{
			base.transform.localScale = baseScale;
		});
	}

	private void SpawnHearts(int amount)
	{
		if (!SettingsManager.Instance.HideEmotesSetting.Value && SettingsManager.Instance.ShowPatEmote.Value)
		{
			for (int i = 0; i < amount; i++)
			{
				_emoteSpawner.SpawnEmoteParticle(_heartIcon, EmoteBehaviorOverride.PetHearts);
			}
		}
	}

	private void OnDestroy()
	{
		if (!_isMultiplayer && (bool)SteamMultiplayer.Instance)
		{
			SteamMultiplayer instance = SteamMultiplayer.Instance;
			instance.OnPatReceived = (Action<CSteamID>)Delegate.Remove(instance.OnPatReceived, new Action<CSteamID>(GetPat));
		}
	}
}
