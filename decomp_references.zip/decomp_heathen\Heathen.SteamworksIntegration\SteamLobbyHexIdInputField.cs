using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyHexIdInputField : MonoBehaviour
{
	public TMP_InputField input;

	private SteamLobbyData _inspector;

	private void Awake()
	{
		_inspector = GetComponent<SteamLobbyData>();
		_inspector.onChanged.AddListener(HandleOnChanged);
		if (input != null)
		{
			input.text = _inspector.Data.ToString();
		}
	}

	private void OnDestroy()
	{
		_inspector.onChanged.RemoveListener(HandleOnChanged);
	}

	private void HandleOnChanged(LobbyData arg0)
	{
		if (_inspector.Data.IsValid)
		{
			if ((bool)input)
			{
				input.text = _inspector.Data.ToString();
			}
		}
		else if ((bool)input)
		{
			input.text = string.Empty;
		}
	}
}
