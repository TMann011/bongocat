using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;

namespace BongoCat;

public class RightClickEvent : MonoBehaviour, IPointerClickHandler, IEventSystemHandler
{
	[SerializeField]
	private UnityEvent _onLeftClick;

	[SerializeField]
	private UnityEvent _onRightClick;

	[SerializeField]
	private UnityEvent _onMiddleClick;

	public void OnPointerClick(PointerEventData eventData)
	{
		if (eventData.button == PointerEventData.InputButton.Left)
		{
			_onLeftClick?.Invoke();
		}
		if (eventData.button == PointerEventData.InputButton.Right)
		{
			_onRightClick?.Invoke();
		}
		if (eventData.button == PointerEventData.InputButton.Middle)
		{
			_onMiddleClick?.Invoke();
		}
	}
}
