namespace Heathen.SteamworksIntegration;

public interface ISteamUserData
{
	UserData Data { set; }
}
