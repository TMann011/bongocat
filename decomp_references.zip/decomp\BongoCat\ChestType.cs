namespace BongoCat;

public enum ChestType
{
	Cosmetic,
	Emote
}
