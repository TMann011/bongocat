using Heathen.SteamworksIntegration;
using Steamworks;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class SetLobbyVisibility : MonoBehaviour
{
	public void SetVisibility(int lobbyVisibility)
	{
		if (LobbyData.Current.IsValid)
		{
			if (!LobbyData.Current.IsOwner || LobbyData.Current.GetMetadata().ContainsKey("LOBBYCODE"))
			{
				SettingsManager.Instance.PrivateLobby.SetSelection((int)LobbyData.Current.Type, onlyUpdateVisuals: true);
			}
			else
			{
				LobbyData.Current.Type = (ELobbyType)lobbyVisibility;
			}
		}
	}
}
