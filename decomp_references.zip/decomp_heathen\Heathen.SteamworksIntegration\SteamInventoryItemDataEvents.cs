using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInventoryItemData))]
public class SteamInventoryItemDataEvents : MonoBehaviour
{
	public UnityEvent onChange = new UnityEvent();

	public UnityEvent onStateChanged = new UnityEvent();

	public UnityEvent<ItemDetail[]> onConsumeRequestComplete = new UnityEvent<ItemDetail[]>();

	public UnityEvent<SteamInventoryStartPurchaseResult_t> onPurchaseStarted = new UnityEvent<SteamInventoryStartPurchaseResult_t>();

	public UnityEvent<ulong> onOrderAuthorized = new UnityEvent<ulong>();

	public UnityEvent<ulong> onOrderNotAuthorized = new UnityEvent<ulong>();

	public UnityEvent<ItemDetail[]> onAddPromoComplete = new UnityEvent<ItemDetail[]>();

	public UnityEvent<bool> onCanExchangeChange = new UnityEvent<bool>();

	public UnityEvent<ItemDetail[]> onExchangeComplete = new UnityEvent<ItemDetail[]>();

	public UnityEvent onConsumeRequestRejected = new UnityEvent();

	public UnityEvent<EResult> onConsumeRequestFailed = new UnityEvent<EResult>();

	public UnityEvent<EResult> onPurchaseStartFailed = new UnityEvent<EResult>();

	public UnityEvent onAddPromoRejected = new UnityEvent();

	public UnityEvent<EResult> onAddPromoFailed = new UnityEvent<EResult>();

	public UnityEvent onExchangeRejected = new UnityEvent();

	public UnityEvent<EResult> onExchangeFailed = new UnityEvent<EResult>();

	private SteamInventoryItemData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamInventoryItemData>();
		Events.OnMicroTxnAuthorisationResponse += HandleTransactionAuth;
		Events.OnInventoryResultReady += HandleInvResultReady;
	}

	private void OnDestroy()
	{
		Events.OnMicroTxnAuthorisationResponse -= HandleTransactionAuth;
		Events.OnInventoryResultReady -= HandleInvResultReady;
	}

	private void HandleTransactionAuth(AppData arg0, ulong arg1, bool arg2)
	{
		if (arg0 == AppData.Me)
		{
			if (arg2)
			{
				onOrderAuthorized?.Invoke(arg1);
			}
			else
			{
				onOrderNotAuthorized?.Invoke(arg1);
			}
		}
	}

	private void HandleInvResultReady(InventoryResult arg0)
	{
		if (arg0.result != EResult.k_EResultOK)
		{
			return;
		}
		bool flag = false;
		ItemDetail[] items = arg0.items;
		foreach (ItemDetail itemDetail in items)
		{
			if (itemDetail.Definition == _mInspector.Data)
			{
				flag = true;
				break;
			}
		}
		if (flag)
		{
			onStateChanged?.Invoke();
		}
	}
}
