using System;
using System.Collections;
using System.Collections.Generic;
using BongoCat.Localizer;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Localization.Settings;
using UnityEngine.UI;

namespace BongoCat;

public class ScaleSetting : MonoBehaviour
{
	private int _index;

	private int _unappliedIndex;

	[SerializeField]
	private GameObject _applyButton;

	[SerializeField]
	private Slider _scaleSlider;

	[SerializeField]
	private TMP_Text _text;

	[SerializeField]
	private List<float> _scales;

	[SerializeField]
	private string KEY;

	[SerializeField]
	private GameObject _resetWarning;

	[SerializeField]
	private TMP_Text _resetCountdown;

	private Coroutine _resetRoutine;

	public UnityEvent<int> OnScaleApplied;

	public int Index => _index;

	private IEnumerator Start()
	{
		yield return null;
		_scales = RealWindowScale.Instance.GetScales(_scales);
		float num = PlayerPrefs.GetFloat(KEY, 1f);
		_index = _scales.IndexOf(num);
		if (_index == -1)
		{
			_index = 0;
			for (int i = 0; i < _scales.Count && !(_scales[i] >= num); i++)
			{
				_index = i;
			}
		}
		_unappliedIndex = _index;
		SettingsManager.Instance.MainScreenSetting.ScreenSwitched += UpdateScale;
		LocalizationSettings.SelectedLocaleChanged += delegate
		{
			DisplayText();
		};
		InitScaleSlider(_scaleSlider);
		UpdateScale();
	}

	public void InitScaleSlider(Slider slider)
	{
		slider.maxValue = _scales.Count - 1;
		slider.value = _index;
	}

	public void ResetUnappliedIndex()
	{
		if (_resetRoutine == null)
		{
			SetUnappliedScaleIndex(_index);
		}
	}

	public void SetUnappliedScaleIndex(float newIndex)
	{
		_unappliedIndex = (int)newIndex;
		_applyButton.SetActive(_unappliedIndex != _index);
		DisplayText(_scales[_unappliedIndex]);
		_scaleSlider.value = _unappliedIndex;
	}

	public void UpdateScale()
	{
		_index = _unappliedIndex;
		float num = _scales[_index];
		PlayerPrefs.SetFloat(KEY, num);
		PlayerPrefs.Save();
		DisplayText(num);
		OnScaleApplied?.Invoke(_index);
		_applyButton.SetActive(value: false);
		_scaleSlider.value = _index;
	}

	private void DisplayText()
	{
		DisplayText(_scales[_index]);
	}

	private void DisplayText(float scale)
	{
		_text.text = $"{Localize.Get(KEY)} {scale:G3}x";
	}

	public void TryApplyNewScale()
	{
		int index = _index;
		UpdateScale();
		_unappliedIndex = index;
		_resetRoutine = StartCoroutine(ResetRoutine());
	}

	private IEnumerator ResetRoutine()
	{
		_resetWarning.SetActive(value: true);
		for (int secondsLeft = 10; secondsLeft > 0; secondsLeft--)
		{
			_resetCountdown.text = Localize.Get("ScaleResetCountdown", secondsLeft);
			yield return new WaitForSeconds(1f);
		}
		_resetWarning.SetActive(value: false);
		ResetToPrevScale();
	}

	public void ApplyNewScale()
	{
		if (_resetRoutine != null)
		{
			StopCoroutine(_resetRoutine);
		}
		_unappliedIndex = _index;
	}

	public void ResetToPrevScale()
	{
		if (_resetRoutine != null)
		{
			StopCoroutine(_resetRoutine);
			_resetRoutine = null;
		}
		UpdateScale();
	}

	public void ResetScale()
	{
		_index = 2;
		UpdateScale();
	}

	public float GetRealScaleFactor(int index)
	{
		int val = (int)(450f * RealWindowScale.DpiScale * _scales[index]);
		val = Math.Min(Screen.mainWindowDisplayInfo.height, val);
		float num = (float)val / 450f;
		if (!((double)num <= 0.01))
		{
			return num;
		}
		return 1f;
	}

	public float GetRealScaleFactor()
	{
		int val = (int)(450f * RealWindowScale.DpiScale * _scales[_index]);
		val = Math.Min(Screen.mainWindowDisplayInfo.height, val);
		float num = (float)val / 450f;
		if (!((double)num <= 0.01))
		{
			return num;
		}
		return 1f;
	}

	public float GetScale()
	{
		return _scales[_index];
	}

	public List<float> GetAvailableScales()
	{
		return _scales;
	}
}
