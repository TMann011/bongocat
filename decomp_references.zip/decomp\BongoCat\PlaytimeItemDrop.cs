using System.Threading;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace BongoCat;

public class PlaytimeItemDrop : MonoBehaviour
{
	private Timer _timer;

	private void Start()
	{
		_timer = new Timer(delegate
		{
			if (Game.Inventory.Chest_Token.GetTotalQuantity() < 10 || Game.Inventory.Emote_Chest_Token.GetTotalQuantity() < 10)
			{
				Inventory.Client.TriggerItemDrop((SteamItemDef_t)10, delegate
				{
				});
			}
		}, null, 60000, 60000);
	}

	private void OnDisable()
	{
		_timer?.Dispose();
	}
}
