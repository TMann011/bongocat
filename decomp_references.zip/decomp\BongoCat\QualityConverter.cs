using BongoCat.SteamJsonParser;

namespace BongoCat;

public static class QualityConverter
{
	public static QualityCategoryWithInfo ToQualityWithInfo(this QualityCategory quality, bool isEmote)
	{
		return quality switch
		{
			QualityCategory.Common => isEmote ? QualityCategoryWithInfo.CommonEmote : QualityCategoryWithInfo.CommonCosmetic, 
			QualityCategory.Uncommon => isEmote ? QualityCategoryWithInfo.UncommonEmote : QualityCategoryWithInfo.UncommonCosmetic, 
			QualityCategory.Rare => isEmote ? QualityCategoryWithInfo.RareEmote : QualityCategoryWithInfo.RareCosmetic, 
			QualityCategory.Epic => isEmote ? QualityCategoryWithInfo.EpicEmote : QualityCategoryWithInfo.EpicCosmetic, 
			QualityCategory.Legendary => isEmote ? QualityCategoryWithInfo.LegendaryEmote : QualityCategoryWithInfo.LegendaryCosmetic, 
			QualityCategory.Special => isEmote ? QualityCategoryWithInfo.SpecialEmote : QualityCategoryWithInfo.SpecialCosmetic, 
			QualityCategory.Unique => isEmote ? QualityCategoryWithInfo.UniqueEmote : QualityCategoryWithInfo.UniqueCosmetic, 
		};
	}

	public static QualityCategory ToQuality(this QualityCategoryWithInfo qualityWithInfo)
	{
		return qualityWithInfo switch
		{
			QualityCategoryWithInfo.CommonCosmetic => QualityCategory.Common, 
			QualityCategoryWithInfo.UncommonCosmetic => QualityCategory.Uncommon, 
			QualityCategoryWithInfo.RareCosmetic => QualityCategory.Rare, 
			QualityCategoryWithInfo.EpicCosmetic => QualityCategory.Epic, 
			QualityCategoryWithInfo.LegendaryCosmetic => QualityCategory.Legendary, 
			QualityCategoryWithInfo.SpecialCosmetic => QualityCategory.Special, 
			QualityCategoryWithInfo.UniqueCosmetic => QualityCategory.Unique, 
			QualityCategoryWithInfo.CommonEmote => QualityCategory.Common, 
			QualityCategoryWithInfo.UncommonEmote => QualityCategory.Uncommon, 
			QualityCategoryWithInfo.RareEmote => QualityCategory.Rare, 
			QualityCategoryWithInfo.EpicEmote => QualityCategory.Epic, 
			QualityCategoryWithInfo.LegendaryEmote => QualityCategory.Legendary, 
			QualityCategoryWithInfo.SpecialEmote => QualityCategory.Special, 
			QualityCategoryWithInfo.UniqueEmote => QualityCategory.Unique, 
		};
	}
}
