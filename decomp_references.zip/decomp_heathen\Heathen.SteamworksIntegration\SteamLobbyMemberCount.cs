using SteamTools;
using Steamworks;
using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyMemberCount : MonoBehaviour
{
	public TextMeshProUGUI label;

	private SteamLobbyData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mInspector.onChanged.AddListener(HandleOnChanged);
		Events.OnLobbyChatUpdate += HandleChatUpdate;
		if (_mInspector.Data.IsValid)
		{
			label.text = _mInspector.Data.MemberCount.ToString();
		}
	}

	private void OnDestroy()
	{
		_mInspector.onChanged.RemoveListener(HandleOnChanged);
		Events.OnLobbyChatUpdate -= HandleChatUpdate;
	}

	private void HandleChatUpdate(LobbyData lobby, UserData user, EChatMemberStateChange state)
	{
		if (lobby == _mInspector.Data)
		{
			label.text = _mInspector.Data.MemberCount + "/" + _mInspector.Data.MaxMembers;
		}
	}

	private void HandleOnChanged(LobbyData arg0)
	{
		if (_mInspector.Data.IsValid)
		{
			label.text = _mInspector.Data.MemberCount + "/" + _mInspector.Data.MaxMembers;
		}
		else
		{
			label.text = "0";
		}
	}
}
