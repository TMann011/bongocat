using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Vfx;

[RequireComponent(typeof(Graphic))]
public class DestroyMaterialInstanceOnDestroy : MonoBehaviour
{
	private void OnDestroy()
	{
		Graphic component = GetComponent<Graphic>();
		if ((bool)component && (bool)component.material && component.material != component.defaultMaterial)
		{
			Object.Destroy(component.material);
		}
	}
}
