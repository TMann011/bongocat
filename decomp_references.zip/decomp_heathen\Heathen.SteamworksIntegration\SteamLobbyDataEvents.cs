using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyDataEvents : MonoBehaviour
{
	public LobbyDataEvent onLobbyChange;

	public UnityEvent<bool> onLobbySet;

	public UnityEvent<bool> onLobbyRemoved;

	public UnityEvent<string> onLobbyIdChanged;

	public UnityEvent<bool> onLobbySetIsOwner;

	public UnityEvent<bool> onLobbySetIsNotOwner;

	public UnityEvent<bool> onLobbySetIsMember;

	public UnityEvent<bool> onLobbySetIsNotMember;

	public UnityEvent<UserData, LobbyData, GameData> onLobbyInvite;

	public GameLobbyJoinRequestedEvent onLobbyJoinRequest;

	public LobbyChatMsgEvent onChatMessage;

	public LobbyDataListEvent onSearchResult;

	public LobbyDataEvent onEnterSuccess;

	public LobbyResponseEvent onEnterFailure;

	public LobbyDataEvent onCreate;

	public EResultEvent onCreationFailure;

	public UnityEvent onQuickMatchFailure;

	public UnityEvent<LobbyData, LobbyMemberData?> onDataUpdate;

	public UnityEvent onUserLeft;

	public UnityEvent onAskedToLeave;

	public GameServerSetEvent onGameCreate;

	public UserDataEvent onOtherUserJoined;

	public UserLeaveEvent onOtherUserLeft;

	public LobbyAuthenticaitonSessionEvent onAuthenticationSessionResult;

	private SteamLobbyData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mInspector.onChanged.AddListener(HandleOnChange);
		Events.OnAskedToLeaveLobby += HandleAskedToLeave;
		Events.OnLobbyDataUpdate += HandleLobbyDataUpdate;
		Events.OnLobbyLeave += HandleLobbyLeave;
		Events.OnLobbyGameServer += HandleGameServerSet;
		Events.OnLobbyChatUpdate += HandleChatUpdate;
		Events.OnLobbyAuthentication += HandleAuthRequest;
		Events.OnLobbyChatMsg += HandleChatMessage;
		Events.OnLobbyInvite += onLobbyInvite.Invoke;
		Events.OnLobbyJoinRequested += onLobbyJoinRequest.Invoke;
	}

	private void OnDestroy()
	{
		Events.OnAskedToLeaveLobby -= HandleAskedToLeave;
		Events.OnLobbyDataUpdate -= HandleLobbyDataUpdate;
		Events.OnLobbyLeave -= HandleLobbyLeave;
		Events.OnLobbyGameServer -= HandleGameServerSet;
		Events.OnLobbyChatUpdate -= HandleChatUpdate;
		Events.OnLobbyAuthentication -= HandleAuthRequest;
		Events.OnLobbyChatMsg -= HandleChatMessage;
		Events.OnLobbyInvite -= onLobbyInvite.Invoke;
		Events.OnLobbyJoinRequested -= onLobbyJoinRequest.Invoke;
	}

	private void HandleOnChange(LobbyData arg0)
	{
		onLobbySet?.Invoke(arg0.IsValid);
		if (arg0.IsValid)
		{
			onLobbySetIsOwner?.Invoke(arg0.IsOwner);
			onLobbySetIsNotOwner?.Invoke(!arg0.IsOwner);
			onLobbySetIsMember?.Invoke(arg0.IsAMember(UserData.Me));
			onLobbySetIsNotMember?.Invoke(!arg0.IsAMember(UserData.Me));
		}
		onLobbyRemoved?.Invoke(!arg0.IsValid);
		onLobbyIdChanged?.Invoke(arg0.IsValid ? arg0.HexId : string.Empty);
		onLobbyChange.Invoke(arg0);
	}

	private void HandleChatMessage(LobbyChatMsg message)
	{
		if (message.lobby == _mInspector.Data)
		{
			onChatMessage.Invoke(message);
		}
	}

	private void HandleAuthRequest(LobbyData lobby, UserData sender, byte[] ticket, byte[] inventory)
	{
		if (lobby == _mInspector.Data)
		{
			Authentication.BeginAuthSession(ticket, sender, delegate(AuthenticationSession session)
			{
				onAuthenticationSessionResult.Invoke(session, inventory);
			});
		}
	}

	private void HandleChatUpdate(LobbyData lobby, UserData user, EChatMemberStateChange state)
	{
		if (lobby == _mInspector.Data)
		{
			if (state == EChatMemberStateChange.k_EChatMemberStateChangeEntered)
			{
				onOtherUserJoined?.Invoke(user);
				return;
			}
			onOtherUserLeft?.Invoke(new UserLobbyLeaveData
			{
				user = user,
				state = state
			});
		}
	}

	private void HandleGameServerSet(LobbyData lobby, CSteamID serverId, string ip, ushort port)
	{
		if (lobby == _mInspector.Data)
		{
			onGameCreate.Invoke(_mInspector.Data.GameServer);
		}
	}

	private void HandleLobbyLeave(LobbyData arg0)
	{
		if (arg0 == _mInspector.Data)
		{
			_mInspector.Data = default(LobbyData);
			onUserLeft.Invoke();
		}
	}

	private void HandleAskedToLeave(LobbyData arg0)
	{
		if (arg0 == _mInspector.Data)
		{
			onAskedToLeave.Invoke();
		}
	}

	private void HandleLobbyDataUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		if (lobby == _mInspector.Data)
		{
			onDataUpdate.Invoke(lobby, member);
		}
	}
}
