using System.Collections;
using BongoCat.Achievements;
using BongoCat.SteamJsonParser;
using BongoCat.TokenRewards;
using Heathen.SteamworksIntegration;
using Steam;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat;

public class TokenItemReward : MonoBehaviour
{
	[SerializeField]
	private SteamItemBase _token;

	private SteamExchange _selectedBundle;

	[SerializeField]
	private GameObject _selectionUi;

	[SerializeField]
	private Button _confirmButton;

	private Coroutine _conditionCoroutine;

	private bool _hasAnyRewardItem;

	[SerializeField]
	private TokenRewardCondition _condition;

	[SerializeField]
	private bool _checkContinuously;

	private CatBobbing[] _catBobbings;

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		StartCoroutine(TryOpenUiDelayed());
		if (_checkContinuously)
		{
			_conditionCoroutine = StartCoroutine(CheckRewardConditionsRoutine());
		}
	}

	private IEnumerator TryOpenUiDelayed()
	{
		yield return new WaitForEndOfFrame();
		TryOpenUi();
	}

	private IEnumerator CheckRewardConditionsRoutine()
	{
		WaitForSeconds waitThirtySeconds = new WaitForSeconds(30f);
		while (!CheckRewardConditions())
		{
			yield return waitThirtySeconds;
		}
		_selectionUi.SetActive(value: true);
		_conditionCoroutine = null;
	}

	public void TryOpenUi()
	{
		if (CheckRewardConditions())
		{
			_selectionUi.SetActive(value: true);
			if (_conditionCoroutine != null)
			{
				StopCoroutine(_conditionCoroutine);
			}
			if ((bool)SettingsManager.Instance.CatBobbing)
			{
				_catBobbings = _selectionUi.GetComponentsInChildren<CatBobbing>();
				CatBobbing[] catBobbings = _catBobbings;
				for (int i = 0; i < catBobbings.Length; i++)
				{
					catBobbings[i].ToggleBobbingAnimation(toggle: true);
				}
			}
		}
		else
		{
			_selectionUi.SetActive(value: false);
		}
	}

	private bool CheckRewardConditions()
	{
		if (_token.ItemData.GetTotalQuantity() == 0L)
		{
			return false;
		}
		if ((bool)_condition)
		{
			return _condition.CheckRewardConditions();
		}
		return true;
	}

	public void SetSelectedItem(SteamExchange selectedBundle)
	{
		_selectedBundle = selectedBundle;
		_confirmButton.interactable = true;
	}

	public void ExchangeItems()
	{
		SteamAnalytics.Instance.SetStatToOne(_selectedBundle.name);
		_selectedBundle.Exchange(delegate((bool, ItemDetail[]) res)
		{
			if (res.Item1)
			{
				ItemDetail[] item = res.Item2;
				foreach (ItemDetail itemDetail in item)
				{
					NewItemPopup.Instance.ShowPopup(itemDetail.Definition.id);
					AchievementStats.IncrementItems();
				}
			}
		});
		if (_catBobbings != null)
		{
			CatBobbing[] catBobbings = _catBobbings;
			for (int num = 0; num < catBobbings.Length; num++)
			{
				catBobbings[num].KillBobbing();
			}
		}
		_selectionUi.SetActive(value: false);
	}
}
