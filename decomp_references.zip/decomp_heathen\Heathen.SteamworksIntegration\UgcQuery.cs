using System;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

public class UgcQuery : IDisposable
{
	public UGCQueryHandle_t Handle;

	public uint MatchedRecordCount;

	public uint PageCount = 1u;

	private bool _isAllQuery;

	private bool _isUserQuery;

	private EUserUGCList _listType;

	private EUGCQuery _queryType;

	private EUGCMatchingUGCType _matchingType;

	private EUserUGCListSortOrder _sortOrder;

	private AppId_t _creatorApp;

	private AppId_t _consumerApp;

	private AccountID_t _account;

	private uint _page = 1u;

	private UnityAction<UgcQuery> _callback;

	public CallResult<SteamUGCQueryCompleted_t> MSteamUgcQueryCompleted;

	public List<WorkshopItemDetails> ResultsList = new List<WorkshopItemDetails>();

	public uint Page
	{
		get
		{
			return _page;
		}
		set
		{
			SetPage(value);
		}
	}

	private UgcQuery()
	{
		MSteamUgcQueryCompleted = CallResult<SteamUGCQueryCompleted_t>.Create(HandleQueryCompleted);
	}

	public static UgcQuery Get(EUGCQuery queryType, EUGCMatchingUGCType matchingType, AppId_t creatorApp, AppId_t consumerApp)
	{
		return new UgcQuery
		{
			MatchedRecordCount = 0u,
			PageCount = 1u,
			_isAllQuery = true,
			_isUserQuery = false,
			_queryType = queryType,
			_matchingType = matchingType,
			_creatorApp = creatorApp,
			_consumerApp = consumerApp,
			Page = 1u,
			Handle = UserGeneratedContent.Client.CreateQueryAllRequest(queryType, matchingType, creatorApp, consumerApp, 1u)
		};
	}

	public static UgcQuery Get(params PublishedFileId_t[] fileIds)
	{
		if (fileIds == null || fileIds.Length < 1)
		{
			return null;
		}
		return new UgcQuery
		{
			MatchedRecordCount = 0u,
			PageCount = 1u,
			_isAllQuery = true,
			_isUserQuery = false,
			Page = 1u,
			Handle = UserGeneratedContent.Client.CreateQueryDetailsRequest(fileIds)
		};
	}

	public static UgcQuery Get(AccountID_t account, EUserUGCList listType, EUGCMatchingUGCType matchingType, EUserUGCListSortOrder sortOrder, AppId_t creatorApp, AppId_t consumerApp)
	{
		return new UgcQuery
		{
			MatchedRecordCount = 0u,
			PageCount = 1u,
			_isAllQuery = false,
			_isUserQuery = true,
			_listType = listType,
			_sortOrder = sortOrder,
			_matchingType = matchingType,
			_creatorApp = creatorApp,
			_consumerApp = consumerApp,
			_account = account,
			Page = 1u,
			Handle = UserGeneratedContent.Client.CreateQueryUserRequest(account, listType, matchingType, sortOrder, creatorApp, consumerApp, 1u)
		};
	}

	public static UgcQuery Get(UserData user, EUserUGCList listType, EUGCMatchingUGCType matchingType, EUserUGCListSortOrder sortOrder, AppId_t creatorApp, AppId_t consumerApp)
	{
		return new UgcQuery
		{
			MatchedRecordCount = 0u,
			PageCount = 1u,
			_isAllQuery = false,
			_isUserQuery = true,
			_listType = listType,
			_sortOrder = sortOrder,
			_matchingType = matchingType,
			_creatorApp = creatorApp,
			_consumerApp = consumerApp,
			_account = user.AccountId,
			Page = 1u,
			Handle = UserGeneratedContent.Client.CreateQueryUserRequest(user.AccountId, listType, matchingType, sortOrder, creatorApp, consumerApp, 1u)
		};
	}

	public static UgcQuery GetMyPublished()
	{
		UgcQuery ugcQuery = Get(UserData.Me, EUserUGCList.k_EUserUGCList_Published, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items_ReadyToUse, EUserUGCListSortOrder.k_EUserUGCListSortOrder_CreationOrderDesc, AppData.Me, AppData.Me);
		ugcQuery.SetReturnLongDescription(longDescription: true);
		ugcQuery.SetReturnMetadata(metadata: true);
		return ugcQuery;
	}

	public bool SetReturnLongDescription(bool longDescription)
	{
		return UserGeneratedContent.Client.SetReturnLongDescription(Handle, longDescription);
	}

	public bool SetReturnMetadata(bool metadata)
	{
		return UserGeneratedContent.Client.SetReturnMetadata(Handle, metadata);
	}

	public bool SetNextPage()
	{
		return SetPage((uint)Mathf.Clamp((int)(_page + 1), 1f, PageCount));
	}

	public bool SetPreviousPage()
	{
		return SetPage((uint)Mathf.Clamp((int)(_page - 1), 1f, PageCount));
	}

	public bool SetPage(uint page)
	{
		_page = ((page == 0) ? 1u : page);
		if (_isAllQuery)
		{
			ReleaseHandle();
			Handle = UserGeneratedContent.Client.CreateQueryAllRequest(_queryType, _matchingType, _creatorApp, _consumerApp, Page);
			MatchedRecordCount = 0u;
			return true;
		}
		if (_isUserQuery)
		{
			ReleaseHandle();
			Handle = UserGeneratedContent.Client.CreateQueryUserRequest(_account, _listType, _matchingType, _sortOrder, _creatorApp, _consumerApp, Page);
			MatchedRecordCount = 0u;
			return true;
		}
		Debug.LogError("Pages are not supported by detail queries e.g. searching for specific file Ids");
		return false;
	}

	public bool Execute(UnityAction<UgcQuery> callback)
	{
		if (Handle == UGCQueryHandle_t.Invalid)
		{
			Debug.LogError("Invalid handle, you must call CreateAll");
			return false;
		}
		ResultsList.Clear();
		_callback = callback;
		UserGeneratedContent.Client.SendQueryUgcRequest(Handle, HandleQueryCompleted);
		return true;
	}

	private void HandleQueryCompleted(SteamUGCQueryCompleted_t param, bool bIOFailure)
	{
		if (!bIOFailure)
		{
			if (param.m_eResult == EResult.k_EResultOK)
			{
				MatchedRecordCount = param.m_unTotalMatchingResults;
				PageCount = (uint)Mathf.Clamp((int)MatchedRecordCount / 50, 1, 2147483647);
				if (PageCount * 50 < MatchedRecordCount)
				{
					PageCount++;
				}
				for (int i = 0; i < param.m_unNumResultsReturned; i++)
				{
					UserGeneratedContent.Client.GetQueryResult(param.m_handle, (uint)i, out var details);
					WorkshopItemDetails workshopItemDetails = new WorkshopItemDetails(details);
					UserGeneratedContent.Client.GetQueryMetadata(param.m_handle, (uint)i, out workshopItemDetails.metadata, 5000u);
					workshopItemDetails.metadata?.Trim();
					uint queryNumKeyValueTags = UserGeneratedContent.Client.GetQueryNumKeyValueTags(param.m_handle, (uint)i);
					workshopItemDetails.keyValueTags = new StringKeyValuePair[queryNumKeyValueTags];
					for (int j = 0; j < queryNumKeyValueTags; j++)
					{
						UserGeneratedContent.Client.GetQueryKeyValueTag(param.m_handle, (uint)i, (uint)j, out var key, 255u, out var value, 255u);
						workshopItemDetails.keyValueTags[j].key = key?.Trim();
						workshopItemDetails.keyValueTags[j].value = value?.Trim();
					}
					ResultsList.Add(workshopItemDetails);
				}
				ReleaseHandle();
				if (_callback != null)
				{
					_callback(this);
				}
			}
			else
			{
				Debug.LogError("HeathenWorkitemQuery|HandleQueryCompleted Unexpected results, state = " + param.m_eResult);
			}
		}
		else
		{
			Debug.LogError("HeathenWorkitemQuery|HandleQueryCompleted failed.");
		}
	}

	public void ReleaseHandle()
	{
		if (Handle != UGCQueryHandle_t.Invalid)
		{
			UserGeneratedContent.Client.ReleaseQueryRequest(Handle);
			Handle = UGCQueryHandle_t.Invalid;
		}
	}

	public void Dispose()
	{
		try
		{
			ReleaseHandle();
		}
		catch
		{
		}
	}

	public static UgcQuery GetSubscribed(bool IncludeLocallyDisabled = false)
	{
		return Get(UserGeneratedContent.Client.GetSubscribedItems(IncludeLocallyDisabled));
	}
}
