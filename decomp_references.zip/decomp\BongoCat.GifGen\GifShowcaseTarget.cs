using UnityEngine;

namespace BongoCat.GifGen;

[DisallowMultipleComponent]
public class GifShowcaseTarget : MonoBehaviour
{
	public GifShowcaseRole Role;
}
