using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Helper;

[RequireComponent(typeof(ScrollRect))]
public class ScrollViewUpdater : MonoBehaviour
{
	[SerializeField]
	private bool _updateOnStart;

	[SerializeField]
	private List<RectTransform> _rebuildLayouts;

	private ScrollRect _scrollRect;

	private float _savedScrollPosition;

	private void Start()
	{
		if (_updateOnStart)
		{
			StartCoroutine(FixLayoutDelayed(resetScrollBar: true));
		}
	}

	[ContextMenu("Update Scroll Rect")]
	public void UpdateScrollRect()
	{
		StartCoroutine(FixLayoutDelayed(resetScrollBar: true));
	}

	public void UpdateScrollView(bool resetScrollBar = false)
	{
		if (base.gameObject.activeInHierarchy)
		{
			if (!_scrollRect)
			{
				_scrollRect = GetComponent<ScrollRect>();
			}
			_savedScrollPosition = _scrollRect.verticalNormalizedPosition;
			if (resetScrollBar)
			{
				_scrollRect.verticalNormalizedPosition = 1f;
			}
			StartCoroutine(FixLayoutDelayed(resetScrollBar));
		}
	}

	private IEnumerator FixLayoutDelayed(bool resetScrollBar)
	{
		yield return null;
		foreach (RectTransform rebuildLayout in _rebuildLayouts)
		{
			if ((bool)rebuildLayout)
			{
				LayoutRebuilder.ForceRebuildLayoutImmediate(rebuildLayout);
			}
		}
		yield return null;
		if (!resetScrollBar)
		{
			_scrollRect.verticalNormalizedPosition = _savedScrollPosition;
		}
	}
}
