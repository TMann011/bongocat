using System;
using BongoCat.SteamJsonParser;

namespace BongoCat.Emotes;

[Serializable]
public struct ConsumableBehaviorListEntry
{
	public SteamItemBase Consumable;

	public EmoteBehaviorOverride Behavior;
}
