using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyCreate : MonoBehaviour
{
	public enum SteamLobbyType
	{
		Private,
		FriendsOnly,
		Public,
		Invisible
	}

	[Tooltip("If true and creating a Party it will leave any existing lobby first, if true when creating a session it will notify any existing party of the new session lobby.")]
	public bool partyWise;

	[Tooltip("How will this lobby be used? This is an optional feature. If set to Party or Session then features of the LobbyData object can be used in code to fetch the created lobby such as LobbyData.GetGroup(...)")]
	public SteamLobbyModeType usageHint = SteamLobbyModeType.Session;

	[Tooltip("The number of slots the newly created lobby should have")]
	public int slots;

	[Tooltip("The type of lobby to create")]
	public SteamLobbyType type;

	private SteamLobbyData _mInspector;

	private SteamLobbyDataEvents _mEvents;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mEvents = GetComponent<SteamLobbyDataEvents>();
	}

	public void Create()
	{
		LobbyData partyLobby = CSteamID.Nil;
		if (partyWise && LobbyData.PartyLobby(out partyLobby) && usageHint == SteamLobbyModeType.Party)
		{
			partyLobby.Leave();
			partyLobby = CSteamID.Nil;
		}
		if (partyLobby.IsValid && !partyLobby.IsOwner)
		{
			Debug.LogWarning("Only a party lobby leader can create lobbies");
			return;
		}
		LobbyData.Create((ELobbyType)type, usageHint, slots, delegate(EResult createResult, LobbyData createdLobby, bool createIoError)
		{
			if (!createIoError && createResult == EResult.k_EResultOK)
			{
				_mInspector.Data = createdLobby;
				if (_mEvents != null)
				{
					_mEvents.onCreate?.Invoke(createdLobby);
				}
				if (partyLobby.IsValid && usageHint == SteamLobbyModeType.Session)
				{
					if (type == SteamLobbyType.Private)
					{
						LobbyMemberData[] members = partyLobby.Members;
						for (int i = 0; i < members.Length; i++)
						{
							LobbyMemberData lobbyMemberData = members[i];
							if (!lobbyMemberData.user.IsMe)
							{
								lobbyMemberData.user.InviteToLobby(createdLobby);
							}
						}
					}
					else
					{
						partyLobby["z_heathenSessionLobby"] = createdLobby.ToString();
					}
				}
			}
			else if (_mEvents != null)
			{
				_mEvents.onCreationFailure?.Invoke(createResult);
			}
		});
	}
}
