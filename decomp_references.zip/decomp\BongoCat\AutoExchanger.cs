using System.Collections;
using System.Collections.Generic;
using BongoCat.Achievements;
using BongoCat.SteamJsonParser;
using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat;

public class AutoExchanger : MonoBehaviour
{
	[SerializeField]
	private List<SteamExchange> _exchangesToPerform;

	[SerializeField]
	private int _timer = 30;

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		StartCoroutine(AutoExchangeRoutine());
	}

	private IEnumerator AutoExchangeRoutine()
	{
		while (true)
		{
			foreach (SteamExchange item2 in _exchangesToPerform)
			{
				item2.Exchange(delegate((bool, ItemDetail[]) res)
				{
					if (res.Item1)
					{
						ItemDetail[] item = res.Item2;
						foreach (ItemDetail itemDetail in item)
						{
							NewItemPopup.Instance.ShowPopup(itemDetail.Definition.id);
							AchievementStats.IncrementItems();
						}
					}
				});
				yield return new WaitForSeconds(1f);
			}
			yield return new WaitForSeconds(_timer);
		}
	}
}
