using System.Collections.Generic;
using UnityEngine;

public class PlayerDataCache : MonoBehaviour
{
	private class PlayerData
	{
		public bool IsHidden;

		public int Rotation;

		public bool IsFlipped;

		private Vector2? _posRelative;

		public Vector2? Position
		{
			get
			{
				if (!_posRelative.HasValue)
				{
					return null;
				}
				return new Vector2(_posRelative.Value.x * (float)ScreenHelper.FullWidth, _posRelative.Value.y * (float)ScreenHelper.FullHeight);
			}
			set
			{
				if (!value.HasValue)
				{
					_posRelative = null;
				}
				else
				{
					_posRelative = new Vector2(value.Value.x / (float)ScreenHelper.FullWidth, value.Value.y / (float)ScreenHelper.FullHeight);
				}
			}
		}
	}

	private static readonly Dictionary<string, PlayerData> _playerDataCache = new Dictionary<string, PlayerData>();

	private void Awake()
	{
		_playerDataCache.Clear();
	}

	public static bool GetIsHidden(string id)
	{
		CheckEntry(id);
		return _playerDataCache[id].IsHidden;
	}

	public static void SetIsHidden(string id, bool isHidden)
	{
		CheckEntry(id);
		_playerDataCache[id].IsHidden = isHidden;
	}

	public static Vector2? GetPos(string id)
	{
		CheckEntry(id);
		return _playerDataCache[id].Position;
	}

	public static void SetPos(string id, Vector3 pos)
	{
		CheckEntry(id);
		_playerDataCache[id].Position = pos;
	}

	public static int GetRot(string id)
	{
		CheckEntry(id);
		return _playerDataCache[id].Rotation;
	}

	public static void SetRot(string id, int rot)
	{
		CheckEntry(id);
		_playerDataCache[id].Rotation = rot;
	}

	public static bool GetFlipped(string id)
	{
		CheckEntry(id);
		return _playerDataCache[id].IsFlipped;
	}

	public static void SetFlipped(string id, bool isFlipped)
	{
		CheckEntry(id);
		_playerDataCache[id].IsFlipped = isFlipped;
	}

	public static void ClearPositions()
	{
		foreach (PlayerData value in _playerDataCache.Values)
		{
			value.Position = null;
		}
	}

	private static void CheckEntry(string id)
	{
		if (!_playerDataCache.ContainsKey(id))
		{
			_playerDataCache.Add(id, new PlayerData());
		}
	}
}
