using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public class CatSlot
{
	public Vector2 Position;

	public int RotationState;

	public ISlotOccupant Occupant;

	public bool Disabled;

	public bool ReservedForMainCat;
}
