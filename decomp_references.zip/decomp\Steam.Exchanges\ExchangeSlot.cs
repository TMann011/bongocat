using BongoCat;
using BongoCat.SteamJsonParser;
using UnityEngine;
using UnityEngine.UI;

namespace Steam.Exchanges;

public class ExchangeSlot : MonoBehaviour
{
	[SerializeField]
	private Image _icon;

	public SteamItemRuntime ItemSlotted;

	[SerializeField]
	private Image _borderImage;

	private long _slottedAmount;

	public long SlottedAmount => _slottedAmount;

	private void OnDisable()
	{
		SetItem(null, 1L);
	}

	public void SetItem(SteamItemRuntime item, long amount = 1L)
	{
		SteamItemRuntime itemSlotted = ItemSlotted;
		ItemSlotted = item;
		if (item == null)
		{
			_icon.sprite = null;
			_icon.enabled = false;
			_borderImage.color = Color.clear;
			if (itemSlotted != null)
			{
				if (itemSlotted.CurrentlyInExchangeSlot > 0)
				{
					itemSlotted.CurrentlyInExchangeSlot -= _slottedAmount;
				}
				itemSlotted.OnItemUpdated?.Invoke();
			}
		}
		else
		{
			_slottedAmount = amount;
			item.CurrentlyInExchangeSlot += amount;
			item.OnItemUpdated?.Invoke();
			_icon.sprite = item.Icon;
			_icon.enabled = true;
			_borderImage.color = item.QualityCategory.GetColor();
		}
	}

	public void OnClick()
	{
		if (ItemSlotted != null)
		{
			SetItem(null, 1L);
			ItemExchange.Instance.UpdateInteractable();
			CatInventory.Instance.UpdateItemsUI();
			CatInventory.Instance.UpdateScrollView();
		}
	}
}
