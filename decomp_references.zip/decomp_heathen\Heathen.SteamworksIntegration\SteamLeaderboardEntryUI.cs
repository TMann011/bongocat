using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamUserData))]
public class SteamLeaderboardEntryUI : MonoBehaviour, ILeaderboardEntryDisplay
{
	[SerializeField]
	private TextMeshProUGUI score;

	[SerializeField]
	private TextMeshProUGUI rank;

	private SteamUserData _userData;

	private LeaderboardEntry _entry;

	public LeaderboardEntry Entry
	{
		get
		{
			return _entry;
		}
		set
		{
			SetEntry(value);
		}
	}

	private void Awake()
	{
		_userData = GetComponent<SteamUserData>();
	}

	private void SetEntry(LeaderboardEntry entry)
	{
		_userData.Data = entry.User;
		if (score != null)
		{
			score.text = entry.Score.ToString();
		}
		if (rank != null)
		{
			rank.text = entry.Rank.ToString();
		}
		_entry = entry;
	}
}
