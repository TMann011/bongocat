using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamLobbyResponseDisplay : MonoBehaviour
{
	public float hideAfterSeconds;

	[FormerlySerializedAs("Success")]
	public SteamText success = new SteamText("Success");

	[FormerlySerializedAs("DoesntExist")]
	public SteamText doesntExist = new SteamText("Chat doesn't exist (probably closed)");

	[FormerlySerializedAs("NotAllowed")]
	public SteamText notAllowed = new SteamText("General Denied - You don't have the permissions needed to join the chat");

	[FormerlySerializedAs("Full")]
	public SteamText full = new SteamText("Chat room has reached its maximum size");

	[FormerlySerializedAs("Error")]
	public SteamText error = new SteamText("Unexpected Error");

	[FormerlySerializedAs("Banned")]
	public SteamText banned = new SteamText("You are banned from this chat room and may not join");

	[FormerlySerializedAs("Limited")]
	public SteamText limited = new SteamText("Joining this chat is not allowed because you are a limited user (no value on account)");

	[FormerlySerializedAs("ClanDisabled")]
	public SteamText clanDisabled = new SteamText("Attempt to join a clan chat when the clan is locked or disabled");

	[FormerlySerializedAs("CommunityBan")]
	public SteamText communityBan = new SteamText("Attempt to join a chat when the user has a community lock on their account");

	[FormerlySerializedAs("MemberBlockedYou")]
	public SteamText memberBlockedYou = new SteamText("Join failed - some member in the chat has blocked you from joining");

	[FormerlySerializedAs("YouBlockedMember")]
	public SteamText youBlockedMember = new SteamText("Join failed - you have blocked some member already in the chat");

	[FormerlySerializedAs("RateLimitExceeded")]
	public SteamText rateLimitExceeded = new SteamText("Join failed - to many join attempts in a very short period of time");

	public TMP_InputField outputElement;

	public GameObject displayElement;

	public UnityEvent onDisplay;

	public UnityEvent onHide;

	private void Start()
	{
		if (outputElement != null)
		{
			outputElement.readOnly = true;
		}
	}

	public string GetString(EChatRoomEnterResponse response)
	{
		return response switch
		{
			EChatRoomEnterResponse.k_EChatRoomEnterResponseBanned => banned, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseClanDisabled => clanDisabled, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseCommunityBan => communityBan, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseDoesntExist => doesntExist, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseError => error, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseFull => full, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseLimited => limited, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseMemberBlockedYou => memberBlockedYou, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseNotAllowed => notAllowed, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseRatelimitExceeded => rateLimitExceeded, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseSuccess => success, 
			EChatRoomEnterResponse.k_EChatRoomEnterResponseYouBlockedMember => youBlockedMember, 
			_ => string.Empty, 
		};
	}

	public void DisplayResponse(EChatRoomEnterResponse response)
	{
		if (outputElement != null)
		{
			outputElement.text = GetString(response);
		}
		if (displayElement != null)
		{
			displayElement.SetActive(value: true);
		}
		onDisplay?.Invoke();
		if (hideAfterSeconds > 0f)
		{
			CancelInvoke("HideDisplay");
			Invoke("HideDisplay", hideAfterSeconds);
		}
	}

	public void HideDisplay()
	{
		if (displayElement != null)
		{
			displayElement.SetActive(value: false);
		}
		onHide?.Invoke();
	}
}
