namespace Heathen.SteamworksIntegration;

public enum AchievementAttributes
{
	Name,
	Desc,
	Hidden
}
