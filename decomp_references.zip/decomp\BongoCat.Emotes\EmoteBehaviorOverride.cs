namespace BongoCat.Emotes;

public enum EmoteBehaviorOverride
{
	None,
	Rocket,
	AfkTimer,
	PetHearts,
	FlyingGift
}
