using System.Collections.Generic;

namespace BongoCat.Multiplayer.Spawning;

public interface ICatSpawnPattern
{
	SpawnControls Controls { get; }

	float MaxDistancePercent { get; }

	float MaxVerticalDistancePercent { get; }

	bool ComputesSlots { get; }

	bool PlayerAuthoredSlots { get; }

	bool KeepsCatsOnTheirSlots { get; }

	bool AnchoredOnMainCat { get; }

	bool IncludesMainCat { get; }

	int RotationState { get; }

	AnchorCorners[] OfferedAnchorCorners { get; }

	AnchorCorners ResolvedAnchorCorner { get; }

	List<CatSlot> CreateSlots();
}
