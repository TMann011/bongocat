using System;
using System.Collections.Generic;
using System.Linq;
using BongoCat.SteamJsonParser;
using UnityEngine;

namespace BongoCat;

public class ShowIfItemInInventory : MonoBehaviour
{
	[SerializeField]
	private GameObject _visual;

	[SerializeField]
	private int _itemId;

	[SerializeField]
	private List<SteamItemBase> _otherOptionalItems;

	[SerializeField]
	private List<SteamExchange> _optionalExchanges;

	[SerializeField]
	private bool _invert;

	private void Start()
	{
		SteamItemRuntime steamItemRuntime = SteamItemIdReference.Inst[_itemId];
		steamItemRuntime.OnItemUpdated = (Action)Delegate.Combine(steamItemRuntime.OnItemUpdated, new Action(OnTokenUpdated));
		OnTokenUpdated();
	}

	private void OnDestroy()
	{
		if ((bool)SteamItemIdReference.Inst)
		{
			SteamItemRuntime steamItemRuntime = SteamItemIdReference.Inst[_itemId];
			if (steamItemRuntime != null)
			{
				steamItemRuntime.OnItemUpdated = (Action)Delegate.Remove(steamItemRuntime.OnItemUpdated, new Action(OnTokenUpdated));
			}
		}
	}

	private void OnTokenUpdated()
	{
		if (_otherOptionalItems == null)
		{
			_otherOptionalItems = new List<SteamItemBase>();
		}
		if ((bool)_visual)
		{
			bool flag = SteamItemIdReference.Inst[_itemId].RuntimeData.GetTotalQuantity() > 0 || _otherOptionalItems.Exists((SteamItemBase item) => SteamItemIdReference.Inst[item.Id].RuntimeData.GetTotalQuantity() > 0) || _optionalExchanges.Any((SteamExchange exc) => exc.CanExchange());
			if (_invert)
			{
				flag = !flag;
			}
			_visual.SetActive(flag);
		}
	}
}
