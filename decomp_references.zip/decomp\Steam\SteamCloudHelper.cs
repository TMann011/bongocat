using System;
using System.Text;
using Newtonsoft.Json;
using Steamworks;
using UnityEngine;

namespace Steam;

public static class SteamCloudHelper
{
	public static void SaveToCloud<T>(string fileName, T data)
	{
		try
		{
			string s = JsonConvert.SerializeObject(data);
			byte[] bytes = Encoding.UTF8.GetBytes(s);
			SteamRemoteStorage.FileWrite(fileName, bytes, bytes.Length);
		}
		catch (Exception ex)
		{
			Debug.LogWarning("Cloud save failed for '" + fileName + "': " + ex.Message);
		}
	}

	public static bool TryLoadFromCloud<T>(string fileName, out T data)
	{
		try
		{
			if (SteamRemoteStorage.FileExists(fileName))
			{
				int fileSize = SteamRemoteStorage.GetFileSize(fileName);
				byte[] array = new byte[fileSize];
				SteamRemoteStorage.FileRead(fileName, array, fileSize);
				string value = Encoding.UTF8.GetString(array);
				data = JsonConvert.DeserializeObject<T>(value);
				return data != null;
			}
		}
		catch (Exception ex)
		{
			Debug.LogWarning("Cloud load failed for '" + fileName + "': " + ex.Message);
		}
		data = default(T);
		return false;
	}
}
