using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamWorkshopItemEditorData))]
public class SteamWorkshopItemEditorCreateAndUpdate : MonoBehaviour
{
	public string metadata;

	public string[] additionalYouTubeIds;

	public WorkshopItemPreviewFile[] additionalPreviews;

	public WorkshopItemKeyValueTag[] additionalKeyValueTags;

	public string[] tags;

	private SteamWorkshopItemEditorData _inspector;

	private SteamWorkshopItemEditorDataEvents _events;

	private void Awake()
	{
		_inspector = GetComponent<SteamWorkshopItemEditorData>();
		_events = GetComponent<SteamWorkshopItemEditorDataEvents>();
	}

	public void CreateNew()
	{
		WorkshopItemEditorData data = _inspector.Data;
		data.visibility = ERemoteStoragePublishedFileVisibility.k_ERemoteStoragePublishedFileVisibilityPrivate;
		data.metadata = metadata;
		data.tags = tags;
		_inspector.Data = data;
		data.Create(additionalPreviews, additionalYouTubeIds, additionalKeyValueTags, HandleCompleted, HandleUploaded, HandleFileCreated);
	}

	public void CreateOrUpdate()
	{
		WorkshopItemEditorData data = _inspector.Data;
		data.metadata = metadata;
		data.tags = tags;
		_inspector.Data = data;
		if (data.PublishedFileId.HasValue)
		{
			data.Update(HandleUpdateCompleted, HandleUploaded);
			return;
		}
		data.visibility = ERemoteStoragePublishedFileVisibility.k_ERemoteStoragePublishedFileVisibilityPrivate;
		data.Create(additionalPreviews, additionalYouTubeIds, additionalKeyValueTags, HandleCompleted, HandleUploaded, HandleFileCreated);
	}

	private void HandleUpdateCompleted(WorkshopItemDataUpdateStatus status)
	{
		_inspector.Data = status.Data;
		if (status.HasError)
		{
			if ((bool)_events)
			{
				EResult arg = EResult.k_EResultFail;
				if (status.SubmitItemUpdateResult.HasValue)
				{
					arg = status.SubmitItemUpdateResult.Value.m_eResult;
				}
				_events.onCreateUpdateError?.Invoke(arg, status.ErrorMessage);
			}
		}
		else if ((bool)_events)
		{
			_events.onCreateUpdateSuccess?.Invoke();
		}
	}

	private void HandleFileCreated(CreateItemResult_t t)
	{
		if (t.m_eResult == EResult.k_EResultOK)
		{
			WorkshopItemEditorData data = _inspector.Data;
			data.PublishedFileId = t.m_nPublishedFileId;
			_inspector.Data = data;
		}
	}

	private void HandleUploaded(UGCUpdateHandle_t t)
	{
	}

	private void HandleCompleted(WorkshopItemDataCreateStatus status)
	{
		_inspector.Data = status.Data;
		if (status.HasError)
		{
			EResult arg = EResult.k_EResultFail;
			if (status.SubmitItemUpdateResult.HasValue)
			{
				arg = status.SubmitItemUpdateResult.Value.m_eResult;
			}
			else if (status.CreateItemResult.HasValue)
			{
				arg = status.CreateItemResult.Value.m_eResult;
			}
			if (_events != null)
			{
				_events.onCreateUpdateError?.Invoke(arg, status.ErrorMessage);
			}
		}
		else if (_events != null)
		{
			_events.onCreateUpdateSuccess?.Invoke();
			CreateItemResult_t? createItemResult = status.CreateItemResult;
			if (createItemResult.HasValue && createItemResult.GetValueOrDefault().m_bUserNeedsToAcceptWorkshopLegalAgreement)
			{
				_events.onUserNeedsToAcceptWorkshopAgreement?.Invoke();
			}
		}
	}
}
