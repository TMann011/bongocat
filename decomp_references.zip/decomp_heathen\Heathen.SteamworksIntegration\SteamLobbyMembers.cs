using System;
using System.Collections.Generic;
using System.Linq;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyMembers : MonoBehaviour
{
	[Serializable]
	public class Attributes
	{
		[Tooltip("If true the local user's display will be shown otherwise we skip the local user")]
		public bool showSelf;

		[Tooltip("This game object will be instantiated for each member that joins and managed by the component")]
		public SteamLobbyMemberData template;

		[Tooltip("The container where member templates will be spawned as members join or removed from when members leave.")]
		public Transform content;
	}

	public Attributes attributes = new Attributes();

	private SteamLobbyData _mInspector;

	private List<SteamLobbyMemberData> _mSpawnedMembers = new List<SteamLobbyMemberData>();

	private List<(UserData, EChatMemberStateChange)> _updates = new List<(UserData, EChatMemberStateChange)>();

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mInspector.onChanged.AddListener(HandleLobbyChanged);
		Events.OnLobbyChatUpdate += GlobalChatUpdate;
	}

	private void OnDestroy()
	{
		_mInspector?.onChanged.RemoveListener(HandleLobbyChanged);
		Events.OnLobbyChatUpdate -= GlobalChatUpdate;
	}

	private void HandleLobbyChanged(LobbyData arg0)
	{
		foreach (SteamLobbyMemberData mSpawnedMember in _mSpawnedMembers)
		{
			UnityEngine.Object.Destroy(mSpawnedMember.gameObject);
		}
		_mSpawnedMembers.Clear();
		if (!_mInspector.Data.IsValid)
		{
			return;
		}
		LobbyMemberData lobbyMemberData = _mInspector.Data.Members.First((LobbyMemberData data) => data.IsOwner);
		AddMember(lobbyMemberData);
		LobbyMemberData lobbyMemberData2 = _mInspector.Data.Members.First((LobbyMemberData data) => data.user == UserData.Me);
		if (lobbyMemberData != lobbyMemberData2)
		{
			AddMember(lobbyMemberData2);
		}
		LobbyMemberData[] members = _mInspector.Data.Members;
		foreach (LobbyMemberData lobbyMemberData3 in members)
		{
			if (!(lobbyMemberData3 == lobbyMemberData) && !(lobbyMemberData3 == lobbyMemberData2))
			{
				AddMember(lobbyMemberData3);
			}
		}
	}

	private void GlobalChatUpdate(LobbyData lobby, UserData user, EChatMemberStateChange state)
	{
		if (lobby == _mInspector.Data)
		{
			_updates.Add((user, state));
		}
	}

	private void LateUpdate()
	{
		if (_updates.Count == 0)
		{
			return;
		}
		foreach (var update in _updates)
		{
			var (u, eChatMemberStateChange) = update;
			if (eChatMemberStateChange == EChatMemberStateChange.k_EChatMemberStateChangeEntered)
			{
				if (!_updates.Any(((UserData, EChatMemberStateChange) p) => p.Item1 == u && p.Item2 != EChatMemberStateChange.k_EChatMemberStateChangeEntered))
				{
					AddMember(LobbyMemberData.Get(_mInspector.Data, u));
				}
			}
			else if (!_updates.Any(((UserData, EChatMemberStateChange) p) => p.Item1 == u && p.Item2 == EChatMemberStateChange.k_EChatMemberStateChangeEntered))
			{
				RemoveMember(new UserLobbyLeaveData
				{
					user = u,
					state = eChatMemberStateChange
				});
			}
		}
		_updates.Clear();
	}

	private void AddMember(LobbyMemberData data)
	{
		if ((attributes.showSelf || !(data.user == UserData.Me)) && (bool)attributes.template && (bool)attributes.content)
		{
			SteamLobbyMemberData component = UnityEngine.Object.Instantiate(attributes.template, attributes.content).GetComponent<SteamLobbyMemberData>();
			component.Data = data;
			_mSpawnedMembers.Add(component);
		}
	}

	private void RemoveMember(UserLobbyLeaveData data)
	{
		SteamLobbyMemberData steamLobbyMemberData = _mSpawnedMembers.Find((SteamLobbyMemberData p) => p.Data.user == data.user);
		if ((bool)steamLobbyMemberData)
		{
			_mSpawnedMembers.Remove(steamLobbyMemberData);
			UnityEngine.Object.Destroy(steamLobbyMemberData.gameObject);
		}
	}
}
