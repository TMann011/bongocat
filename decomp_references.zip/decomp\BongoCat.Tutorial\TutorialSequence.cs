using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Tutorial;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Tutorial;

public class TutorialSequence : MonoBehaviour
{
	[Serializable]
	private class TemporaryPlayerPref
	{
		public PlayerPrefsToggle PlayerPrefsToggle;

		public bool Value;
	}

	[SerializeField]
	private TemporaryPlayerPref[] _tmpPlayerPrefsValues;

	[SerializeField]
	private GameObject[] _hiddenForTutorial;

	[SerializeField]
	private Image _backgroundPanel;

	private List<TutorialStep> _steps = new List<TutorialStep>();

	private int _index;

	private IEnumerator Start()
	{
		if (TutorialUnlocks.HasFlag(TutorialUnlocks.TutorialTasks.FinishedInitTutorial))
		{
			base.gameObject.SetActive(value: false);
			yield break;
		}
		yield return null;
		yield return null;
		yield return null;
		if (!Application.isEditor)
		{
			yield return new WaitUntil(() => SettingsManager.Instance.MainScreenSetting.IsInitialized);
		}
		SetupObjectsForTutorial();
		BeginCurrent();
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.Space))
		{
			Advance();
		}
	}

	public void Advance()
	{
		_index++;
		BeginCurrent();
	}

	private void BeginCurrent()
	{
		if (_index >= _steps.Count)
		{
			FinishTutorial();
			return;
		}
		TutorialStep tutorialStep = _steps[_index];
		if (tutorialStep.ShouldSkip())
		{
			Advance();
		}
		else
		{
			tutorialStep.Begin();
		}
	}

	private void FinishTutorial()
	{
		TutorialUnlocks.SetFlag(TutorialUnlocks.TutorialTasks.FinishedInitTutorial);
		ResetObjectsAfterTutorial();
		base.gameObject.SetActive(value: false);
	}

	private void SetupObjectsForTutorial()
	{
		GetComponentsInChildren(includeInactive: true, _steps);
		foreach (TutorialStep step in _steps)
		{
			step.onCompleted.AddListener(Advance);
		}
		_backgroundPanel.color = new Color(_backgroundPanel.color.r, _backgroundPanel.color.g, _backgroundPanel.color.b, 0f);
		_backgroundPanel.gameObject.SetActive(value: true);
		_backgroundPanel.DOFade(1f, 0.5f);
		MainCat.Instance.Reset();
		foreach (TutorialStep step2 in _steps)
		{
			step2.gameObject.SetActive(value: false);
		}
		TemporaryPlayerPref[] tmpPlayerPrefsValues = _tmpPlayerPrefsValues;
		foreach (TemporaryPlayerPref temporaryPlayerPref in tmpPlayerPrefsValues)
		{
			if (temporaryPlayerPref.Value)
			{
				temporaryPlayerPref.PlayerPrefsToggle.ToggleOn();
			}
			else
			{
				temporaryPlayerPref.PlayerPrefsToggle.ToggleOff();
			}
		}
		GameObject[] hiddenForTutorial = _hiddenForTutorial;
		for (int i = 0; i < hiddenForTutorial.Length; i++)
		{
			hiddenForTutorial[i].gameObject.SetActive(value: false);
		}
	}

	private void ResetObjectsAfterTutorial()
	{
		TemporaryPlayerPref[] tmpPlayerPrefsValues = _tmpPlayerPrefsValues;
		for (int i = 0; i < tmpPlayerPrefsValues.Length; i++)
		{
			tmpPlayerPrefsValues[i].PlayerPrefsToggle.ToggleDefault();
		}
		GameObject[] hiddenForTutorial = _hiddenForTutorial;
		for (int i = 0; i < hiddenForTutorial.Length; i++)
		{
			hiddenForTutorial[i].gameObject.SetActive(value: true);
		}
	}

	public void FadeOutBackground()
	{
		_backgroundPanel.DOFade(0f, 1f).OnComplete(delegate
		{
			_backgroundPanel.gameObject.SetActive(value: false);
			_backgroundPanel.color = new Color(_backgroundPanel.color.r, _backgroundPanel.color.g, _backgroundPanel.color.b, 1f);
		});
	}
}
