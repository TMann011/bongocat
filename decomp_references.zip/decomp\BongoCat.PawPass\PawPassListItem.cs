using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassListItem : MonoBehaviour
{
	[SerializeField]
	private Image _icon;

	[SerializeField]
	private LocalizeStringEvent _passName;

	[SerializeField]
	private GameObject _buyPass;

	public PawPassEntity Pass;

	public void Setup(PawPassEntity pass)
	{
		Pass = pass;
		_icon.sprite = pass.Icon;
		_passName.StringReference = pass.Subtitle;
		_buyPass.SetActive(!pass.HasPremiumPass);
	}

	public void Select()
	{
		PawPassManager.Instance.ShowPass(Pass);
	}

	public void BuyPass()
	{
		PawPassManager.Instance.UnlockPremiumPass(Pass);
	}
}
