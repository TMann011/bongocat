using System;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct TimelineEventData : IEquatable<TimelineEventHandle_t>, IEquatable<ulong>, IComparable<TimelineEventHandle_t>, IComparable<ulong>
{
	[SerializeField]
	private TimelineEventHandle_t handle;

	public ulong Id => handle.m_TimelineEventHandle;

	public int CompareTo(TimelineEventHandle_t other)
	{
		return Id.CompareTo(other.m_TimelineEventHandle);
	}

	public int CompareTo(ulong other)
	{
		return Id.CompareTo(other);
	}

	public override string ToString()
	{
		return Id.ToString();
	}

	public bool Equals(TimelineEventHandle_t other)
	{
		return Id.Equals(other.m_TimelineEventHandle);
	}

	public bool Equals(ulong other)
	{
		return Id.Equals(other);
	}

	public override bool Equals(object obj)
	{
		return Id.Equals(obj);
	}

	public override int GetHashCode()
	{
		return Id.GetHashCode();
	}
}
