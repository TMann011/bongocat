using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace BongoCat.DiscordHelper;

public class DiscordMultiplayerActivity : MonoBehaviour
{
	private void Awake()
	{
		Events.OnLobbyEnterSuccess += OnLobbyEntered;
		Events.OnLobbyLeave += OnLobbyLeave;
		Events.OnLobbyChatUpdate += OnLobbyChatUpdate;
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= OnLobbyEntered;
		Events.OnLobbyLeave -= OnLobbyLeave;
		Events.OnLobbyChatUpdate -= OnLobbyChatUpdate;
	}

	private void OnLobbyEntered(LobbyData lobby)
	{
		DiscordManager.Instance.SetMultiplayerActivity(lobby.ToString(), lobby.MemberCount);
	}

	private void OnLobbyChatUpdate(LobbyData lobby, UserData user, EChatMemberStateChange changes)
	{
		DiscordManager.Instance.SetMultiplayerActivity(lobby.ToString(), lobby.MemberCount);
	}

	private void OnLobbyLeave(LobbyData lobby)
	{
		DiscordManager.Instance.SetDefaultActivity();
	}
}
