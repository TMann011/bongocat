using System;

namespace Helper;

public static class SteamHelper
{
	public static string GetMarketLink(string itemName)
	{
		return string.Format("{0}https://steamcommunity.com/market/listings/{1}/{2}", "steam://openurl/", 3419430, Uri.EscapeUriString(itemName));
	}

	public static string GetItemStoreLink(int itemId)
	{
		return string.Format("{0}https://store.steampowered.com/itemstore/{1}/detail/{2}/", "steam://openurl/", 3419430, itemId);
	}
}
