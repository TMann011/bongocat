namespace BongoCat.Multiplayer.Spawning;

public enum AlignmentAxes
{
	Horizontal,
	Vertical
}
