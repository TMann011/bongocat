using UnityEngine;

namespace Helper;

public static class EditorUtilityCompileSafe
{
	public static void SetDirty(Object target)
	{
	}
}
