using System;
using System.Collections;
using System.Linq;
using BongoCat;
using BongoCat.Localizer;
using BongoCat.SteamJsonParser;
using DG.Tweening;
using Heathen.SteamworksIntegration;
using Steam;
using SteamTools;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BattleRoyale : MonoBehaviour
{
	[Serializable]
	public struct RoundDuration
	{
		public int playerCountAnchor;

		public int roundDuration;
	}

	public static BattleRoyale Instance;

	[SerializeField]
	private int _matchmakingDuration;

	[SerializeField]
	private RoundDuration[] _roundDuration;

	[SerializeField]
	private int _minPlayerAmountToStart;

	[SerializeField]
	private TMP_Text _countdownTxt;

	[SerializeField]
	private TMP_Text _infoTxt;

	[SerializeField]
	private RectTransform _announcementPanel;

	[SerializeField]
	private TMP_Text _announcementTitle;

	[SerializeField]
	private TMP_Text _announcementSubtitle;

	[SerializeField]
	private FrameAnimation _bloodExplosion;

	[SerializeField]
	private Transform _canvas;

	[SerializeField]
	private Image _eliminatedPanel;

	[SerializeField]
	private Color _eliminatedColor;

	private bool _matchmakingRound;

	private int _currentRound;

	private long _endOfRoundTime;

	private Coroutine _countdownRoutine;

	private bool _eliminatingPlayers;

	private string _eliminatedPlayers;

	private int _eliminationRequest;

	[SerializeField]
	private SteamItemBase _winnerItem;

	private const string COUNTDOWN_KEY = "BattleCountdownEnd";

	private const string CLOSED_KEY = "LobbyClosed";

	private const string ELIM_PLAYERS_KEY = "BattleEliminatedPlayers";

	private const string START_BATTLE = "BattleStart";

	private const string START_BATTLE_SUB = "BattleStartSub";

	private const string NEXT_ROUND = "BattleRound";

	private const string NEXT_ROUND_SUB = "BattlePlayersRemaining";

	private const string ELIMINATION = "BattleEliminated";

	private const string ELIMINATION_SUB = "BattleEliminatedSub";

	private const string WIN = "BattleWin";

	private const string WIN_SUB = "BattleWinSub";

	private const string WAITING_FOR_PLAYERS = "BattleWaitingForPlayers";

	private const string LEAST_TAPS_INFO = "BattleLeastTapsInfo";

	public bool InBattle => _endOfRoundTime != -1;

	public bool HasWon { get; private set; }

	private void OnEnable()
	{
		Instance = this;
	}

	private void Start()
	{
		Cleanup(default(LobbyData));
		Events.OnLobbyEnterSuccess += SubscribeMethods;
		Events.OnLobbyLeave += Cleanup;
	}

	private void SubscribeMethods(LobbyData lobby)
	{
		Events.OnLobbyChatUpdate += OnChatUpdate;
		Events.OnLobbyDataUpdate += OnLobbyUpdate;
		_infoTxt.text = Localize.Get("BattleWaitingForPlayers");
		if (LobbyData.Current.MemberCount < _minPlayerAmountToStart)
		{
			_countdownTxt.text = "";
		}
	}

	private void OnChatUpdate(LobbyData lobby, UserData user, EChatMemberStateChange changes)
	{
		CheckForBattleStart();
		StartNextRound();
	}

	private void OnLobbyUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		StartBattleRound();
		CheckIfEliminated();
	}

	private void Cleanup(LobbyData lobby)
	{
		Events.OnLobbyChatUpdate -= OnChatUpdate;
		Events.OnLobbyDataUpdate -= OnLobbyUpdate;
		_eliminationRequest = 0;
		if (_countdownRoutine != null)
		{
			StopCoroutine(_countdownRoutine);
		}
		_eliminatedPlayers = "";
		_eliminatingPlayers = false;
		_endOfRoundTime = -1L;
		_currentRound = 0;
		_matchmakingRound = false;
	}

	private void CheckForBattleStart()
	{
		long.TryParse(LobbyData.Current["BattleCountdownEnd"], out var result);
		if (!InBattle && result > 0)
		{
			StartBattleRound();
		}
		else if (LobbyData.Current.IsOwner && LobbyData.Current.MemberCount >= _minPlayerAmountToStart)
		{
			SendCountdown(_matchmakingDuration);
		}
	}

	private void SendCountdown(int minutes)
	{
		LobbyData.Current["BattleCountdownEnd"] = ((minutes > 0) ? (SteamUtils.GetServerRealTime() + minutes * 60) : (-1)).ToString();
	}

	private void StartBattleRound()
	{
		string text = LobbyData.Current["BattleCountdownEnd"];
		if (!long.TryParse(text, out var result))
		{
			return;
		}
		if (result < 0)
		{
			if (InBattle)
			{
				Cleanup(default(LobbyData));
				SubscribeMethods(default(LobbyData));
			}
		}
		else if (!string.IsNullOrEmpty(text) && _endOfRoundTime != result)
		{
			_matchmakingRound = !InBattle;
			if (_matchmakingRound)
			{
				DisplayAnnouncement(Localize.Get("BattleStart"), Localize.Get("BattleStartSub"));
			}
			else
			{
				_infoTxt.text = Localize.Get("BattleLeastTapsInfo");
				DisplayAnnouncement(Localize.Get("BattleRound", _currentRound), Localize.Get("BattlePlayersRemaining", LobbyData.Current.MemberCount));
			}
			_endOfRoundTime = result;
			Leaderboard.Instance.ResetAll();
			_eliminatingPlayers = false;
			_eliminationRequest = 0;
			if (_countdownRoutine != null)
			{
				StopCoroutine(_countdownRoutine);
			}
			_countdownRoutine = StartCoroutine(CountdownRound());
			_currentRound++;
		}
	}

	private IEnumerator CountdownRound()
	{
		long remaining = 1L;
		while (remaining > 0)
		{
			remaining = _endOfRoundTime - SteamUtils.GetServerRealTime();
			DisplayCountdown(remaining);
			yield return new WaitForSeconds(1f);
		}
		if (_endOfRoundTime >= 0)
		{
			DisplayCountdown(0L);
			EndRound();
		}
	}

	private void EndRound()
	{
		if (LobbyData.Current.IsOwner)
		{
			if (_matchmakingRound)
			{
				LobbyData.Current.SetJoinable(makeJoinable: false);
				LobbyData.Current["LobbyClosed"] = "True";
				SendCountdown(GetRoundDuration());
			}
			else
			{
				string value = string.Join(' ', Leaderboard.Instance.GetLowerHalf());
				LobbyData.Current["BattleEliminatedPlayers"] = value;
			}
		}
	}

	private void CheckIfEliminated()
	{
		if (!InBattle)
		{
			return;
		}
		string text = LobbyData.Current["BattleEliminatedPlayers"];
		if (text == _eliminatedPlayers || string.IsNullOrEmpty(text))
		{
			return;
		}
		_eliminatedPlayers = text;
		if (IsPlayerEliminated(SteamUser.GetSteamID()))
		{
			EliminateSelf();
			return;
		}
		if (_eliminationRequest > 0)
		{
			if (LobbyData.Current.IsOwner)
			{
				CheckNextRoundStart();
			}
			_eliminationRequest = 0;
		}
		_eliminatingPlayers = true;
	}

	private void EliminateSelf()
	{
		DisplayAnnouncement(Localize.Get("BattleEliminated"), Localize.Get("BattleEliminatedSub"));
		_eliminatedPanel.color = _eliminatedColor;
		_eliminatedPanel.DOFade(0f, 0.3f);
		Cleanup(default(LobbyData));
		LobbyData.Current.Leave();
		PromoItemChecker.Instance.GrantPromoItem(_winnerItem.Id);
	}

	private void StartNextRound()
	{
		if (!InBattle || !LobbyData.Current.IsOwner)
		{
			return;
		}
		if (!_matchmakingRound)
		{
			if (LobbyData.Current.MemberCount == 1)
			{
				BattleWon();
				return;
			}
		}
		else if (LobbyData.Current.MemberCount < _minPlayerAmountToStart)
		{
			SendCountdown(-1);
			return;
		}
		if (!_eliminatingPlayers)
		{
			_eliminationRequest++;
		}
		else
		{
			CheckNextRoundStart();
		}
	}

	private void CheckNextRoundStart()
	{
		for (int i = 0; i < LobbyData.Current.MemberCount; i++)
		{
			if (IsPlayerEliminated(LobbyData.Current.Members[i].user))
			{
				return;
			}
		}
		SendCountdown(GetRoundDuration());
	}

	private void BattleWon()
	{
		DisplayAnnouncement(Localize.Get("BattleWin"), Localize.Get("BattleWinSub"));
		HasWon = true;
		LobbyData.Current.Leave();
		PromoItemChecker.Instance.GrantPromoItem(_winnerItem.Id);
	}

	private bool IsPlayerEliminated(CSteamID playerId)
	{
		string[] array = _eliminatedPlayers.Split(' ');
		for (int i = 0; i < array.Length; i++)
		{
			if (ulong.TryParse(array[i], out var result) && new CSteamID(result) == playerId)
			{
				return true;
			}
		}
		return false;
	}

	private void DisplayCountdown(long remainingTime)
	{
		if (remainingTime <= 10 && remainingTime > 0)
		{
			DisplayAnnouncement(remainingTime.ToString(), "", 1f);
		}
		int num = Mathf.FloorToInt((float)remainingTime / 60f);
		int num2 = Mathf.FloorToInt((float)remainingTime % 60f);
		_countdownTxt.text = $"{num:00}:{num2:00}";
	}

	private void DisplayAnnouncement(string title, string subtitle, float length = 2f)
	{
		_announcementTitle.text = title;
		_announcementSubtitle.text = subtitle;
		DOTween.Kill(_announcementPanel);
		DOTween.Kill(_announcementTitle);
		DOTween.Kill(_announcementSubtitle);
		if (_announcementPanel.sizeDelta.y > 0f)
		{
			_announcementPanel.sizeDelta = new Vector2(_announcementPanel.sizeDelta.x, 200f);
			OnDemandRenderHelper.Instance.ResumeRenderingForDuration(length);
			FadeTexts(length);
		}
		else
		{
			OnDemandRenderHelper.Instance.ResumeRenderingForDuration(length + 1f);
			_announcementPanel.DOSizeDelta(new Vector2(_announcementPanel.sizeDelta.x, 200f), 0.5f).OnComplete(delegate
			{
				FadeTexts(length);
			});
		}
	}

	private void FadeTexts(float length)
	{
		_announcementTitle.DOFade(1f, length / 2f).OnComplete(delegate
		{
			_announcementTitle.DOFade(0f, length / 2f).SetEase(Ease.InCubic);
		});
		_announcementSubtitle.DOFade(1f, length / 2f).OnComplete(delegate
		{
			_announcementSubtitle.DOFade(0f, length / 2f).SetEase(Ease.InCubic).OnComplete(delegate
			{
				_announcementPanel.DOSizeDelta(new Vector2(_announcementPanel.sizeDelta.x, 0f), 0.5f);
			});
		});
	}

	private int GetRoundDuration()
	{
		return _roundDuration.OrderBy((RoundDuration c) => Mathf.Abs(c.playerCountAnchor - LobbyData.Current.MemberCount)).First().roundDuration;
	}

	public void KillCat(Transform cat)
	{
		UnityEngine.Object.Instantiate(_bloodExplosion, cat.position, Quaternion.identity, _canvas).PlayAnimation(delegate
		{
			UnityEngine.Object.Destroy(cat.gameObject);
		});
		HasWon = false;
	}
}
