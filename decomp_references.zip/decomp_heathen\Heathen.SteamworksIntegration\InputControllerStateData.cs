using System;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct InputControllerStateData
{
	public InputHandle_t handle;

	public InputActionStateData[] inputs;

	public InputActionUpdate[] changes;
}
