using System;

namespace BongoCat.Multiplayer.Spawning;

[Flags]
public enum SpawnControls
{
	None = 0,
	Spacing = 1,
	VerticalSpacing = 2,
	Anchor = 4,
	AlignmentAxis = 8,
	FillOrder = 0x10,
	Clockwise = 0x20,
	IncludeMainCat = 0x40,
	SnapCats = 0x80,
	Recalculate = 0x100
}
