using System;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct UserData : IEquatable<CSteamID>, IEquatable<ulong>, IEquatable<UserData>
{
	public CSteamID id;

	public static UserData Me => User.Client.Id;

	public bool IsMe => id == User.Client.Id.id;

	public ulong SteamId => id.m_SteamID;

	public string IdStr => SteamId.ToString();

	public bool IsValid
	{
		get
		{
			if (!(id == CSteamID.Nil))
			{
				CSteamID cSteamID = id;
				if (cSteamID.GetEAccountType() == EAccountType.k_EAccountTypeIndividual)
				{
					cSteamID = id;
					if (cSteamID.GetEUniverse() == EUniverse.k_EUniversePublic)
					{
						return true;
					}
				}
			}
			return false;
		}
	}

	public string Name => Friends.Client.GetFriendPersonaName(id);

	public string Nickname
	{
		get
		{
			string playerNickname = Friends.Client.GetPlayerNickname(id);
			if (!string.IsNullOrEmpty(playerNickname))
			{
				return playerNickname;
			}
			return Friends.Client.GetFriendPersonaName(id);
		}
	}

	public EPersonaState State => SteamFriends.GetFriendPersonaState(id);

	public bool InGame
	{
		get
		{
			FriendGameInfo_t pFriendGameInfo;
			return SteamFriends.GetFriendGamePlayed(id, out pFriendGameInfo);
		}
	}

	public bool InThisGame
	{
		get
		{
			if (SteamFriends.GetFriendGamePlayed(id, out var pFriendGameInfo))
			{
				return pFriendGameInfo.m_gameID == GameData.Me;
			}
			return false;
		}
	}

	public FriendGameInfo GameInfo
	{
		get
		{
			SteamFriends.GetFriendGamePlayed(id, out var pFriendGameInfo);
			return pFriendGameInfo;
		}
	}

	public int Level => SteamFriends.GetFriendSteamLevel(id);

	public AccountID_t AccountId
	{
		get
		{
			CSteamID cSteamID = id;
			return cSteamID.GetAccountID();
		}
	}

	public uint FriendId => AccountId.m_AccountID;

	public string HexId => FriendId.ToString("X");

	public void LoadAvatar(Action<Texture2D> callback)
	{
		Friends.Client.GetFriendAvatar(id, callback);
	}

	public bool GetGamePlayed(out FriendGameInfo gameInfo)
	{
		return Friends.Client.GetFriendGamePlayed(id, out gameInfo);
	}

	public bool InviteToLobby(LobbyData lobby)
	{
		return lobby.InviteUserToLobby(this);
	}

	public static UserData Get(string accountId)
	{
		uint num = Convert.ToUInt32(accountId, 16);
		if (num != 0)
		{
			return Get(num);
		}
		return CSteamID.Nil;
	}

	public static UserData Get(ulong id)
	{
		return new UserData
		{
			id = new CSteamID(id)
		};
	}

	public static UserData Get(CSteamID id)
	{
		return new UserData
		{
			id = id
		};
	}

	public static UserData Get(uint accountId)
	{
		return Get(new AccountID_t(accountId));
	}

	public static UserData Get(AccountID_t accountId)
	{
		return new CSteamID(accountId, EUniverse.k_EUniversePublic, EAccountType.k_EAccountTypeIndividual);
	}

	public override string ToString()
	{
		return HexId;
	}

	public bool Equals(UserData other)
	{
		CSteamID cSteamID = id;
		return cSteamID.Equals(other.id);
	}

	public bool Equals(CSteamID other)
	{
		CSteamID cSteamID = id;
		return cSteamID.Equals(other);
	}

	public bool Equals(ulong other)
	{
		ulong steamID = id.m_SteamID;
		return steamID.Equals(other);
	}

	public override bool Equals(object obj)
	{
		ulong steamID = id.m_SteamID;
		return steamID.Equals(obj);
	}

	public override int GetHashCode()
	{
		CSteamID cSteamID = id;
		return cSteamID.GetHashCode();
	}

	public static bool operator ==(UserData l, UserData r)
	{
		return l.id == r.id;
	}

	public static bool operator ==(UserData l, CSteamID r)
	{
		return l.id == r;
	}

	public static bool operator !=(UserData l, UserData r)
	{
		return l.id != r.id;
	}

	public static bool operator !=(CSteamID l, UserData r)
	{
		return l != r.id;
	}

	public static implicit operator ulong(UserData c)
	{
		return c.id.m_SteamID;
	}

	public static implicit operator UserData(ulong id)
	{
		return new UserData
		{
			id = new CSteamID(id)
		};
	}

	public static implicit operator CSteamID(UserData c)
	{
		return c.id;
	}

	public static implicit operator UserData(CSteamID id)
	{
		return new UserData
		{
			id = id
		};
	}
}
