using UnityEngine;

namespace Tutorial;

public class ReleaseCondition : UnlockCondition
{
	private const string SeenIdKey = "RELEASE_UNLOCK_MAX_ID";

	private static int _seenAtStartup;

	[SerializeField]
	private bool _released;

	public int UpdateId;

	public override int Current
	{
		get
		{
			if (!_released)
			{
				return 0;
			}
			return Target;
		}
	}

	public override bool RevealSeen => UpdateId <= _seenAtStartup;

	public override void MarkRevealSeen()
	{
		if (UpdateId > PlayerPrefs.GetInt("RELEASE_UNLOCK_MAX_ID", 0))
		{
			PlayerPrefs.SetInt("RELEASE_UNLOCK_MAX_ID", UpdateId);
		}
	}

	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
	private static void CaptureStartupMark()
	{
		_seenAtStartup = PlayerPrefs.GetInt("RELEASE_UNLOCK_MAX_ID", 0);
	}
}
