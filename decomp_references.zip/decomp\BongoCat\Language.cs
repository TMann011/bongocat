using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;

namespace BongoCat;

public class Language : MonoBehaviour
{
	public const string KEY = "LANGUAGE";

	[SerializeField]
	private TMP_Dropdown _languageDropdown;

	private List<Locale> _locales;

	private int _index;

	private static readonly Dictionary<SystemLanguage, string> languageMap = new Dictionary<SystemLanguage, string>
	{
		{
			SystemLanguage.Afrikaans,
			"af"
		},
		{
			SystemLanguage.Arabic,
			"ar"
		},
		{
			SystemLanguage.Basque,
			"eu"
		},
		{
			SystemLanguage.Belarusian,
			"be"
		},
		{
			SystemLanguage.Bulgarian,
			"bg"
		},
		{
			SystemLanguage.Catalan,
			"ca"
		},
		{
			SystemLanguage.Chinese,
			"zh"
		},
		{
			SystemLanguage.Czech,
			"cs"
		},
		{
			SystemLanguage.Danish,
			"da"
		},
		{
			SystemLanguage.Dutch,
			"nl"
		},
		{
			SystemLanguage.English,
			"en"
		},
		{
			SystemLanguage.Estonian,
			"et"
		},
		{
			SystemLanguage.Faroese,
			"fo"
		},
		{
			SystemLanguage.Finnish,
			"fi"
		},
		{
			SystemLanguage.French,
			"fr"
		},
		{
			SystemLanguage.German,
			"de"
		},
		{
			SystemLanguage.Greek,
			"el"
		},
		{
			SystemLanguage.Hebrew,
			"he"
		},
		{
			SystemLanguage.Hungarian,
			"hu"
		},
		{
			SystemLanguage.Icelandic,
			"is"
		},
		{
			SystemLanguage.Indonesian,
			"id"
		},
		{
			SystemLanguage.Italian,
			"it"
		},
		{
			SystemLanguage.Japanese,
			"ja"
		},
		{
			SystemLanguage.Korean,
			"ko"
		},
		{
			SystemLanguage.Latvian,
			"lv"
		},
		{
			SystemLanguage.Lithuanian,
			"lt"
		},
		{
			SystemLanguage.Norwegian,
			"no"
		},
		{
			SystemLanguage.Polish,
			"pl"
		},
		{
			SystemLanguage.Portuguese,
			"pt"
		},
		{
			SystemLanguage.Romanian,
			"ro"
		},
		{
			SystemLanguage.Russian,
			"ru"
		},
		{
			SystemLanguage.SerboCroatian,
			"sh"
		},
		{
			SystemLanguage.Slovak,
			"sk"
		},
		{
			SystemLanguage.Slovenian,
			"sl"
		},
		{
			SystemLanguage.Spanish,
			"es"
		},
		{
			SystemLanguage.Swedish,
			"sv"
		},
		{
			SystemLanguage.Thai,
			"th"
		},
		{
			SystemLanguage.Turkish,
			"tr"
		},
		{
			SystemLanguage.Ukrainian,
			"uk"
		},
		{
			SystemLanguage.Vietnamese,
			"vi"
		},
		{
			SystemLanguage.ChineseSimplified,
			"zh-CN"
		},
		{
			SystemLanguage.ChineseTraditional,
			"zh-TW"
		},
		{
			SystemLanguage.Unknown,
			"unknown"
		}
	};

	private void Awake()
	{
		string text = PlayerPrefs.GetString("LANGUAGE", string.Empty);
		if (string.IsNullOrEmpty(text))
		{
			text = GetLanguageKey(Application.systemLanguage);
			Debug.Log("Default language code: " + text);
		}
		ApplyLocale(LocalizationSettings.AvailableLocales.GetLocale(text) ?? LocalizationSettings.AvailableLocales.GetLocale("en"));
	}

	private void Start()
	{
		_locales = LocalizationSettings.AvailableLocales.Locales.OrderBy((Locale locale) => locale.LocaleName).ToList();
		InitLanguageDropdown(_languageDropdown);
	}

	public void InitLanguageDropdown(TMP_Dropdown dropdown)
	{
		dropdown.ClearOptions();
		dropdown.AddOptions(_locales.Select((Locale locale) => locale.LocaleName).ToList());
		dropdown.onValueChanged.AddListener(ChangeLanguage);
		_index = Mathf.Max(0, _locales.IndexOf(LocalizationSettings.SelectedLocale));
		dropdown.SetValueWithoutNotify(_index);
	}

	private void ChangeLanguage(int index)
	{
		_index = index;
		ApplyLocale(_locales[index]);
	}

	public void ToggleForward()
	{
		_languageDropdown.value = (_index + 1) % _locales.Count;
	}

	public void ToggleBackward()
	{
		_languageDropdown.value = (_index - 1 + _locales.Count) % _locales.Count;
	}

	private void ApplyLocale(Locale locale)
	{
		if ((bool)locale)
		{
			LocalizationSettings.SelectedLocale = locale;
			PlayerPrefs.SetString("LANGUAGE", locale.Identifier.Code);
			PlayerPrefs.Save();
		}
	}

	private string GetLanguageKey(SystemLanguage language)
	{
		if (!languageMap.TryGetValue(language, out var value))
		{
			return "en";
		}
		return value;
	}
}
