using BongoCat.Localizer;
using Heathen.SteamworksIntegration;
using TMPro;
using UnityEngine;

public class LobbiesListEntry : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _lobbyName;

	[SerializeField]
	private TMP_Text _numMembers;

	[SerializeField]
	private SteamLobbyData _lobby;

	private void Start()
	{
		string text = (string.IsNullOrEmpty(_lobby.Data.Name) ? Localize.Get("OldLobby") : _lobby.Data.Name);
		_lobbyName.text = text;
		_numMembers.text = $"{_lobby.Data.MemberCount}/{250}";
	}
}
