using Steamworks;

namespace Heathen.SteamworksIntegration;

public struct LeaderboardUgcSet
{
	public LeaderboardUGCSet_t Data;

	public LeaderboardData Leaderboard => Data.m_hSteamLeaderboard;
}
