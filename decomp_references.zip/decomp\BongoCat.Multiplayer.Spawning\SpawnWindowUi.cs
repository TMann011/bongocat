using System;
using System.Linq;
using IroxGames.Helper.ClassExtensions;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

namespace BongoCat.Multiplayer.Spawning;

public class SpawnWindowUi : MonoBehaviour
{
	[SerializeField]
	private TMP_Dropdown _patternDropdown;

	[SerializeField]
	private Slider _distanceSlider;

	[SerializeField]
	private GameObject _distanceSliderObj;

	[SerializeField]
	private Slider _verticalDistanceSlider;

	[SerializeField]
	private GameObject _verticalDistanceSliderObj;

	[SerializeField]
	private TMP_Dropdown _anchorDropdown;

	[SerializeField]
	private EnumLocalizer _anchorOptions;

	[SerializeField]
	private TMP_Dropdown _alignmentAxisDropdown;

	[SerializeField]
	private TMP_Dropdown _fillOrderDropdown;

	[SerializeField]
	private GameObject _clockwiseToggleObj;

	[SerializeField]
	private GameObject _includeMainCatToggleObj;

	[SerializeField]
	private GameObject _snapCatsToggleObj;

	[SerializeField]
	private GameObject _recalculateButton;

	[SerializeField]
	private GameObject _windowRecalculateButton;

	[SerializeField]
	private HoverTooltip _enableAllPreviewCatsTooltip;

	[SerializeField]
	private HoverTooltip _disableAllPreviewCatsTooltip;

	[SerializeField]
	private LocalizeStringEvent _distanceTitle;

	[SerializeField]
	private LocalizeStringEvent _distanceTitleTooltip;

	[SerializeField]
	private LocalizedString _preferredSpacingLoca;

	[SerializeField]
	private LocalizedString _preferredSpacingTooltipLoca;

	[SerializeField]
	private LocalizedString _preferredHorizontalSpacingLoca;

	[SerializeField]
	private LocalizedString _preferredHorizontalSpacingTooltipLoca;

	public void ShowPickedValues(CatSpawnSettings settings)
	{
		_patternDropdown.SetValueWithoutNotify((int)settings.SpawnPattern);
		_alignmentAxisDropdown.SetValueWithoutNotify((int)settings.AlignmentAxis);
		_fillOrderDropdown.SetValueWithoutNotify((int)settings.GridFillOrder);
	}

	public void RefreshControls(ICatSpawnPattern pattern, bool inLobby)
	{
		SpawnControls controls = pattern.Controls;
		bool flag = controls.HasFlag(SpawnControls.VerticalSpacing);
		_distanceSliderObj.SetActive(controls.HasFlag(SpawnControls.Spacing));
		_verticalDistanceSliderObj.SetActive(flag);
		_anchorDropdown.gameObject.SetActive(controls.HasFlag(SpawnControls.Anchor));
		_alignmentAxisDropdown.gameObject.SetActive(controls.HasFlag(SpawnControls.AlignmentAxis));
		_fillOrderDropdown.gameObject.SetActive(controls.HasFlag(SpawnControls.FillOrder));
		_clockwiseToggleObj.SetActive(controls.HasFlag(SpawnControls.Clockwise));
		_includeMainCatToggleObj.SetActive(controls.HasFlag(SpawnControls.IncludeMainCat));
		_snapCatsToggleObj.SetActive(controls.HasFlag(SpawnControls.SnapCats));
		bool flag2 = controls.HasFlag(SpawnControls.Recalculate);
		_windowRecalculateButton.SetActive(flag2);
		_recalculateButton.SetActiveWithCheck(flag2 & inLobby);
		SetSliderTitle(_distanceTitle, flag ? _preferredHorizontalSpacingLoca : _preferredSpacingLoca);
		SetSliderTitle(_distanceTitleTooltip, flag ? _preferredHorizontalSpacingTooltipLoca : _preferredSpacingTooltipLoca);
		AnchorCorners[] offeredAnchorCorners = pattern.OfferedAnchorCorners;
		_anchorOptions.SetVisibleValues(offeredAnchorCorners.Select((AnchorCorners corner) => corner.ToString()).ToList());
		_anchorDropdown.SetValueWithoutNotify(Array.IndexOf(offeredAnchorCorners, pattern.ResolvedAnchorCorner));
	}

	public void RefreshSliders(ICatSpawnPattern pattern, CatSpawnSettings settings)
	{
		if (pattern.Controls.HasFlag(SpawnControls.Spacing))
		{
			SetSliderRange(_distanceSlider, pattern.MaxDistancePercent, settings.PreferredDistancePercent);
		}
		if (pattern.Controls.HasFlag(SpawnControls.VerticalSpacing))
		{
			SetSliderRange(_verticalDistanceSlider, pattern.MaxVerticalDistancePercent, settings.PreferredVerticalDistancePercent);
		}
	}

	public void RefreshSlotButtons(bool canEnableAll, bool canDisableAll)
	{
		_enableAllPreviewCatsTooltip.gameObject.SetActiveWithCheck(canEnableAll);
		_enableAllPreviewCatsTooltip.HideTooltip();
		_disableAllPreviewCatsTooltip.gameObject.SetActiveWithCheck(canDisableAll);
		_disableAllPreviewCatsTooltip.HideTooltip();
	}

	private static void SetSliderRange(Slider slider, float max, float value)
	{
		slider.maxValue = max;
		slider.SetValueWithoutNotify(value);
	}

	private static void SetSliderTitle(LocalizeStringEvent target, LocalizedString source)
	{
		target.StringReference.SetReference(source.TableReference, source.TableEntryReference);
		target.RefreshString();
	}
}
