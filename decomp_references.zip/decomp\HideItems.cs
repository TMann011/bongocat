using System.Collections.Generic;
using System.Linq;
using BongoCat;
using IroxGames.Helper.ClassExtensions;
using UnityEngine;

public class HideItems : MonoBehaviour
{
	public static HideItems Instance;

	private List<InventoryItem> _inventoryHiddenItems;

	private void Awake()
	{
		Instance = this;
		_inventoryHiddenItems = new List<InventoryItem>();
	}

	public void AddHiddenItem(InventoryItem item)
	{
		_inventoryHiddenItems.Add(item);
	}

	public void ShowAllItems()
	{
		while (_inventoryHiddenItems.Count > 0)
		{
			ShowItem(_inventoryHiddenItems[0], isPartOfBongoDex: false);
		}
	}

	public void TempShowHiddenItems()
	{
		foreach (InventoryItem inventoryHiddenItem in _inventoryHiddenItems)
		{
			inventoryHiddenItem.ShowHiddenItemTemp();
		}
	}

	public void HideItem(InventoryItem item, bool isPartOfBongoDex)
	{
		if (isPartOfBongoDex)
		{
			ItemCollection collection = CatInventory.Instance.GetCollection(item.SteamItem.ItemSlot);
			item = collection.CollectionItems.First((InventoryItem i) => i.SteamItem == item.SteamItem);
		}
		_inventoryHiddenItems.Add(item);
		item.gameObject.SetActiveWithCheck(active: false);
		item.SteamItem.SetHideInventoryItem(value: true);
		item.SteamItem.OnItemUpdated?.Invoke();
		CatInventory.Instance.SetSeparatorVisibility();
	}

	public void ShowItem(InventoryItem hiddenItem, bool isPartOfBongoDex)
	{
		if (isPartOfBongoDex)
		{
			hiddenItem = _inventoryHiddenItems.FirstOrDefault((InventoryItem i) => i.SteamItem == hiddenItem.SteamItem) ?? hiddenItem;
		}
		hiddenItem.gameObject.SetActive(value: true);
		hiddenItem.SteamItem.SetHideInventoryItem(value: false);
		_inventoryHiddenItems.Remove(hiddenItem);
		hiddenItem.SteamItem.OnItemUpdated?.Invoke();
		CatInventory.Instance.SetSeparatorVisibility();
	}
}
