using System.Collections.Generic;
using UnityEngine;

namespace BongoCat.SteamJsonParser;

public class SteamItemTag : ScriptableObject
{
	public string Identifier;

	public List<string> Values;
}
