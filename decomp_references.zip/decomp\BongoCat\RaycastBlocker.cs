using UnityEngine;
using UnityEngine.EventSystems;

namespace BongoCat;

public class RaycastBlocker : MonoBehaviour, IPointerClickHandler, IEventSystemHandler, IPointerDownHandler
{
	public void OnPointerClick(PointerEventData eventData)
	{
	}

	public void OnPointerDown(PointerEventData eventData)
	{
	}
}
