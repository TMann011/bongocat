using System.Collections.Generic;
using UnityEngine;

namespace BongoCat;

public class ToggleCounterOnHover : MonoBehaviour
{
	[SerializeField]
	private List<GameObject> _toggleOnHover;

	[SerializeField]
	private GameObject _normalChestVisuals;

	[SerializeField]
	private GameObject _emoteChestVisuals;

	private bool _listenToToggle;

	private void Start()
	{
		ToggleObjectsWithKey.Instance.OnToggleWithKey += OnToggleChanged;
		SettingsManager.Instance.AutoHideCounter.OnToggleUpdated.AddListener(OnAutoHideChanged);
	}

	private void OnDestroy()
	{
		ToggleObjectsWithKey.Instance.OnToggleWithKey -= OnToggleChanged;
		SettingsManager.Instance.AutoHideCounter.OnToggleUpdated.RemoveListener(OnAutoHideChanged);
	}

	private void OnAutoHideChanged(bool autoHide)
	{
		_listenToToggle = !autoHide;
		ToggleObjectsWithKey.Instance.showObjects = _listenToToggle;
		TryHideCounter();
	}

	private void OnToggleChanged(bool toggle)
	{
		_listenToToggle = toggle;
		TryHideCounter();
	}

	public void ShowCounter()
	{
		SetCounterActive(visible: true);
	}

	public void TryHideCounter()
	{
		if (_listenToToggle)
		{
			SetCounterActive(visible: true);
			return;
		}
		SetCounterActive(visible: false);
		if (!SettingsManager.Instance.AlwaysShowChest.Value)
		{
			if (!Shop.NormalShop.CanGetChest)
			{
				_normalChestVisuals.SetActive(value: false);
			}
			if (!Shop.EmoteShop.CanGetChest || !SettingsManager.Instance.ShowEmoteChest.Value)
			{
				_emoteChestVisuals.SetActive(value: false);
			}
		}
	}

	private void SetCounterActive(bool visible)
	{
		foreach (GameObject item in _toggleOnHover)
		{
			item.SetActive(visible);
		}
	}
}
