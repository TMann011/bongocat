using System;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct UserAchievementStoredData(UserAchievementStored_t data)
{
	public GameData game = data.m_nGameID;

	public bool groupAchievement = data.m_bGroupAchievement;

	public string achievementName = data.m_rgchAchievementName;

	public uint currentProgress = data.m_nCurProgress;

	public uint maxProgress = data.m_nMaxProgress;
}
