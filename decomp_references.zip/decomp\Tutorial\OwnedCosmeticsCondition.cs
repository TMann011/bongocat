using BongoCat;

namespace Tutorial;

public class OwnedCosmeticsCondition : UnlockCondition
{
	public override int Current
	{
		get
		{
			int num = 0;
			foreach (SteamItemRuntime item in CatInventory.Instance.Items)
			{
				if (item.IsOwned && item.IsCosmetic)
				{
					num++;
				}
			}
			return num;
		}
	}
}
