using BongoCat;
using UnityEngine;

namespace Tutorial;

public class OwnedSlotCondition : UnlockCondition
{
	public enum Slot
	{
		Hat,
		Skin,
		Emote
	}

	[SerializeField]
	private Slot _slot;

	public override int Current
	{
		get
		{
			int num = 0;
			foreach (SteamItemRuntime item in CatInventory.Instance.Items)
			{
				if (item.IsOwned && _slot switch
				{
					Slot.Hat => item.IsHat, 
					Slot.Skin => item.IsSkin, 
					Slot.Emote => item.IsEmote, 
					_ => false, 
				})
				{
					num++;
				}
			}
			return num;
		}
	}
}
