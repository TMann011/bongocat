using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[DisallowMultipleComponent]
public class SteamAchievementData : MonoBehaviour
{
	public string apiName;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> mDelegates;

	public AchievementData Data
	{
		get
		{
			return apiName;
		}
		set
		{
			apiName = value.ApiName;
		}
	}

	public void Unlock()
	{
		Data.Unlock();
	}

	public void Clear()
	{
		Data.Clear();
	}

	public void Store()
	{
		Data.Store();
	}

	public void SetAchieved(bool value)
	{
		if (value)
		{
			Data.Unlock();
		}
		else
		{
			Data.Clear();
		}
	}
}
