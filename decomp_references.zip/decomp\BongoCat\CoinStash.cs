using System;
using System.Collections;
using BongoCat.SteamJsonParser;
using Steam;
using TMPro;
using UnityEngine;

namespace BongoCat;

public class CoinStash : MonoBehaviour
{
	[SerializeField]
	private SteamItemBasic _coins;

	[SerializeField]
	private TMP_Text _amount;

	private SteamItemRuntime Coins => SteamItemIdReference.Inst[_coins.Id];

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => StatsInitializer.Initialized);
		SteamItemRuntime coins = Coins;
		coins.OnItemUpdated = (Action)Delegate.Combine(coins.OnItemUpdated, new Action(Refresh));
		Refresh();
	}

	private void Refresh()
	{
		_amount.text = Coins.RuntimeData.GetTotalQuantity().ToString();
	}

	[ContextMenu("GetCoins")]
	public void GetCoins()
	{
		Debug.Log($"{Coins.RuntimeData.GetTotalQuantity()}");
	}
}
