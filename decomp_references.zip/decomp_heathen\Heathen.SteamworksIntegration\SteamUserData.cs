using System.Collections.Generic;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamUserData : MonoBehaviour, ISteamUserData
{
	public bool localUser;

	public UnityEvent<UserData, EPersonaChange> onChanged;

	private UserData _mData;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> mDelegates;

	public UserData Data
	{
		get
		{
			return _mData;
		}
		set
		{
			_mData = value;
			onChanged?.Invoke(value, (EPersonaChange)2147483647);
		}
	}

	private void Awake()
	{
		Events.OnPersonaStateChange += GlobalPersonaUpdate;
	}

	private void Start()
	{
		Interface.WhenReady(HandleInitialization);
	}

	private void HandleInitialization()
	{
		if (localUser)
		{
			Data = UserData.Me;
		}
	}

	private void OnDestroy()
	{
		Events.OnPersonaStateChange -= GlobalPersonaUpdate;
	}

	private void GlobalPersonaUpdate(UserData user, EPersonaChange changeFlag)
	{
		if (user == Data)
		{
			onChanged?.Invoke(user, changeFlag);
		}
	}
}
