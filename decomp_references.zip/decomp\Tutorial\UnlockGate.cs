using BongoCat;
using DG.Tweening;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

namespace Tutorial;

public class UnlockGate : MonoBehaviour
{
	[SerializeField]
	private UnlockCondition _condition;

	[SerializeField]
	private Button _tabButton;

	[SerializeField]
	private bool _lockedDuringTutorial = true;

	[SerializeField]
	private GameObject _lockedObj;

	[SerializeField]
	private Image _lockedOverlay;

	[SerializeField]
	private ShakeAnimation _lock;

	[SerializeField]
	private LocalizeStringEvent _progressLabel;

	[SerializeField]
	private LocalizedString _unlockAfterTutorial;

	[SerializeField]
	private GameObject _highlightObj;

	[SerializeField]
	private Transform _exclamationMark;

	[SerializeField]
	private Image _exclamationColor;

	[SerializeField]
	private Image _border;

	private bool _revealed;

	private bool _shouldHighlight;

	private bool TutorialPassed
	{
		get
		{
			if (_lockedDuringTutorial)
			{
				return TutorialUnlocks.HasFlag(TutorialUnlocks.TutorialTasks.FinishedInitTutorial);
			}
			return true;
		}
	}

	private bool ConditionMet
	{
		get
		{
			if ((bool)_condition)
			{
				return _condition.IsMet;
			}
			return true;
		}
	}

	private void Awake()
	{
		_revealed = (_condition ? _condition.RevealSeen : TutorialPassed);
	}

	private void OnEnable()
	{
		TutorialUnlocks.OnUnlocksChanged.AddListener(Refresh);
		CatInventory.OnInventoryChanged.AddListener(Refresh);
		Refresh();
		if (_shouldHighlight)
		{
			ShowHighlight();
		}
	}

	private void OnDisable()
	{
		TutorialUnlocks.OnUnlocksChanged.RemoveListener(Refresh);
		CatInventory.OnInventoryChanged.RemoveListener(Refresh);
	}

	public void Refresh()
	{
		if (_revealed)
		{
			return;
		}
		_lockedObj.gameObject.SetActive(value: true);
		if (TutorialPassed && ConditionMet)
		{
			RevealUnlock();
			return;
		}
		if (ConditionMet)
		{
			_progressLabel.StringReference = _unlockAfterTutorial;
		}
		else
		{
			_condition.LocalizerKey.Arguments = new object[1] { _condition.Remaining };
			_progressLabel.StringReference = _condition.LocalizerKey;
		}
		_progressLabel.RefreshString();
	}

	[ContextMenu("Reveal")]
	private void RevealUnlock()
	{
		_revealed = true;
		if ((bool)_condition)
		{
			_condition.MarkRevealSeen();
		}
		_lock.transform.localScale = Vector3.one;
		_lock.ShakeForDuration(1f);
		_lock.transform.DOScale(0f, 0.5f).SetEase(Ease.InBack, 3f).SetDelay(1f)
			.SetLink(base.gameObject, LinkBehaviour.CompleteAndKillOnDisable);
		_lockedOverlay.DOFade(0f, 0.5f).SetDelay(1f).SetLink(base.gameObject, LinkBehaviour.CompleteAndKillOnDisable)
			.OnComplete(delegate
			{
				_lockedObj.gameObject.SetActive(value: false);
				Highlight();
			});
	}

	public void Highlight()
	{
		Highlight(null);
	}

	public void Highlight(Color? color)
	{
		if (!_shouldHighlight && !_highlightObj.activeSelf)
		{
			_shouldHighlight = true;
			CatInventory.Instance.HighlightInventory();
			if (color.HasValue)
			{
				_exclamationColor.color = color.Value;
			}
			if (base.gameObject.activeSelf)
			{
				ShowHighlight();
			}
		}
	}

	private void ShowHighlight()
	{
		_highlightObj.SetActive(value: true);
		_border.color = new Color(_border.color.r, _border.color.g, _border.color.b, 0f);
		_border.DOFade(1f, 0.5f).SetLink(base.gameObject, LinkBehaviour.CompleteAndKillOnDisable);
		_exclamationMark.localScale = Vector3.zero;
		_exclamationMark.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutBack, 3f).SetLink(base.gameObject, LinkBehaviour.CompleteAndKillOnDisable);
		if (!_tabButton)
		{
			_tabButton = GetComponentInParent<Button>(includeInactive: true);
		}
		_tabButton.onClick.AddListener(DismissHighlight);
		_shouldHighlight = false;
	}

	public void DismissHighlight()
	{
		if (_shouldHighlight || _highlightObj.activeSelf)
		{
			_highlightObj.SetActive(value: false);
			_tabButton.onClick.RemoveListener(DismissHighlight);
			CatInventory.Instance.DismissHighlight();
		}
	}
}
