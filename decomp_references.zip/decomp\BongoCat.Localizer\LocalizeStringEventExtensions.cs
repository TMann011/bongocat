using UnityEngine.Localization.Components;

namespace BongoCat.Localizer;

public static class LocalizeStringEventExtensions
{
	public static void SetKey(this LocalizeStringEvent localizeStringEvent, string key)
	{
		localizeStringEvent.StringReference.SetReference("BongoCat", key);
		localizeStringEvent.RefreshString();
	}
}
