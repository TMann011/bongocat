using System;
using System.Collections;
using System.Collections.Generic;
using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Serialization;

namespace BongoCat.Multiplayer;

public class SteamMultiplayer : MonoBehaviour
{
	public class Bus<T>
	{
		private Dictionary<CSteamID, List<Action<T>>> _callbacks = new Dictionary<CSteamID, List<Action<T>>>();

		private List<Action<CSteamID, T>> _globalCallbacks = new List<Action<CSteamID, T>>();

		public void Invoke(CSteamID receiver, T value)
		{
			if (_callbacks.TryGetValue(receiver, out var value2))
			{
				foreach (Action<T> item in value2)
				{
					item(value);
				}
			}
			foreach (Action<CSteamID, T> globalCallback in _globalCallbacks)
			{
				globalCallback(receiver, value);
			}
		}

		public void Register(CSteamID userId, Action<T> callback)
		{
			if (!_callbacks.ContainsKey(userId))
			{
				_callbacks[userId] = new List<Action<T>>();
			}
			_callbacks[userId].Add(callback);
		}

		public void Deregister(CSteamID userId, Action<T> callback)
		{
			if (_callbacks.ContainsKey(userId))
			{
				_callbacks[userId].Remove(callback);
				if (_callbacks[userId].Count == 0)
				{
					_callbacks.Remove(userId);
				}
			}
		}
	}

	[Serializable]
	private class LobbyMessage
	{
		public int Channel;

		public string Message;
	}

	[FormerlySerializedAs("_root")]
	public Transform Root;

	private Coroutine _sendTapsRoutine;

	private int _tapsToSend;

	public static SteamMultiplayer Instance;

	public Bus<int> OnTapsReceived = new Bus<int>();

	public Bus<string> OnChatReceived = new Bus<string>();

	public Bus<int> OnEmoteReceived = new Bus<int>();

	public Bus<int> OnItemReceived = new Bus<int>();

	public Action OnResetLeaderboardReceived;

	public Action<CSteamID, ChestType> OnOpenChestForMeReceived;

	public Action<CSteamID> OnPatReceived;

	private void Awake()
	{
		Instance = this;
	}

	private void Start()
	{
		Events.OnLobbyEnterSuccess += OnLobbyEntered;
		Events.OnLobbyLeave += OnLobbyLeft;
		Events.OnLobbyChatMsg += OnLobbyChatMsg;
		Cat.Instance.OnTap.AddListener(AddTaps);
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= OnLobbyEntered;
		Events.OnLobbyLeave -= OnLobbyLeft;
		Events.OnLobbyChatMsg -= OnLobbyChatMsg;
		Cat.Instance.OnTap.RemoveListener(AddTaps);
	}

	private void OnLobbyEntered(LobbyData lobby)
	{
		_tapsToSend = 0;
		_sendTapsRoutine = StartCoroutine(SendingTapsRoutine());
	}

	private void OnLobbyChatMsg(LobbyChatMsg msg)
	{
		LobbyMessage lobbyMessage = msg.FromJson<LobbyMessage>();
		if (lobbyMessage == null)
		{
			return;
		}
		switch (lobbyMessage.Channel)
		{
		case 2:
		{
			if (int.TryParse(lobbyMessage.Message, out var result6))
			{
				OnTapsReceived?.Invoke(msg.sender, result6);
			}
			break;
		}
		case 3:
			OnChatReceived?.Invoke(msg.sender, lobbyMessage.Message);
			break;
		case 6:
		{
			if (int.TryParse(lobbyMessage.Message, out var result3))
			{
				OnEmoteReceived?.Invoke(msg.sender, result3);
			}
			break;
		}
		case 5:
		{
			if (SettingsManager.Instance.MultiplayerPopups.Value && int.TryParse(lobbyMessage.Message, out var result2))
			{
				OnItemReceived?.Invoke(msg.sender, result2);
			}
			break;
		}
		case 7:
			OnResetLeaderboardReceived?.Invoke();
			break;
		case 4:
		{
			string[] array = lobbyMessage.Message.Split(':');
			if (ulong.TryParse(array[0], out var result4) && UserData.Me.id.m_SteamID == result4 && SettingsManager.Instance.MultiplayerPopups.Value)
			{
				ChestType arg = ChestType.Cosmetic;
				if (array.Length > 1 && int.TryParse(array[1], out var result5))
				{
					arg = (ChestType)result5;
				}
				OnOpenChestForMeReceived?.Invoke(msg.sender, arg);
			}
			break;
		}
		case 8:
		{
			if (ulong.TryParse(lobbyMessage.Message, out var result) && UserData.Me.id.m_SteamID == result)
			{
				OnPatReceived?.Invoke(msg.sender);
			}
			break;
		}
		}
	}

	private void OnLobbyLeft(LobbyData lobby)
	{
		if (_sendTapsRoutine != null)
		{
			StopCoroutine(_sendTapsRoutine);
			_sendTapsRoutine = null;
		}
	}

	public static void SendReceivedItem(int itemId)
	{
		SendMessageToLobby(itemId.ToString(), 5);
	}

	public static void SendSpeech(string text)
	{
		SendMessageToLobby(text, 3);
	}

	public static void SendEmote(SteamItemRuntime emote)
	{
		SendMessageToLobby(emote.Id.ToString(), 6);
	}

	public static void SendResetLeaderboard()
	{
		SendMessageToLobby("Reset", 7);
	}

	public static void SendOpenChest(CSteamID target, ChestType chestType)
	{
		SendMessageToLobby($"{target.m_SteamID}:{(int)chestType}", 4);
	}

	public static void SendPat(CSteamID target)
	{
		SendMessageToLobby(target.m_SteamID.ToString(), 8);
	}

	private static void SendMessageToLobby(string message, int channel)
	{
		if (LobbyData.Current.IsValid)
		{
			LobbyData.Current.SendChatMessage(new LobbyMessage
			{
				Channel = channel,
				Message = message
			});
		}
	}

	private IEnumerator SendingTapsRoutine()
	{
		while (true)
		{
			yield return null;
			if (_tapsToSend > 0)
			{
				if (_tapsToSend >= 8)
				{
					_tapsToSend = 0;
					continue;
				}
				SendMessageToLobby(_tapsToSend.ToString(), 2);
				_tapsToSend = 0;
			}
		}
	}

	private void AddTaps(int amount)
	{
		_tapsToSend += amount;
	}
}
