using System;
using UnityEngine;
using UnityEngine.UI;

public class Tabs : MonoBehaviour
{
	[Serializable]
	private class Tab
	{
		public Button button;

		public GameObject tab;
	}

	[SerializeField]
	private Tab[] tabs;

	[SerializeField]
	private int selectedTab;

	public Action<int> OnOpenTab;

	public Action<int> OnCloseTab;

	private int _currentTab;

	private void Awake()
	{
		for (int i = 0; i < tabs.Length; i++)
		{
			int index = i;
			tabs[i].button.onClick.AddListener(delegate
			{
				OpenTab(index);
			});
		}
		OpenTab(selectedTab);
		ActivateTab(activate: true);
	}

	public void OpenTab(int tab)
	{
		if (tab == _currentTab)
		{
			OnOpenTab?.Invoke(tab);
			return;
		}
		OnCloseTab?.Invoke(_currentTab);
		ActivateTab(activate: false);
		_currentTab = tab;
		ActivateTab(activate: true);
		OnOpenTab?.Invoke(tab);
	}

	private void ActivateTab(bool activate)
	{
		tabs[_currentTab].tab.SetActive(activate);
		tabs[_currentTab].button.interactable = !activate;
	}

	public void EnableTab(int index, bool enable)
	{
		tabs[index].button.enabled = enable;
	}

	public void EnableAllTabs(bool enable)
	{
		for (int i = 0; i < tabs.Length; i++)
		{
			EnableTab(i, enable);
		}
		ActivateTab(enable);
	}

	private void OnEnable()
	{
		OnOpenTab?.Invoke(_currentTab);
	}

	private void OnDisable()
	{
		OnCloseTab?.Invoke(_currentTab);
	}
}
