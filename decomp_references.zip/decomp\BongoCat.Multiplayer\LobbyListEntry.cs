using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.Multiplayer;

public class LobbyListEntry : MonoBehaviour
{
	[SerializeField]
	private GameObject _ownerVisual;

	[SerializeField]
	private Button _kickButton;

	[SerializeField]
	private SteamUserData _steamUserData;

	[SerializeField]
	private SteamLobbyMemberData _lobbyMemberData;

	private void Start()
	{
		MultiplayerLobbyReferences.LobbyListEntries.Add(_steamUserData.Data, this);
		_ownerVisual.SetActive(_lobbyMemberData.Data.IsOwner);
		_kickButton.gameObject.SetActive(_lobbyMemberData.Lobby.IsOwner && !_lobbyMemberData.Lobby.IsClosedLobby && !_steamUserData.Data.IsMe);
		Events.OnLobbyChatUpdate += HandleChatUpdate;
		Events.OnLobbyDataUpdate += OnLobbyDataUpdate;
	}

	private void OnDestroy()
	{
		MultiplayerLobbyReferences.LobbyListEntries.Remove(_steamUserData.Data);
		Events.OnLobbyChatUpdate -= HandleChatUpdate;
		Events.OnLobbyDataUpdate -= OnLobbyDataUpdate;
	}

	private void OnLobbyDataUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		_kickButton.gameObject.SetActive(lobby.IsOwner && !lobby.IsClosedLobby && !_steamUserData.Data.IsMe);
		_ownerVisual.SetActive(_lobbyMemberData.Data.IsOwner);
	}

	private void HandleChatUpdate(LobbyData lobby, UserData userData, EChatMemberStateChange changes)
	{
		if (changes == EChatMemberStateChange.k_EChatMemberStateChangeLeft || changes == EChatMemberStateChange.k_EChatMemberStateChangeDisconnected)
		{
			_kickButton.gameObject.SetActive(_lobbyMemberData.Lobby.IsOwner && !_lobbyMemberData.Lobby.IsClosedLobby && !_steamUserData.Data.IsMe);
			_ownerVisual.SetActive(_lobbyMemberData.Data.IsOwner);
		}
	}
}
