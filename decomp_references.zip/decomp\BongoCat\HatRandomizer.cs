using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat.Localizer;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Settings;

namespace BongoCat;

public class HatRandomizer : MonoBehaviour
{
	[SerializeField]
	private List<float> _waitDurationInMinutes;

	[SerializeField]
	private TMP_Text _text;

	[SerializeField]
	private TMP_Dropdown _settingsDropdown;

	[SerializeField]
	private string _baseLocaKey;

	[SerializeField]
	private string _neverOptionLocaKey;

	[SerializeField]
	private string _minutesLocaKey;

	[SerializeField]
	private PlayerPrefsToggle _onlyRandomizeFavorites;

	[SerializeField]
	private PlayerPrefsToggle _onlyRandomizePresets;

	public RectTransform SettingsWindow;

	private int _index;

	private Coroutine _routine;

	private const string SETTING_KEY = "HAT_RANDOMIZER";

	private bool IsEnabled => _index > 0;

	public bool IsVisible => SettingsWindow.gameObject.activeSelf;

	private void Start()
	{
		SetIndex(PlayerPrefs.GetInt("HAT_RANDOMIZER", 0));
		UpdateLanguage();
		LocalizationSettings.SelectedLocaleChanged += delegate
		{
			UpdateLanguage();
		};
	}

	public void SetIndex(int index)
	{
		_index = index;
		UpdateWaitDuration();
	}

	public void UpdateWaitDuration()
	{
		if (_routine != null)
		{
			StopCoroutine(_routine);
		}
		UpdateText();
		PlayerPrefs.SetInt("HAT_RANDOMIZER", _index);
		PlayerPrefs.Save();
		if (IsEnabled)
		{
			_routine = StartCoroutine(RandomizeSkinAndHatRoutine(_waitDurationInMinutes[_index - 1] * 60f));
		}
	}

	private IEnumerator RandomizeSkinAndHatRoutine(float waitDuration)
	{
		while (true)
		{
			yield return new WaitForSeconds(waitDuration);
			RandomizeSkinAndHat();
		}
	}

	public void RandomizeSkinAndHat()
	{
		if (_onlyRandomizePresets.Value)
		{
			PresetManager.Instance.GetRandomPreset().Equip();
			return;
		}
		RandomizeHat();
		RandomizeSkin();
	}

	public void RandomizeHat()
	{
		List<SteamItemRuntime> list = CatInventory.Instance.Items.Where((SteamItemRuntime item) => item.ItemSlot == "hat" && item.RuntimeData.GetTotalQuantity() > 0 && !item.IsEquipped && !item.IsHiddenInInventory).ToList();
		if (_onlyRandomizeFavorites.Value)
		{
			list = list.Where((SteamItemRuntime item) => item.IsFavorite).ToList();
		}
		if (list.Count > 0)
		{
			SteamItemRuntime steamItem = list[Random.Range(0, list.Count)];
			CatCosmetics.Instance.EquipItem(steamItem, playAnimation: true, unequipIfSameItemIsEquipped: false, resetRandomizerTimer: true);
		}
	}

	public void RandomizeSkin()
	{
		List<SteamItemRuntime> list = CatInventory.Instance.Items.Where((SteamItemRuntime item) => item.ItemSlot == "skin" && item.RuntimeData.GetTotalQuantity() > 0 && !item.IsHiddenInInventory).ToList();
		if (_onlyRandomizeFavorites.Value)
		{
			list = list.Where((SteamItemRuntime item) => item.IsFavorite && !item.IsEquipped).ToList();
		}
		if (list.Count > 0)
		{
			SteamItemRuntime steamItem = list[Random.Range(0, list.Count)];
			CatCosmetics.Instance.EquipItem(steamItem, playAnimation: true, unequipIfSameItemIsEquipped: false, resetRandomizerTimer: true);
		}
	}

	private void UpdateText()
	{
		if (!IsEnabled)
		{
			_text.text = Localize.Get(_baseLocaKey) + " " + Localize.Get(_neverOptionLocaKey);
		}
		else
		{
			_text.text = $"{Localize.Get(_baseLocaKey)} {_waitDurationInMinutes[_index - 1]}{Localize.Get(_minutesLocaKey)}";
		}
	}

	private void UpdateLanguage()
	{
		UpdateText();
		List<string> list = new List<string> { Localize.Get(_neverOptionLocaKey) ?? "" };
		foreach (float waitDurationInMinute in _waitDurationInMinutes)
		{
			list.Add($"{waitDurationInMinute}{Localize.Get(_minutesLocaKey)}");
		}
		_settingsDropdown.ClearOptions();
		_settingsDropdown.AddOptions(list);
		_settingsDropdown.value = _index;
	}
}
