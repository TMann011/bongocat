using System;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct InputActionSetData : IEquatable<InputActionSetHandle_t>, IComparable<InputActionSetHandle_t>, IEquatable<ulong>, IComparable<ulong>
{
	[SerializeField]
	private InputActionSetHandle_t handle;

	public ulong Handle => handle.m_InputActionSetHandle;

	public static InputActionSetData Get(string setName)
	{
		return new InputActionSetData
		{
			handle = Heathen.SteamworksIntegration.API.Input.Client.GetActionSetHandle(setName)
		};
	}

	public bool Equals(InputActionSetHandle_t other)
	{
		return handle.Equals(other);
	}

	public int CompareTo(InputActionSetHandle_t other)
	{
		return handle.CompareTo(other);
	}

	public bool Equals(ulong other)
	{
		return handle.m_InputActionSetHandle.Equals(other);
	}

	public int CompareTo(ulong other)
	{
		return handle.m_InputActionSetHandle.CompareTo(other);
	}

	public override bool Equals(object obj)
	{
		return handle.Equals(obj);
	}

	public override int GetHashCode()
	{
		return handle.GetHashCode();
	}

	public static bool operator ==(InputActionSetData l, ulong r)
	{
		return l.handle == new InputActionSetHandle_t(r);
	}

	public static bool operator ==(ulong l, InputActionSetData r)
	{
		return new InputActionSetHandle_t(l) == r.handle;
	}

	public static bool operator !=(InputActionSetData l, ulong r)
	{
		return l.handle != new InputActionSetHandle_t(r);
	}

	public static implicit operator InputActionSetHandle_t(InputActionSetData c)
	{
		return c.handle;
	}
}
