using System;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct ClanData : IEquatable<CSteamID>, IEquatable<ClanData>, IEquatable<ulong>, IComparable<CSteamID>, IComparable<ClanData>, IComparable<ulong>
{
	[SerializeField]
	private ulong id;

	public CSteamID SteamId => new CSteamID(id);

	public int CompareTo(CSteamID other)
	{
		ulong num = id;
		return num.CompareTo(other.m_SteamID);
	}

	public int CompareTo(ClanData other)
	{
		ulong num = id;
		return num.CompareTo(other.id);
	}

	public int CompareTo(ulong other)
	{
		ulong num = id;
		return num.CompareTo(other);
	}

	public override string ToString()
	{
		ulong num = id;
		return num.ToString();
	}

	public bool Equals(CSteamID other)
	{
		ulong num = id;
		return num.Equals(other);
	}

	public bool Equals(ClanData other)
	{
		ulong num = id;
		return num.Equals(other.id);
	}

	public bool Equals(ulong other)
	{
		ulong num = id;
		return num.Equals(other);
	}

	public override bool Equals(object obj)
	{
		ulong num = id;
		return num.Equals(obj);
	}

	public override int GetHashCode()
	{
		ulong num = id;
		return num.GetHashCode();
	}

	public static bool operator ==(ClanData l, ClanData r)
	{
		return l.id == r.id;
	}

	public static implicit operator CSteamID(ClanData c)
	{
		return c.SteamId;
	}
}
