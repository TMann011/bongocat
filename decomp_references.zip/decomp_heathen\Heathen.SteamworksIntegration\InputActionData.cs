using System;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct InputActionData
{
	[SerializeField]
	private InputActionType type;

	[SerializeField]
	private string name;

	public InputActionType Type => type;

	public string Name => name;

	public InputAnalogActionHandle_t AnalogHandle => Heathen.SteamworksIntegration.API.Input.Client.GetAnalogActionHandle(name);

	public InputDigitalActionHandle_t DigitalHandle => Heathen.SteamworksIntegration.API.Input.Client.GetDigitalActionHandle(name);

	public Texture2D[] GetInputGlyphs(InputHandle_t controller, InputActionSetData set)
	{
		return GetInputGlyphs(controller, new InputActionSetHandle_t(set.Handle));
	}

	public Texture2D[] GetInputGlyphs(InputHandle_t controller, InputActionSetLayerData set)
	{
		return GetInputGlyphs(controller, new InputActionSetHandle_t(set.Data.Handle));
	}

	public Texture2D[] GetInputGlyphs(InputHandle_t controller, InputActionSetHandle_t set)
	{
		if (type == InputActionType.Analog)
		{
			EInputActionOrigin[] analogActionOrigins = Heathen.SteamworksIntegration.API.Input.Client.GetAnalogActionOrigins(controller, set, AnalogHandle);
			Texture2D[] array = new Texture2D[analogActionOrigins.Length];
			for (int i = 0; i < analogActionOrigins.Length; i++)
			{
				array[i] = Heathen.SteamworksIntegration.API.Input.Client.GetGlyphActionOrigin(analogActionOrigins[i]);
			}
			return array;
		}
		EInputActionOrigin[] digitalActionOrigins = Heathen.SteamworksIntegration.API.Input.Client.GetDigitalActionOrigins(controller, set, DigitalHandle);
		Texture2D[] array2 = new Texture2D[digitalActionOrigins.Length];
		for (int j = 0; j < digitalActionOrigins.Length; j++)
		{
			array2[j] = Heathen.SteamworksIntegration.API.Input.Client.GetGlyphActionOrigin(digitalActionOrigins[j]);
		}
		return array2;
	}

	public string[] GetInputNames(InputHandle_t controller, InputActionSetData set)
	{
		return GetInputNames(controller, new InputActionSetHandle_t(set.Handle));
	}

	public string[] GetInputNames(InputHandle_t controller, InputActionSetLayerData set)
	{
		return GetInputNames(controller, new InputActionSetHandle_t(set.Data.Handle));
	}

	public string[] GetInputNames(InputHandle_t controller, InputActionSetHandle_t set)
	{
		if (type == InputActionType.Analog)
		{
			EInputActionOrigin[] analogActionOrigins = Heathen.SteamworksIntegration.API.Input.Client.GetAnalogActionOrigins(controller, set, AnalogHandle);
			string[] array = new string[analogActionOrigins.Length];
			for (int i = 0; i < analogActionOrigins.Length; i++)
			{
				array[i] = Heathen.SteamworksIntegration.API.Input.Client.GetStringForActionOrigin(analogActionOrigins[i]);
			}
			return array;
		}
		EInputActionOrigin[] digitalActionOrigins = Heathen.SteamworksIntegration.API.Input.Client.GetDigitalActionOrigins(controller, set, DigitalHandle);
		string[] array2 = new string[digitalActionOrigins.Length];
		for (int j = 0; j < digitalActionOrigins.Length; j++)
		{
			array2[j] = Heathen.SteamworksIntegration.API.Input.Client.GetStringForActionOrigin(digitalActionOrigins[j]);
		}
		return array2;
	}
}
