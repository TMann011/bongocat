using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat.UI;
using Helper;
using Steam;
using UnityEngine;

namespace BongoCat;

public class PresetManager : MonoBehaviour
{
	private List<Preset> _presets = new List<Preset>();

	[SerializeField]
	private Transform _presetsRoot;

	[SerializeField]
	private Preset _presetPrefab;

	[SerializeField]
	private PresetsWindowLayout _windowLayout;

	private int _rowCount;

	private const string PRESET_KEY = "PRESETS";

	private const string CLOUD_FILE = "presets.json";

	public static PresetManager Instance;

	private int RowCount => ItemScaleSetting.Instance.Count;

	private void Awake()
	{
		Instance = this;
	}

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		Load();
		ItemScaleSetting.OnChangeScale = (Action<int>)Delegate.Combine(ItemScaleSetting.OnChangeScale, new Action<int>(ChangeCellCount));
		RecalculatePresetCount();
	}

	private void CreateNewEmptyPreset()
	{
		Preset item = global::UnityEngine.Object.Instantiate(_presetPrefab, _presetsRoot);
		_presets.Add(item);
	}

	private void Load()
	{
		List<Preset.PresetData> list = LoadLocalPresets();
		List<Preset.PresetData> list2 = LoadCloudPresets();
		List<Preset.PresetData> list3 = MergePresets(list, list2);
		for (int i = 0; i < list3.Count; i++)
		{
			CreateNewEmptyPreset();
			Preset.PresetData presetData = list3[i];
			_presets[i].SetData(presetData.HatItemId, presetData.SkinItemId);
			_presets[i].LoadVisuals();
		}
		if (!list3.SequenceEqual(list) || !list3.SequenceEqual(list2))
		{
			PersistPresets(list3);
		}
		RecalculatePresetCount();
	}

	private static List<Preset.PresetData> LoadLocalPresets()
	{
		if (PlayerPrefsHelp.TryGetObject<List<Preset.PresetData>>("PRESETS", out var o) && o != null)
		{
			return o;
		}
		return new List<Preset.PresetData>();
	}

	private static List<Preset.PresetData> LoadCloudPresets()
	{
		if (SteamCloudHelper.TryLoadFromCloud<List<Preset.PresetData>>("presets.json", out var data) && data != null)
		{
			return data;
		}
		return new List<Preset.PresetData>();
	}

	private static List<Preset.PresetData> MergePresets(List<Preset.PresetData> local, List<Preset.PresetData> cloud)
	{
		List<Preset.PresetData> list = new List<Preset.PresetData>();
		HashSet<(int, int)> hashSet = new HashSet<(int, int)>();
		foreach (Preset.PresetData item in local.Concat(cloud))
		{
			if (hashSet.Add((item.HatItemId, item.SkinItemId)))
			{
				list.Add(item);
			}
		}
		return list;
	}

	private static void PersistPresets(List<Preset.PresetData> data)
	{
		PlayerPrefsHelp.SetObject("PRESETS", data);
		SteamCloudHelper.SaveToCloud("presets.json", data);
	}

	public void ReorderToHierarchy()
	{
		_presets = _presets.OrderBy((Preset preset) => preset.transform.GetSiblingIndex()).ToList();
		Save();
	}

	public void Save()
	{
		_presets = _presets.OrderByDescending((Preset preset) => preset.ContainsData ? 1 : 0).ToList();
		foreach (Preset preset in _presets)
		{
			preset.transform.SetAsLastSibling();
		}
		PersistPresets((from preset in _presets
			where preset.ContainsData
			select preset.Data).ToList());
		RecalculatePresetCount();
	}

	private void RecalculatePresetCount()
	{
		ChangeCellCount(RowCount);
	}

	private void ChangeCellCount(int rowCount)
	{
		int num = _presets.Count;
		int num2 = _presets.Count((Preset preset) => preset.ContainsData);
		if (num > rowCount)
		{
			int num3 = num - Mathf.Max(num2, rowCount);
			if (num2 >= rowCount)
			{
				num3--;
			}
			if (num3 < 0)
			{
				CreateNewEmptyPreset();
			}
			else
			{
				for (int num4 = 0; num4 < num3; num4++)
				{
					global::UnityEngine.Object.Destroy(_presets[num - 1 - num4].gameObject);
					_presets.RemoveAt(num - 1 - num4);
					num--;
				}
			}
		}
		else
		{
			int num5 = rowCount - num;
			if (num2 == rowCount)
			{
				num5++;
			}
			for (int num6 = 0; num6 < num5; num6++)
			{
				CreateNewEmptyPreset();
			}
		}
		StartCoroutine(FixLayoutDelayed());
	}

	private IEnumerator FixLayoutDelayed()
	{
		yield return null;
		int num = Mathf.CeilToInt((float)_presets.Count / (float)RowCount);
		if (num != _rowCount)
		{
			bool scrollToBottom = num > _rowCount;
			_rowCount = num;
			_windowLayout.Rebuild(scrollToBottom);
		}
	}

	public Preset GetRandomPreset()
	{
		List<Preset> list = _presets.Where((Preset preset) => preset.ContainsData).ToList();
		return list[global::UnityEngine.Random.Range(0, list.Count)];
	}
}
