namespace Heathen.SteamworksIntegration;

public enum FriendDialog
{
	Steamid,
	Chat,
	Jointrade,
	Stats,
	Achievements,
	Friendadd,
	Friendremove,
	Friendrequestaccept,
	Friendrequestignore
}
