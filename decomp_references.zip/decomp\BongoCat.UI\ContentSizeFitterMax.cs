using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace BongoCat.UI;

public class ContentSizeFitterMax : ContentSizeFitter
{
	[SerializeField]
	[FormerlySerializedAs("maxSize")]
	private Vector2 _maxSize;

	public override void SetLayoutHorizontal()
	{
		base.SetLayoutHorizontal();
		ClampAxis(RectTransform.Axis.Horizontal, _maxSize.x);
	}

	public override void SetLayoutVertical()
	{
		base.SetLayoutVertical();
		ClampAxis(RectTransform.Axis.Vertical, _maxSize.y);
	}

	private void ClampAxis(RectTransform.Axis axis, float max)
	{
		if (!(max <= 0f))
		{
			RectTransform rectTransform = (RectTransform)base.transform;
			if (((axis == RectTransform.Axis.Horizontal) ? rectTransform.rect.width : rectTransform.rect.height) > max)
			{
				rectTransform.SetSizeWithCurrentAnchors(axis, max);
			}
		}
	}
}
