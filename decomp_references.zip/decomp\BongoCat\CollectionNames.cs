using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace BongoCat;

public class CollectionNames : ScriptableObject
{
	[Serializable]
	public struct CollectionName
	{
		public string Key;

		public List<string> OtherKeys;

		public string DisplayName;

		public Color DisplayColor;

		public Sprite Icon;

		public bool AlwaysVisible;
	}

	public struct HeaderAttributes
	{
		public string DisplayName;

		public Color CollectionColor;

		public Sprite HeaderIcon;
	}

	[FormerlySerializedAs("_collections")]
	[SerializeField]
	public List<CollectionName> Collections;

	private Dictionary<string, HeaderAttributes> _collectionsDict;

	public HeaderAttributes GetDisplayValues(string key)
	{
		if (_collectionsDict == null)
		{
			_collectionsDict = new Dictionary<string, HeaderAttributes>();
			foreach (CollectionName collection in Collections)
			{
				HeaderAttributes value = new HeaderAttributes
				{
					DisplayName = collection.DisplayName,
					CollectionColor = collection.DisplayColor,
					HeaderIcon = collection.Icon
				};
				_collectionsDict.Add(collection.Key, value);
				foreach (string otherKey in collection.OtherKeys)
				{
					_collectionsDict.Add(otherKey, value);
				}
			}
		}
		if (_collectionsDict.TryGetValue(key, out var value2))
		{
			return value2;
		}
		Debug.LogWarning("[CollectionNames] Key " + key + " not found. Using key as name.");
		return new HeaderAttributes
		{
			DisplayName = key,
			CollectionColor = Color.white,
			HeaderIcon = null
		};
	}

	public int GetIndex(string displayName)
	{
		return Collections.FindIndex((CollectionName c) => c.DisplayName == displayName);
	}
}
