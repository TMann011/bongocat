using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public interface ISlotOccupant
{
	CatRotator Rotator { get; }

	FlipVisuals FlipVisuals { get; }

	CatPatter Patter { get; }

	Vector2 Pos { get; }

	void SetPos(Vector2 pos);
}
