using System.Collections.Generic;
using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class MultiplayerDebugClass : MonoBehaviour
{
	public List<UserData> _lobbyListEntriesKey;

	public List<LobbyListEntry> _lobbyListEntriesValues;

	public List<UserData> _gameplayInstancesKeys;

	public List<LobbyMemberInstance> _gameplayInstancesValues;

	public List<UserData> _leaderboardKeys;

	public List<LeaderboardEntry> _leaderboardValues;

	private void Update()
	{
		_lobbyListEntriesKey = new List<UserData>(MultiplayerLobbyReferences.LobbyListEntries.Keys);
		_lobbyListEntriesValues = new List<LobbyListEntry>(MultiplayerLobbyReferences.LobbyListEntries.Values);
		_gameplayInstancesKeys = new List<UserData>(MultiplayerLobbyReferences.GameplayInstances.Keys);
		_gameplayInstancesValues = new List<LobbyMemberInstance>(MultiplayerLobbyReferences.GameplayInstances.Values);
		_leaderboardKeys = new List<UserData>(MultiplayerLobbyReferences.LeaderboardEntries.Keys);
		_leaderboardValues = new List<LeaderboardEntry>(MultiplayerLobbyReferences.LeaderboardEntries.Values);
	}
}
