using System;
using Heathen.SteamworksIntegration.API;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct ChatRoom : IEquatable<ChatRoom>
{
	public ClanData clan;

	public CSteamID id;

	public EChatRoomEnterResponse enterResponse;

	public UserData[] Members => Clans.Client.GetChatMembers(clan);

	public bool IsOpenInSteam => Clans.Client.IsClanChatWindowOpenInSteam(id);

	public bool SendMessage(string message)
	{
		return SteamFriends.SendClanChatMessage(id, message);
	}

	public bool OpenChatWindowInSteam()
	{
		return Clans.Client.OpenChatWindowInSteam(id);
	}

	public void Leave()
	{
		Clans.Client.LeaveChatRoom(id);
	}

	public bool Equals(ChatRoom other)
	{
		if (clan == other.clan)
		{
			return id == other.id;
		}
		return false;
	}

	public override bool Equals(object obj)
	{
		if (obj is ChatRoom other)
		{
			return Equals(other);
		}
		return base.Equals(obj);
	}

	public override int GetHashCode()
	{
		return clan.GetHashCode() ^ id.GetHashCode();
	}
}
