using Heathen.SteamworksIntegration.API;
using SteamTools;
using UnityEngine;
using UnityEngine.UI;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamAchievementData))]
public class SteamAchievementIcon : MonoBehaviour
{
	public RawImage image;

	private SteamAchievementData _data;

	private void Awake()
	{
		_data = GetComponent<SteamAchievementData>();
	}

	private void Start()
	{
		StatsAndAchievements.Client.OnAchievementStatusChanged.AddListener(HandleChange);
		Interface.WhenReady(Refresh);
	}

	private void OnDestroy()
	{
		StatsAndAchievements.Client.OnAchievementStatusChanged.RemoveListener(HandleChange);
	}

	private void HandleChange(string arg0, bool arg1)
	{
		Refresh();
	}

	private void Refresh()
	{
		if (!string.IsNullOrEmpty(_data.apiName))
		{
			StatsAndAchievements.Client.GetAchievementIcon(_data.apiName, delegate(Texture2D texture)
			{
				image.texture = texture;
			});
		}
		Events.OnSteamInitialised -= Refresh;
	}
}
