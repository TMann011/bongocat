using System;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct NearFilter : IEquatable<NearFilter>, IComparable<NearFilter>
{
	public string key;

	public int value;

	public int CompareTo(NearFilter other)
	{
		if (key.CompareTo(other.key) != 0)
		{
			return key.CompareTo(other.key);
		}
		int num = value;
		return num.CompareTo(other.value);
	}

	public bool Equals(NearFilter other)
	{
		if (key.Equals(other.key))
		{
			int num = value;
			return num.Equals(other.value);
		}
		return false;
	}

	public override bool Equals(object obj)
	{
		if (obj.GetType() == typeof(NearFilter))
		{
			return this == (NearFilter)obj;
		}
		if (obj.GetType() == typeof(MetadataTemplate))
		{
			MetadataTemplate metadataTemplate = (MetadataTemplate)obj;
			if (int.TryParse(metadataTemplate.value, out var result))
			{
				if (key == metadataTemplate.key)
				{
					return value == result;
				}
				return false;
			}
			return false;
		}
		return false;
	}

	public override int GetHashCode()
	{
		int hashCode = key.GetHashCode();
		int num = value;
		return hashCode ^ num.GetHashCode();
	}

	public static bool operator ==(NearFilter l, NearFilter r)
	{
		if (l.key == r.key)
		{
			return l.value == r.value;
		}
		return false;
	}
}
