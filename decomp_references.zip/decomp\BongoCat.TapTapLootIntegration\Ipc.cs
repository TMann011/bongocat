using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using BongoCat.IPC;
using BongoCat.Multiplayer;
using BongoCat.OSSpecific;
using Heathen.SteamworksIntegration;
using Newtonsoft.Json;
using UnityEngine;

namespace BongoCat.TapTapLootIntegration;

public class Ipc : MonoBehaviour
{
	public static Ipc Instance;

	private Thread _t;

	private Thread _farmerReplacedThread;

	private volatile bool _isRunning;

	private volatile bool _isRunningFarmerReplaced;

	private NamedPipeServerStream _pipeServer;

	private NamedPipeClientStream _pipeClient;

	private List<TapTapLootBuff> _buffs = new List<TapTapLootBuff>();

	private bool _buffsChanged;

	private readonly object _lock = new object();

	private int _taps;

	private void Awake()
	{
		Instance = this;
	}

	public void Start()
	{
		if (!Application.isEditor)
		{
			_isRunning = true;
			_t = new Thread(BongoCatServerThread)
			{
				IsBackground = true
			};
			_t.Start();
			_isRunningFarmerReplaced = true;
			_farmerReplacedThread = new Thread(TheFarmerWasReplacedThread)
			{
				IsBackground = true
			};
			_farmerReplacedThread.Start();
		}
	}

	private void OnDestroy()
	{
		_isRunning = false;
		_isRunningFarmerReplaced = false;
		try
		{
			_pipeServer?.Dispose();
		}
		catch
		{
		}
		try
		{
			_pipeClient?.Dispose();
		}
		catch
		{
		}
		_t?.Join(500);
		_farmerReplacedThread?.Join(500);
		_t = null;
		_farmerReplacedThread = null;
	}

	private void Update()
	{
		if (_taps > 0)
		{
			BongoCat.OSSpecific.GlobalKeyHook.Instance.OnKeyPressed?.Invoke(_taps);
			_taps = 0;
		}
	}

	public void UpdateBuffs()
	{
		if (!_isRunning)
		{
			return;
		}
		Dictionary<string, float> dictionary = new Dictionary<string, float>();
		if ((bool)CatCosmetics.Instance && CatCosmetics.Instance.EquippedItems != null)
		{
			foreach (SteamItemRuntime item in CatCosmetics.Instance.EquippedItems.Distinct())
			{
				if (item.Data.TapTapLootBuffs == null)
				{
					continue;
				}
				foreach (TapTapLootBuff tapTapLootBuff in item.Data.TapTapLootBuffs)
				{
					if (dictionary.ContainsKey(tapTapLootBuff.Name))
					{
						dictionary[tapTapLootBuff.Name] += tapTapLootBuff.Value;
					}
					else
					{
						dictionary.Add(tapTapLootBuff.Name, tapTapLootBuff.Value);
					}
				}
			}
		}
		if ((bool)MultiplayerLobby.Instance && MultiplayerLobbyReferences.GameplayInstances != null)
		{
			foreach (KeyValuePair<UserData, LobbyMemberInstance> gameplayInstance in MultiplayerLobbyReferences.GameplayInstances)
			{
				if (gameplayInstance.Key.IsMe || gameplayInstance.Value.IsHidden)
				{
					continue;
				}
				CatCosmeticsMultiplayer componentInChildren = gameplayInstance.Value.GetComponentInChildren<CatCosmeticsMultiplayer>();
				if (!componentInChildren || componentInChildren.EquippedItems == null)
				{
					continue;
				}
				foreach (SteamItemRuntime item2 in componentInChildren.EquippedItems.Distinct())
				{
					if (item2.Data.TapTapLootBuffs == null)
					{
						continue;
					}
					foreach (TapTapLootBuff tapTapLootBuff2 in item2.Data.TapTapLootBuffs)
					{
						if (dictionary.ContainsKey(tapTapLootBuff2.Name))
						{
							dictionary[tapTapLootBuff2.Name] += tapTapLootBuff2.Value * 0.25f;
						}
						else
						{
							dictionary.Add(tapTapLootBuff2.Name, tapTapLootBuff2.Value * 0.25f);
						}
					}
				}
			}
		}
		lock (_lock)
		{
			_buffs = dictionary.Select((KeyValuePair<string, float> kv) => new TapTapLootBuff(kv.Key, kv.Value)).ToList();
			_buffsChanged = true;
		}
	}

	private void TheFarmerWasReplacedThread()
	{
		while (_isRunningFarmerReplaced)
		{
			try
			{
				using NamedPipeClientStream namedPipeClientStream = new NamedPipeClientStream(".", "BongoCatxTheFarmerWasReplaced", PipeDirection.InOut, PipeOptions.Asynchronous, TokenImpersonationLevel.Anonymous);
				_pipeClient = namedPipeClientStream;
				namedPipeClientStream.Connect(1000);
				StreamString streamString = new StreamString(namedPipeClientStream);
				while (_isRunningFarmerReplaced && namedPipeClientStream.IsConnected)
				{
					Thread.Sleep(90);
					string text = streamString.ReadString();
					if (!string.IsNullOrEmpty(text))
					{
						_taps += int.Parse(text);
					}
				}
			}
			catch (Exception)
			{
			}
			if (_isRunningFarmerReplaced)
			{
				Thread.Sleep(1000);
			}
		}
	}

	private void BongoCatServerThread()
	{
		while (_isRunning)
		{
			try
			{
				using NamedPipeServerStream namedPipeServerStream = new NamedPipeServerStream("TapTapLootxBongoCat", PipeDirection.InOut, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
				_pipeServer = namedPipeServerStream;
				namedPipeServerStream.WaitForConnection();
				StreamString streamString = new StreamString(namedPipeServerStream);
				bool flag = true;
				while (_isRunning && namedPipeServerStream.IsConnected)
				{
					List<TapTapLootBuff> list = null;
					lock (_lock)
					{
						if (flag || _buffsChanged)
						{
							list = _buffs;
							flag = false;
							_buffsChanged = false;
						}
					}
					if (list != null)
					{
						streamString.WriteString(JsonConvert.SerializeObject(list));
					}
					Thread.Sleep(500);
				}
			}
			catch (Exception)
			{
			}
			if (_isRunning)
			{
				Thread.Sleep(1000);
			}
		}
	}
}
