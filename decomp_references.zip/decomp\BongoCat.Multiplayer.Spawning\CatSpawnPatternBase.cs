using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public abstract class CatSpawnPatternBase : ICatSpawnPattern
{
	protected readonly CatSpawnSettings Settings;

	public abstract SpawnControls Controls { get; }

	public virtual float MaxDistancePercent => 1f;

	public virtual float MaxVerticalDistancePercent => 1f;

	public virtual bool ComputesSlots => true;

	public virtual bool PlayerAuthoredSlots => false;

	public virtual bool KeepsCatsOnTheirSlots => false;

	public virtual bool AnchoredOnMainCat => false;

	public virtual bool IncludesMainCat => Settings.IncludeMainCatToggle.Value;

	public virtual int RotationState => Settings.RotationOffset;

	public virtual AnchorCorners[] OfferedAnchorCorners => (AnchorCorners[])Enum.GetValues(typeof(AnchorCorners));

	public virtual AnchorCorners ResolvedAnchorCorner => Settings.AnchorCorner;

	protected int CatCount => MultiplayerLobbyReferences.VisibleCats.Count() + (IncludesMainCat ? 1 : 0);

	protected float PreferredSpacing => SpawnGeometry.SpacingFor(Settings.PreferredDistancePercent);

	protected float PreferredVerticalSpacing => SpawnGeometry.SpacingFor(Settings.PreferredVerticalDistancePercent);

	protected bool AnchorIsRight => Settings.AnchorCorner.IsRight();

	protected bool AnchorIsTop => Settings.AnchorCorner.IsTop();

	protected bool AnchorIsCenter => Settings.AnchorCorner == AnchorCorners.Center;

	protected CatSpawnPatternBase(CatSpawnSettings settings)
	{
		Settings = settings;
	}

	protected abstract List<CatSlot> Layout();

	public List<CatSlot> CreateSlots()
	{
		List<CatSlot> list = Layout();
		foreach (CatSlot item in list)
		{
			item.RotationState = SlotRotation(item.RotationState);
			if (!item.ReservedForMainCat)
			{
				item.Position = SpawnGeometry.KeepCatOnScreen(item.Position, item.RotationState);
			}
		}
		return list;
	}

	protected virtual int SlotRotation(int layoutRotation)
	{
		return (layoutRotation + Settings.RotationOffset) % 4;
	}

	protected int SlotsFromSlider(int tightestCount)
	{
		int num = Mathf.Max(1, CatCount);
		if (tightestCount <= num)
		{
			return tightestCount;
		}
		return Mathf.RoundToInt(Mathf.Lerp(tightestCount, num, Mathf.Clamp01(Settings.PreferredDistancePercent)));
	}

	protected static IEnumerable<int> FillOrderIndices(int count, bool fromFarEnd, bool fromCenter)
	{
		if (!fromCenter)
		{
			for (int i = 0; i < count; i++)
			{
				yield return fromFarEnd ? (count - 1 - i) : i;
			}
			yield break;
		}
		int mid = (count - 1) / 2;
		yield return mid;
		for (int i = 1; i < count; i++)
		{
			if (mid - i >= 0)
			{
				yield return mid - i;
			}
			if (mid + i <= count - 1)
			{
				yield return mid + i;
			}
		}
	}
}
