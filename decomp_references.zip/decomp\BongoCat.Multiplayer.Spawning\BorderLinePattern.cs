using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public class BorderLinePattern : CatSpawnPatternBase
{
	private readonly int _rotationState;

	private readonly AnchorCorners[] _offeredCorners;

	public override SpawnControls Controls => SpawnControls.Spacing | SpawnControls.Anchor | SpawnControls.IncludeMainCat | SpawnControls.SnapCats | SpawnControls.Recalculate;

	public override AnchorCorners[] OfferedAnchorCorners => _offeredCorners;

	public override AnchorCorners ResolvedAnchorCorner
	{
		get
		{
			if (_offeredCorners.Contains(Settings.AnchorCorner))
			{
				return Settings.AnchorCorner;
			}
			AnchorCorners[] offeredCorners = _offeredCorners;
			foreach (AnchorCorners anchorCorners in offeredCorners)
			{
				if (anchorCorners != AnchorCorners.Center && (RunsHorizontally ? (anchorCorners.IsRight() == base.AnchorIsRight) : (anchorCorners.IsTop() == base.AnchorIsTop)))
				{
					return anchorCorners;
				}
			}
			return _offeredCorners[0];
		}
	}

	private bool RunsHorizontally
	{
		get
		{
			int rotationState = _rotationState;
			return rotationState == 0 || rotationState == 2;
		}
	}

	private float Span
	{
		get
		{
			if (!RunsHorizontally)
			{
				return SpawnGeometry.ScreenHeight;
			}
			return SpawnGeometry.ScreenWidth;
		}
	}

	public BorderLinePattern(CatSpawnSettings settings, int rotationState, params AnchorCorners[] offeredCorners)
		: base(settings)
	{
		_rotationState = rotationState;
		_offeredCorners = offeredCorners;
	}

	protected override List<CatSlot> Layout()
	{
		return BuildLine(Span);
	}

	public List<CatSlot> BuildLine(float spanLength)
	{
		float spacing = SpawnGeometry.TightestSpacing;
		int count = SlotsFromSlider(SpawnGeometry.SlotsSpanning(spanLength, ref spacing));
		float spacing2 = SpawnGeometry.SpanStep(spanLength, count);
		Vector2 start;
		Vector2 direction;
		switch (_rotationState)
		{
		case 1:
			start = new Vector2(SpawnGeometry.XMax, SpawnGeometry.YMin + SpawnGeometry.Inset);
			direction = Vector2.up;
			break;
		case 2:
			start = new Vector2(SpawnGeometry.XMin + SpawnGeometry.Inset, SpawnGeometry.YMax);
			direction = Vector2.right;
			break;
		case 3:
			start = new Vector2(SpawnGeometry.XMin, SpawnGeometry.YMin + SpawnGeometry.Inset);
			direction = Vector2.up;
			break;
		default:
			start = new Vector2(SpawnGeometry.XMin + SpawnGeometry.Inset, SpawnGeometry.YMin);
			direction = Vector2.right;
			break;
		}
		bool fromFarEnd = (RunsHorizontally ? base.AnchorIsRight : base.AnchorIsTop);
		return (from i in CatSpawnPatternBase.FillOrderIndices(count, fromFarEnd, base.AnchorIsCenter)
			select new CatSlot
			{
				Position = start + direction * (spacing2 * (float)i),
				RotationState = _rotationState
			}).ToList();
	}
}
