using UnityEngine;
using UnityEngine.UI;

namespace Tutorial;

public class ChestTutorial : TutorialStep
{
	[SerializeField]
	private Button _counterButton;

	[SerializeField]
	private FakeShop _fakeShop;

	public void OnBegin()
	{
		_counterButton.onClick.AddListener(ToggleShopVisibility);
	}

	public void OnComplete()
	{
		_counterButton.onClick.RemoveListener(ToggleShopVisibility);
	}

	private void ToggleShopVisibility()
	{
		_fakeShop.ToggleVisibility();
		Complete();
	}
}
