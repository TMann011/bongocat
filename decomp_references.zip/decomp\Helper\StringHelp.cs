namespace Helper;

public static class StringHelp
{
	public static string GetSuffixString(long val)
	{
		string result = val.ToString();
		if (val >= 1000)
		{
			result = (val / 1000).ToString("D") + "k";
		}
		return result;
	}
}
