using System.Collections;
using BongoCat;
using IroxGames.Helper.ClassExtensions;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ItemCollectionHeader : MonoBehaviour
{
	[SerializeField]
	private Slider _progressBar;

	[SerializeField]
	private Image _progressBarBackground;

	[SerializeField]
	private Image _progressBarFill;

	[SerializeField]
	private float _progressBarAlpha;

	[SerializeField]
	private TMP_Text _title;

	[SerializeField]
	private TMP_Text _amountIndicator;

	[SerializeField]
	private Image _coverIcon;

	[SerializeField]
	private GameObject _hideAllButton;

	[SerializeField]
	private GameObject _hiddenIndicator;

	private ItemCollection _collection;

	private bool _titleLayoutPending;

	public void Init(ItemCollection collection, CollectionNames.CollectionName attributes)
	{
		_collection = collection;
		_title.text = attributes.DisplayName;
		_titleLayoutPending = true;
		_progressBarFill.color = attributes.DisplayColor;
		_progressBarBackground.color = attributes.DisplayColor.SetA(_progressBarAlpha);
		SetInfo();
		RebuildTitleLayout();
		if ((bool)_coverIcon)
		{
			_coverIcon.sprite = attributes.Icon;
			string text = attributes.DisplayName.ToLower();
			if (text == "emotes" || text == "consumables")
			{
				_coverIcon.transform.localScale = Vector3.one * 0.4f;
			}
		}
	}

	public void SetInfo()
	{
		_amountIndicator.text = $"({_collection.OwnedItems} / {_collection.Count})";
		_progressBar.value = (float)_collection.OwnedItems / Mathf.Max(_collection.Count, 1f);
		base.gameObject.SetActiveWithCheck(_collection.Count > 0);
		_hideAllButton.SetActiveWithCheck(_collection.ContainsVisibleItems);
		_hiddenIndicator.SetActiveWithCheck(!_collection.ContainsVisibleItems);
	}

	public void Enable(bool show)
	{
		base.gameObject.SetActive(show);
		if (show)
		{
			SetInfo();
		}
	}

	public void ShowHiddenIndicator(bool show)
	{
		_hiddenIndicator.SetActive(show);
		_hideAllButton.SetActive(!show);
	}

	private void OnEnable()
	{
		RebuildTitleLayout();
	}

	private void RebuildTitleLayout()
	{
		if (_titleLayoutPending && base.gameObject.activeInHierarchy)
		{
			StartCoroutine(RebuildTitleLayoutDelayed());
		}
	}

	private IEnumerator RebuildTitleLayoutDelayed()
	{
		yield return null;
		_title.ForceMeshUpdate();
		LayoutRebuilder.ForceRebuildLayoutImmediate((RectTransform)_title.transform);
		LayoutRebuilder.ForceRebuildLayoutImmediate((RectTransform)_title.transform.parent);
		_titleLayoutPending = false;
	}
}
