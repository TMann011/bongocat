using Heathen.SteamworksIntegration.API;
using SteamTools;
using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamAchievementData))]
public class SteamAchievementDescription : MonoBehaviour
{
	public TextMeshProUGUI label;

	private SteamAchievementData _mData;

	private void Awake()
	{
		_mData = GetComponent<SteamAchievementData>();
		Interface.WhenReady(Refresh);
	}

	private void OnDestroy()
	{
		Events.OnSteamInitialised -= Refresh;
	}

	public void Refresh()
	{
		if (!string.IsNullOrEmpty(_mData.apiName))
		{
			label.text = StatsAndAchievements.Client.GetAchievementDisplayAttribute(_mData.apiName, AchievementAttributes.Desc);
		}
		Events.OnSteamInitialised -= Refresh;
	}
}
