using System;
using System.Collections;
using Steamworks;
using UnityEngine;

namespace Steam;

public class SteamAnalytics : MonoBehaviour
{
	public static SteamAnalytics Instance;

	private const string MAU_KEY = "MAU";

	public const string PREM_KEY = "PREM";

	public const string PREM_AMT_KEY = "PREM_AMT";

	private void Awake()
	{
		Instance = this;
	}

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => StatsInitializer.Initialized);
		SteamUserStats.SetStat(string.Format("{0}_{1}_{2}", "MAU", DateTime.UtcNow.Year, DateTime.UtcNow.Month), 1);
		SteamUserStats.StoreStats();
	}

	public void SetStatToOne(string stat)
	{
		SteamUserStats.SetStat(stat, 1);
		SteamUserStats.StoreStats();
	}
}
