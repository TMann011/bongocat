namespace Heathen.SteamworksIntegration;

public enum SteamLobbyModeType
{
	General,
	Session,
	Party
}
