using System;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct LeaderboardScoreUploaded
{
	public LeaderboardScoreUploaded_t Data;

	public LeaderboardData Leaderboard => Data.m_hSteamLeaderboard;

	public int GlobalRankNew => Data.m_nGlobalRankNew;

	public int GlobalRankPrevious => Data.m_nGlobalRankPrevious;

	public static implicit operator LeaderboardScoreUploaded(LeaderboardScoreUploaded_t native)
	{
		return new LeaderboardScoreUploaded
		{
			Data = native
		};
	}
}
