using Heathen.SteamworksIntegration;
using SteamTools;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;

namespace BongoCat.Multiplayer;

public class LobbyIdDisplay : MonoBehaviour
{
	[SerializeField]
	private TMP_Text _text;

	[SerializeField]
	private PlayerPrefsToggle _hideLobbyIdToggle;

	[SerializeField]
	private GameObject _hideIdObject;

	[SerializeField]
	private GameObject _lobbyCodeDisplay;

	[SerializeField]
	private TMP_Text _lobbyCodeTxt;

	[SerializeField]
	private LocalizedString _privateLobbyLoca;

	[SerializeField]
	private GameObject _lobbyCodeButtons;

	private string _lobbyId;

	private string _customLobbyId;

	private bool _hidden;

	private void Start()
	{
		_hideLobbyIdToggle.OnToggleUpdated.AddListener(SetHidden);
		SetHidden(_hideLobbyIdToggle.Value);
		Events.OnLobbyEnterSuccess += OnLobbyEntered;
		Events.OnLobbyDataUpdate += OnLobbyDataUpdate;
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= OnLobbyEntered;
		Events.OnLobbyDataUpdate -= OnLobbyDataUpdate;
	}

	private void OnLobbyDataUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		HideLobbyId(LobbyData.Current.Type == ELobbyType.k_ELobbyTypePrivate);
		SettingsManager.Instance.PrivateLobby.SetSelection((int)LobbyData.Current.Type, onlyUpdateVisuals: true);
	}

	private void OnLobbyEntered(LobbyData lobby)
	{
		SettingsManager.Instance.PrivateLobby.SetSelection((int)lobby.Type, onlyUpdateVisuals: true);
		_lobbyId = BaseConverter.EncodeToBase59(lobby.SteamId.m_SteamID);
		if (!string.IsNullOrEmpty(_customLobbyId))
		{
			LobbyData.Current.LobbyCode = _customLobbyId;
			_lobbyId = _customLobbyId;
			_customLobbyId = "";
		}
		else if (!string.IsNullOrEmpty(LobbyData.Current.LobbyCode))
		{
			_lobbyId = LobbyData.Current.LobbyCode;
		}
		_text.text = _lobbyId;
		SetHidden(_hideLobbyIdToggle.Value);
		HideLobbyId(lobby.Type == ELobbyType.k_ELobbyTypePrivate);
	}

	private void HideLobbyId(bool hide)
	{
		_lobbyCodeTxt.text = (hide ? _privateLobbyLoca.GetLocalizedString() : _lobbyId);
		_lobbyCodeButtons.SetActive(!hide);
	}

	public void CopyToClipboard()
	{
		GUIUtility.systemCopyBuffer = _lobbyId;
	}

	public void SetLobbyId(string id)
	{
		_customLobbyId = id;
	}

	private void SetHidden(bool hide)
	{
		_hidden = hide;
		_hideIdObject.SetActive(_hidden);
	}
}
