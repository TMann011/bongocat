using DG.Tweening;
using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat.Multiplayer;

public class OpenChestForMember : MonoBehaviour
{
	[SerializeField]
	private SteamUserData _targetUser;

	[SerializeField]
	private ChestType _chestType;

	[SerializeField]
	private SetActiveBasedOnLobbyMemberValue _setChestActive;

	private bool _hasClicked;

	private Shop TargetShop
	{
		get
		{
			if (_chestType != ChestType.Emote)
			{
				return Shop.NormalShop;
			}
			return Shop.EmoteShop;
		}
	}

	public void Reset()
	{
		_hasClicked = false;
	}

	public void OnClicked()
	{
		if (!_hasClicked && TargetShop.TryGiftChestTo(_targetUser.Data, _setChestActive))
		{
			base.transform.DOComplete();
			base.transform.DOPunchScale(Vector3.one * 0.15f, 0.4f).SetLink(base.gameObject);
			_hasClicked = true;
			_setChestActive.FreezeState();
		}
	}
}
