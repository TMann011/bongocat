using System;
using System.Text;
using Heathen.SteamworksIntegration.API;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct RemoteStorageFile : IEquatable<RemoteStorageFile>
{
	public string name;

	public int size;

	public DateTime Timestamp;

	public bool Equals(RemoteStorageFile other)
	{
		if (name.Equals(other.name) && size.Equals(other.size))
		{
			return Timestamp.Equals(other.Timestamp);
		}
		return false;
	}

	public override bool Equals(object obj)
	{
		if (obj.GetType() == typeof(RemoteStorageFile))
		{
			return Equals((RemoteStorageFile)obj);
		}
		return base.Equals(obj);
	}

	public override int GetHashCode()
	{
		return name.GetHashCode() ^ size.GetHashCode() ^ Timestamp.GetHashCode();
	}

	public override string ToString()
	{
		return RemoteStorage.Client.FileReadString(name, Encoding.UTF8);
	}
}
