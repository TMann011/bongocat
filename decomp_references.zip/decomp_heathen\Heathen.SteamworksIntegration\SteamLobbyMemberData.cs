using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamUserData))]
public class SteamLobbyMemberData : MonoBehaviour
{
	private LobbyMemberData _mData;

	private SteamUserData _mUserData;

	private SteamLobbyMemberDataEvents _mEvents;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> Delegates;

	public LobbyMemberData Data
	{
		get
		{
			return _mData;
		}
		set
		{
			_mData = value;
			if (_mUserData == null)
			{
				_mUserData = GetComponent<SteamUserData>();
			}
			_mUserData.Data = value.user;
			if (_mEvents != null)
			{
				_mEvents.onMetadataChanged?.Invoke(_mData.lobby, _mData);
			}
		}
	}

	public LobbyData Lobby => Data.lobby;

	public void Kick()
	{
		if (!Lobby.IsClosedLobby)
		{
			Lobby.KickMember(Data.user);
		}
	}

	private void Awake()
	{
		_mUserData = GetComponent<SteamUserData>();
		_mEvents = GetComponent<SteamLobbyMemberDataEvents>();
	}
}
