using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat.Emotes;
using BongoCat.Multiplayer;
using DG.Tweening;
using Heathen.SteamworksIntegration;
using IroxGames.Helper;
using SteamTools;
using Steamworks;
using TMPro;
using UnityEngine;
using Vfx;

namespace BongoCat;

public class Shop : MonoBehaviour
{
	[SerializeField]
	private bool _isEmoteShop;

	private int _stockRefreshTime = 1800;

	public int StockRefreshTimeLeft;

	[SerializeField]
	private string _shopTimeKey = "TIME_LEFT";

	[SerializeField]
	private float _delayDefocusOnStartup;

	private bool _canDefocus;

	[SerializeField]
	private ShopItem _shopItem;

	[SerializeField]
	private GameObject _shopVisuals;

	[SerializeField]
	private Sprite _giftIcon;

	[SerializeField]
	private GameObject _loadingObj;

	[SerializeField]
	private GameObject _successObj;

	[SerializeField]
	private GameObject _failObj;

	[SerializeField]
	private GameObject _outOfStockObj;

	private TMP_Text _stockRefreshText;

	[SerializeField]
	private PricePaid _pricePaid;

	[SerializeField]
	private ErrorMessage _genericSteamError;

	[SerializeField]
	private FlashAnimation _counterFlash;

	private ShakeAnimation _shakeAnimation;

	[SerializeField]
	private PlayerPrefsToggle _showChestPopup;

	public bool ChestIsReady;

	private bool _sentChestReady;

	public static Shop NormalShop;

	public static Shop EmoteShop;

	private readonly Queue<Action> _pendingGiftPayoffs = new Queue<Action>();

	private bool _openingChest;

	public bool CanGetChest
	{
		get
		{
			if (ChestIsReady)
			{
				return _shopItem.CanBuy();
			}
			return false;
		}
	}

	public ChestType ChestType
	{
		get
		{
			if (!_isEmoteShop)
			{
				return ChestType.Cosmetic;
			}
			return ChestType.Emote;
		}
	}

	private bool ShowChest
	{
		get
		{
			if (SettingsManager.Instance.MultiplayerPopups.Value)
			{
				if (_isEmoteShop)
				{
					return SettingsManager.Instance.ShowEmoteChest.Value;
				}
				return true;
			}
			return false;
		}
	}

	private void Awake()
	{
		_shakeAnimation = _shopVisuals.GetComponent<ShakeAnimation>();
		if (_isEmoteShop)
		{
			EmoteShop = this;
		}
		else
		{
			NormalShop = this;
		}
	}

	private IEnumerator Start()
	{
		SteamMultiplayer instance = SteamMultiplayer.Instance;
		instance.OnOpenChestForMeReceived = (Action<CSteamID, ChestType>)Delegate.Combine(instance.OnOpenChestForMeReceived, new Action<CSteamID, ChestType>(OnRemoteChestOpenRequested));
		Events.OnLobbyEnterSuccess += InitChestStatus;
		StockRefreshTimeLeft = PlayerPrefs.GetInt(_shopTimeKey, _stockRefreshTime);
		StockRefreshTimeLeft = Mathf.Min(StockRefreshTimeLeft, _stockRefreshTime);
		_shopItem.gameObject.SetActive(value: false);
		_outOfStockObj.SetActive(value: true);
		_stockRefreshText = _outOfStockObj.GetComponent<TMP_Text>();
		UpdateStockRefreshText();
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		_shopVisuals.SetActive(_showChestPopup.Value || SettingsManager.Instance.AlwaysShowChest.Value);
		StartCoroutine(DelayDefocusApplication());
		StartCoroutine(TimerUpdate());
	}

	public void SetLoadingVisuals()
	{
		_openingChest = true;
		_shopItem.gameObject.SetActive(value: false);
		_outOfStockObj.SetActive(value: false);
		_loadingObj.SetActive(value: true);
	}

	public void SetSuccessVisuals(bool success, bool showError = true, bool animatePrice = true)
	{
		if (success && SettingsManager.Instance.AnimateChestPurchase.Value)
		{
			_shopVisuals.transform.DOPunchScale(Vector3.one * 0.15f, 0.5f);
			if (animatePrice)
			{
				_pricePaid.Animate();
			}
		}
		_successObj.SetActive(success);
		_failObj.SetActive(!success);
		_shopItem.gameObject.SetActive(value: false);
		_outOfStockObj.SetActive(value: false);
		_loadingObj.SetActive(value: false);
		StartCoroutine(SetOutOfStockDelayed());
		_openingChest = false;
		if (success)
		{
			return;
		}
		StockRefreshTimeLeft = 60;
		UpdateStockRefreshText();
		ChestIsReady = false;
		_sentChestReady = false;
		SendChestReady(ready: false);
		if (showError)
		{
			ErrorMessageHandler.Instance.SetErrorMessage(_genericSteamError, delegate
			{
				ErrorMessageHandler.Instance.CloseErrorPopup();
			});
		}
	}

	private IEnumerator SetOutOfStockDelayed()
	{
		yield return new WaitForSeconds(0.8f);
		_successObj.SetActive(value: false);
		_failObj.SetActive(value: false);
		_outOfStockObj.SetActive(value: true);
	}

	private IEnumerator DelayDefocusApplication()
	{
		yield return new WaitForSecondsRealtime(_delayDefocusOnStartup);
		_canDefocus = true;
		OnApplicationFocus(Application.isFocused);
	}

	private void OnApplicationFocus(bool hasFocus)
	{
		if (!hasFocus && (StockRefreshTimeLeft > 0 || !CanGetChest) && _canDefocus)
		{
			HideTimer(applicationDefocused: true);
		}
	}

	private IEnumerator TimerUpdate()
	{
		while (true)
		{
			if (_outOfStockObj.activeSelf)
			{
				StockRefreshTimeLeft--;
				PlayerPrefs.SetInt(_shopTimeKey, StockRefreshTimeLeft);
				UpdateStockRefreshText();
				if (StockRefreshTimeLeft <= 0)
				{
					if ((_isEmoteShop ? Game.Inventory.Emote_Chest_Token : Game.Inventory.Chest_Token).GetTotalQuantity() == 0L)
					{
						StockRefreshTimeLeft = 60;
					}
					else
					{
						StockRefreshTimeLeft = 0;
						_shopItem.gameObject.SetActive(value: true);
						_outOfStockObj.SetActive(value: false);
						ChestIsReady = true;
						OnChestReady();
					}
				}
			}
			else if (StockRefreshTimeLeft <= 0 && !_shopVisuals.activeInHierarchy)
			{
				OnChestReady();
			}
			yield return new WaitForSecondsRealtime(1f);
		}
	}

	private void OnChestReady()
	{
		if (!_sentChestReady)
		{
			SendChestReady(ready: true);
			_sentChestReady = true;
		}
		if (_showChestPopup.Value && _shopItem.CanBuy())
		{
			_shopVisuals.SetActive(value: true);
		}
	}

	private void UpdateStockRefreshText()
	{
		_stockRefreshText.text = $"{TimeSpan.FromSeconds(StockRefreshTimeLeft):mm':'ss}";
	}

	private void OnDestroy()
	{
		PlayerPrefs.Save();
	}

	public void ItemGotBought()
	{
		StockRefreshTimeLeft = _stockRefreshTime;
		PlayerPrefs.SetInt(_shopTimeKey, StockRefreshTimeLeft);
		ChestIsReady = false;
		_sentChestReady = false;
		SendChestReady(ready: false);
		StartCoroutine(RoutineHelper.CallDelayed(delegate
		{
			HideTimer(applicationDefocused: true);
		}, 2f));
	}

	private void HideTimer(bool applicationDefocused = false)
	{
		if (!SettingsManager.Instance.AlwaysShowChest.Value && (!ChestIsReady || applicationDefocused))
		{
			_shopVisuals.SetActive(value: false);
		}
	}

	public void OnClick()
	{
		if (!_shopItem.gameObject.activeSelf)
		{
			_shakeAnimation.Shake();
		}
		else if (!_shopItem.CanBuy())
		{
			_shakeAnimation.Shake();
			_counterFlash.Flash();
		}
		else
		{
			_shopItem.Buy();
		}
	}

	private void SendChestReady(bool ready)
	{
		if (_isEmoteShop)
		{
			LobbyData.Current.MyEmoteChestReady = ready && ShowChest;
		}
		else
		{
			LobbyData.Current.MyChestReady = ready && ShowChest;
		}
	}

	private void InitChestStatus(LobbyData lobby)
	{
		SendChestStatus();
	}

	public void SendChestStatus()
	{
		SendChestReady(ChestIsReady);
	}

	public bool TryGiftChestTo(CSteamID target, SetActiveBasedOnLobbyMemberValue setChestActive)
	{
		if (!_shopItem.TrySpendForGift())
		{
			return false;
		}
		if (SettingsManager.Instance.AnimateChestPurchase.Value)
		{
			_pricePaid.Animate();
		}
		SendGiftAnimationTo(target, setChestActive);
		SteamMultiplayer.SendOpenChest(target, ChestType);
		return true;
	}

	private void OnRemoteChestOpenRequested(CSteamID sender, ChestType chestType)
	{
		if (!_openingChest && chestType == ChestType && ChestIsReady)
		{
			SendChestReady(ready: false);
			SetLoadingVisuals();
			SendGiftAnimationFrom(sender);
		}
	}

	public void OnGiftAnimationFinished()
	{
		if (_pendingGiftPayoffs.Count > 0)
		{
			_pendingGiftPayoffs.Dequeue()();
		}
	}

	private void SendGiftAnimationTo(CSteamID recipient, SetActiveBasedOnLobbyMemberValue setChestActive)
	{
		foreach (LobbyMemberInstance item in MultiplayerLobbyReferences.GameplayInstances.Values.Where((LobbyMemberInstance lobbyMember) => lobbyMember.steamUserData.Data.Equals(recipient)))
		{
			Debug.Log("Sending a gift to " + item.steamUserData.Data.Name + "!");
			CatPatter recipientCatPatter = item.cat.catPatter;
			Cat.Instance.catPatter.GetPat();
			if (!SettingsManager.Instance.HideEmotesSetting.Value)
			{
				_pendingGiftPayoffs.Enqueue(delegate
				{
					recipientCatPatter.GetPat(3);
					setChestActive.Unfreeze();
				});
				Cat.Instance.emoteSpawner.SpawnEmoteParticle(_giftIcon, EmoteBehaviorOverride.FlyingGift, recipientCatPatter.transform, OnGiftAnimationFinished);
			}
			else
			{
				recipientCatPatter.GetPat(3);
				setChestActive.Unfreeze();
			}
		}
	}

	private void SendGiftAnimationFrom(CSteamID sender)
	{
		foreach (LobbyMemberInstance item in MultiplayerLobbyReferences.GameplayInstances.Values.Where((LobbyMemberInstance lobbyMember) => lobbyMember.steamUserData.Data.Equals(sender)))
		{
			Debug.Log(item.steamUserData.Data.Name + " sent a gift!");
			CatPatter catPatter = item.cat.catPatter;
			EmoteSpawner emoteSpawner = item.cat.emoteSpawner;
			catPatter.GetPat();
			if (!SettingsManager.Instance.HideEmotesSetting.Value)
			{
				_pendingGiftPayoffs.Enqueue(delegate
				{
					Cat.Instance.catPatter.GetPat(3);
					_shopItem.BuyAsGift();
				});
				emoteSpawner.SpawnEmoteParticle(_giftIcon, EmoteBehaviorOverride.FlyingGift, _shopVisuals.transform, OnGiftAnimationFinished);
			}
			else
			{
				Cat.Instance.catPatter.GetPat(3);
				_shopItem.BuyAsGift();
			}
		}
	}
}
