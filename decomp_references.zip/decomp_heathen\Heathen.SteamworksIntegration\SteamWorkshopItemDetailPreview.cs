using System;
using UnityEngine;
using UnityEngine.UI;

namespace Heathen.SteamworksIntegration;

[Obsolete("Unity's built in Texture2D LoadImage cant handle many file types and this proves to be more of a liability than an aid.Recomend the developer use a 3rd party image loader and our WorkshopItemDetail.GetPreviewImage tool to get the file data.")]
[RequireComponent(typeof(SteamWorkshopItemDetailDataEvents))]
[RequireComponent(typeof(SteamWorkshopItemDetailData))]
public class SteamWorkshopItemDetailPreview : MonoBehaviour
{
	public RawImage image;

	private SteamWorkshopItemDetailData _inspector;

	private SteamWorkshopItemDetailDataEvents _events;

	private void Awake()
	{
		_inspector = GetComponent<SteamWorkshopItemDetailData>();
		_events = GetComponent<SteamWorkshopItemDetailDataEvents>();
		_events.onChange.AddListener(HandleChanged);
		HandleChanged();
	}

	private void HandleChanged()
	{
		if (image == null || _inspector.Data == null)
		{
			return;
		}
		_inspector.Data.GetPreviewImage(delegate(string path, byte[] data)
		{
			if (data != null && data.Length != 0)
			{
				Texture2D texture2D = new Texture2D(2, 2, TextureFormat.RGBA32, mipChain: false);
				if (texture2D.LoadImage(data))
				{
					image.texture = texture2D;
					image.SetNativeSize();
				}
				else
				{
					Debug.LogError("Failed to load " + path + ".");
				}
			}
		});
	}
}
