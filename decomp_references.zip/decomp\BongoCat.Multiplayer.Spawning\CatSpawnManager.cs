using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Heathen.SteamworksIntegration;
using SteamTools;
using UnityEngine;
using UnityEngine.Serialization;

namespace BongoCat.Multiplayer.Spawning;

public class CatSpawnManager : MonoBehaviour
{
	public static CatSpawnManager Instance;

	[FormerlySerializedAs("_spawnPattern")]
	[SerializeField]
	private CatSpawnSettings _settings;

	[SerializeField]
	private SpawnWindowUi _windowUi;

	[SerializeField]
	private SlotPreviews _previews;

	[SerializeField]
	private CatDepthSorter _catDepth;

	private List<CatSlot> _slots = new List<CatSlot>();

	private bool _previewing;

	private bool _windowOpen;

	private Coroutine _initialSpawnRoutine;

	private bool _rebuilding;

	public bool InitialSpawnDone;

	private ICatSpawnPattern Pattern => _settings.Pattern;

	private bool MainCatInLayout
	{
		get
		{
			if (Pattern.IncludesMainCat)
			{
				return InitialSpawnDone;
			}
			return false;
		}
	}

	private void Awake()
	{
		Instance = this;
		Events.OnLobbyEnterSuccess += PositionCatsInitial;
		Events.OnLobbyLeave += OnLobbyLeave;
		_settings.LoadFromPlayerPrefs();
	}

	private void Start()
	{
		SettingsManager.Instance.MainScreenSetting.ScreenSwitched += WatchScreenBounds;
		_windowUi.ShowPickedValues(_settings);
		_windowUi.RefreshSliders(Pattern, _settings);
		RefreshControls();
		RefreshSlotButtons();
	}

	private void WatchScreenBounds()
	{
		if (Pattern.PlayerAuthoredSlots)
		{
			PackIntoSlots(OrderedCats(), RestoredSlots());
		}
		else
		{
			Relayout();
		}
		RefreshLayoutVisuals();
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.F6) && InitialSpawnDone)
		{
			TogglePreviewCats();
		}
	}

	private void RefreshControls()
	{
		_windowUi.RefreshControls(Pattern, InitialSpawnDone);
	}

	private void PositionCatsInitial(LobbyData lobby)
	{
		if (_initialSpawnRoutine != null)
		{
			StopCoroutine(_initialSpawnRoutine);
		}
		_initialSpawnRoutine = StartCoroutine(PositionCatsAfterAllInstantiated());
	}

	private IEnumerator PositionCatsAfterAllInstantiated()
	{
		InitialSpawnDone = false;
		yield return new WaitUntil(() => !LobbyData.Current.IsValid || MultiplayerLobbyReferences.GameplayInstances.Count >= LobbyData.Current.MemberCount - 1);
		_initialSpawnRoutine = null;
		if (!LobbyData.Current.IsValid)
		{
			yield break;
		}
		_slots = RestoredSlots();
		InitialSpawnDone = true;
		SeatMainCatNearby();
		foreach (LobbyMemberInstance visibleCat in MultiplayerLobbyReferences.VisibleCats)
		{
			AssignCatToSlot(visibleCat);
		}
		if (!Pattern.ComputesSlots)
		{
			_slots.RemoveAll((CatSlot slot) => slot.Occupant == null);
		}
		RefreshControls();
		RefreshLayoutVisuals();
	}

	public void HandleCatRemoved(LobbyMemberInstance cat)
	{
		FreeSlot(cat);
		if (InitialSpawnDone)
		{
			RefreshLayoutVisuals();
		}
	}

	private List<CatSlot> BuildSlots()
	{
		return ApplyDisabledSlots(Pattern.CreateSlots());
	}

	private List<CatSlot> RestoredSlots()
	{
		List<CatSlot> list = SavedSlots.Load();
		if (list != null)
		{
			return ApplyDisabledSlots(list);
		}
		return BuildSlots();
	}

	private List<CatSlot> ApplyDisabledSlots(List<CatSlot> slots)
	{
		if (!Pattern.ComputesSlots)
		{
			return slots;
		}
		foreach (int disabledSlot in _settings.DisabledSlots)
		{
			if (disabledSlot < slots.Count && !slots[disabledSlot].ReservedForMainCat)
			{
				slots[disabledSlot].Disabled = true;
			}
		}
		return slots;
	}

	private void RefreshSlotButtons()
	{
		bool computesSlots = Pattern.ComputesSlots;
		_windowUi.RefreshSlotButtons(computesSlots && _settings.DisabledSlots.Count > 0, computesSlots && _slots.Any((CatSlot slot) => slot.Occupant == null && !slot.Disabled));
	}

	public void ToggleSlotDisabled(int index)
	{
		if (Pattern.ComputesSlots && !_slots[index].ReservedForMainCat)
		{
			if (!_settings.DisabledSlots.Add(index))
			{
				_settings.DisabledSlots.Remove(index);
			}
			CatSlot catSlot = _slots[index];
			catSlot.Disabled = _settings.DisabledSlots.Contains(index);
			if (catSlot.Disabled && catSlot.Occupant != null)
			{
				ISlotOccupant occupant = catSlot.Occupant;
				catSlot.Occupant = null;
				PlaceOnFreeSlot(occupant);
			}
			RefreshLayoutVisuals();
		}
	}

	public void DisableAllSlots()
	{
		for (int i = 0; i < _slots.Count; i++)
		{
			if (_slots[i].Occupant == null)
			{
				_settings.DisabledSlots.Add(i);
				_slots[i].Disabled = true;
			}
		}
		for (int j = _slots.Count; j < 250; j++)
		{
			_settings.DisabledSlots.Add(j);
		}
		RefreshLayoutVisuals();
	}

	public void EnableAllSlots()
	{
		_settings.DisabledSlots.Clear();
		foreach (CatSlot slot in _slots)
		{
			slot.Disabled = false;
		}
		RefreshLayoutVisuals();
	}

	private void PackIntoSlots(List<(ISlotOccupant, int)> ordered, List<CatSlot> slots)
	{
		ordered.RemoveAll(((ISlotOccupant, int) slot) => slot.Item1 == MainCat.Instance);
		_slots = slots;
		SeatMainCatNearby();
		foreach (var item in ordered)
		{
			PlaceOnFreeSlot(item.Item1, item.Item2);
		}
		RefreshLayoutVisuals();
	}

	public void Relayout()
	{
		if (Pattern.ComputesSlots)
		{
			RebuildSlots();
		}
	}

	private void RebuildSlots()
	{
		PackIntoSlots(OrderedCats(), BuildSlots());
	}

	public void RecalculatePattern()
	{
		_settings.RotationOffset = 0;
		RecalculateLayout();
	}

	public void RecalculateLayout()
	{
		_rebuilding = true;
		RebuildSlots();
		_rebuilding = false;
	}

	private List<(ISlotOccupant, int)> OrderedCats()
	{
		List<(ISlotOccupant, int)> list = (from slot in _slots.Select((CatSlot slot, int i) => (slot.Occupant, i))
			where slot.Item1 != null
			select slot).ToList();
		foreach (LobbyMemberInstance cat in MultiplayerLobbyReferences.VisibleCats)
		{
			if (!list.Any(((ISlotOccupant, int) slot) => cat == slot.Item1))
			{
				list.Add((cat, -1));
			}
		}
		return list;
	}

	public void TryCalcPosition(LobbyMemberInstance cat)
	{
		if (InitialSpawnDone && !cat.IsHidden)
		{
			AssignCatToSlot(cat);
			RefreshLayoutVisuals();
		}
	}

	private void FreeSlot(ISlotOccupant cat)
	{
		foreach (CatSlot slot in _slots)
		{
			if (slot.Occupant == cat)
			{
				if (!Pattern.ComputesSlots)
				{
					_slots.Remove(slot);
				}
				else
				{
					slot.Occupant = null;
				}
				break;
			}
		}
	}

	public void HandleMainCatInclusion()
	{
		if (!InitialSpawnDone)
		{
			return;
		}
		if (Pattern.ComputesSlots)
		{
			RecalculateLayout();
			return;
		}
		if (MainCatInLayout)
		{
			KeepSlotOnScreen(AddSlotUnder(MainCat.Instance));
		}
		else
		{
			FreeSlot(MainCat.Instance);
		}
		RefreshLayoutVisuals();
	}

	private bool ParticipatesInLayout(ISlotOccupant cat)
	{
		if (cat is MainCat)
		{
			return MainCatInLayout;
		}
		return true;
	}

	private IEnumerable<ISlotOccupant> LayoutCats()
	{
		if (!MainCatInLayout)
		{
			return MultiplayerLobbyReferences.VisibleCats;
		}
		return MultiplayerLobbyReferences.VisibleCats.Append<ISlotOccupant>(MainCat.Instance);
	}

	private CatSlot SlotOf(ISlotOccupant cat)
	{
		return _slots.FirstOrDefault((CatSlot slot) => slot.Occupant == cat);
	}

	public void UpdateOccupancy(ISlotOccupant cat)
	{
		if (!InitialSpawnDone || !ParticipatesInLayout(cat))
		{
			return;
		}
		if (!Pattern.ComputesSlots)
		{
			DropFreely(cat);
			return;
		}
		if (AnchorsLayout(cat))
		{
			Relayout();
			return;
		}
		FreeSlot(cat);
		int num = ClaimSlot(cat);
		if (num >= 0 && _settings.DisabledSlots.Remove(num))
		{
			_slots[num].Disabled = false;
		}
		RefreshLayoutVisuals();
	}

	public void KeepRotatedCatOnScreen(CatRotator rotator)
	{
		if (InitialSpawnDone && !Pattern.ComputesSlots)
		{
			CatSlot catSlot = _slots.FirstOrDefault((CatSlot slot) => slot.Occupant != null && slot.Occupant.Rotator == rotator);
			if (catSlot != null)
			{
				catSlot.RotationState = rotator.RotationState;
				KeepSlotOnScreen(catSlot);
				RefreshLayoutVisuals();
			}
		}
	}

	private void KeepSlotOnScreen(CatSlot slot)
	{
		if (!Pattern.ComputesSlots && slot.Occupant != null)
		{
			slot.Occupant.SetPos(SpawnGeometry.KeepCatOnScreen(slot.Occupant.Pos, slot.RotationState));
			slot.Position = slot.Occupant.Pos;
		}
		else
		{
			slot.Position = SpawnGeometry.KeepCatOnScreen(slot.Position, slot.RotationState);
			slot.Occupant?.SetPos(slot.Position);
		}
	}

	private void DropFreely(ISlotOccupant cat)
	{
		CatSlot catSlot = SlotOf(cat) ?? AddSlotUnder(cat);
		CatSlot catSlot2 = DraggedOverCat(cat, catSlot);
		if (catSlot2 == null)
		{
			catSlot.Position = cat.Pos;
		}
		else
		{
			ISlotOccupant occupant = catSlot2.Occupant;
			PlaceOn(cat, catSlot2);
			PlaceOn(occupant, catSlot);
			occupant.Patter.GetPat();
		}
		RefreshLayoutVisuals();
	}

	private CatSlot DraggedOverCat(ISlotOccupant cat, CatSlot ownSlot)
	{
		CatSlot catSlot = NearestSlot(_slots.Where((CatSlot slot) => slot.Occupant != null && slot.Occupant != cat), cat.Pos);
		if (catSlot == null)
		{
			return null;
		}
		float num = Vector2.Distance(catSlot.Position, cat.Pos);
		if (!(num <= SpawnGeometry.DropOnCatDistance) || !(num < Vector2.Distance(ownSlot.Position, cat.Pos)))
		{
			return null;
		}
		return catSlot;
	}

	private int ClaimSlot(ISlotOccupant cat)
	{
		for (int i = 0; i < _slots.Count; i++)
		{
			if (_slots[i].Occupant == null && !_slots[i].ReservedForMainCat && !(Vector2.Distance(_slots[i].Position, cat.Pos) >= SpawnGeometry.SlotMatchDistance))
			{
				_slots[i].Occupant = cat;
				return i;
			}
		}
		return -1;
	}

	private void MoveToSlot(ISlotOccupant cat, CatSlot slot)
	{
		if (!IsPinned(cat))
		{
			PlaceOn(cat, slot);
		}
	}

	private static void PlaceOn(ISlotOccupant cat, CatSlot slot)
	{
		slot.Occupant = cat;
		cat.Rotator.RotateTo(slot.RotationState);
		cat.SetPos(slot.Position);
	}

	private bool IsPinned(ISlotOccupant cat)
	{
		if (!AnchorsLayout(cat))
		{
			if (!_rebuilding && _windowOpen)
			{
				return cat is MainCat;
			}
			return false;
		}
		return true;
	}

	private bool AnchorsLayout(ISlotOccupant cat)
	{
		if (cat is MainCat)
		{
			return Pattern.AnchoredOnMainCat;
		}
		return false;
	}

	private void AssignCatToSlot(LobbyMemberInstance cat)
	{
		if (!TryUseSavedPos(cat))
		{
			cat.Rotator.RotationState = Pattern.RotationState;
			cat.FlipVisuals.Flip(_settings.IsFlipped);
			PlaceOnFreeSlot(cat);
		}
	}

	private void PlaceOnFreeSlot(ISlotOccupant cat, int preference = -1)
	{
		if (!IsPinned(cat))
		{
			CatSlot catSlot = FirstFreeSlot();
			if (preference >= 0 && preference < _slots.Count && IsFree(_slots[preference]) && (Pattern.KeepsCatsOnTheirSlots || catSlot == null))
			{
				catSlot = _slots[preference];
			}
			if (!TryOccupyFreeSlot(cat, catSlot))
			{
				CreateNewSlotWithinPattern(cat, catSlot);
			}
		}
	}

	private void CreateNewSlotWithinPattern(ISlotOccupant cat, CatSlot preference)
	{
		if (!Pattern.ComputesSlots)
		{
			PlaceOn(cat, AddSlot(SpawnGeometry.RandomPos(), _settings.RotationOffset));
			return;
		}
		CatSlot catSlot = preference ?? CrowdedSlot();
		PlaceOn(cat, AddSlot(catSlot.Position, catSlot.RotationState));
	}

	private CatSlot CrowdedSlot()
	{
		return _slots.FirstOrDefault((CatSlot slot) => !slot.Disabled && !slot.ReservedForMainCat) ?? _slots.First((CatSlot slot) => !slot.Disabled);
	}

	private CatSlot AddSlot(Vector2 position, int rotationState)
	{
		CatSlot catSlot = new CatSlot
		{
			Position = position,
			RotationState = rotationState
		};
		_slots.Add(catSlot);
		return catSlot;
	}

	private CatSlot AddSlotUnder(ISlotOccupant cat)
	{
		CatSlot catSlot = AddSlot(cat.Pos, cat.Rotator.RotationState);
		catSlot.Occupant = cat;
		return catSlot;
	}

	private bool TryUseSavedPos(LobbyMemberInstance cat)
	{
		Vector2? pos = PlayerDataCache.GetPos(cat.steamUserData.Data.IdStr);
		if (!pos.HasValue)
		{
			return false;
		}
		Vector2 pos2 = pos.Value;
		if (MultiplayerLobbyReferences.VisibleCats.Any((LobbyMemberInstance other) => other != cat && IsSameSpot(other.Pos, pos2)))
		{
			return false;
		}
		if (MainCatInLayout && IsSameSpot(MainCat.Instance.Pos, pos2))
		{
			return false;
		}
		if (_slots.Any((CatSlot slot) => slot.Disabled && IsSameSpot(slot.Position, pos2)))
		{
			return false;
		}
		cat.Rotator.RotationState = PlayerDataCache.GetRot(cat.steamUserData.Data.IdStr);
		cat.FlipVisuals.Flip(PlayerDataCache.GetFlipped(cat.steamUserData.Data.IdStr));
		cat.SetPos(pos2);
		if (ClaimSlot(cat) < 0 && !Pattern.ComputesSlots)
		{
			AddSlotUnder(cat);
		}
		return true;
	}

	private static bool IsSameSpot(Vector2 a, Vector2 b)
	{
		return Vector2.Distance(a, b) < SpawnGeometry.SlotMatchDistance;
	}

	private CatSlot FirstFreeSlot()
	{
		return _slots.FirstOrDefault(IsFree);
	}

	private static bool IsFree(CatSlot slot)
	{
		if (slot.Occupant == null && !slot.Disabled)
		{
			return !slot.ReservedForMainCat;
		}
		return false;
	}

	private bool TryOccupyFreeSlot(ISlotOccupant cat, CatSlot preference)
	{
		CatSlot catSlot = ((preference != null && preference.Occupant == null) ? preference : FirstFreeSlot());
		if (catSlot == null)
		{
			return false;
		}
		MoveToSlot(cat, catSlot);
		return true;
	}

	public bool TrySnapToSlot(ISlotOccupant cat)
	{
		if (!Pattern.ComputesSlots)
		{
			return false;
		}
		if (_slots.Count == 0)
		{
			FreeSlot(cat);
			return false;
		}
		if (!ParticipatesInLayout(cat) || AnchorsLayout(cat))
		{
			return false;
		}
		CatSlot catSlot = NearestSlot(_slots.Where((CatSlot slot) => !slot.ReservedForMainCat), cat.Pos);
		if (catSlot == null || Vector2.Distance(cat.Pos, catSlot.Position) > SpawnGeometry.SnapDistance)
		{
			return false;
		}
		CatSlot catSlot2 = SlotOf(cat);
		FreeSlot(cat);
		ISlotOccupant occupant = catSlot.Occupant;
		if (occupant != null && occupant != cat)
		{
			FreeSlot(occupant);
			catSlot.Occupant = cat;
			CatSlot catSlot3 = catSlot2 ?? FirstFreeSlot();
			if (catSlot3 != null)
			{
				PlaceOn(occupant, catSlot3);
			}
			else
			{
				cat.Rotator.RotationState = Pattern.RotationState;
				cat.FlipVisuals.Flip(_settings.IsFlipped);
				cat.SetPos(SpawnGeometry.RandomPos());
			}
			occupant.Patter.GetPat();
		}
		PlaceOn(cat, catSlot);
		return true;
	}

	private static CatSlot NearestSlot(IEnumerable<CatSlot> slots, Vector2 pos)
	{
		CatSlot result = null;
		float num = 3.4028235E+38f;
		foreach (CatSlot slot in slots)
		{
			float sqrMagnitude = (slot.Position - pos).sqrMagnitude;
			if (!(sqrMagnitude >= num))
			{
				num = sqrMagnitude;
				result = slot;
			}
		}
		return result;
	}

	public void SetSpawnPattern(int pattern)
	{
		_settings.SpawnPattern = (CatSpawnPatterns)pattern;
		SavedSlots.Clear();
		RefreshControls();
		if (Pattern.PlayerAuthoredSlots)
		{
			TakeCatsAsFreeSlots();
		}
		else
		{
			RebuildSlots();
		}
	}

	private void TakeCatsAsFreeSlots()
	{
		_slots = (from cat in LayoutCats()
			select new CatSlot
			{
				Position = cat.Pos,
				RotationState = cat.Rotator.RotationState,
				Occupant = cat
			}).ToList();
		RefreshLayoutVisuals();
	}

	public void SetAnchorCorner(int option)
	{
		_settings.AnchorCorner = Pattern.OfferedAnchorCorners[option];
		RefreshControls();
		Relayout();
	}

	public void SetAlignmentAxis(int axis)
	{
		_settings.AlignmentAxis = (AlignmentAxes)axis;
		Relayout();
	}

	public void SetFillOrder(int order)
	{
		_settings.GridFillOrder = (FillOrder)order;
		Relayout();
	}

	public void RotateAllCats()
	{
		if (Pattern.AnchoredOnMainCat)
		{
			TurnMainCat();
		}
		else
		{
			_settings.RotationOffset = (_settings.RotationOffset + 1) % 4;
		}
		if (!Pattern.ComputesSlots)
		{
			foreach (CatSlot slot in _slots)
			{
				slot.RotationState = _settings.RotationOffset;
			}
		}
		else
		{
			Relayout();
		}
		foreach (CatSlot slot2 in _slots)
		{
			slot2.Occupant?.Rotator.RotateTo(slot2.RotationState);
			KeepSlotOnScreen(slot2);
		}
		RefreshLayoutVisuals();
	}

	private static void TurnMainCat()
	{
		MainCat.Instance.Rotator.Rotate();
		MainCat.Instance.SetPos(SpawnGeometry.KeepCatOnScreen(MainCat.Instance.Pos, MainCat.Instance.Rotator.RotationState));
	}

	public void FlipAllCats()
	{
		_settings.IsFlipped = !_settings.IsFlipped;
		foreach (LobbyMemberInstance value in MultiplayerLobbyReferences.GameplayInstances.Values)
		{
			value.FlipVisuals.Flip(_settings.IsFlipped);
		}
		if (MainCatInLayout)
		{
			MainCat.Instance.FlipVisuals.Flip(_settings.IsFlipped);
		}
		RefreshLayoutVisuals();
	}

	public void SetPrefDistance(float perc)
	{
		_settings.PreferredDistancePercent = perc;
		Relayout();
	}

	public void SetVerticalPrefDistance(float perc)
	{
		_settings.PreferredVerticalDistancePercent = perc;
		Relayout();
	}

	private void RefreshLayoutVisuals()
	{
		SavedSlots.Save(_slots);
		if (_previewing)
		{
			_previews.Show(_slots, Pattern, _settings.IsFlipped);
		}
		else
		{
			_previews.Hide();
		}
		RefreshSlotButtons();
		_windowUi.RefreshSliders(Pattern, _settings);
		if (Pattern.ComputesSlots)
		{
			int horizontalSign = (Pattern.Controls.HasFlag(SpawnControls.Anchor) ? Pattern.ResolvedAnchorCorner.HorizontalSign() : 0);
			_catDepth.Sort(horizontalSign);
			_previews.Sort(horizontalSign);
		}
	}

	public void TogglePreviewCats()
	{
		_previewing = !_previewing;
		RefreshLayoutVisuals();
	}

	public void HidePreviewCats()
	{
		if (_previewing)
		{
			_previewing = false;
			RefreshLayoutVisuals();
		}
	}

	public void StartDistancePreview()
	{
		_windowOpen = true;
		_previewing = true;
		RefreshLayoutVisuals();
	}

	public void StopDistancePreview()
	{
		_windowOpen = false;
		_previewing = false;
		SeatMainCatNearby();
		RefreshLayoutVisuals();
	}

	private void SeatMainCatNearby()
	{
		if (!MainCatInLayout)
		{
			return;
		}
		CatSlot catSlot = SlotOf(MainCat.Instance) ?? MainCatSlot();
		if (catSlot != null)
		{
			if (IsPinned(MainCat.Instance))
			{
				catSlot.Occupant = MainCat.Instance;
			}
			else
			{
				PlaceOn(MainCat.Instance, catSlot);
			}
		}
	}

	private CatSlot MainCatSlot()
	{
		return _slots.FirstOrDefault((CatSlot slot) => slot.ReservedForMainCat) ?? NearestFreeSlot(MainCat.Instance.Pos);
	}

	public void SnapAllCatsToSlots(bool snapping)
	{
		if (!snapping || !InitialSpawnDone)
		{
			return;
		}
		foreach (CatSlot slot in _slots)
		{
			slot.Occupant = null;
		}
		SeatMainCatNearby();
		List<ISlotOccupant> list = (from cat in LayoutCats()
			where SlotOf(cat) == null
			select cat).ToList();
		while (list.Count > 0 && FirstFreeSlot() != null)
		{
			ISlotOccupant slotOccupant = list.OrderBy((ISlotOccupant cat) => Vector2.Distance(cat.Pos, NearestFreeSlot(cat.Pos).Position)).First();
			MoveToSlot(slotOccupant, NearestFreeSlot(slotOccupant.Pos));
			list.Remove(slotOccupant);
		}
		RefreshLayoutVisuals();
	}

	private CatSlot NearestFreeSlot(Vector2 pos)
	{
		return NearestSlot(_slots.Where(IsFree), pos);
	}

	private void OnLobbyLeave(LobbyData lobby)
	{
		InitialSpawnDone = false;
		HidePreviewCats();
		SaveState();
		_settings.RotationOffset = 0;
		_settings.IsFlipped = false;
		_slots.Clear();
		PlayerDataCache.ClearPositions();
		RefreshControls();
	}

	private void SaveState()
	{
		SavedSlots.Save(_slots);
		_settings.SaveSessionOptions();
		_settings.SaveDisabledSlots();
	}

	private void OnDestroy()
	{
		SaveState();
		Events.OnLobbyEnterSuccess -= PositionCatsInitial;
		Events.OnLobbyLeave -= OnLobbyLeave;
		SettingsManager.Instance.MainScreenSetting.ScreenSwitched -= WatchScreenBounds;
	}
}
