using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat.TapTapLootIntegration;
using Heathen.SteamworksIntegration;
using Helper;
using SteamTools;
using UnityEngine;

namespace BongoCat;

public class CatCosmetics : MonoBehaviour
{
	[NonSerialized]
	public List<SteamItemRuntime> EquippedItems;

	private List<SteamItemRuntime> _locallyEquippedItems;

	public static CatCosmetics Instance;

	private bool validated;

	private const string EQUIPPED_ITEMS_KEY = "EQUIPPED_ITEMS_3";

	public SteamItemRuntime Hat => EquippedItems.FirstOrDefault((SteamItemRuntime i) => i.IsHat);

	public SteamItemRuntime Skin => EquippedItems.FirstOrDefault((SteamItemRuntime i) => i.IsSkin);

	public static event Action OnEquippedItemsChanged;

	private void Awake()
	{
		Instance = this;
		EquippedItems = new List<SteamItemRuntime>();
		_locallyEquippedItems = new List<SteamItemRuntime>();
		Events.OnLobbyEnterSuccess += OnLobbyEnter;
	}

	private void OnDestroy()
	{
		Events.OnLobbyEnterSuccess -= OnLobbyEnter;
	}

	private void OnLobbyEnter(LobbyData lobby)
	{
		lobby.MyHat = Hat?.Id ?? (-1);
		lobby.MySkin = Skin?.Id ?? (-1);
	}

	private void OnEnable()
	{
		MenuTabs.OnCloseTab = (Action<MenuTabs.MenuTab>)Delegate.Combine(MenuTabs.OnCloseTab, new Action<MenuTabs.MenuTab>(RestoreActuallyEquippedItems));
	}

	private void OnDisable()
	{
		MenuTabs.OnCloseTab = (Action<MenuTabs.MenuTab>)Delegate.Remove(MenuTabs.OnCloseTab, new Action<MenuTabs.MenuTab>(RestoreActuallyEquippedItems));
	}

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		if (PlayerPrefsHelp.TryGetObject<int[]>("EQUIPPED_ITEMS_3", out var ids) && ids != null)
		{
			List<SteamItemRuntime> itemsToEquip = CatInventory.Instance.Items.Where((SteamItemRuntime i) => ids.Contains(i.Id)).ToList();
			yield return new WaitUntil(() => itemsToEquip.All((SteamItemRuntime i) => i.Icon));
			foreach (SteamItemRuntime item in itemsToEquip)
			{
				Equip(item, playAnimation: true, isLocal: false);
			}
		}
		Debug.Log("CatCosmetics initialized.");
	}

	public void Validate()
	{
		if (_locallyEquippedItems.Count > 0 || !PlayerPrefsHelp.TryGetObject<int[]>("EQUIPPED_ITEMS_3", out var ids))
		{
			return;
		}
		List<SteamItemRuntime> list = CatInventory.Instance.Items.Where((SteamItemRuntime i) => ids.Contains(i.Id) && i.RuntimeData.GetTotalQuantity() > 0).ToList();
		if (list.Count((SteamItemRuntime i) => i.IsHat) == 0)
		{
			Cat.Instance.ClearItemSlot("hat");
		}
		if (list.Count((SteamItemRuntime i) => i.IsSkin) == 0)
		{
			Cat.Instance.ClearItemSlot("skin");
		}
		foreach (SteamItemRuntime item in list)
		{
			EquipItem(item, playAnimation: false);
		}
		validated = true;
	}

	public void EquipItem(SteamItemRuntime steamItem, bool playAnimation = true, bool unequipIfSameItemIsEquipped = false, bool resetRandomizerTimer = false)
	{
		bool flag = steamItem.RuntimeData.GetTotalQuantity() == 0;
		if (unequipIfSameItemIsEquipped && (flag ? _locallyEquippedItems.Any((SteamItemRuntime i) => i.Id == steamItem.Id) : EquippedItems.Any((SteamItemRuntime i) => i.Id == steamItem.Id)))
		{
			Unequip(steamItem, flag);
			return;
		}
		Equip(steamItem, playAnimation, flag);
		if (resetRandomizerTimer)
		{
			CatInventory.Instance.CatRandomizer.UpdateWaitDuration();
		}
	}

	private void Unequip(SteamItemRuntime steamItem, bool isLocal)
	{
		if (isLocal)
		{
			_locallyEquippedItems.RemoveAll((SteamItemRuntime i) => i.Id == steamItem.Id);
		}
		else
		{
			EquippedItems.RemoveAll((SteamItemRuntime i) => i.Id == steamItem.Id);
			PlayerPrefsHelp.SetObject("EQUIPPED_ITEMS_3", EquippedItems.Select((SteamItemRuntime i) => i.Id).ToArray());
		}
		Cat.Instance.ClearItemSlot(steamItem.ItemSlot);
		if (isLocal)
		{
			foreach (SteamItemRuntime equippedItem in EquippedItems)
			{
				if (equippedItem.ItemSlot == steamItem.ItemSlot)
				{
					Equip(equippedItem, playAnimation: true, isLocal: false);
					break;
				}
			}
		}
		else
		{
			steamItem.IsEquipped = false;
			steamItem.OnItemUpdated?.Invoke();
			LobbyMemberData me = LobbyData.Current.Me;
			me[steamItem.ItemSlot] = "-1";
		}
		CatInventory.Instance.SeparateItem(steamItem);
		Ipc.Instance.UpdateBuffs();
		OnEquippedItemsChanged?.Invoke();
	}

	private void Equip(SteamItemRuntime steamItem, bool playAnimation, bool isLocal)
	{
		Cat.Instance.SetItem(steamItem, playAnimation);
		if (isLocal)
		{
			_locallyEquippedItems = RemoveItemsWithSameCategory(_locallyEquippedItems, steamItem);
			return;
		}
		steamItem.IsNew = false;
		steamItem.IsEquipped = true;
		steamItem.OnItemUpdated?.Invoke();
		LobbyMemberData me = LobbyData.Current.Me;
		me[steamItem.ItemSlot] = steamItem.Id.ToString();
		EquippedItems = RemoveItemsWithSameCategory(EquippedItems, steamItem);
		CatInventory.Instance.SeparateItem(steamItem);
		PlayerPrefsHelp.SetObject("EQUIPPED_ITEMS_3", EquippedItems.Select((SteamItemRuntime i) => i.Id).ToArray());
		Ipc.Instance.UpdateBuffs();
		OnEquippedItemsChanged?.Invoke();
	}

	public void AutoEquipDrop(int itemId)
	{
		StartCoroutine(DoAutoEquip(itemId));
	}

	private IEnumerator DoAutoEquip(int itemId)
	{
		yield return new WaitUntil(() => validated);
		Equip(SteamItemIdReference.Inst[itemId], playAnimation: true, isLocal: false);
		validated = false;
	}

	private List<SteamItemRuntime> RemoveItemsWithSameCategory(List<SteamItemRuntime> items, SteamItemRuntime steamItem)
	{
		items.Add(steamItem);
		foreach (SteamItemRuntime item in items)
		{
			if (item.ItemSlot == steamItem.ItemSlot && item != steamItem)
			{
				item.IsEquipped = false;
				item.OnItemUpdated?.Invoke();
				CatInventory.Instance.SeparateItem(item);
			}
		}
		items.RemoveAll((SteamItemRuntime i) => i.ItemSlot == steamItem.ItemSlot && i != steamItem);
		return items;
	}

	public void RestoreActuallyEquippedItems(MenuTabs.MenuTab menuTab = MenuTabs.MenuTab.Bongodecks)
	{
		if (menuTab != MenuTabs.MenuTab.Bongodecks || _locallyEquippedItems.Count == 0)
		{
			return;
		}
		while (_locallyEquippedItems.Count > 0)
		{
			Unequip(_locallyEquippedItems[0], isLocal: true);
		}
		foreach (SteamItemRuntime equippedItem in EquippedItems)
		{
			Equip(equippedItem, playAnimation: true, isLocal: true);
		}
		_locallyEquippedItems.Clear();
	}
}
