using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyInputUI : MonoBehaviour
{
	public bool inputAlwaysReadOnly;

	public bool onlyOwnerCanInvite;

	public int minimalIdLength = 8;

	public TMP_InputField idInput;

	public GameObject createElement;

	public GameObject joinElement;

	public GameObject leaveElement;

	public GameObject inviteElement;

	public GameObject membersElement;

	public GameObject chatElement;

	private SteamLobbyData _mInspector;

	private void Start()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mInspector.onChanged.AddListener(HandleOnChanged);
		idInput.onValueChanged.AddListener(HandleOnValueChanged);
		HandleOnChanged(_mInspector.Data);
	}

	private void OnDestroy()
	{
		_mInspector.onChanged.RemoveListener(HandleOnChanged);
		idInput.onValueChanged.RemoveListener(HandleOnValueChanged);
	}

	private void HandleOnValueChanged(string arg0)
	{
		if (joinElement != null)
		{
			if (idInput.text.Length >= minimalIdLength)
			{
				LobbyData lobbyData = LobbyData.Get(idInput.text);
				joinElement.SetActive(lobbyData.IsValid);
			}
			else
			{
				joinElement.SetActive(value: false);
			}
		}
	}

	private void HandleOnChanged(LobbyData arg0)
	{
		if (arg0.IsValid)
		{
			if (createElement != null)
			{
				createElement.SetActive(value: false);
			}
			if (joinElement != null)
			{
				joinElement.SetActive(value: false);
			}
			if (leaveElement != null)
			{
				leaveElement.SetActive(value: true);
			}
			if (inviteElement != null)
			{
				if (onlyOwnerCanInvite)
				{
					inviteElement.SetActive(arg0.IsOwner);
				}
				else
				{
					inviteElement.SetActive(value: true);
				}
			}
			if (membersElement != null)
			{
				membersElement.SetActive(value: true);
			}
			if (chatElement != null)
			{
				chatElement.SetActive(value: true);
			}
			idInput.text = arg0.ToString();
			idInput.readOnly = true;
			return;
		}
		if (createElement != null)
		{
			createElement.SetActive(value: true);
		}
		if (joinElement != null)
		{
			if (idInput.text.Length >= minimalIdLength)
			{
				LobbyData lobbyData = LobbyData.Get(idInput.text);
				joinElement.SetActive(lobbyData.IsValid);
			}
			else
			{
				joinElement.SetActive(value: false);
			}
		}
		if (leaveElement != null)
		{
			leaveElement.SetActive(value: false);
		}
		if (inviteElement != null)
		{
			inviteElement.SetActive(value: false);
		}
		if (membersElement != null)
		{
			membersElement.SetActive(value: false);
		}
		if (chatElement != null)
		{
			chatElement.SetActive(value: false);
		}
		idInput.text = string.Empty;
		idInput.readOnly = inputAlwaysReadOnly;
	}
}
