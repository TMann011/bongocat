using UnityEngine;
using UnityEngine.Events;

public class ToggleGameObject : MonoBehaviour
{
	public UnityEvent<bool> OnToggle;

	public void Toggle()
	{
		bool active = !base.gameObject.activeSelf;
		SetActive(active);
	}

	public void SetActive(bool active)
	{
		base.gameObject.SetActive(active);
		OnToggle?.Invoke(active);
	}
}
