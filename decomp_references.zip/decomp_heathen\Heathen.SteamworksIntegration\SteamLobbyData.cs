using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using UnityEngine;
using UnityEngine.Serialization;

namespace Heathen.SteamworksIntegration;

public class SteamLobbyData : MonoBehaviour
{
	public enum LoadOnStart
	{
		None,
		Any,
		Party,
		Session,
		General
	}

	public LoadOnStart load;

	public LobbyDataEvent onChanged;

	private LobbyData _mData;

	[FormerlySerializedAs("m_Delegates")]
	[SerializeField]
	private List<string> mDelegates;

	public LobbyData Data
	{
		get
		{
			return _mData;
		}
		set
		{
			_mData = value;
			onChanged?.Invoke(value);
		}
	}

	public void Join()
	{
		_mData.Join();
	}

	private void Start()
	{
		switch (load)
		{
		case LoadOnStart.Any:
			if (Matchmaking.Client.MemberOfLobbies.Count > 0)
			{
				Data = Matchmaking.Client.MemberOfLobbies[0];
			}
			break;
		case LoadOnStart.General:
			if (Matchmaking.Client.MemberOfLobbies.Count <= 0)
			{
				break;
			}
			{
				foreach (LobbyData memberOfLobby in Matchmaking.Client.MemberOfLobbies)
				{
					if (memberOfLobby.IsGeneral)
					{
						Data = memberOfLobby;
						break;
					}
				}
				break;
			}
		case LoadOnStart.Session:
			if (Matchmaking.Client.MemberOfLobbies.Count <= 0)
			{
				break;
			}
			{
				foreach (LobbyData memberOfLobby2 in Matchmaking.Client.MemberOfLobbies)
				{
					if (memberOfLobby2.IsSession)
					{
						Data = memberOfLobby2;
						break;
					}
				}
				break;
			}
		case LoadOnStart.Party:
			if (Matchmaking.Client.MemberOfLobbies.Count <= 0)
			{
				break;
			}
			{
				foreach (LobbyData memberOfLobby3 in Matchmaking.Client.MemberOfLobbies)
				{
					if (memberOfLobby3.IsParty)
					{
						Data = memberOfLobby3;
						break;
					}
				}
				break;
			}
		}
	}
}
