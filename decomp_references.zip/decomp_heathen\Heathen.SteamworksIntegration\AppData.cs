using System;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct AppData : IEquatable<AppId_t>, IEquatable<CGameID>, IEquatable<uint>, IEquatable<ulong>, IEquatable<AppData>, IComparable<AppData>, IComparable<AppId_t>, IComparable<uint>, IComparable<ulong>
{
	[SerializeField]
	private uint id;

	public static AppData Me => App.Id;

	public AppId_t AppId => new AppId_t(id);

	public uint Id => AppId.m_AppId;

	public int CompareTo(AppData other)
	{
		return AppId.CompareTo(other.AppId);
	}

	public int CompareTo(AppId_t other)
	{
		return AppId.CompareTo(other);
	}

	public int CompareTo(ulong other)
	{
		return AppId.CompareTo(new CGameID(other).AppID());
	}

	public int CompareTo(uint other)
	{
		return AppId.m_AppId.CompareTo(other);
	}

	public override string ToString()
	{
		return AppId.ToString();
	}

	public bool Equals(AppData other)
	{
		return AppId.Equals(other.AppId);
	}

	public bool Equals(AppId_t other)
	{
		return AppId.Equals(other);
	}

	public bool Equals(uint other)
	{
		return AppId.m_AppId.Equals(other);
	}

	public bool Equals(CGameID other)
	{
		return AppId.Equals(other.AppID());
	}

	public bool Equals(ulong other)
	{
		return AppId.Equals(new CGameID(other).AppID());
	}

	public override bool Equals(object obj)
	{
		return AppId.m_AppId.Equals(obj);
	}

	public override int GetHashCode()
	{
		return AppId.GetHashCode();
	}

	public static bool operator ==(AppData l, AppData r)
	{
		return l.AppId == r.AppId;
	}

	public static bool operator ==(AppData l, AppId_t r)
	{
		return l.AppId == r;
	}

	public static bool operator !=(AppData l, AppId_t r)
	{
		return l.AppId != r;
	}

	public static implicit operator AppData(uint id)
	{
		return new AppData
		{
			id = id
		};
	}

	public static implicit operator AppId_t(AppData c)
	{
		return c.AppId;
	}

	public static implicit operator AppData(AppId_t id)
	{
		return new AppData
		{
			id = id.m_AppId
		};
	}

	public static implicit operator AppData(GameData id)
	{
		return new AppData
		{
			id = id.App.Id
		};
	}
}
