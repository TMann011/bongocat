using BongoCat.SteamJsonParser;
using UnityEngine;
using UnityEngine.UI;

namespace BongoCat;

public class SelectedItemUi : MonoBehaviour
{
	[SerializeField]
	private SteamExchange _bundleToSelect;

	[SerializeField]
	private TokenItemReward tokenItemReward;

	[SerializeField]
	private Image _backgroundImage;

	[SerializeField]
	private Image _selectedBorder;

	public void Select()
	{
		tokenItemReward.SetSelectedItem(_bundleToSelect);
		_selectedBorder.enabled = true;
	}

	public void Deselect()
	{
		_selectedBorder.enabled = false;
	}
}
