using System;
using System.Collections.Generic;
using System.Globalization;
using BongoCat.SteamJsonParser;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Serialization;

namespace BongoCat.PawPass;

public class PawPassEntity : ScriptableObject
{
	public string SeasonCode;

	public string StartDate;

	public string EndDate;

	public int RequiredTapsPerMilestone = 10000;

	[FormerlySerializedAs("SteamItemsFolder")]
	public string SeasonFolder;

	public LocalizedString Title;

	public LocalizedString Subtitle;

	public Sprite Icon;

	public SteamItemBasic PassToken;

	public SteamItemBasic FreeToken;

	public SteamItemBasic FreeKey;

	public SteamItemBasic PremiumKey;

	public SteamExchange FreeUnlockExchange;

	public SteamExchange PremiumUnlockExchange;

	public SteamExchange PremiumUnlockLateExchange;

	public List<PawPassMilestone> FreePassMilestones = new List<PawPassMilestone>();

	public List<PawPassMilestone> PremiumPassMilestones = new List<PawPassMilestone>();

	public int TotalMilestones => FreePassMilestones.Count;

	public int TotalTaps => TotalMilestones * RequiredTapsPerMilestone;

	public DateTime StartDateTime => DateTime.Parse(StartDate, CultureInfo.InvariantCulture);

	public DateTime EndDateTime => DateTime.Parse(EndDate, CultureInfo.InvariantCulture).AddDays(1.0).AddTicks(-1L);

	public bool HasFreePass => FreeKey.HasItem;

	public bool HasPremiumPass => PremiumKey.HasItem;

	public bool IsGenerated
	{
		get
		{
			if ((bool)PassToken && (bool)FreeToken && (bool)FreeKey && (bool)PremiumKey && (bool)FreeUnlockExchange && (bool)PremiumUnlockExchange)
			{
				return PremiumUnlockLateExchange;
			}
			return false;
		}
	}

	public bool HasStarted => DateTime.Now >= StartDateTime;

	public bool IsPast => DateTime.Now > EndDateTime;

	public SteamExchange PremiumUnlock
	{
		get
		{
			if (!IsPast || HasFreePass)
			{
				return PremiumUnlockExchange;
			}
			return PremiumUnlockLateExchange;
		}
	}

	public bool IsLive
	{
		get
		{
			if (HasStarted)
			{
				return DateTime.Now <= EndDateTime;
			}
			return false;
		}
	}

	public bool IsJoined
	{
		get
		{
			if (!HasFreePass)
			{
				return HasPremiumPass;
			}
			return true;
		}
	}

	public bool HasUnclaimedRewards
	{
		get
		{
			if (!HasFreePass || !FreePassMilestones.Exists((PawPassMilestone milestone) => milestone.IsUnclaimed))
			{
				if (HasPremiumPass)
				{
					return PremiumPassMilestones.Exists((PawPassMilestone milestone) => milestone.IsUnclaimed);
				}
				return false;
			}
			return true;
		}
	}

	public bool IsCompleted
	{
		get
		{
			if (IsJoined)
			{
				return !HasUnclaimedRewards;
			}
			return false;
		}
	}

	public bool IsHidden
	{
		get
		{
			if (IsJoined)
			{
				return IsCompleted;
			}
			return true;
		}
	}

	public List<PawPassMilestone> Milestones(bool premium)
	{
		if (!premium)
		{
			return FreePassMilestones;
		}
		return PremiumPassMilestones;
	}
}
