using System;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

public class RichPresenceReader : MonoBehaviour
{
	[Serializable]
	public class RichPresenceReaderUpdatedEvent : UnityEvent<RichPresenceReader>
	{
	}

	public RichPresenceReaderUpdatedEvent evtUpdate;

	private UserData _currentUser = CSteamID.Nil;

	public AppData App { get; private set; } = AppId_t.Invalid;

	public UserData User
	{
		get
		{
			return _currentUser;
		}
		set
		{
			Apply(value);
		}
	}

	public Dictionary<string, string> Values { get; private set; } = new Dictionary<string, string>();

	private void OnEnable()
	{
		Events.OnFriendRichPresenceUpdate += HandleChange;
	}

	private void OnDisable()
	{
		Events.OnFriendRichPresenceUpdate -= HandleChange;
	}

	public void Apply(UserData user)
	{
		_currentUser = user;
		if (user.GetGamePlayed(out var gameInfo))
		{
			App = gameInfo.Game;
			Values = Friends.Client.GetFriendRichPresence(user);
			evtUpdate.Invoke(this);
		}
		else
		{
			App = AppId_t.Invalid;
			Values.Clear();
			evtUpdate.Invoke(this);
		}
	}

	private void HandleChange(UserData friend, AppData app)
	{
		if (!(friend != _currentUser))
		{
			App = app;
			Values = Friends.Client.GetFriendRichPresence(friend);
			evtUpdate.Invoke(this);
		}
	}
}
