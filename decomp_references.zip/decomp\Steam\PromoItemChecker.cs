using System;
using System.Collections;
using BongoCat;
using Heathen.SteamworksIntegration;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace Steam;

public class PromoItemChecker : MonoBehaviour
{
	public static PromoItemChecker Instance;

	public Action<SteamItemRuntime> OnItemUpdated;

	[SerializeField]
	private GameObject _discordChest;

	[SerializeField]
	private GameObject _followChest;

	private void Awake()
	{
		Instance = this;
	}

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => Interface.IsReady);
		_discordChest.SetActive(Game.Inventory.Headphones.GetTotalQuantity() == 0);
		_followChest.SetActive(Game.Inventory.Follower.GetTotalQuantity() == 0);
		StartCoroutine(GrantPromoItemsRoutine());
		StartCoroutine(CheckForManualToken());
	}

	private IEnumerator GrantPromoItemsRoutine()
	{
		WaitForSeconds waitForTwoMinutes = new WaitForSeconds(900f);
		while (true)
		{
			Inventory.Client.GrantPromoItems(delegate
			{
			});
			yield return waitForTwoMinutes;
		}
	}

	public void GrantPromoItem(int itemId, float delay = 0f)
	{
		StartCoroutine(AddPromoItemRoutine(itemId, delay));
	}

	private IEnumerator AddPromoItemRoutine(int itemId, float delay = 0f)
	{
		yield return new WaitForSeconds(delay);
		ItemData runtimeData = SteamItemIdReference.Inst[itemId].RuntimeData;
		runtimeData.AddPromoItem(delegate(InventoryResult result)
		{
			if (result.result != EResult.k_EResultOK)
			{
				Debug.Log("PromoItemChecker | Failed to grant promo item: " + result.result);
				OnItemUpdated?.Invoke(null);
			}
			else
			{
				StartCoroutine(HandleItems(result.items));
			}
		});
	}

	private IEnumerator HandleItems(ItemDetail[] items)
	{
		WaitForSeconds waitForSeconds = new WaitForSeconds(3f);
		for (int i = 0; i < items.Length; i++)
		{
			ItemDetail itemDetail = items[i];
			if (itemDetail.Definition.id != 0)
			{
				SteamItemRuntime steamItemRuntime = SteamItemIdReference.Inst[itemDetail.Definition.id];
				OnItemUpdated?.Invoke(steamItemRuntime);
				NewItemPopup.Instance.ShowPopup(steamItemRuntime.Id);
				yield return waitForSeconds;
			}
		}
		CatInventory.Instance.UpdateVisuals();
	}

	private IEnumerator CheckForManualToken()
	{
		WaitForSeconds waitForTwoMinutes = new WaitForSeconds(420f);
		while (Game.Inventory.ManualToken.GetTotalQuantity() == 0L)
		{
			Inventory.Client.AddPromoItems(new SteamItemDef_t[2]
			{
				new SteamItemDef_t(Game.Inventory.Achievement_Token.id),
				new SteamItemDef_t(Game.Inventory.ManualToken.id)
			}, delegate
			{
			});
			yield return waitForTwoMinutes;
		}
	}
}
