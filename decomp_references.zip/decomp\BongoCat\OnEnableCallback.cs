using UnityEngine;
using UnityEngine.Events;

namespace BongoCat;

public class OnEnableCallback : MonoBehaviour
{
	public UnityEvent OnEnableEvent;

	private void OnEnable()
	{
		OnEnableEvent?.Invoke();
	}
}
