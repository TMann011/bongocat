using System;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public struct FriendGameInfo
{
	public FriendGameInfo_t Data;

	public GameData Game => Data.m_gameID;

	public LobbyData Lobby => Data.m_steamIDLobby;

	public static implicit operator FriendGameInfo(FriendGameInfo_t native)
	{
		return new FriendGameInfo
		{
			Data = native
		};
	}

	public static implicit operator FriendGameInfo_t(FriendGameInfo heathen)
	{
		return heathen.Data;
	}
}
