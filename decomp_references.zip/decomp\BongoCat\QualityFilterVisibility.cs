using UnityEngine;

namespace BongoCat;

public class QualityFilterVisibility : MonoBehaviour
{
	private void OnEnable()
	{
		if (!InventoryQualityFilter.Instance.FilterVisible)
		{
			base.gameObject.SetActive(value: false);
		}
	}
}
