using System;
using System.Collections;
using BongoCat.SteamJsonParser;
using Helper;
using IroxGames.Helper.ClassExtensions;
using Steam;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace BongoCat;

public class InventoryItem : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
{
	public SteamItemRuntime SteamItem;

	[SerializeField]
	private bool _isEmote;

	[SerializeField]
	private Graphic _borderImage;

	[SerializeField]
	private Image _background;

	[SerializeField]
	private Image _itemImage;

	[SerializeField]
	private GameObject _counterIndicator;

	[SerializeField]
	private TMP_Text _itemAmount;

	[SerializeField]
	private Image _isNewIndicator;

	[SerializeField]
	private Color _equippedColor;

	[SerializeField]
	private Color _unequippedColor;

	[SerializeField]
	private Image _disabledOverlay;

	[SerializeField]
	private EventBadges _eventBadges;

	[SerializeField]
	private Image _eventBadge;

	[SerializeField]
	private Image _equippedIcon;

	[SerializeField]
	private Image _iconHideButton;

	[SerializeField]
	private GameObject _hideButton;

	[SerializeField]
	private Image _favoriteImage;

	[SerializeField]
	private Image _favoriteHover;

	[SerializeField]
	private Image _unownedOverlay;

	[SerializeField]
	private Image _chestIcon;

	[SerializeField]
	private Image _marketIcon;

	[SerializeField]
	private InventoryItemMarketLinks _marketLinks;

	[SerializeField]
	private Image _hiddenIndicator;

	[SerializeField]
	private Image _showButton;

	[SerializeField]
	private TooltipUiElement _nameTooltip;

	private bool _hovering;

	private Coroutine _hoverTooltipRoutine;

	[SerializeField]
	private GameObject _iconPreview;

	[SerializeField]
	private Image _iconPreviewIcon;

	private bool _initialized;

	private bool _isPartOfBongoDex;

	private ItemCollection _collection;

	public void SetItem(SteamItemRuntime steamItem, bool isPartOfBongoDex, ItemCollection collection)
	{
		SteamItem = steamItem;
		base.gameObject.name = steamItem.ItemName;
		_isPartOfBongoDex = isPartOfBongoDex;
		_collection = collection;
		ItemCollection collection2 = _collection;
		collection2.OnInitialized = (Action)Delegate.Combine(collection2.OnInitialized, new Action(OnItemUpdated));
		SteamItemRuntime steamItem2 = SteamItem;
		steamItem2.OnItemUpdated = (Action)Delegate.Combine(steamItem2.OnItemUpdated, new Action(OnItemUpdated));
		if (!_isPartOfBongoDex && SteamItem.IsHiddenInInventory)
		{
			HideItems.Instance.AddHiddenItem(this);
		}
		HideTabSpecificItems();
	}

	private void HideTabSpecificItems()
	{
		_hiddenIndicator.enabled = false;
		_unownedOverlay.gameObject.SetActiveWithCheck(active: false);
		_chestIcon.enabled = false;
		_showButton.enabled = false;
		_marketIcon.enabled = false;
		_isNewIndicator.gameObject.SetActiveWithCheck(active: false);
		_favoriteImage.enabled = false;
		_favoriteHover.enabled = false;
	}

	private void OnDisable()
	{
		OnPointerExit(null);
	}

	private void OnDestroy()
	{
		if (SteamItem != null)
		{
			SteamItemRuntime steamItem = SteamItem;
			steamItem.OnItemUpdated = (Action)Delegate.Remove(steamItem.OnItemUpdated, new Action(OnItemUpdated));
		}
		if (_collection != null)
		{
			ItemCollection collection = _collection;
			collection.OnInitialized = (Action)Delegate.Remove(collection.OnInitialized, new Action(OnItemUpdated));
		}
	}

	private void OnItemUpdated()
	{
		if (_initialized && !SteamItem.IsOwned)
		{
			if (!CatInventory.Instance.FetchingItems)
			{
				if (!_isPartOfBongoDex)
				{
					base.gameObject.SetActiveWithCheck(active: false);
				}
				else if (SteamItem.HideUntilReceived && !_collection.UnhideHiddenCollection)
				{
					base.gameObject.SetActiveWithCheck(active: false);
				}
			}
			return;
		}
		_itemImage.sprite = SteamItem.Icon;
		_iconPreviewIcon.sprite = SteamItem.Icon;
		_equippedIcon.enabled = SteamItem.IsEquipped;
		_background.color = (SteamItem.IsEquipped ? _equippedColor : _unequippedColor);
		_borderImage.color = SteamItem.QualityCategory.GetColor();
		_itemAmount.color = SteamItem.QualityCategory.GetColor();
		_itemAmount.SetText(StringHelp.GetSuffixString(SteamItem.DisplayedItemAmount));
		bool flag = SteamItem.IsNew && SteamItem.IsOwned;
		_counterIndicator.gameObject.SetActiveWithCheck((SteamItem.IsConsumable && SteamItem.DisplayedItemAmount > 0) || (!flag && SteamItem.DisplayedItemAmount > 1 && !_isPartOfBongoDex));
		_eventBadge.sprite = _eventBadges.GetEventBadge(SteamItem.Tag);
		_eventBadge.gameObject.SetActiveWithCheck(SteamItem.IsEventItem && (bool)_eventBadge.sprite);
		if (_isPartOfBongoDex)
		{
			UpdateBongoDecksItem();
		}
		else
		{
			UpdateInventoryItem();
		}
		_initialized = true;
	}

	private void UpdateBongoDecksItem()
	{
		_hiddenIndicator.enabled = SteamItem.IsOwned && SteamItem.IsHiddenInInventory;
		_disabledOverlay.enabled = SteamItem.IsOwned && SteamItem.IsHiddenInInventory;
		_unownedOverlay.gameObject.SetActive(!SteamItem.IsOwned);
		_showButton.enabled = false;
		_marketIcon.enabled = false;
		if (!SteamItem.IsOwned && SteamItem.Data.IsActivePromo && _marketLinks.HasCustomLink(SteamItem))
		{
			_chestIcon.enabled = true;
		}
		base.gameObject.SetActive(_collection.IsItemVisible(this));
	}

	private void UpdateInventoryItem()
	{
		bool active = SteamItem.IsNew && SteamItem.IsOwned;
		_isNewIndicator.gameObject.SetActiveWithCheck(active);
		_favoriteImage.enabled = SteamItem.IsFavorite;
		bool flag = ItemExchange.Instance.IsItemSlottable(SteamItem);
		bool flag2 = TrashCan.Instance.IsItemInTrash(SteamItem);
		_disabledOverlay.enabled = !flag | flag2;
		_hiddenIndicator.enabled = ItemExchange.Instance.IsVisible && SteamItem.IsHiddenInInventory;
		bool flag3 = (ItemExchange.Instance.IsVisible ? ItemExchange.Instance.IsItemExchangeable(SteamItem) : (!SteamItem.IsHiddenInInventory));
		base.gameObject.SetActiveWithCheck(flag3 && ItemExchange.Instance.IsItemSameCategory(SteamItem) && !ItemExchange.Instance.IsEventItemHidden(SteamItem) && !ItemExchange.Instance.IsFavoriteItemHidden(SteamItem) && InventoryQualityFilter.Instance.PassesFilter(SteamItem));
	}

	public void OnClick()
	{
		if (!SteamItem.Icon)
		{
			return;
		}
		if (_disabledOverlay.enabled)
		{
			if (TrashCan.Instance.IsItemInTrash(SteamItem))
			{
				TrashCan.Instance.RemoveFromTrash(SteamItem);
			}
		}
		else if (ItemExchange.Instance.IsVisible)
		{
			OnExchangeItemClick();
		}
		else if (TrashCan.Instance.InTrashMode)
		{
			if (!TrashCan.Instance.IsItemInTrash(SteamItem))
			{
				TrashCan.Instance.AddToTrash(SteamItem);
			}
		}
		else if (_isPartOfBongoDex)
		{
			OnBongoDecksItemClick();
		}
		else
		{
			OnInventoryItemClick();
		}
	}

	private void OnExchangeItemClick()
	{
		if ((Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) && SteamItem.RuntimeData.GetTotalQuantity() - SteamItem.CurrentlyInExchangeSlot - 1 > 1)
		{
			ItemExchange.Instance.SlotItem(SteamItem, SteamItem.RuntimeData.GetTotalQuantity() - SteamItem.CurrentlyInExchangeSlot - 1);
		}
		else
		{
			ItemExchange.Instance.SlotItem(SteamItem, 1L);
		}
	}

	private void OnBongoDecksItemClick()
	{
		if (!SteamItem.IsOwned && SteamItem.Data.IsActivePromo && _marketLinks.HasCustomLink(SteamItem))
		{
			Application.OpenURL(_marketLinks.GetMarketLink(SteamItem));
		}
		else if (!_isEmote)
		{
			CatCosmetics.Instance.EquipItem(SteamItem, playAnimation: true, unequipIfSameItemIsEquipped: true);
		}
	}

	private void OnInventoryItemClick()
	{
		if (_isEmote)
		{
			EmoteDonut.Instance.ToggleItem(SteamItem);
		}
		else
		{
			CatCosmetics.Instance.EquipItem(SteamItem, playAnimation: true, unequipIfSameItemIsEquipped: true, resetRandomizerTimer: true);
		}
		OnItemUpdated();
		_isNewIndicator.gameObject.SetActive(value: false);
		_counterIndicator.gameObject.SetActive(SteamItem.RuntimeData.GetTotalQuantity() > 1 || SteamItem.IsConsumable);
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		_hovering = true;
		_hiddenIndicator.enabled = false;
		if (ItemExchange.Instance.IsVisible)
		{
			return;
		}
		_iconHideButton.enabled = SteamItem.IsOwned && !SteamItem.IsHiddenInInventory;
		if (_isPartOfBongoDex)
		{
			if (!SteamItem.IsOwned && (SteamItem.Marketable || SteamItem.EventTag == "itemstore"))
			{
				_marketIcon.enabled = true;
			}
			_nameTooltip.SetText(SteamItem.ItemName);
			_hoverTooltipRoutine = StartCoroutine(ShowNameTooltipRoutine());
			_showButton.enabled = SteamItem.IsHiddenInInventory;
		}
		else
		{
			_favoriteHover.enabled = SteamItem.IsOwned;
		}
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		_favoriteHover.enabled = false;
		_iconHideButton.enabled = false;
		_hideButton.SetActive(value: false);
		_hiddenIndicator.enabled = (_isPartOfBongoDex || ItemExchange.Instance.IsVisible) && SteamItem.IsHiddenInInventory;
		_showButton.enabled = false;
		_marketIcon.enabled = false;
		_hovering = false;
		if ((bool)_nameTooltip)
		{
			if (_hoverTooltipRoutine != null)
			{
				StopCoroutine(_hoverTooltipRoutine);
				_hoverTooltipRoutine = null;
			}
			_nameTooltip.Hide();
		}
	}

	public void ToggleFavorite()
	{
		if (!ItemExchange.Instance.IsVisible)
		{
			SteamItem.SetFavorite(!SteamItem.IsFavorite);
			_favoriteImage.enabled = SteamItem.IsFavorite;
			CatInventory.Instance.SeparateItem(SteamItem);
		}
	}

	public void OpenMarket()
	{
		if (_marketLinks.HasCustomLink(SteamItem) && SteamItem.Data.IsActivePromo)
		{
			Application.OpenURL(_marketLinks.GetMarketLink(SteamItem));
		}
		else if (SteamItem.EventTag == "itemstore")
		{
			Application.OpenURL(SteamHelper.GetItemStoreLink(SteamItem.Id));
		}
		else
		{
			Application.OpenURL(SteamHelper.GetMarketLink(SteamItem.ItemName));
		}
	}

	public void TryHideInInventory()
	{
		if (_isPartOfBongoDex)
		{
			HideInInventory();
			OnPointerEnter(null);
		}
		else
		{
			_hideButton.gameObject.SetActiveWithCheck(active: true);
		}
	}

	public void HideInInventory()
	{
		if (SteamItem.IsOwned)
		{
			HideItems.Instance.HideItem(this, _isPartOfBongoDex);
		}
	}

	public void ShowInInventory()
	{
		HideItems.Instance.ShowItem(this, _isPartOfBongoDex);
	}

	public void ShowHiddenItemTemp()
	{
		_hiddenIndicator.enabled = true;
		base.gameObject.SetActiveWithCheck(ItemExchange.Instance.IsItemExchangeable(SteamItem));
	}

	private IEnumerator ShowNameTooltipRoutine()
	{
		yield return new WaitForSeconds(0.5f);
		if (_hovering)
		{
			_nameTooltip.Show();
			_iconPreview.SetActiveWithCheck(SettingsManager.Instance.ShowIconPreview);
		}
	}
}
