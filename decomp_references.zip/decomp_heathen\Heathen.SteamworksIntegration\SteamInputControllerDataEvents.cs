using SteamTools;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInputControllerData))]
public class SteamInputControllerDataEvents : MonoBehaviour
{
	public UnityEvent onChange;

	public ControllerDataEvent onUpdate;

	private SteamInputControllerData _inspector;

	private void Awake()
	{
		_inspector = GetComponent<SteamInputControllerData>();
		_inspector.onChanged?.AddListener(onChange.Invoke);
		Events.OnInputDataChanged += HandleEvent;
	}

	private void OnDestroy()
	{
		if (_inspector != null)
		{
			_inspector.onChanged?.RemoveListener(onChange.Invoke);
		}
		Events.OnInputDataChanged -= HandleEvent;
	}

	private void HandleEvent(InputControllerStateData state)
	{
		if (_inspector.Data.HasValue && state.handle == _inspector.Data.Value)
		{
			onUpdate?.Invoke(state);
		}
	}
}
