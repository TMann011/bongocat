using System;

namespace BongoCat.IPC;

[Serializable]
public struct TapTapLootBuff(string name, float val)
{
	public string Name = name;

	public float Value = val;
}
