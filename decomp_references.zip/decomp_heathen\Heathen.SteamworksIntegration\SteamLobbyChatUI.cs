using System.Collections;
using System.Collections.Generic;
using SteamTools;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyChatUI : MonoBehaviour
{
	[SerializeField]
	private int maxMessages = 200;

	[SerializeField]
	private GameObject chatPanel;

	[SerializeField]
	private TMP_InputField inputField;

	[SerializeField]
	private ScrollRect scrollView;

	[SerializeField]
	private Transform messageRoot;

	[SerializeField]
	private GameObject myChatTemplate;

	[SerializeField]
	private GameObject theirChatTemplate;

	private SteamLobbyData _mInspector;

	private readonly List<SteamLobbyMemberChatMessage> _chatMessages = new List<SteamLobbyMemberChatMessage>();

	private void Start()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mInspector.onChanged.AddListener(HandleOnChanged);
		Events.OnLobbyChatMsg += HandleChatMessage;
	}

	private void HandleOnChanged(LobbyData arg0)
	{
		if (!arg0.IsValid)
		{
			Clear();
		}
	}

	private void OnDestroy()
	{
		Events.OnLobbyChatMsg -= HandleChatMessage;
	}

	private void Update()
	{
		if ((bool)chatPanel && (bool)inputField)
		{
			if (_mInspector.Data.IsValid && !chatPanel.activeSelf)
			{
				chatPanel.SetActive(value: true);
			}
			else if (!_mInspector.Data.IsValid && chatPanel.activeSelf)
			{
				chatPanel.SetActive(value: false);
			}
			if (EventSystem.current.currentSelectedGameObject == inputField.gameObject && (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter)))
			{
				SendMessage();
			}
		}
	}

	public void Clear()
	{
		if (_chatMessages == null)
		{
			return;
		}
		foreach (SteamLobbyMemberChatMessage chatMessage in _chatMessages)
		{
			Object.Destroy(chatMessage.gameObject);
		}
		_chatMessages.Clear();
	}

	private void HandleChatMessage(LobbyChatMsg message)
	{
		if (!(message.lobby == _mInspector.Data) || message.type != EChatEntryType.k_EChatEntryTypeChatMsg || _chatMessages == null)
		{
			return;
		}
		if (_chatMessages.Count == maxMessages)
		{
			Object.Destroy(_chatMessages[0].gameObject);
			_chatMessages.RemoveAt(0);
		}
		if (message.sender == UserData.Me)
		{
			GameObject obj = Object.Instantiate(myChatTemplate, messageRoot);
			obj.transform.SetAsLastSibling();
			SteamLobbyMemberChatMessage component = obj.GetComponent<SteamLobbyMemberChatMessage>();
			if (component != null)
			{
				component.Initialise(message);
				if (_chatMessages.Count > 0)
				{
					List<SteamLobbyMemberChatMessage> chatMessages = _chatMessages;
					if (chatMessages[chatMessages.Count - 1].User == component.User)
					{
						component.IsExpanded = false;
					}
				}
				_chatMessages.Add(component);
			}
		}
		else
		{
			GameObject obj2 = Object.Instantiate(theirChatTemplate, messageRoot);
			obj2.transform.SetAsLastSibling();
			SteamLobbyMemberChatMessage component2 = obj2.GetComponent<SteamLobbyMemberChatMessage>();
			if (component2 != null)
			{
				component2.Initialise(message);
				List<SteamLobbyMemberChatMessage> chatMessages2 = _chatMessages;
				if (chatMessages2[chatMessages2.Count - 1].User == component2.User)
				{
					component2.IsExpanded = false;
				}
				_chatMessages.Add(component2);
			}
		}
		StartCoroutine(ForceScrollDown());
	}

	public void SendMessage()
	{
		if (_mInspector.Data.IsValid && !string.IsNullOrEmpty(inputField.text))
		{
			_mInspector.Data.SendChatMessage(inputField.text);
			inputField.text = string.Empty;
			StartCoroutine(SelectInputField());
		}
	}

	private IEnumerator SelectInputField()
	{
		yield return new WaitForEndOfFrame();
		yield return new WaitForEndOfFrame();
		inputField.ActivateInputField();
	}

	private IEnumerator ForceScrollDown()
	{
		yield return new WaitForEndOfFrame();
		yield return new WaitForEndOfFrame();
		scrollView.verticalNormalizedPosition = 0f;
	}
}
