using System;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace BongoCat;

public class Preset : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler, IBeginDragHandler, IDragHandler, IEndDragHandler
{
	[Serializable]
	public struct PresetData
	{
		public int SkinItemId;

		public int HatItemId;
	}

	[SerializeField]
	private GameObject _deleteIcon;

	[SerializeField]
	private RectTransform _preview;

	[SerializeField]
	private Image _hatPreview;

	[SerializeField]
	private Image _skinPreview;

	[SerializeField]
	private Image _pawPreview;

	[SerializeField]
	private Sprite _defaultSkin;

	[SerializeField]
	private Sprite _defaultPaw;

	[SerializeField]
	private GameObject _saveIcon;

	[SerializeField]
	private Image _background;

	[SerializeField]
	private Color _equippedColor = new Color(1f, 0f, 0.6864319f, 0.41960785f);

	[SerializeField]
	private Color _normalColor = new Color(1f, 1f, 1f, 0.1764706f);

	public PresetData Data;

	public bool ContainsData;

	private bool _isHovering;

	private RectTransform _placeholder;

	private Transform _dragHomeParent;

	private Vector2 _dragOffset;

	private bool _isDragging;

	private void Start()
	{
		int rowCount = PlayerPrefs.GetInt("ITEMS_SCALE", 5);
		OnChangeScale(rowCount);
		ItemScaleSetting.OnChangeScale = (Action<int>)Delegate.Combine(ItemScaleSetting.OnChangeScale, new Action<int>(OnChangeScale));
		CatCosmetics.OnEquippedItemsChanged += UpdateEquippedHighlight;
		UpdateEquippedHighlight();
	}

	private void OnDestroy()
	{
		ItemScaleSetting.OnChangeScale = (Action<int>)Delegate.Remove(ItemScaleSetting.OnChangeScale, new Action<int>(OnChangeScale));
		CatCosmetics.OnEquippedItemsChanged -= UpdateEquippedHighlight;
	}

	public void UpdateEquippedHighlight()
	{
		bool flag = ContainsData && (CatCosmetics.Instance.Hat?.Id ?? (-1)) == Data.HatItemId && (CatCosmetics.Instance.Skin?.Id ?? (-1)) == Data.SkinItemId;
		_background.color = (flag ? _equippedColor : _normalColor);
	}

	private void OnChangeScale(int rowCount)
	{
		_preview.localScale = Vector3.one * (1.5f / (float)rowCount);
	}

	public void OnClick()
	{
		if (!_isDragging)
		{
			if (ContainsData)
			{
				Equip();
			}
			else
			{
				Save();
			}
		}
	}

	private void Save()
	{
		SetData(CatCosmetics.Instance.Hat?.Id ?? (-1), CatCosmetics.Instance.Skin?.Id ?? (-1));
		LoadVisuals();
		PresetManager.Instance.Save();
		if (_isHovering)
		{
			_deleteIcon.SetActive(ContainsData);
		}
	}

	public void LoadVisuals()
	{
		SteamItemRuntime steamItemRuntime = CatInventory.Instance.Items.FirstOrDefault((SteamItemRuntime item) => item.Id == Data.HatItemId);
		SteamItemRuntime steamItemRuntime2 = CatInventory.Instance.Items.FirstOrDefault((SteamItemRuntime item) => item.Id == Data.SkinItemId);
		_skinPreview.gameObject.SetActive(value: true);
		_pawPreview.gameObject.SetActive(value: true);
		if (steamItemRuntime != null)
		{
			_hatPreview.sprite = steamItemRuntime.FullImage;
			_hatPreview.enabled = _hatPreview.sprite != null;
		}
		if (steamItemRuntime2 != null)
		{
			string text = steamItemRuntime2.ItemName.Replace(" ", "");
			_skinPreview.sprite = MemoryImageCache.Instance.GetSprite(text + "Left");
			_pawPreview.sprite = MemoryImageCache.Instance.GetSprite(text + "Right");
		}
		_saveIcon.SetActive(value: false);
		UpdateEquippedHighlight();
	}

	public void SetData(int hatId, int skinId)
	{
		Data = new PresetData
		{
			HatItemId = hatId,
			SkinItemId = skinId
		};
		ContainsData = true;
	}

	public void Equip()
	{
		SteamItemRuntime steamItemRuntime = CatCosmetics.Instance.Hat;
		bool unequipIfSameItemIsEquipped = true;
		if (Data.HatItemId > 0)
		{
			steamItemRuntime = CatInventory.Instance.Items.FirstOrDefault((SteamItemRuntime item) => item.Id == Data.HatItemId && item.RuntimeData.GetTotalQuantity() > 0);
			unequipIfSameItemIsEquipped = false;
		}
		if (steamItemRuntime != null)
		{
			CatCosmetics.Instance.EquipItem(steamItemRuntime, playAnimation: true, unequipIfSameItemIsEquipped);
		}
		SteamItemRuntime steamItemRuntime2 = CatCosmetics.Instance.Skin;
		unequipIfSameItemIsEquipped = true;
		if (Data.SkinItemId > 0)
		{
			unequipIfSameItemIsEquipped = false;
			steamItemRuntime2 = CatInventory.Instance.Items.FirstOrDefault((SteamItemRuntime item) => item.Id == Data.SkinItemId && item.RuntimeData.GetTotalQuantity() > 0);
		}
		if (steamItemRuntime2 != null)
		{
			CatCosmetics.Instance.EquipItem(steamItemRuntime2, playAnimation: false, unequipIfSameItemIsEquipped);
		}
	}

	public void Delete()
	{
		Data = default(PresetData);
		ContainsData = false;
		_deleteIcon.SetActive(value: false);
		_hatPreview.enabled = false;
		_skinPreview.gameObject.SetActive(value: false);
		_pawPreview.gameObject.SetActive(value: false);
		_skinPreview.sprite = _defaultSkin;
		_pawPreview.sprite = _defaultPaw;
		_hatPreview.sprite = null;
		_saveIcon.SetActive(value: true);
		UpdateEquippedHighlight();
		PresetManager.Instance.Save();
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		_isHovering = true;
		_deleteIcon.SetActive(ContainsData);
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		_isHovering = false;
		_deleteIcon.SetActive(value: false);
	}

	public void OnBeginDrag(PointerEventData eventData)
	{
		if (ContainsData)
		{
			_isDragging = true;
			_deleteIcon.SetActive(value: false);
			_dragHomeParent = base.transform.parent;
			_placeholder = new GameObject("PresetPlaceholder", typeof(RectTransform)).GetComponent<RectTransform>();
			_placeholder.SetParent(_dragHomeParent, worldPositionStays: false);
			_placeholder.SetSiblingIndex(base.transform.GetSiblingIndex());
			base.transform.SetParent(base.transform.root, worldPositionStays: true);
			base.transform.SetAsLastSibling();
			_dragOffset = (Vector2)base.transform.position - eventData.position;
		}
	}

	public void OnDrag(PointerEventData eventData)
	{
		if (!_isDragging)
		{
			return;
		}
		base.transform.position = eventData.position + _dragOffset;
		int siblingIndex = _placeholder.GetSiblingIndex();
		for (int i = 0; i < _dragHomeParent.childCount; i++)
		{
			Transform child = _dragHomeParent.GetChild(i);
			if (!(child == _placeholder))
			{
				Preset component = child.GetComponent<Preset>();
				if (!(component == null) && component.ContainsData && RectTransformUtility.RectangleContainsScreenPoint((RectTransform)child, eventData.position, null))
				{
					siblingIndex = child.GetSiblingIndex();
					break;
				}
			}
		}
		_placeholder.SetSiblingIndex(siblingIndex);
	}

	public void OnEndDrag(PointerEventData eventData)
	{
		if (_isDragging)
		{
			_isDragging = false;
			int siblingIndex = _placeholder.GetSiblingIndex();
			base.transform.SetParent(_dragHomeParent, worldPositionStays: true);
			base.transform.SetSiblingIndex(siblingIndex);
			_placeholder.gameObject.SetActive(value: false);
			global::UnityEngine.Object.Destroy(_placeholder.gameObject);
			_placeholder = null;
			PresetManager.Instance.ReorderToHierarchy();
		}
	}
}
