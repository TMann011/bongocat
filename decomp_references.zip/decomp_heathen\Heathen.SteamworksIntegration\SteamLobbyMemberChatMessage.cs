using System;
using Steamworks;
using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyMemberData))]
public class SteamLobbyMemberChatMessage : MonoBehaviour
{
	public GameObject expansionPanel;

	[SerializeField]
	private string dateTimeFormat = "HH:mm:ss";

	[SerializeField]
	private TextMeshProUGUI datetime;

	[SerializeField]
	private TextMeshProUGUI message;

	private SteamLobbyMemberData _mData;

	public UserData User => _mData.Data.user;

	public byte[] Data { get; private set; }

	public string Message { get; private set; }

	public DateTime ReceivedAt { get; private set; }

	public EChatEntryType Type { get; private set; }

	public bool IsExpanded
	{
		get
		{
			if (expansionPanel != null)
			{
				return expansionPanel.activeSelf;
			}
			return false;
		}
		set
		{
			if (expansionPanel != null)
			{
				expansionPanel.SetActive(value);
			}
		}
	}

	private void Awake()
	{
		_mData = GetComponent<SteamLobbyMemberData>();
	}

	public void Initialise(LobbyChatMsg chatMessage)
	{
		_mData.Data = new LobbyMemberData
		{
			lobby = chatMessage.lobby,
			user = chatMessage.sender
		};
		Type = chatMessage.type;
		Message = chatMessage.Message;
		Data = chatMessage.data;
		ReceivedAt = DateTime.Now;
		message.text = Message;
		if (datetime != null)
		{
			datetime.text = ReceivedAt.ToString(dateTimeFormat);
		}
	}
}
