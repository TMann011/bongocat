using System.Collections.Generic;
using UnityEngine;

namespace BongoCat.Multiplayer.Spawning;

public class GridPattern : CatSpawnPatternBase
{
	public override SpawnControls Controls => (SpawnControls)(0x1C7 | (base.AnchorIsCenter ? 32 : 16));

	public override float MaxDistancePercent
	{
		get
		{
			Rect area = Area;
			float spacing = base.PreferredVerticalSpacing;
			int divisor = SpawnGeometry.SlotsSpanning(area.height, ref spacing);
			return SpawnGeometry.PercentFor(SpawnGeometry.SpanStep(area.width, SpawnGeometry.CeilDivide(base.CatCount, divisor)));
		}
	}

	public override float MaxVerticalDistancePercent
	{
		get
		{
			Rect area = Area;
			float spacing = base.PreferredSpacing;
			int divisor = SpawnGeometry.SlotsSpanning(area.width, ref spacing);
			return SpawnGeometry.PercentFor(SpawnGeometry.SpanStep(area.height, SpawnGeometry.CeilDivide(base.CatCount, divisor)));
		}
	}

	private Rect Area
	{
		get
		{
			bool flag = Settings.RotationOffset == 0;
			bool flag2 = Settings.RotationOffset == 1;
			bool flag3 = Settings.RotationOffset == 2;
			bool flag4 = Settings.RotationOffset == 3;
			float catWidth = SpawnGeometry.CatWidth;
			return Rect.MinMaxRect(flag4 ? SpawnGeometry.XMin : (SpawnGeometry.XMin + (flag2 ? catWidth : SpawnGeometry.Inset)), flag ? SpawnGeometry.YMin : (SpawnGeometry.YMin + (flag3 ? catWidth : SpawnGeometry.Inset)), flag2 ? SpawnGeometry.XMax : (SpawnGeometry.XMax - (flag4 ? catWidth : SpawnGeometry.Inset)), flag3 ? SpawnGeometry.YMax : (SpawnGeometry.YMax - (flag ? catWidth : SpawnGeometry.Inset)));
		}
	}

	public GridPattern(CatSpawnSettings settings)
		: base(settings)
	{
	}

	protected override List<CatSlot> Layout()
	{
		int catCount = base.CatCount;
		Rect area = Area;
		float width = area.width;
		float height = area.height;
		float spacing = base.PreferredSpacing;
		float spacing2 = base.PreferredVerticalSpacing;
		if (Capacity(spacing, spacing2, width, height) < catCount)
		{
			float num = Mathf.Sqrt(width * height / ((float)catCount * spacing * spacing2));
			spacing = Mathf.Max(1f, spacing * num);
			spacing2 = Mathf.Max(1f, spacing2 * num);
		}
		int num2 = SpawnGeometry.SlotsSpanning(width, ref spacing);
		int num3 = SpawnGeometry.SlotsSpanning(height, ref spacing2);
		if (num2 * num3 > 250)
		{
			float num4 = Mathf.Sqrt(250f / (float)(num2 * num3));
			num2 = Mathf.Max(1, Mathf.FloorToInt((float)num2 * num4));
			num3 = Mathf.Clamp(Mathf.FloorToInt((float)num3 * num4), 1, 250 / num2);
			spacing = SpawnGeometry.SpanStep(width, num2);
			spacing2 = SpawnGeometry.SpanStep(height, num3);
		}
		float num5 = (base.AnchorIsRight ? area.xMax : area.xMin);
		float num6 = (base.AnchorIsRight ? (0f - spacing) : spacing);
		float num7 = (base.AnchorIsTop ? area.yMax : area.yMin);
		float num8 = (base.AnchorIsTop ? (0f - spacing2) : spacing2);
		List<CatSlot> list = new List<CatSlot>();
		foreach (Vector2Int item in CellOrder(num2, num3))
		{
			list.Add(new CatSlot
			{
				Position = new Vector2(num5 + (float)item.x * num6, num7 + (float)item.y * num8),
				RotationState = 0
			});
		}
		return list;
	}

	private IEnumerable<Vector2Int> CellOrder(int columns, int rows)
	{
		if (!base.AnchorIsCenter)
		{
			return RowsAndColumns(columns, rows);
		}
		return SpiralCells(columns, rows, Settings.Clockwise.Value);
	}

	private IEnumerable<Vector2Int> RowsAndColumns(int columns, int rows)
	{
		bool rowFirst = Settings.GridFillOrder == FillOrder.RowFirst;
		foreach (int outer in CatSpawnPatternBase.FillOrderIndices(rowFirst ? rows : columns, fromFarEnd: false, fromCenter: false))
		{
			foreach (int item in CatSpawnPatternBase.FillOrderIndices(rowFirst ? columns : rows, fromFarEnd: false, fromCenter: false))
			{
				yield return rowFirst ? new Vector2Int(item, outer) : new Vector2Int(outer, item);
			}
		}
	}

	private static IEnumerable<Vector2Int> SpiralCells(int columns, int rows, bool clockwise)
	{
		Vector2Int[] directions = ((!clockwise) ? new Vector2Int[4]
		{
			Vector2Int.right,
			Vector2Int.up,
			Vector2Int.left,
			Vector2Int.down
		} : new Vector2Int[4]
		{
			Vector2Int.right,
			Vector2Int.down,
			Vector2Int.left,
			Vector2Int.up
		});
		Vector2Int cell = new Vector2Int((columns - 1) / 2, (rows - 1) / 2);
		int remaining = columns * rows;
		yield return cell;
		remaining--;
		int run = 1;
		int direction = 0;
		while (remaining > 0)
		{
			for (int leg = 0; leg < 2; leg++)
			{
				if (remaining <= 0)
				{
					break;
				}
				for (int step = 0; step < run; step++)
				{
					if (remaining <= 0)
					{
						break;
					}
					cell += directions[direction % 4];
					if (cell.x >= 0 && cell.x < columns && cell.y >= 0 && cell.y < rows)
					{
						yield return cell;
						remaining--;
					}
				}
				direction++;
			}
			run++;
		}
	}

	private static int Capacity(float horizontalSpacing, float verticalSpacing, float gridWidth, float gridHeight)
	{
		return SpawnGeometry.SlotsSpanning(gridWidth, ref horizontalSpacing) * SpawnGeometry.SlotsSpanning(gridHeight, ref verticalSpacing);
	}
}
