using Heathen.SteamworksIntegration.API;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInputControllerData))]
public class SteamInputControllerVibrate : MonoBehaviour
{
	public float left;

	public float right;

	private SteamInputControllerData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamInputControllerData>();
	}

	private void Update()
	{
		if (_mInspector.Data.HasValue)
		{
			Heathen.SteamworksIntegration.API.Input.Client.TriggerVibration(_mInspector.Data.Value, (ushort)Mathf.Lerp(0f, 65535f, left), (ushort)Mathf.Lerp(0f, 65535f, right));
		}
	}
}
