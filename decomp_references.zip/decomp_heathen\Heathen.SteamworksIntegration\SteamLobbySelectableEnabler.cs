using System;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace Heathen.SteamworksIntegration;

public class SteamLobbySelectableEnabler : MonoBehaviour
{
	public enum EnableWhenRule
	{
		IsSet,
		IsNotSet,
		AmITheOwner,
		AmINotTheOwner,
		AmIMember,
		AmINotMember,
		IsParty,
		IsSession,
		IsNotParty,
		IsNotSession
	}

	[Flags]
	public enum ConditionMode
	{
		None = 0,
		Or = 1,
		And = 2
	}

	public SteamLobbyData targetLobby;

	[Tooltip("The conditions that will enable this GameObject.")]
	public EnableWhenRule[] conditions;

	[Tooltip("Should conditions be combined with AND or OR logic?")]
	public ConditionMode mode = ConditionMode.Or;

	private Selectable[] _selectable;

	private void Awake()
	{
		if (targetLobby != null)
		{
			targetLobby.onChanged?.AddListener(HandleOnChanged);
			HandleOnChanged(targetLobby.Data);
		}
		else
		{
			HandleOnChanged(CSteamID.Nil);
		}
		_selectable = GetComponents<Selectable>();
	}

	private void OnDestroy()
	{
		if (targetLobby != null)
		{
			targetLobby.onChanged?.RemoveListener(HandleOnChanged);
		}
	}

	private void HandleOnChanged(LobbyData arg0)
	{
		bool flag = mode == ConditionMode.And;
		EnableWhenRule[] array = conditions;
		foreach (EnableWhenRule condition in array)
		{
			bool flag2 = CheckCondition(condition);
			if (mode == ConditionMode.Or)
			{
				flag |= flag2;
			}
			else if (mode == ConditionMode.And)
			{
				flag &= flag2;
			}
		}
		Selectable[] selectable = _selectable;
		for (int i = 0; i < selectable.Length; i++)
		{
			selectable[i].interactable = flag;
		}
	}

	private bool CheckCondition(EnableWhenRule condition)
	{
		return condition switch
		{
			EnableWhenRule.IsSet => targetLobby != null && targetLobby.Data.IsValid, 
			EnableWhenRule.IsNotSet => targetLobby == null || !targetLobby.Data.IsValid, 
			EnableWhenRule.AmITheOwner => targetLobby != null && targetLobby.Data.IsOwner, 
			EnableWhenRule.AmINotTheOwner => targetLobby == null || !targetLobby.Data.IsOwner, 
			EnableWhenRule.AmIMember => targetLobby != null && targetLobby.Data.IsAMember(UserData.Me), 
			EnableWhenRule.AmINotMember => targetLobby == null || !targetLobby.Data.IsAMember(UserData.Me), 
			EnableWhenRule.IsParty => targetLobby != null && targetLobby.Data.IsParty, 
			EnableWhenRule.IsSession => targetLobby != null && targetLobby.Data.IsSession, 
			EnableWhenRule.IsNotParty => targetLobby == null || !targetLobby.Data.IsParty, 
			EnableWhenRule.IsNotSession => targetLobby == null || !targetLobby.Data.IsSession, 
			_ => false, 
		};
	}
}
