using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat.Achievements;
using BongoCat.SteamJsonParser;
using DG.Tweening;
using Heathen.SteamworksIntegration;
using Heathen.SteamworksIntegration.API;
using Helper;
using Steam;
using SteamTools;
using Steamworks;
using TMPro;
using Tutorial;
using UnityEngine;
using UnityEngine.Events;

namespace BongoCat;

public class CatInventory : MonoBehaviour
{
	public enum SortingMode
	{
		Rarity,
		Count,
		Event
	}

	public static CatInventory Instance;

	public static readonly UnityEvent OnInventoryChanged = new UnityEvent();

	[SerializeField]
	private Transform _inventoryExclamationMark;

	[SerializeField]
	private UnlockGate _exchangeExclamationBadge;

	public List<SteamItemRuntime> Items = new List<SteamItemRuntime>();

	public Tabs Tabs;

	public HatRandomizer CatRandomizer;

	[SerializeField]
	private RectTransform _inventorySettingsWindow;

	[SerializeField]
	private GameObject _consumableSeparator;

	[SerializeField]
	private ScrollViewUpdater _scrollViewUpdater;

	[SerializeField]
	private RectTransform _presetsWindow;

	[SerializeField]
	private ItemCollection _hatsCollection;

	[SerializeField]
	private ItemCollection _skinsCollection;

	[SerializeField]
	private ItemCollection _consumableCollection;

	[SerializeField]
	private ItemCollection _emoteCollection;

	[SerializeField]
	private SteamItemIdReference _itemIdReference;

	[SerializeField]
	private TMP_Dropdown _sortingModeDropdown;

	[SerializeField]
	private Transform _ascendingButton;

	private const string SORTING_MODE_KEY = "InventorySortingMode";

	public SortingMode SortMode;

	public bool SortAscending;

	private bool _flaggedPremium;

	private int _highlightedTabs;

	private const string CONSUMABLE_CATEGORY = "consumable";

	private const string HAT_CATEGORY = "hat";

	private const string SKIN_CATEGORY = "skin";

	private const string EMOTE_CATEGORY = "emote";

	public bool FetchingItems;

	public bool IsInitialized;

	private void Awake()
	{
		Instance = this;
		_itemIdReference.Init();
		Tabs tabs = Tabs;
		tabs.OnOpenTab = (Action<int>)Delegate.Combine(tabs.OnOpenTab, new Action<int>(OnOpenTab));
		_sortingModeDropdown.value = PlayerPrefs.GetInt("InventorySortingMode", 0);
	}

	private IEnumerator Start()
	{
		InstantiateItemsRoutine();
		yield return new WaitUntil(() => Interface.IsReady);
		while (true)
		{
			FetchingItems = true;
			Inventory.Client.GetAllItems(HandleInventoryUpdate);
			yield return new WaitForSecondsRealtime(120f);
		}
	}

	private void OnDestroy()
	{
		Tabs tabs = Tabs;
		tabs.OnOpenTab = (Action<int>)Delegate.Remove(tabs.OnOpenTab, new Action<int>(OnOpenTab));
	}

	private void OnOpenTab(int tabIndex)
	{
		SortItems();
		if (tabIndex == 0)
		{
			UpdateScrollView(resetScrollBar: true);
		}
	}

	private void HandleInventoryUpdate(InventoryResult res)
	{
		if (res.result != EResult.k_EResultOK)
		{
			return;
		}
		bool flag = !IsInitialized;
		IsInitialized = true;
		if (res.items.Length == 0)
		{
			return;
		}
		FetchingItems = false;
		AchievementStats.SetTotalItems(Items.Where((SteamItemRuntime item) => !item.Hidden).Sum((SteamItemRuntime item) => item.RuntimeData.GetTotalQuantity()) + 1);
		if (flag)
		{
			foreach (SteamItemRuntime item in Items.Where((SteamItemRuntime steamItem) => steamItem.RuntimeData.GetTotalQuantity() > 0).ToList())
			{
				item.IsNew = false;
				item.OnItemUpdated?.Invoke();
			}
		}
		UpdateVisuals();
		if (Items.Any((SteamItemRuntime item) => item.IsPremium && item.RuntimeData.GetTotalQuantity() > 0))
		{
			if (!_flaggedPremium)
			{
				_flaggedPremium = true;
				SteamAnalytics.Instance.SetStatToOne(string.Format("{0}_{1}_{2}", "PREM", DateTime.UtcNow.Year, DateTime.UtcNow.Month));
			}
			SteamUserStats.SetStat(string.Format("{0}_{1}_{2}", "PREM_AMT", DateTime.UtcNow.Year, DateTime.UtcNow.Month), Items.Where((SteamItemRuntime item) => item.IsPremium).Sum((SteamItemRuntime item) => item.RuntimeData.GetTotalQuantity()));
			SteamUserStats.StoreStats();
		}
	}

	private void InstantiateItemsRoutine()
	{
		foreach (SteamItemBasic allItemDatum in _itemIdReference.AllItemData)
		{
			SteamItemRuntime steamItemRuntime = SteamItemIdReference.Inst[allItemDatum.Id];
			if (!steamItemRuntime.Hidden && !steamItemRuntime.Data.GameOnly)
			{
				Items.Add(steamItemRuntime);
			}
		}
		_hatsCollection.CreateCollection("", Items.Where((SteamItemRuntime item) => item.IsHat).ToList(), isPartOfBongoDex: false);
		_skinsCollection.CreateCollection("", Items.Where((SteamItemRuntime item) => item.IsSkin).ToList(), isPartOfBongoDex: false);
		_consumableCollection.CreateCollection("", Items.Where((SteamItemRuntime item) => item.IsConsumable).ToList(), isPartOfBongoDex: false);
		_emoteCollection.CreateCollection("", Items.Where((SteamItemRuntime item) => item.IsEmote).ToList(), isPartOfBongoDex: false);
		foreach (SteamItemRuntime item in Items)
		{
			item.OnItemUpdated?.Invoke();
		}
	}

	public void UpdateItemsUI()
	{
		foreach (SteamItemRuntime item in Items)
		{
			item.OnItemUpdated?.Invoke();
		}
		if (!ItemExchange.Instance.HasItemsSlotted)
		{
			Tabs.EnableAllTabs(enable: true);
		}
		SetSeparatorVisibility();
		OnInventoryChanged.Invoke();
	}

	public void UpdateVisuals()
	{
		if (FetchingItems)
		{
			return;
		}
		foreach (SteamItemRuntime item in Items)
		{
			item.OnItemUpdated?.Invoke();
		}
		CatCosmetics.Instance.Validate();
		EmoteDonut.Instance.Validate();
		UpdateExchangeBadges();
		SortItems();
		OnInventoryChanged.Invoke();
	}

	private void UpdateExchangeBadges()
	{
		if (ItemExchange.Instance.CanFillExchangeWithDuplicates(out var duplicateQuality))
		{
			_exchangeExclamationBadge.Highlight(duplicateQuality.ToQuality().GetColor());
		}
		else
		{
			_exchangeExclamationBadge.DismissHighlight();
		}
	}

	public void HighlightInventory()
	{
		_highlightedTabs++;
		_inventoryExclamationMark.gameObject.SetActive(value: true);
		_inventoryExclamationMark.DOKill(complete: true);
		_inventoryExclamationMark.localScale = Vector3.zero;
		_inventoryExclamationMark.DOScale(1f, 0.3f).SetEase(Ease.OutBack, 3f);
	}

	public void DismissHighlight()
	{
		_highlightedTabs = Mathf.Max(_highlightedTabs - 1, 0);
		if (_highlightedTabs == 0)
		{
			_inventoryExclamationMark.gameObject.SetActive(value: false);
		}
	}

	public ItemCollection GetCollection(string itemSlot)
	{
		return itemSlot switch
		{
			"hat" => _hatsCollection, 
			"skin" => _skinsCollection, 
			"emote" => _emoteCollection, 
			"consumable" => _consumableCollection, 
			_ => null, 
		};
	}

	public void SeparateItem(SteamItemRuntime item)
	{
		GetCollection(item.ItemSlot).SeparateItem(item, sortCollection: true);
		SetSeparatorVisibility();
	}

	private void SortItems()
	{
		_hatsCollection.SortCollection();
		_skinsCollection.SortCollection();
		_emoteCollection.SortCollection();
		_consumableCollection.SortCollection();
		SetSeparatorVisibility();
		StartCoroutine(SortDelayed());
	}

	private IEnumerator SortDelayed()
	{
		yield return null;
		_hatsCollection.SortCollection();
		_skinsCollection.SortCollection();
		_emoteCollection.SortCollection();
		_consumableCollection.SortCollection();
		SetSeparatorVisibility();
	}

	public void SetSeparatorVisibility()
	{
		_consumableSeparator.SetActive(_consumableCollection.ContainsActiveItems && _emoteCollection.ContainsActiveItems);
		_hatsCollection.SetFavoriteSeparatorVisibility();
		_skinsCollection.SetFavoriteSeparatorVisibility();
		_emoteCollection.SetFavoriteSeparatorVisibility();
	}

	public void UpdateScrollView(bool resetScrollBar = false)
	{
		_scrollViewUpdater.UpdateScrollView(resetScrollBar);
	}

	public void ToggleAscending()
	{
		SortAscending = !SortAscending;
		_ascendingButton.localRotation = (SortAscending ? Quaternion.Euler(0f, 0f, 270f) : Quaternion.Euler(0f, 0f, 90f));
		SortItems();
	}

	public void SetSortingMode(int value)
	{
		SortMode = (SortingMode)value;
		SortItems();
	}
}
