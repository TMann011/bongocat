using System.Collections;
using BongoCat.Multiplayer;
using DG.Tweening;
using Heathen.SteamworksIntegration;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace BongoCat;

[RequireComponent(typeof(CatBobbing))]
public class Cat : MonoBehaviour
{
	public static Cat Instance;

	[FormerlySerializedAs("_openDuration")]
	[SerializeField]
	private float _hitDuration;

	[SerializeField]
	private Image _catImage;

	[SerializeField]
	private Image _catFront;

	[SerializeField]
	private Image _hatImage;

	[SerializeField]
	private GameObject _hatObject;

	public EmoteSpawner emoteSpawner;

	public CatPatter catPatter;

	public OnSpecificUIHoverCallback hoverCallback;

	public FlipVisuals flipVisuals;

	public CatRotator catRotator;

	public CatBobbing catBobbing;

	[SerializeField]
	private Sprite _catNormalDefault;

	[SerializeField]
	private Sprite _catLeftDefault;

	[SerializeField]
	private Sprite _catNormalFrontDefault;

	[SerializeField]
	private Sprite _catRightFrontDefault;

	[SerializeField]
	private Sprite _catNormal;

	[SerializeField]
	private Sprite _catLeft;

	[SerializeField]
	private Sprite _catNormalFront;

	[SerializeField]
	private Sprite _catRightFront;

	[SerializeField]
	private SteamLobbyMemberData _lobbyMemberData;

	[FormerlySerializedAs("_popUpImage")]
	[SerializeField]
	private FrameAnimation _popUpAnimation;

	private bool _isMultiplayer;

	private bool _wasLeft;

	private Coroutine _routineLeft;

	private Coroutine _routineRight;

	private Sequence _sequence;

	private bool _started;

	public UnityEvent<int> OnTap;

	private void Awake()
	{
		if (!Instance)
		{
			Instance = this;
		}
	}

	private void OnEnable()
	{
		_catFront.sprite = _catNormalFront;
		_routineRight = null;
		_catImage.sprite = _catNormal;
		_routineLeft = null;
	}

	private void Start()
	{
		if ((bool)_lobbyMemberData)
		{
			_isMultiplayer = true;
			SteamMultiplayer.Instance.OnTapsReceived.Register(_lobbyMemberData.Data.user.id, Tap);
		}
		if ((bool)_popUpAnimation)
		{
			_catImage.gameObject.SetActive(value: false);
			_catFront.gameObject.SetActive(value: false);
			_hatObject.SetActive(value: false);
			_popUpAnimation.PlayAnimation(delegate
			{
				_catImage.gameObject.SetActive(value: true);
				_catFront.gameObject.SetActive(value: true);
				_hatObject.SetActive(value: true);
			}, forceAction: true);
		}
		else
		{
			_catImage.gameObject.SetActive(value: true);
			_catFront.gameObject.SetActive(value: true);
			_hatObject.SetActive(value: true);
		}
		_started = true;
	}

	private void OnDestroy()
	{
		if (_isMultiplayer)
		{
			SteamMultiplayer.Instance.OnTapsReceived.Deregister(_lobbyMemberData.Data.user.id, Tap);
		}
	}

	public Sprite GetBaseSprite()
	{
		return _catNormal;
	}

	public Sprite GetFrontSprite()
	{
		return _catNormalFront;
	}

	public Sprite GetHatSprite()
	{
		return _hatImage.sprite;
	}

	public void ClearItemSlot(string itemSlot)
	{
		if (!(itemSlot == "hat"))
		{
			if (itemSlot == "skin")
			{
				SetSkin(null);
			}
		}
		else
		{
			_hatImage.sprite = null;
			_hatImage.enabled = _hatImage.sprite;
		}
	}

	public void SetItem(SteamItemRuntime item, bool playAnimation = false)
	{
		string itemSlot = item.ItemSlot;
		if (!(itemSlot == "hat"))
		{
			if (itemSlot == "skin")
			{
				SetSkin(item);
			}
		}
		else
		{
			SetHat(item, playAnimation);
		}
	}

	private void SetHat(SteamItemRuntime steamItem, bool playAnimation = false)
	{
		_hatImage.sprite = steamItem.FullImage;
		_hatImage.enabled = _hatImage.sprite;
		bool flag = flipVisuals.IsFlipped && MemoryImageCache.Instance.LetterSprites.Contains(_hatImage.sprite);
		if (playAnimation)
		{
			_hatImage.GetComponent<OpenScaleAnimation>()?.PlayAnimation(flag ? new Vector3(-1f, 1f, 1f) : Vector3.one);
		}
		else
		{
			_hatImage.transform.localScale = (flag ? new Vector3(-1f, 1f, 1f) : Vector3.one);
		}
	}

	public void UpdateFlip(bool isFlipped)
	{
		bool flag = isFlipped && MemoryImageCache.Instance.LetterSprites.Contains(_hatImage.sprite);
		_hatImage.transform.localScale = (flag ? new Vector3(-1f, 1f, 1f) : Vector3.one);
	}

	private void SetSkin(SteamItemRuntime steamItem)
	{
		if (steamItem == null)
		{
			_catNormal = _catNormalDefault;
			_catLeft = _catLeftDefault;
			_catNormalFront = _catNormalFrontDefault;
			_catRightFront = _catRightFrontDefault;
			_catImage.sprite = _catNormal;
			_catFront.sprite = _catNormalFront;
		}
		else
		{
			string text = steamItem.ItemName.Replace(" ", "");
			_catNormal = MemoryImageCache.Instance.GetSprite(text + "Left");
			_catLeft = MemoryImageCache.Instance.GetSprite(text + "LeftPunch");
			_catNormalFront = MemoryImageCache.Instance.GetSprite(text + "Right");
			_catRightFront = MemoryImageCache.Instance.GetSprite(text + "RightPunch");
			_catImage.sprite = _catNormal;
			_catFront.sprite = _catNormalFront;
		}
	}

	public void Tap(int amount)
	{
		OnTap?.Invoke(amount);
		if (_wasLeft)
		{
			if (_routineRight == null)
			{
				_catFront.sprite = _catRightFront;
				if (base.gameObject.activeInHierarchy)
				{
					_routineRight = StartCoroutine(CatHitRight());
				}
			}
		}
		else if (_routineLeft == null)
		{
			_catImage.sprite = _catLeft;
			if (base.gameObject.activeInHierarchy)
			{
				_routineLeft = StartCoroutine(CatHitLeft());
			}
		}
		_wasLeft = !_wasLeft;
	}

	private IEnumerator CatHitLeft()
	{
		OnDemandRenderHelper.Instance.ResumeRendering();
		yield return new WaitForSeconds(_hitDuration);
		_catImage.sprite = _catNormal;
		_routineLeft = null;
		OnDemandRenderHelper.Instance.TryPauseRendering();
	}

	private IEnumerator CatHitRight()
	{
		OnDemandRenderHelper.Instance.ResumeRendering();
		yield return new WaitForSeconds(_hitDuration);
		_catFront.sprite = _catNormalFront;
		_routineRight = null;
		OnDemandRenderHelper.Instance.TryPauseRendering();
	}
}
