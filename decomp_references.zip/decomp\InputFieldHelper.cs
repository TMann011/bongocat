using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

public class InputFieldHelper : MonoBehaviour
{
	[SerializeField]
	private int _maxChars;

	[SerializeField]
	private bool _activateOnEnable = true;

	[SerializeField]
	private bool _hideOnDeselect = true;

	[SerializeField]
	private UnityEvent<string> OnSendEvent;

	[SerializeField]
	private UnityEvent OnDeselectEvent;

	private TMP_InputField _inputField;

	private bool _singleLine;

	public static bool ProcessingSubmit;

	private void Awake()
	{
		_inputField = GetComponent<TMP_InputField>();
		_inputField.onSelect.AddListener(SelectTextfield);
		_inputField.onValueChanged.AddListener(CheckTextfield);
		_inputField.onEndEdit.AddListener(DelayDeselection);
		_singleLine = _inputField.lineType == TMP_InputField.LineType.SingleLine;
	}

	public void Send()
	{
		OnSendEvent?.Invoke(_inputField.text);
		_inputField.ReleaseSelection();
	}

	private void OnEnable()
	{
		if (_activateOnEnable)
		{
			StartCoroutine(ActivateInput());
		}
	}

	private IEnumerator ActivateInput()
	{
		yield return null;
		_inputField.ActivateInputField();
	}

	private void OnDisable()
	{
		Deselect();
	}

	private void SelectTextfield(string str)
	{
		ProcessingSubmit = true;
	}

	private void CheckTextfield(string str)
	{
		if (!_singleLine && str.Contains("\n"))
		{
			_inputField.text = str.Replace("\n", "").Replace("\r", "");
			Send();
			Deselect();
		}
		else
		{
			int length = Mathf.Min(str.Length, _maxChars);
			_inputField.text = str.Substring(0, length);
		}
	}

	private void DelayDeselection(string str)
	{
		if (_singleLine && Input.GetKeyDown(KeyCode.Return))
		{
			OnSendEvent?.Invoke(str);
		}
		if (base.gameObject.activeInHierarchy)
		{
			StartCoroutine(DeselectRoutine());
		}
	}

	private IEnumerator DeselectRoutine()
	{
		yield return new WaitUntil(() => Input.GetKeyUp(KeyCode.Return) || Input.GetMouseButtonUp(0) || !Application.isFocused);
		Deselect();
	}

	private void Deselect()
	{
		OnDeselectEvent?.Invoke();
		_inputField.text = "";
		ProcessingSubmit = false;
		if (_hideOnDeselect)
		{
			_inputField.gameObject.SetActive(value: false);
		}
	}
}
