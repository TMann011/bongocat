using BongoCat.SteamJsonParser;
using Heathen.SteamworksIntegration;
using Steam;
using UnityEngine;

namespace BongoCat;

public class TrackButtonUsage : MonoBehaviour
{
	[SerializeField]
	private string _steamString;

	[SerializeField]
	private bool _hasToHaveItem;

	[SerializeField]
	private SteamItemBasic _steamItem;

	private StatData Stat => _steamString;

	public void AddToUsage()
	{
		if (!StatsInitializer.Initialized)
		{
			return;
		}
		if (_hasToHaveItem)
		{
			if (_steamItem != null && !_steamItem.HasItem)
			{
				return;
			}
		}
		else if (_steamItem != null && _steamItem.HasItem)
		{
			return;
		}
		Stat.Set(Stat.IntValue() + 1);
		Stat.Store();
	}
}
