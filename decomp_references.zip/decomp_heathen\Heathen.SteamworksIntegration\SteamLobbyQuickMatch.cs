using System;
using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyQuickMatch : MonoBehaviour
{
	public enum SteamLobbyType
	{
		Private,
		FriendsOnly,
		Public,
		Invisible
	}

	public enum LobbyDistanceFilter
	{
		Close,
		Default,
		Far,
		Worldwide
	}

	[Tooltip("If true the search will check if there is currently a party lobby if so it will search for a lobby enough slots for each party member, else it will obey the slots field.")]
	public bool partyWise;

	[Tooltip("The type of lobby to create")]
	public SteamLobbyType type = SteamLobbyType.Public;

	[Tooltip("The number of slots to create the lobby with if created.")]
	public int slotsOnCreate = 1;

	[Tooltip("The distance from the searching user that should be considered when searching")]
	public LobbyDistanceFilter distance = LobbyDistanceFilter.Default;

	[Tooltip("Metadata values that should be used to sort the results e.g. values `closer` to these values will be weighted higher in the results")]
	public List<NearFilter> nearValues = new List<NearFilter>();

	[Tooltip("Metadata values that should be compared as numeric values e.g., should follow typical maths rules for concepts such as less than, greater than, etc.")]
	public List<NumericFilter> numericFilters = new List<NumericFilter>();

	[Tooltip("Metadata values that should be compared as strings")]
	public List<StringFilter> stringFilters = new List<StringFilter>();

	private int _slots = 1;

	private SteamLobbyData _inspector;

	private SteamLobbyDataEvents _events;

	private void Awake()
	{
		_inspector = GetComponent<SteamLobbyData>();
		_events = GetComponent<SteamLobbyDataEvents>();
	}

	public void Match()
	{
		LobbyData partyLobby = CSteamID.Nil;
		if (partyWise && LobbyData.PartyLobby(out partyLobby))
		{
			if (!partyLobby.IsOwner)
			{
				Debug.LogWarning("Only a party lobby leader can create or join lobbies");
				return;
			}
			_slots = partyLobby.MemberCount;
		}
		else
		{
			_slots = 1;
		}
		Matchmaking.Client.AddRequestLobbyListDistanceFilter((ELobbyDistanceFilter)distance);
		if (_slots > 0)
		{
			Matchmaking.Client.AddRequestLobbyListFilterSlotsAvailable(_slots);
		}
		foreach (NearFilter nearValue in nearValues)
		{
			Matchmaking.Client.AddRequestLobbyListNearValueFilter(nearValue.key, nearValue.value);
		}
		foreach (NumericFilter numericFilter in numericFilters)
		{
			Matchmaking.Client.AddRequestLobbyListNumericalFilter(numericFilter.key, numericFilter.value, numericFilter.comparison);
		}
		foreach (StringFilter stringFilter in stringFilters)
		{
			Matchmaking.Client.AddRequestLobbyListStringFilter(stringFilter.key, stringFilter.value, stringFilter.comparison);
		}
		Matchmaking.Client.AddRequestLobbyListResultCountFilter(1);
		Matchmaking.Client.RequestLobbyList(delegate(LobbyData[] r, bool e)
		{
			if (!e)
			{
				if (r.Length != 0)
				{
					r[0].Join(delegate(LobbyEnter enterLobby, bool enterIoError)
					{
						if (!enterIoError && enterLobby.Response == EChatRoomEnterResponse.k_EChatRoomEnterResponseSuccess)
						{
							_inspector.Data = enterLobby.Lobby;
							if (_events != null)
							{
								_events.onEnterSuccess?.Invoke(enterLobby.Lobby);
							}
							if (partyLobby.IsValid)
							{
								partyLobby["z_heathenSessionLobby"] = enterLobby.Lobby.ToString();
							}
						}
						else
						{
							slotsOnCreate = Convert.ToInt32(Mathf.Max(1, slotsOnCreate));
							LobbyData.Create((ELobbyType)type, SteamLobbyModeType.Session, slotsOnCreate, delegate(EResult createResult, LobbyData createdLobby, bool createIoError)
							{
								if (!createIoError && createResult == EResult.k_EResultOK)
								{
									_inspector.Data = createdLobby;
									if (_events != null)
									{
										_events.onCreate?.Invoke(createdLobby);
									}
									if (partyLobby.IsValid)
									{
										partyLobby["z_heathenSessionLobby"] = createdLobby.ToString();
									}
								}
								else if (_events != null)
								{
									_events.onCreationFailure?.Invoke(createResult);
								}
							});
						}
					});
				}
				else
				{
					slotsOnCreate = Convert.ToInt32(Mathf.Max(1, slotsOnCreate));
					LobbyData.Create((ELobbyType)type, SteamLobbyModeType.Session, slotsOnCreate, delegate(EResult createResult, LobbyData createdLobby, bool createIoError)
					{
						if (!createIoError && createResult == EResult.k_EResultOK)
						{
							_inspector.Data = createdLobby;
							if (_events != null)
							{
								_events.onCreate?.Invoke(createdLobby);
							}
							if (partyLobby.IsValid)
							{
								partyLobby["z_heathenSessionLobby"] = createdLobby.ToString();
							}
						}
						else if (_events != null)
						{
							_events.onCreationFailure?.Invoke(createResult);
						}
					});
				}
			}
			else
			{
				slotsOnCreate = Convert.ToInt32(Mathf.Max(1, slotsOnCreate));
				LobbyData.Create((ELobbyType)type, SteamLobbyModeType.Session, slotsOnCreate, delegate(EResult createResult, LobbyData createdLobby, bool createIoError)
				{
					if (!createIoError && createResult == EResult.k_EResultOK)
					{
						_inspector.Data = createdLobby;
						if (_events != null)
						{
							_events.onCreate?.Invoke(createdLobby);
						}
						if (partyLobby.IsValid)
						{
							partyLobby["z_heathenSessionLobby"] = createdLobby.ToString();
						}
					}
					else if (_events != null)
					{
						_events.onCreationFailure?.Invoke(createResult);
					}
				});
			}
		});
	}
}
