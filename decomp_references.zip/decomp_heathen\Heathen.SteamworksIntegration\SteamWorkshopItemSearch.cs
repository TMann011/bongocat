using System.Collections.Generic;
using Heathen.SteamworksIntegration.API;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace Heathen.SteamworksIntegration;

public class SteamWorkshopItemSearch : MonoBehaviour
{
	public TMP_InputField searchText;

	public TextMeshProUGUI currentPageLabel;

	public TextMeshProUGUI pageCountLabel;

	public SteamWorkshopItemDetailData template;

	public Transform content;

	public UgcQuery ActiveQuery;

	public UnityEvent<UgcQuery> onResultsReady;

	public UnityEvent<UgcQuery> onQueryUpdated;

	private readonly List<SteamWorkshopItemDetailData> _currentRecords = new List<SteamWorkshopItemDetailData>();

	private string _lastSearchString = "";

	public int CurrentFrom
	{
		get
		{
			if (ActiveQuery != null)
			{
				int num = (int)(ActiveQuery.Page * 50);
				if (num < ActiveQuery.MatchedRecordCount)
				{
					return num - 49;
				}
				int num2 = (int)(ActiveQuery.MatchedRecordCount % 50);
				num = num - 50 + num2;
				return num - num2 + 1;
			}
			return 0;
		}
	}

	public int CurrentTo
	{
		get
		{
			if (ActiveQuery != null)
			{
				int num = (int)(ActiveQuery.Page * 50);
				if (num < ActiveQuery.MatchedRecordCount)
				{
					return num;
				}
				int num2 = (int)(ActiveQuery.MatchedRecordCount % 50);
				return num - 50 + num2;
			}
			return 0;
		}
	}

	public int TotalCount
	{
		get
		{
			if (ActiveQuery == null)
			{
				return 0;
			}
			return (int)ActiveQuery.MatchedRecordCount;
		}
	}

	public int CurrentPage
	{
		get
		{
			if (ActiveQuery == null)
			{
				return 0;
			}
			return (int)ActiveQuery.Page;
		}
	}

	private string GetSearchString()
	{
		if (searchText != null)
		{
			return searchText.text;
		}
		return string.Empty;
	}

	public void SearchMyPublished()
	{
		string text = (_lastSearchString = GetSearchString());
		ActiveQuery = UgcQuery.GetMyPublished();
		if (!string.IsNullOrEmpty(text))
		{
			UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, text);
		}
		if (ActiveQuery.Handle != UGCQueryHandle_t.Invalid)
		{
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogError("Steam was unable to create a query handle for this argument. Check your App ID and the App ID in the query manager.");
		}
	}

	public void SearchAll()
	{
		string text = (_lastSearchString = GetSearchString());
		ActiveQuery = UgcQuery.Get(EUGCQuery.k_EUGCQuery_RankedByTrend, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items_ReadyToUse, new AppId_t(0u), AppData.Me);
		if (!string.IsNullOrEmpty(text))
		{
			UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, text);
		}
		if (ActiveQuery.Handle != UGCQueryHandle_t.Invalid)
		{
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogError("Steam was unable to create a query handle for this argument. Check your App ID and the App ID in the query manager.");
		}
	}

	public void SearchSubscribed()
	{
		string text = (_lastSearchString = GetSearchString());
		ActiveQuery = UgcQuery.GetSubscribed();
		if (!string.IsNullOrEmpty(text))
		{
			UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, text);
		}
		if (ActiveQuery.Handle != UGCQueryHandle_t.Invalid)
		{
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogError("Steam was unable to create a query handle for this argument. Check your App ID and the App ID in the query manager.");
		}
	}

	public void PrepareSearchAll()
	{
		string text = (_lastSearchString = GetSearchString());
		ActiveQuery = UgcQuery.Get(EUGCQuery.k_EUGCQuery_RankedByTrend, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items_ReadyToUse, new AppId_t(0u), AppData.Me);
		if (!string.IsNullOrEmpty(text))
		{
			UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, text);
		}
		if (ActiveQuery.Handle != UGCQueryHandle_t.Invalid)
		{
			onQueryUpdated.Invoke(ActiveQuery);
		}
		else
		{
			Debug.LogError("Steam was unable to create a query handle for this argument. Check your App ID and the App ID in the query manager.");
		}
	}

	public void SearchFavorites()
	{
		string text = (_lastSearchString = GetSearchString());
		ActiveQuery = UgcQuery.Get(SteamUser.GetSteamID().GetAccountID(), EUserUGCList.k_EUserUGCList_Favorited, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items_ReadyToUse, EUserUGCListSortOrder.k_EUserUGCListSortOrder_TitleAsc, new AppId_t(0u), AppData.Me);
		if (!string.IsNullOrEmpty(text))
		{
			UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, text);
		}
		if (ActiveQuery.Handle != UGCQueryHandle_t.Invalid)
		{
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogError("Steam was unable to create a query handle for this argument. Check your App ID and the App ID in the query manager.");
		}
	}

	public void PrepareSearchFavorites()
	{
		string text = (_lastSearchString = GetSearchString());
		ActiveQuery = UgcQuery.Get(SteamUser.GetSteamID().GetAccountID(), EUserUGCList.k_EUserUGCList_Favorited, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items_ReadyToUse, EUserUGCListSortOrder.k_EUserUGCListSortOrder_TitleAsc, new AppId_t(0u), AppData.Me);
		if (!string.IsNullOrEmpty(text))
		{
			UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, text);
		}
		if (ActiveQuery.Handle != UGCQueryHandle_t.Invalid)
		{
			onQueryUpdated.Invoke(ActiveQuery);
		}
		else
		{
			Debug.LogError("Steam was unable to create a query handle for this argument. Check your App ID and the App ID in the query manager.");
		}
	}

	public void SearchFollowed()
	{
		string text = (_lastSearchString = GetSearchString());
		ActiveQuery = UgcQuery.Get(SteamUser.GetSteamID().GetAccountID(), EUserUGCList.k_EUserUGCList_Followed, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items_ReadyToUse, EUserUGCListSortOrder.k_EUserUGCListSortOrder_TitleAsc, new AppId_t(0u), AppData.Me);
		if (!string.IsNullOrEmpty(text))
		{
			UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, text);
		}
		if (ActiveQuery.Handle != UGCQueryHandle_t.Invalid)
		{
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogError("Steam was unable to create a query handle for this argument. Check your App ID and the App ID in the query manager.");
		}
	}

	public void PrepareSearchFollowed()
	{
		string text = (_lastSearchString = GetSearchString());
		ActiveQuery = UgcQuery.Get(SteamUser.GetSteamID().GetAccountID(), EUserUGCList.k_EUserUGCList_Followed, EUGCMatchingUGCType.k_EUGCMatchingUGCType_Items_ReadyToUse, EUserUGCListSortOrder.k_EUserUGCListSortOrder_TitleAsc, new AppId_t(0u), AppData.Me);
		if (!string.IsNullOrEmpty(text))
		{
			UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, text);
		}
		onQueryUpdated.Invoke(ActiveQuery);
	}

	public void ExecuteSearch()
	{
		if (ActiveQuery != null && ActiveQuery.Handle != UGCQueryHandle_t.Invalid)
		{
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogError("Attempted to execute a query with an invalid query handle.");
		}
	}

	public void SetNextSearchPage()
	{
		if (ActiveQuery != null)
		{
			ActiveQuery.SetNextPage();
			if (!string.IsNullOrEmpty(_lastSearchString))
			{
				UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, _lastSearchString);
			}
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogWarning("No active query or the query handle is invalid, you must call a Search or Prepare Search method before iterating over the pages");
		}
	}

	public void SetPreviousSearchPage()
	{
		if (ActiveQuery != null)
		{
			ActiveQuery.SetPreviousPage();
			if (!string.IsNullOrEmpty(_lastSearchString))
			{
				UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, _lastSearchString);
			}
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogWarning("No active query or the query handle is invalid, you must call a Search or Prepare Search method before iterating over the pages");
		}
	}

	public void SetSearchPage(uint page)
	{
		if (ActiveQuery != null)
		{
			ActiveQuery.SetPage(page);
			if (!string.IsNullOrEmpty(_lastSearchString))
			{
				UserGeneratedContent.Client.SetSearchText(ActiveQuery.Handle, _lastSearchString);
			}
			ActiveQuery.Execute(HandleResults);
		}
		else
		{
			Debug.LogWarning("No active query or the query handle is invalid, you must call a Search or Prepare Search method before iterating over the pages");
		}
	}

	private void HandleResults(UgcQuery query)
	{
		if (currentPageLabel != null)
		{
			currentPageLabel.text = ActiveQuery.Page.ToString();
		}
		if (pageCountLabel != null)
		{
			pageCountLabel.text = ActiveQuery.PageCount.ToString();
		}
		if (template != null && content != null)
		{
			foreach (SteamWorkshopItemDetailData currentRecord in _currentRecords)
			{
				Object.Destroy(currentRecord.gameObject);
			}
			_currentRecords.Clear();
			foreach (WorkshopItemDetails results in query.ResultsList)
			{
				SteamWorkshopItemDetailData steamWorkshopItemDetailData = Object.Instantiate(template, content);
				_currentRecords.Add(steamWorkshopItemDetailData);
				steamWorkshopItemDetailData.Data = results;
				steamWorkshopItemDetailData.LoadPreview();
			}
		}
		onResultsReady?.Invoke(ActiveQuery);
	}
}
