using SteamTools;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
[RequireComponent(typeof(SteamLobbyJoin))]
public class SteamLobbyJoinSessionLobby : MonoBehaviour
{
	public SteamLobbyData partyLobbyData;

	public bool leaveOnSessionClear = true;

	private SteamLobbyData _mInspector;

	private SteamLobbyJoin _mJoin;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		if (partyLobbyData != null)
		{
			partyLobbyData.onChanged.AddListener(HandleChange);
		}
		Events.OnLobbyDataUpdate += HandleDataUpdate;
	}

	private void OnDestroy()
	{
		if (partyLobbyData != null)
		{
			partyLobbyData.onChanged.RemoveListener(HandleChange);
		}
		Events.OnLobbyDataUpdate -= HandleDataUpdate;
	}

	private void HandleChange(LobbyData arg0)
	{
		if (arg0.IsValid)
		{
			string text = arg0["z_heathenSessionLobby"];
			if (!string.IsNullOrEmpty(text))
			{
				LobbyData sessionLobby = LobbyData.Get(text);
				JoinSessionLobby(sessionLobby);
			}
		}
	}

	private void HandleDataUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		if (partyLobbyData != null && partyLobbyData.Data == lobby && !member.HasValue)
		{
			string text = partyLobbyData.Data["z_heathenSessionLobby"];
			if (!string.IsNullOrEmpty(text))
			{
				LobbyData sessionLobby = LobbyData.Get(text);
				JoinSessionLobby(sessionLobby);
			}
			else if (leaveOnSessionClear && _mInspector.Data.IsValid)
			{
				_mInspector.Data.Leave();
				_mInspector.Data = CSteamID.Nil;
			}
		}
	}

	private void JoinSessionLobby(LobbyData sessionLobby)
	{
		if (sessionLobby.IsValid)
		{
			if (_mInspector.Data != sessionLobby && _mInspector.Data.IsValid)
			{
				_mInspector.Data.Leave();
			}
			if (!sessionLobby.IsAMember(UserData.Me))
			{
				_mJoin.Join(sessionLobby);
			}
			else
			{
				_mInspector.Data = sessionLobby;
			}
		}
	}
}
