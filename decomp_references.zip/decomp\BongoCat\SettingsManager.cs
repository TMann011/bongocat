using BongoCat.Helper;
using UnityEngine;
using UnityEngine.Serialization;

namespace BongoCat;

public class SettingsManager : MonoBehaviour
{
	public static SettingsManager Instance;

	[FormerlySerializedAs("_mainScreenSetting")]
	public MainScreenSetting MainScreenSetting;

	public PlayerPrefsToggle AnimateChestPurchase;

	public PlayerPrefsToggle AutoHideCounter;

	[FormerlySerializedAs("_snapping")]
	public PlayerPrefsToggle Snapping;

	[FormerlySerializedAs("_lockPosition")]
	public PlayerPrefsToggle LockPosition;

	[FormerlySerializedAs("_catScaleSetting")]
	public ScaleSetting CatScaleSetting;

	[FormerlySerializedAs("_uiScaleSetting")]
	public ScaleSetting UIScaleSetting;

	public PlayerPrefsToggle AfkIndicator;

	public PlayerPrefsToggle ShowEmoteChest;

	[SerializeField]
	private PlayerPrefsToggle _showIconPreview;

	[FormerlySerializedAs("_alwaysShowChest")]
	public PlayerPrefsToggle AlwaysShowChest;

	public PlayerPrefsToggle PatOwnCat;

	public PlayerPrefsToggle ShowPatEmote;

	public PlayerPrefsToggle CatBobbing;

	public PlayerPrefsToggle SyncCatBobbing;

	[FormerlySerializedAs("_snapCats")]
	public PlayerPrefsToggle SnapCats;

	[FormerlySerializedAs("_showPlayerNames")]
	public PlayerPrefsToggle ShowPlayerNames;

	[FormerlySerializedAs("_scaleAllCats")]
	public PlayerPrefsToggle ScaleAllCats;

	[FormerlySerializedAs("_multiplayerPopups")]
	public PlayerPrefsToggle MultiplayerPopups;

	[FormerlySerializedAs("_hideEmotesSetting")]
	public PlayerPrefsToggle HideEmotesSetting;

	[FormerlySerializedAs("_privateLobby")]
	public SelectionMenu PrivateLobby;

	[FormerlySerializedAs("_autoHideCats")]
	public PlayerPrefsToggle AutoHideCats;

	[FormerlySerializedAs("_muteChats")]
	public PlayerPrefsToggle MuteChats;

	public PlayerPrefsToggle ReceivePats;

	[FormerlySerializedAs("_chatLanguageFilter")]
	public PlayerPrefsToggle ChatLanguageFilter;

	[SerializeField]
	private PlayerPrefsToggle _autoEquipDrops;

	public bool ShowIconPreview => _showIconPreview.Value;

	public bool AutoEquipDrops => _autoEquipDrops.Value;

	private void Awake()
	{
		Instance = this;
	}
}
