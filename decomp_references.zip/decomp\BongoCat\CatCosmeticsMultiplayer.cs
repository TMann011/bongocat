using System.Collections.Generic;
using System.Linq;
using BongoCat.TapTapLootIntegration;
using Heathen.SteamworksIntegration;
using SteamTools;
using UnityEngine;

namespace BongoCat;

public class CatCosmeticsMultiplayer : MonoBehaviour
{
	[SerializeField]
	private Cat _cat;

	private Dictionary<string, int> _equippedItemIds;

	public List<SteamItemRuntime> EquippedItems;

	[SerializeField]
	private SteamLobbyMemberData _lobbyMemberData;

	private const string HAT_ITEMSLOT_KEY = "hat";

	private const string SKIN_ITEMSLOT_KEY = "skin";

	private void Awake()
	{
		if (EquippedItems == null)
		{
			EquippedItems = new List<SteamItemRuntime>();
		}
		if (_equippedItemIds == null)
		{
			_equippedItemIds = new Dictionary<string, int>
			{
				{ "hat", -1 },
				{ "skin", -1 }
			};
		}
	}

	private void Start()
	{
		Events.OnLobbyDataUpdate += OnLobbyDataUpdate;
		EquipCosmetic("hat", _lobbyMemberData.Data.Hat);
		EquipCosmetic("skin", _lobbyMemberData.Data.Skin);
	}

	private void OnDestroy()
	{
		Events.OnLobbyDataUpdate -= OnLobbyDataUpdate;
	}

	private void OnLobbyDataUpdate(LobbyData lobby, LobbyMemberData? member)
	{
		if (member.HasValue && member.Value.user == _lobbyMemberData.Data.user)
		{
			EquipCosmetic("hat", _lobbyMemberData.Data.Hat);
			EquipCosmetic("skin", _lobbyMemberData.Data.Skin);
		}
	}

	private void EquipCosmetic(string itemSlot, int itemId)
	{
		if (itemId == -1)
		{
			UnequipItem(itemSlot);
		}
		else
		{
			EquipItem(SteamItemIdReference.Inst[itemId]);
		}
	}

	public void EquipItem(SteamItemRuntime steamItem, bool playAnimation = true)
	{
		if (EquippedItems == null)
		{
			EquippedItems = new List<SteamItemRuntime>();
		}
		if (_equippedItemIds == null)
		{
			_equippedItemIds = new Dictionary<string, int>
			{
				{ "hat", -1 },
				{ "skin", -1 }
			};
		}
		if (!_equippedItemIds.Values.Contains(steamItem.Id))
		{
			_cat.SetItem(steamItem, playAnimation);
			_equippedItemIds[steamItem.ItemSlot] = steamItem.Id;
			EquippedItems.RemoveAll((SteamItemRuntime i) => i.ItemSlot == steamItem.ItemSlot);
			EquippedItems.Add(steamItem);
			OnDemandRenderHelper.Instance.ResumeRenderingForDuration(0.2f);
			Ipc.Instance.UpdateBuffs();
		}
	}

	private void UnequipItem(string itemSlot)
	{
		_cat.ClearItemSlot(itemSlot);
		_equippedItemIds[itemSlot] = -1;
		EquippedItems.RemoveAll((SteamItemRuntime i) => i.ItemSlot == itemSlot);
		OnDemandRenderHelper.Instance.ResumeRenderingForDuration(0.2f);
		Ipc.Instance.UpdateBuffs();
	}
}
