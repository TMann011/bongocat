using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BongoCat.SteamJsonParser;
using Steam;
using UnityEngine;

namespace BongoCat;

public class HideIfItemInInventory : MonoBehaviour
{
	[SerializeField]
	private GameObject _visual;

	[SerializeField]
	private List<SteamItemBase> _items;

	private IEnumerator Start()
	{
		yield return new WaitUntil(() => CatInventory.Instance.IsInitialized);
		PromoItemChecker instance = PromoItemChecker.Instance;
		instance.OnItemUpdated = (Action<SteamItemRuntime>)Delegate.Combine(instance.OnItemUpdated, new Action<SteamItemRuntime>(OnItemUpdated));
		OnItemUpdated(null);
	}

	private void OnDestroy()
	{
		if ((bool)PromoItemChecker.Instance)
		{
			PromoItemChecker instance = PromoItemChecker.Instance;
			instance.OnItemUpdated = (Action<SteamItemRuntime>)Delegate.Remove(instance.OnItemUpdated, new Action<SteamItemRuntime>(OnItemUpdated));
		}
	}

	private void OnItemUpdated(SteamItemRuntime _)
	{
		if (_items == null)
		{
			_items = new List<SteamItemBase>();
		}
		if (!_visual)
		{
			return;
		}
		bool active = !_items.All((SteamItemBase item) => CatInventory.Instance.Items.Any((SteamItemRuntime i) => item.Id == i.Id && i.RuntimeData.GetTotalQuantity() > 0));
		_visual.SetActive(active);
	}
}
