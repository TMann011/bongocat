using System.Collections;
using DG.Tweening;
using Heathen.SteamworksIntegration;
using UnityEngine;

namespace BongoCat;

public class CatBobbing : MonoBehaviour
{
	[SerializeField]
	private bool _subscribeOnStart;

	[SerializeField]
	private Transform _bobTransform;

	[SerializeField]
	private float _bobDistance = 0.975f;

	[SerializeField]
	[Min(0.01f)]
	private float _bobDuration = 1f;

	[SerializeField]
	private SteamLobbyMemberData _lobbyMemberData;

	private Sequence _sequence;

	private bool _started;

	private bool _isMultiplayer;

	private float BobbingProgression => _sequence.Elapsed(includeLoops: false);

	private bool IsBobbing => _sequence != null;

	private void OnEnable()
	{
		if (_started && _subscribeOnStart)
		{
			SubscribeToBobbingSetting();
		}
	}

	private void Start()
	{
		if ((bool)_lobbyMemberData)
		{
			_isMultiplayer = true;
		}
		if (_subscribeOnStart)
		{
			SubscribeToBobbingSetting();
		}
		_started = true;
	}

	private void SubscribeToBobbingSetting()
	{
		SettingsManager.Instance.CatBobbing.OnToggleUpdated.AddListener(ToggleBobbingAnimation);
		SettingsManager.Instance.SyncCatBobbing.OnToggleUpdated.AddListener(ToggleSyncBobbing);
		ToggleBobbingAnimation(SettingsManager.Instance.CatBobbing.Value);
	}

	private void OnDisable()
	{
		SettingsManager.Instance.CatBobbing.OnToggleUpdated.RemoveListener(ToggleBobbingAnimation);
		SettingsManager.Instance.SyncCatBobbing.OnToggleUpdated.RemoveListener(ToggleSyncBobbing);
	}

	public void ToggleBobbingAnimation(bool toggle)
	{
		if (toggle)
		{
			BounceSequence();
		}
		else if (_sequence != null && _sequence.active)
		{
			StartCoroutine(FinishCurrentLoop());
		}
	}

	private IEnumerator FinishCurrentLoop()
	{
		yield return _sequence.WaitForElapsedLoops(_sequence.CompletedLoops() + 1);
		KillBobbing();
	}

	public void KillBobbing()
	{
		if (_sequence != null)
		{
			_sequence.Kill();
			_bobTransform.localScale = new Vector3(_bobTransform.localScale.x, 1f, _bobTransform.localScale.z);
			_sequence = null;
		}
	}

	private void ToggleSyncBobbing(bool toggle)
	{
		if (_isMultiplayer)
		{
			GetBobbingAnimationStart();
		}
	}

	private void GetBobbingAnimationStart()
	{
		if (_sequence == null)
		{
			return;
		}
		if (!_isMultiplayer)
		{
			_sequence.Goto(0f, andPlay: true);
			return;
		}
		CatBobbing catBobbing = Cat.Instance.catBobbing;
		if (SettingsManager.Instance.SyncCatBobbing.Value && catBobbing.IsBobbing)
		{
			_sequence.Goto(catBobbing.BobbingProgression, andPlay: true);
		}
		else
		{
			_sequence.Goto(Random.Range(0f, 1.5f), andPlay: true);
		}
	}

	public void BounceSequence()
	{
		if (_sequence == null)
		{
			_sequence = DOTween.Sequence();
			_sequence.Append(_bobTransform.transform.DOScaleY(_bobDistance, _bobDuration / 2f));
			_sequence.Append(_bobTransform.transform.DOScaleY(1f, _bobDuration / 2f));
			_sequence.SetLoops(-1);
			_sequence.SetLink(base.gameObject);
			_sequence.Play();
		}
	}
}
