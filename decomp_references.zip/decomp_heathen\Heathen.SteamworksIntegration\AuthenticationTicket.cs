using System;
using System.Runtime.CompilerServices;
using Steamworks;

namespace Heathen.SteamworksIntegration;

[Serializable]
public class AuthenticationTicket
{
	[CompilerGenerated]
	private bool _003CIsClientTicket_003Ek__BackingField;

	[CompilerGenerated]
	private uint _003CCreatedOn_003Ek__BackingField;

	private bool IsClientTicket
	{
		[CompilerGenerated]
		set
		{
			_003CIsClientTicket_003Ek__BackingField = value;
		}
	}

	public HAuthTicket Handle { get; private set; }

	public byte[] Data { get; private set; }

	public bool Verified { get; private set; }

	private uint CreatedOn
	{
		[CompilerGenerated]
		set
		{
			_003CCreatedOn_003Ek__BackingField = value;
		}
	}

	public EResult Result { get; private set; }

	public Action<AuthenticationTicket, bool> Callback { get; private set; }

	public AuthenticationTicket(SteamNetworkingIdentity forIdentity, Action<AuthenticationTicket, bool> callback, bool isClient = true)
	{
		Callback = callback;
		IsClientTicket = isClient;
		byte[] array = new byte[1024];
		Handle = (isClient ? SteamUser.GetAuthSessionTicket(array, 1024, out var pcbTicket, ref forIdentity) : SteamGameServer.GetAuthSessionTicket(array, 1024, out pcbTicket, ref forIdentity));
		CreatedOn = SteamUtils.GetServerRealTime();
		Array.Resize(ref array, (int)pcbTicket);
		Data = array;
	}

	public AuthenticationTicket(string webIdentity, Action<AuthenticationTicket, bool> callback)
	{
		Callback = callback;
		IsClientTicket = true;
		Handle = SteamUser.GetAuthTicketForWebApi(webIdentity);
		CreatedOn = SteamUtils.GetServerRealTime();
		Data = null;
	}

	public void Authenticate(GetAuthSessionTicketResponse_t response)
	{
		if (Handle != default(HAuthTicket) && Handle != HAuthTicket.Invalid && response.m_eResult == EResult.k_EResultOK)
		{
			Result = response.m_eResult;
			Verified = true;
			Callback?.Invoke(this, arg2: false);
		}
		else
		{
			Result = response.m_eResult;
			Callback?.Invoke(this, arg2: true);
		}
	}

	public void Authenticate(GetTicketForWebApiResponse_t response)
	{
		Data = new byte[response.m_cubTicket];
		Array.Copy(response.m_rgubTicket, Data, response.m_cubTicket);
		if (Handle != default(HAuthTicket) && Handle != HAuthTicket.Invalid && response.m_eResult == EResult.k_EResultOK)
		{
			Result = response.m_eResult;
			Verified = true;
			Callback?.Invoke(this, arg2: false);
		}
		else
		{
			Result = response.m_eResult;
			Callback?.Invoke(this, arg2: true);
		}
	}
}
