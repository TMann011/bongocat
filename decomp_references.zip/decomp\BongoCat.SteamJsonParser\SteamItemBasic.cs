using System.Collections.Generic;
using System.Linq;
using BongoCat.IPC;
using UnityEngine;

namespace BongoCat.SteamJsonParser;

public class SteamItemBasic : SteamItemBase
{
	public string Description;

	public List<string> Tags = new List<string> { "quality:common", "cosmetics_quality:common", "itemslot:hat" };

	public bool Tradable = true;

	public bool Marketable = true;

	public bool Hidden;

	public bool Dropable = true;

	public int BundleFrequency = 1;

	public bool GameOnly;

	public string Promo;

	public string DropStartTime;

	public bool IsOtherToken;

	public bool HideUntilReceived;

	public bool IsActivePromo;

	public string PriceCategory;

	public bool FeatureInItemStore;

	public int PurchaseLimit;

	public List<TapTapLootBuff> TapTapLootBuffs;

	public bool HasTagWithValue(string tagAndValue)
	{
		return Tags.Any((string tag) => tag == tagAndValue);
	}

	public string GetTagValue(string tag)
	{
		string text = Tags.FirstOrDefault((string t) => t.StartsWith(tag + ":"));
		if (text != null)
		{
			return text.Split(":")[1];
		}
		return string.Empty;
	}

	public static Color GetColorForQuality(string quality)
	{
		Color color = Color.white;
		switch (quality)
		{
		case "common":
			ColorUtility.TryParseHtmlString("#B0B0B0", out color);
			return color;
		case "uncommon":
			ColorUtility.TryParseHtmlString("#5ACC3D", out color);
			return color;
		case "rare":
			ColorUtility.TryParseHtmlString("#258ED4", out color);
			return color;
		case "epic":
			ColorUtility.TryParseHtmlString("#B939DB", out color);
			return color;
		case "legendary":
			ColorUtility.TryParseHtmlString("#FFB000", out color);
			return color;
		case "unique":
			ColorUtility.TryParseHtmlString("#FF3D87", out color);
			return color;
		default:
			return Color.white;
		}
	}

	public override SteamItemJson ToSteamItemBackend()
	{
		bool granted_manually = false;
		if (!string.IsNullOrEmpty(Promo) && string.IsNullOrEmpty(DropStartTime))
		{
			granted_manually = Promo.Contains("manual");
		}
		string text = "";
		if (!string.IsNullOrEmpty(PriceCategory))
		{
			text = GetTagValue("itemslot");
			if (FeatureInItemStore)
			{
				text += ";featured";
			}
		}
		return new SteamItemJson(this)
		{
			type = "item",
			bundle = "",
			tags = string.Join(";", Tags),
			tradable = Tradable,
			marketable = Marketable,
			hidden = Hidden,
			description = Description,
			name_color = ColorUtility.ToHtmlStringRGB(GetColorForQuality(GetTagValue("quality"))),
			store_tags = text,
			icon_url = "https://pub-d6170922fa31462fa15463d240b18424.r2.dev/" + Name.Replace(" ", "") + "Icon.png",
			icon_url_large = "https://pub-d6170922fa31462fa15463d240b18424.r2.dev/" + Name.Replace(" ", "") + "Icon.png",
			auto_stack = true,
			promo = Promo,
			price_category = PriceCategory,
			game_only = GameOnly,
			drop_interval = ((!string.IsNullOrEmpty(DropStartTime)) ? 99999999 : 0),
			granted_manually = granted_manually,
			purchase_limit = PurchaseLimit,
			drop_start_time = DropStartTime,
			hide_until_received = HideUntilReceived
		};
	}
}
