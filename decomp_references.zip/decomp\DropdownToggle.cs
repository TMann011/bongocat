using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class DropdownToggle : MonoBehaviour
{
	[SerializeField]
	[Tooltip("Dropdown menu should be expanded by default")]
	private bool defaultValue = true;

	[SerializeField]
	[Tooltip("Dropdown menu expansion will be set to default value when disabling")]
	private bool _resetOnDisable = true;

	[SerializeField]
	private Transform dropdownArrow;

	[SerializeField]
	private ToggleGameObject foldoutWindow;

	[SerializeField]
	private int _parentsToRebuild = 1;

	private bool _expanded;

	[SerializeField]
	private string _playerPrefsSaveKey;

	private void Awake()
	{
		_expanded = defaultValue;
	}

	private void OnEnable()
	{
		if (!string.IsNullOrEmpty(_playerPrefsSaveKey))
		{
			_expanded = PlayerPrefs.GetInt(_playerPrefsSaveKey, defaultValue ? 1 : 0) == 1;
		}
		Display(animate: false);
	}

	private void OnDisable()
	{
		if (_resetOnDisable)
		{
			_expanded = defaultValue;
		}
	}

	public void Toggle()
	{
		_expanded = !_expanded;
		if (!string.IsNullOrEmpty(_playerPrefsSaveKey))
		{
			PlayerPrefs.SetInt(_playerPrefsSaveKey, _expanded ? 1 : 0);
		}
		Display();
	}

	public void SetToggle(bool value)
	{
		if (value != _expanded)
		{
			_expanded = !value;
			Toggle();
		}
	}

	private void Display(bool animate = true)
	{
		foldoutWindow.SetActive(_expanded);
		if ((bool)dropdownArrow)
		{
			DOTween.Kill(dropdownArrow);
			float z = (_expanded ? 0f : 90f);
			if (animate)
			{
				dropdownArrow.DOLocalRotate(new Vector3(0f, 0f, z), 0.2f);
			}
			else
			{
				dropdownArrow.localRotation = Quaternion.Euler(0f, 0f, z);
			}
		}
		Transform parent = foldoutWindow.transform;
		for (int i = 0; i <= _parentsToRebuild; i++)
		{
			LayoutRebuilder.ForceRebuildLayoutImmediate(parent as RectTransform);
			if (!parent.parent)
			{
				break;
			}
			parent = parent.parent;
		}
	}
}
