using System.Collections.Generic;
using System.Linq;
using Heathen.SteamworksIntegration.API;
using SteamTools;
using Steamworks;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

public class SteamFriendsListUI : MonoBehaviour
{
	public enum Filter
	{
		All,
		InThisGame,
		InOtherGame,
		InAnyGame,
		NotInThisGame,
		NotInGame,
		AnyOnline,
		AnyOffline,
		Away,
		Busy,
		Followed
	}

	public bool includeFollowed;

	[SerializeField]
	private Filter filter;

	public Transform content;

	public GameObject recordTemplate;

	private readonly Dictionary<UserData, GameObject> _records = new Dictionary<UserData, GameObject>();

	public Filter ActiveFilter
	{
		get
		{
			return filter;
		}
		set
		{
			filter = value;
			UpdateDisplay();
		}
	}

	private void Awake()
	{
		Events.OnPersonaStateChange += HandleStateChange;
		Interface.WhenReady(UpdateDisplay);
	}

	private void OnDestroy()
	{
		Events.OnPersonaStateChange -= HandleStateChange;
		Clear();
	}

	private void DelayUpdate()
	{
		UpdateDisplay();
	}

	private void HandleStateChange(UserData user, EPersonaChange change)
	{
		if (!user.IsMe)
		{
			if (MatchFilter(user))
			{
				Add(user);
			}
			else
			{
				Remove(user);
			}
		}
	}

	private void Remove(UserData user)
	{
		if (_records.ContainsKey(user))
		{
			GameObject obj = _records[user];
			_records.Remove(user);
			Object.Destroy(obj.gameObject);
		}
	}

	private void Add(UserData user)
	{
		if (!_records.ContainsKey(user))
		{
			AddNewRecord(user);
		}
		else
		{
			_records[user].GetComponent<SteamUserData>().Data = user;
		}
		SortRecords();
	}

	private void AddNewRecord(UserData user)
	{
		GameObject gameObject = Object.Instantiate(recordTemplate, content);
		gameObject.GetComponent<SteamUserData>().Data = user;
		_records.Add(user, gameObject);
	}

	private void SortRecords()
	{
		foreach (UserData item in _records.Keys.OrderBy(SortGroup).ThenBy((UserData user) => user.Nickname).ToList())
		{
			_records[item].transform.SetAsLastSibling();
		}
	}

	private static int SortGroup(UserData user)
	{
		if (user.InThisGame)
		{
			return 0;
		}
		return user.State switch
		{
			EPersonaState.k_EPersonaStateOnline => 1, 
			EPersonaState.k_EPersonaStateOffline => 3, 
			_ => 2, 
		};
	}

	public void Clear()
	{
		_records.Clear();
		if (content.childCount <= 0)
		{
			return;
		}
		foreach (Transform item in content)
		{
			try
			{
				Object.Destroy(item.gameObject);
			}
			catch
			{
			}
		}
	}

	public void UpdateDisplay()
	{
		Clear();
		List<UserData> filtered = new List<UserData>();
		List<UserData> friends = new List<UserData>(Friends.Client.GetFriends(EFriendFlags.k_EFriendFlagImmediate));
		if (includeFollowed)
		{
			List<UserData> followed = new List<UserData>();
			Friends.Client.GetFollowed(delegate(CSteamID[] r)
			{
				if (r != null && r.Length != 0)
				{
					IEnumerable<CSteamID> enumerable = r.Where((CSteamID p) => p.GetEAccountType() == EAccountType.k_EAccountTypeIndividual);
					if (enumerable.Count() > 0)
					{
						foreach (CSteamID item in enumerable)
						{
							if (!friends.Contains(item))
							{
								friends.Add(item);
							}
							followed.Add(item);
						}
					}
				}
				if (filter == Filter.Followed)
				{
					foreach (UserData item2 in followed)
					{
						if (item2 != UserData.Me && !_records.ContainsKey(item2))
						{
							AddNewRecord(item2);
						}
					}
				}
				else
				{
					foreach (UserData item3 in friends)
					{
						if (item3 != UserData.Me && MatchFilter(item3))
						{
							filtered.Add(item3);
						}
					}
					foreach (UserData item4 in filtered)
					{
						if (item4 != UserData.Me && !_records.ContainsKey(item4))
						{
							AddNewRecord(item4);
						}
					}
				}
				SortRecords();
			});
			return;
		}
		foreach (UserData item5 in friends)
		{
			if (item5 != UserData.Me && MatchFilter(item5))
			{
				AddNewRecord(item5);
			}
		}
		SortRecords();
	}

	public bool MatchFilter(UserData friend)
	{
		if (!Friends.Client.HasFriend(friend, EFriendFlags.k_EFriendFlagImmediate))
		{
			return false;
		}
		switch (filter)
		{
		case Filter.All:
			return true;
		case Filter.AnyOffline:
			return friend.State == EPersonaState.k_EPersonaStateOffline;
		case Filter.AnyOnline:
			return friend.State != EPersonaState.k_EPersonaStateOffline;
		case Filter.Away:
			return friend.State == EPersonaState.k_EPersonaStateAway;
		case Filter.Busy:
			return friend.State == EPersonaState.k_EPersonaStateBusy;
		case Filter.InAnyGame:
			return friend.InGame;
		case Filter.InOtherGame:
		{
			if (friend.GetGamePlayed(out var gameInfo2))
			{
				if (!gameInfo2.Game.IsMe)
				{
					return true;
				}
				return false;
			}
			return false;
		}
		case Filter.InThisGame:
		{
			if (friend.GetGamePlayed(out var gameInfo3))
			{
				if (gameInfo3.Game.IsMe)
				{
					return true;
				}
				return false;
			}
			return false;
		}
		case Filter.NotInThisGame:
		{
			if (friend.GetGamePlayed(out var gameInfo))
			{
				if (!gameInfo.Game.IsMe)
				{
					return true;
				}
				return false;
			}
			if (friend.State != EPersonaState.k_EPersonaStateOffline)
			{
				return true;
			}
			return false;
		}
		case Filter.NotInGame:
			return !friend.InGame;
		default:
			return false;
		}
	}
}
