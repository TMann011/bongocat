using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamInventoryItemDataEvents))]
[RequireComponent(typeof(SteamInventoryItemData))]
public class SteamInventoryItemBasePrice : MonoBehaviour
{
	public TextMeshProUGUI label;

	private SteamInventoryItemData _inspector;

	private SteamInventoryItemDataEvents _events;

	private void Awake()
	{
		_inspector = GetComponent<SteamInventoryItemData>();
		_events = GetComponent<SteamInventoryItemDataEvents>();
		_events.onChange?.AddListener(HandleChange);
	}

	private void HandleChange()
	{
		if (label != null)
		{
			label.text = _inspector.Data.BasePriceString();
		}
	}
}
