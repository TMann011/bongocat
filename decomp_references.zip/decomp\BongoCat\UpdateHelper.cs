using Steamworks;
using UnityEngine;

namespace BongoCat;

public class UpdateHelper : MonoBehaviour
{
	public void ForceUpdate()
	{
		SteamApps.MarkContentCorrupt(bMissingFilesOnly: false);
		RestartApplication.RestartGameViaSteam();
	}
}
