using System;
using UnityEngine;

namespace BongoCat;

public class ToggleObjectsWithKey : MonoBehaviour
{
	public static ToggleObjectsWithKey Instance;

	public bool showObjects;

	public event Action<bool> OnToggleWithKey;

	private void Awake()
	{
		Instance = this;
	}

	private void Start()
	{
		showObjects = !SettingsManager.Instance.AutoHideCounter;
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.F2))
		{
			showObjects = !showObjects;
			OnToggleWithKey?.Invoke(showObjects);
		}
	}
}
