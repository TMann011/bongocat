using SteamTools;
using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamLobbyData))]
public class SteamLobbyMaxSlots : MonoBehaviour
{
	public TextMeshProUGUI label;

	private SteamLobbyData _mInspector;

	private void Awake()
	{
		_mInspector = GetComponent<SteamLobbyData>();
		_mInspector.onChanged.AddListener(HandleOnChanged);
		Events.OnLobbyDataUpdate += HandleLobbyDataChange;
		if (_mInspector.Data.IsValid)
		{
			label.text = _mInspector.Data.MaxMembers.ToString();
		}
	}

	private void OnDestroy()
	{
		_mInspector.onChanged.RemoveListener(HandleOnChanged);
		Events.OnLobbyDataUpdate -= HandleLobbyDataChange;
	}

	private void HandleLobbyDataChange(LobbyData lobby, LobbyMemberData? member)
	{
		if (lobby == _mInspector.Data)
		{
			label.text = _mInspector.Data.MaxMembers.ToString();
		}
	}

	private void HandleOnChanged(LobbyData arg0)
	{
		if (_mInspector.Data.IsValid)
		{
			label.text = _mInspector.Data.MaxMembers.ToString();
		}
		else
		{
			label.text = "0";
		}
	}
}
