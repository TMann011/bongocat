namespace Heathen.SteamworksIntegration;

public struct InputActionSetLayerData
{
	public string LayerName;

	public InputActionSetData Data { get; }
}
