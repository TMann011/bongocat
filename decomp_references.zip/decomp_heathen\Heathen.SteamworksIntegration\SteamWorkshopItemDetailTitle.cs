using TMPro;
using UnityEngine;

namespace Heathen.SteamworksIntegration;

[RequireComponent(typeof(SteamWorkshopItemDetailDataEvents))]
[RequireComponent(typeof(SteamWorkshopItemDetailData))]
public class SteamWorkshopItemDetailTitle : MonoBehaviour
{
	public TextMeshProUGUI label;

	private SteamWorkshopItemDetailData _inspector;

	private SteamWorkshopItemDetailDataEvents _events;

	private void Awake()
	{
		_inspector = GetComponent<SteamWorkshopItemDetailData>();
		_events = GetComponent<SteamWorkshopItemDetailDataEvents>();
		_events.onChange.AddListener(HandleChanged);
		HandleChanged();
	}

	private void HandleChanged()
	{
		if ((bool)label)
		{
			label.text = ((_inspector.Data != null) ? _inspector.Data.Title : string.Empty);
		}
	}
}
