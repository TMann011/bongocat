using DG.Tweening;
using UnityEngine;

namespace BongoCat.Tutorial;

public class TutorialHighlight : MonoBehaviour
{
	[SerializeField]
	private Transform _target;

	private Vector3 _baseScale;

	public void OnBegin()
	{
		_baseScale = _target.localScale;
		if (!_target.gameObject.activeSelf)
		{
			_target.gameObject.SetActive(value: true);
			_target.localScale = Vector3.zero;
			_target.DOScale(_baseScale, 0.1f).OnComplete(StartAnimation);
		}
		else
		{
			StartAnimation();
		}
	}

	private void StartAnimation()
	{
		_target.DOScale(_baseScale * 1.1f, 0.5f).SetLoops(-1, LoopType.Yoyo);
	}

	public void OnComplete()
	{
		DOTween.Kill(_target);
		_target.DOScale(_baseScale, 0.2f);
	}
}
