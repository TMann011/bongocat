using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BongoCat.SteamJsonParser;

public class SteamShopBundle : SteamItemBase
{
	public List<SteamItemBasic> ItemsInBundle;

	public Sprite Image;

	public int PurchaseBundleDiscount;

	public bool UsePriceCategory;

	public string PriceCategory;

	public bool FeatureInItemStore;

	public override SteamItemJson ToSteamItemBackend()
	{
		string text = "";
		if (FeatureInItemStore && !string.IsNullOrEmpty(PriceCategory))
		{
			text += "featured";
		}
		string text2 = "";
		string text3 = "";
		foreach (SteamItemBasic item in ItemsInBundle)
		{
			text3 = text3 + item.Id + ";";
			text2 = text2 + "https://pub-d6170922fa31462fa15463d240b18424.r2.dev/" + item.Name.Replace(" ", "") + "Icon.png;";
		}
		text3 = text3.TrimEnd(';');
		text2 = text2.TrimEnd(';');
		string text4 = "Thank you very much for supporting Bongo Cat!\n\n\nThis bundle includes the skins ";
		text4 += string.Join(", ", (from i in ItemsInBundle
			where i.HasTagWithValue("itemslot:skin")
			select $"[url=https://store.steampowered.com/itemstore/{3419430}/detail/{i.Id}/]{i.Name}[/url]").ToArray());
		text4 += ", as well as the hats ";
		text4 += string.Join(", ", (from i in ItemsInBundle
			where i.HasTagWithValue("itemslot:hat")
			select $"[url=https://store.steampowered.com/itemstore/{3419430}/detail/{i.Id}/]{i.Name}[/url]").ToArray());
		text4 += ".\n\nCredits: [url=https://steamcommunity.com/id/neonflores/]Neon Flores[/url]";
		return new SteamItemJson(this)
		{
			type = (string.IsNullOrEmpty(text3) ? "item" : "bundle"),
			bundle = text3,
			description = text4,
			store_tags = text,
			icon_url = "https://pub-d6170922fa31462fa15463d240b18424.r2.dev/" + Name.Replace(" ", "") + ".png",
			icon_url_large = "https://pub-d6170922fa31462fa15463d240b18424.r2.dev/" + Name.Replace(" ", "") + ".png",
			price_category = PriceCategory,
			use_bundle_price = UsePriceCategory,
			store_images = text2,
			purchase_bundle_discount = PurchaseBundleDiscount
		};
	}
}
