using UnityEngine;
using UnityEngine.UI;

namespace BongoCat.PawPass;

public class PawPassItemCosmetic : PawPassItemClass
{
	[SerializeField]
	protected Image _cosmetic;

	public override void FillContent(PawPassMilestone pawPassMilestone)
	{
		FillContent(pawPassMilestone.Items[0]);
	}

	public override void FillContent(PawPassMilestoneItem pawPassMilestoneItem)
	{
		_cosmetic.sprite = pawPassMilestoneItem.FullImage;
	}
}
